const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: './backend/.env' });

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY);

async function checkColumns() {
  const { data, error } = await supabase.from('EXCESOS DE VELOCIDAD').select('*').limit(1);
  if (error) {
    console.error(error);
    return;
  }
  if (data.length > 0) {
    console.log("Tipos de datos detectados:");
    for (const [key, value] of Object.entries(data[0])) {
      console.log(`${key}: ${typeof value} (${value})`);
    }
  }
}
checkColumns();
