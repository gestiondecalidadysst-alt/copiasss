const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: './backend/.env' });

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error("Faltan las credenciales de Supabase");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function checkData() {
  console.log("Consultando tabla 'EXCESOS DE VELOCIDAD'...");
  const { data, error } = await supabase.from('EXCESOS DE VELOCIDAD').select('*').limit(5);
  
  if (error) {
    console.error("Error:", error);
    return;
  }
  
  console.log("Datos encontrados:", data.length);
  if (data.length > 0) {
    console.log("Ejemplo de registro:", JSON.stringify(data[0], null, 2));
    
    const hasLat = 'latitud' in data[0];
    const hasLng = 'longitud' in data[0];
    const hasVel = 'velocidad' in data[0];
    const hasCreatedAt = 'created_at' in data[0];
    
    console.log("Columnas presentes:");
    console.log("- latitud:", hasLat);
    console.log("- longitud:", hasLng);
    console.log("- velocidad:", hasVel);
    console.log("- created_at:", hasCreatedAt);
  } else {
    console.log("La tabla está vacía.");
  }
}

checkData();
