// Tipos y constantes para notificaciones de velocidad

export type SpeedLevel = 'baja' | 'media' | 'alta' | 'crítica';

export interface SpeedNotification {
  id: string;
  placa: string;
  velocidad: number;
  ruta?: string;
  level: SpeedLevel;
  timestamp: Date;
  message: string;
}

// Configuración de niveles de velocidad
export const SPEED_THRESHOLDS = {
  baja: { min: 0, max: 80, label: 'Baja', color: 'green', icon: '🟢' },
  media: { min: 81, max: 100, label: 'Media', color: 'yellow', icon: '🟡' },
  alta: { min: 101, max: 150, label: 'Alta', color: 'orange', icon: '🟠' },
  crítica: { min: 151, max: Infinity, label: 'Crítica', color: 'red', icon: '🔴' },
} as const;

// Obtener el nivel según la velocidad
export const getSpeedLevel = (velocidad: number): SpeedLevel => {
  if (velocidad <= 80) return 'baja';
  if (velocidad <= 100) return 'media';
  if (velocidad <= 150) return 'alta';
  return 'crítica';
};

// Obtener configuración del nivel
export const getSpeedConfig = (level: SpeedLevel) => {
  return SPEED_THRESHOLDS[level];
};

// Generar mensaje según el nivel
export const getSpeedMessage = (velocidad: number, placa: string, level: SpeedLevel): string => {
  const config = getSpeedConfig(level);
  
  switch (level) {
    case 'baja':
      return `Velocidad normal: ${placa} a ${velocidad} km/h`;
    case 'media':
      return `⚠️ Velocidad media: ${placa} a ${velocidad} km/h`;
    case 'alta':
      return `🚨 Exceso de velocidad: ${placa} a ${velocidad} km/h`;
    case 'crítica':
      return `🚨🚨 ¡ALERTA CRÍTICA! ${placa} a ${velocidad} km/h`;
    default:
      return `Evento de velocidad: ${placa} a ${velocidad} km/h`;
  }
};
