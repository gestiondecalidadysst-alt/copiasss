import { useState, useCallback, useEffect } from 'react';
import { SpeedNotification, SpeedLevel, getSpeedLevel, getSpeedMessage } from '@/types/notifications';

const MAX_NOTIFICATIONS = 5; // Máximo de notificaciones simultáneas
const NOTIFICATION_DURATION = 5000; // 5 segundos por defecto

export const useSpeedNotification = () => {
  const [notifications, setNotifications] = useState<SpeedNotification[]>([]);

  // Agregar una notificación
  const addNotification = useCallback(
    (placa: string, velocidad: number, ruta?: string) => {
      const level = getSpeedLevel(velocidad);
      const id = `${placa}-${Date.now()}-${Math.random()}`;
      
      const notification: SpeedNotification = {
        id,
        placa,
        velocidad,
        ruta,
        level,
        timestamp: new Date(),
        message: getSpeedMessage(velocidad, placa, level),
      };

      setNotifications((prev) => {
        // Limitar el número de notificaciones
        const updated = [...prev, notification];
        if (updated.length > MAX_NOTIFICATIONS) {
          return updated.slice(updated.length - MAX_NOTIFICATIONS);
        }
        return updated;
      });

      // Auto-remover notificación después del tiempo especificado
      // Las críticas duran más
      const duration = level === 'crítica' ? 8000 : NOTIFICATION_DURATION;
      
      setTimeout(() => {
        removeNotification(id);
      }, duration);

      return id;
    },
    []
  );

  // Remover una notificación
  const removeNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((notif) => notif.id !== id));
  }, []);

  // Limpiar todas las notificaciones
  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  return {
    notifications,
    addNotification,
    removeNotification,
    clearAll,
  };
};

// Hook para capturar eventos y convertirlos en notificaciones
export const useSpeedEventListener = (onNewEvent?: (evento: any) => void) => {
  useEffect(() => {
    // Este hook puede ser extendido para escuchar eventos en tiempo real
    // Por ahora, es un placeholder para futura integración con WebSockets
    
    return () => {
      // Cleanup
    };
  }, [onNewEvent]);
};
