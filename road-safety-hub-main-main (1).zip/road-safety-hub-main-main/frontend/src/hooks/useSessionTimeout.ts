import { useEffect, useRef } from 'react';
import { useAuthStore } from '@/stores/authStore';
import { toast } from '@/hooks/use-toast';

const TIMEOUT_MS = 20 * 60 * 1000;  // 20 minutos de inactividad
const WARNING_MS = 2 * 60 * 1000;   // aviso 2 minutos antes de expirar
export const ACTIVITY_KEY = 'lastActivity';

const WATCHED_EVENTS = [
  'mousemove',
  'mousedown',
  'keydown',
  'touchstart',
  'scroll',
  'click',
] as const;

/**
 * Cierra la sesión automáticamente tras 20 minutos sin interacción del usuario.
 * Muestra un aviso 2 minutos antes de cerrar.
 * También detecta sesiones expiradas tras recargar la página.
 */
export function useSessionTimeout() {
  const logoutFn = useAuthStore((s) => s.logout);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const warningRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Ref para leer el estado actual desde dentro de los event listeners
  // sin capturar valores obsoletos en el closure.
  const isAuthRef = useRef(isAuthenticated);
  isAuthRef.current = isAuthenticated;

  useEffect(() => {
    const clearTimers = () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      if (warningRef.current) clearTimeout(warningRef.current);
      timeoutRef.current = null;
      warningRef.current = null;
    };

    const doLogout = () => {
      clearTimers();
      localStorage.removeItem(ACTIVITY_KEY);
      logoutFn();
      window.location.href = '/login';
    };

    const resetTimer = () => {
      if (!isAuthRef.current) return;

      // Actualizar marca de tiempo de última actividad
      localStorage.setItem(ACTIVITY_KEY, Date.now().toString());
      clearTimers();

      // Aviso 2 minutos antes de la expiración
      warningRef.current = setTimeout(() => {
        toast({
          title: 'Sesión a punto de expirar',
          description:
            'Su sesión se cerrará en 2 minutos por inactividad. Interactúe con la página para continuar.',
          variant: 'destructive',
        });
      }, TIMEOUT_MS - WARNING_MS);

      // Cerrar sesión al cumplirse el tiempo
      timeoutRef.current = setTimeout(doLogout, TIMEOUT_MS);
    };

    if (!isAuthenticated) {
      clearTimers();
      return;
    }

    // Comprobar si la sesión ya expiró antes del último refresco de página
    const lastActivity = localStorage.getItem(ACTIVITY_KEY);
    if (lastActivity) {
      const elapsed = Date.now() - parseInt(lastActivity, 10);
      if (elapsed >= TIMEOUT_MS) {
        doLogout();
        return;
      }
    }

    // Registrar listeners de actividad
    WATCHED_EVENTS.forEach((e) =>
      window.addEventListener(e, resetTimer, { passive: true }),
    );

    // Arrancar el contador desde ya
    resetTimer();

    return () => {
      clearTimers();
      WATCHED_EVENTS.forEach((e) => window.removeEventListener(e, resetTimer));
    };
    // Solo volver a ejecutar cuando cambie el estado de autenticación
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, logoutFn]);
}
