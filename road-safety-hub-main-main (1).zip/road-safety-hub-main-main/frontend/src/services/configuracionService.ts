import api from './api';
import type { CertificateDesign, CertificateFieldConfig } from '@/stores/appStore';

export interface CertificadoConfigPayload {
  design: CertificateDesign;
  fields: CertificateFieldConfig[];
}

/** Convierte el diseño del store al formato de columnas de la BD */
function designToDb(design: CertificateDesign, fields: CertificateFieldConfig[]) {
  return {
    titulo:            design.certificateTitle,
    certify_text:      design.certifyText,
    course_intro:      design.courseIntroText,
    firma_nombre:      design.signatureName,
    firma_titulo:      design.signatureTitle,
    footer_text:       design.footerText,
    numero_prefix:     design.numberPrefix,
    show_numero:       design.showCertNumber,
    color_fondo:       design.backgroundColor,
    color_borde:       design.borderColor,
    color_titulo:      design.titleColor,
    color_nombre:      design.nameColor,
    color_texto:       design.textColor,
    color_acento:      design.accentColor,
    show_logo_sistema: design.showSystemLogo,
    font_family:       design.fontFamily,
    title_font_size:   design.titleFontSize,
    name_font_size:    design.nameFontSize,
    body_font_size:    design.bodyFontSize,
    course_font_size:  design.courseFontSize,
    logo_height:       design.logoHeight,
    footer_logo_height: design.footerLogoHeight,
    campos_activos:    fields.filter((f) => f.enabled).map((f) => f.key),
    etiquetas_campos:  Object.fromEntries(fields.map((f) => [f.key, f.label])),
  };
}

/** Guarda la configuración del diploma en el backend */
export async function saveCertificadoConfigBackend(
  design: CertificateDesign,
  fields: CertificateFieldConfig[],
): Promise<void> {
  await api.put('/configuracion/certificado', designToDb(design, fields));
}

/** Carga la configuración del diploma desde el backend */
export async function loadCertificadoConfigBackend(): Promise<CertificadoConfigPayload | null> {
  try {
    const { data } = await api.get('/configuracion/certificado');
    if (!data) return null;
    const design: Partial<CertificateDesign> = {
      certificateTitle: data.titulo,
      certifyText:      data.certify_text,
      courseIntroText:  data.course_intro,
      signatureName:    data.firma_nombre,
      signatureTitle:   data.firma_titulo ?? '',
      footerText:       data.footer_text ?? '',
      numberPrefix:     data.numero_prefix,
      showCertNumber:   data.show_numero,
      backgroundColor:  data.color_fondo,
      borderColor:      data.color_borde,
      titleColor:       data.color_titulo,
      nameColor:        data.color_nombre,
      textColor:        data.color_texto,
      accentColor:      data.color_acento,
      showSystemLogo:   data.show_logo_sistema,
      ...(data.font_family       && { fontFamily:        data.font_family }),
      ...(data.title_font_size   && { titleFontSize:     data.title_font_size }),
      ...(data.name_font_size    && { nameFontSize:      data.name_font_size }),
      ...(data.body_font_size    && { bodyFontSize:      data.body_font_size }),
      ...(data.course_font_size  && { courseFontSize:    data.course_font_size }),
      ...(data.logo_height       && { logoHeight:        data.logo_height }),
      ...(data.footer_logo_height && { footerLogoHeight: data.footer_logo_height }),
    };
    const labels: Record<string, string> = data.etiquetas_campos ?? {};
    const activos: string[] = data.campos_activos ?? [];
    const fields: CertificateFieldConfig[] = (['nombre', 'apellido', 'documento', 'fecha', 'calificacion'] as const).map((key) => ({
      key,
      label:   labels[key] ?? key,
      enabled: activos.includes(key),
    }));
    return { design: design as CertificateDesign, fields };
  } catch {
    return null;
  }
}
