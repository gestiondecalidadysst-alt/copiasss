import api from './api';
import { User } from '../stores/authStore';

interface CrearUsuarioRequest {
  email: string;
  nombre: string;
  empresa?: string;
  password: string;
  rol?: 'admin' | 'usuario';
}

interface UsuarioResponse extends User {
  activo: boolean;
  created_at: string;
}

export const usuariosService = {
  /**
   * Obtener todos los usuarios (solo admin)
   */
  getAll: async () => {
    const response = await api.get<{
      total: number;
      usuarios: UsuarioResponse[];
    }>('/usuarios');
    return response.data;
  },

  /**
   * Obtener usuario por ID
   */
  getById: async (id: string) => {
    const response = await api.get<UsuarioResponse>(`/usuarios/${id}`);
    return response.data;
  },

  /**
   * Crear nuevo usuario (solo admin)
   */
  crear: async (data: CrearUsuarioRequest) => {
    const response = await api.post<{
      message: string;
      usuario: User;
    }>('/usuarios', data);
    return response.data;
  },

  /**
   * Actualizar usuario (solo admin)
   */
  actualizar: async (id: string, data: {
    nombre?: string;
    empresa?: string;
    activo?: boolean;
  }) => {
    const response = await api.put<{
      message: string;
      usuario: UsuarioResponse;
    }>(`/usuarios/${id}`, data);
    return response.data;
  },

  /**
   * Eliminar usuario (solo admin)
   */
  eliminar: async (id: string) => {
    const response = await api.delete<{
      message: string;
    }>(`/usuarios/${id}`);
    return response.data;
  },

  /**
   * Asignar rol a usuario (solo admin)
   */
  asignarRol: async (id: string, rol: 'admin' | 'usuario') => {
    const response = await api.post<{
      message: string;
    }>(`/usuarios/${id}/roles`, { rol });
    return response.data;
  },

  /**
   * Remover rol de usuario (solo admin)
   */
  removerRol: async (id: string, rol: 'admin' | 'usuario') => {
    const response = await api.delete<{
      message: string;
    }>(`/usuarios/${id}/roles`, { data: { rol } });
    return response.data;
  },

  /**
   * Activar/Desactivar usuario (solo admin)
   */
  toggleActivo: async (id: string) => {
    const response = await api.patch<{
      message: string;
      usuario: UsuarioResponse;
    }>(`/usuarios/${id}/toggle-activo`, {});
    return response.data;
  }
};
