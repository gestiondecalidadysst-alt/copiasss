import api from './api';

export const conductoresService = {
  getAll: () => api.get('/conductores'),
  getById: (id: string) => api.get(`/conductores/${id}`),
  create: (data: any) => api.post('/conductores', data),
  update: (id: string, data: any) => api.put(`/conductores/${id}`, data),
  delete: (id: string) => api.delete(`/conductores/${id}`),
};
