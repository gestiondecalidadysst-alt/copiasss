import api from './api';

export const vehiculosService = {
  getAll: () => api.get('/vehiculos'),
  getById: (id: string) => api.get(`/vehiculos/${id}`),
  create: (data: any) => api.post('/vehiculos', data),
  update: (id: string, data: any) => api.put(`/vehiculos/${id}`, data),
  delete: (id: string) => api.delete(`/vehiculos/${id}`),
};
