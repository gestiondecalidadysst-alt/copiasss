import api from './api';
import { User } from '../stores/authStore';

interface LoginResponse {
  token: string;
  usuario: User;
}

export const authService = {
  /**
   * Login con credenciales
   */
  login: async (email: string, password: string): Promise<LoginResponse> => {
    const response = await api.post<LoginResponse>('/auth/login', { email, password });
    return response.data;
  },

  /**
   * Logout
   */
  logout: async () => {
    return api.post('/auth/logout');
  },

  /**
   * Obtener perfil del usuario autenticado
   */
  getMe: async (): Promise<User> => {
    const response = await api.get<User>('/auth/me');
    return response.data;
  },

  /**
   * Registrar nuevo usuario
   */
  registrar: async (email: string, nombre: string, empresa: string, password: string) => {
    const response = await api.post('/auth/registrar', {
      email,
      nombre,
      empresa,
      password
    });
    return response.data;
  },

  /**
   * Cambiar contraseña
   */
  cambiarPassword: async (passwordAntigua: string, passwordNueva: string) => {
    const response = await api.post('/auth/cambiar-password', {
      passwordAntigua,
      passwordNueva
    });
    return response.data;
  },

  /**
   * Actualizar perfil del usuario autenticado
   */
  actualizarPerfil: async (nombre: string, empresa: string) => {
    const response = await api.put('/auth/perfil', { nombre, empresa });
    return response.data;
  },

  /**
   * Verificar si el token es válido
   */
  verificarToken: async () => {
    const response = await api.get('/auth/verificar-token');
    return response.data;
  }
};
