import api from './api';

export const eventosService = {
  getAll: (params?: any) => api.get('/eventos', { params }),
  getById: (id: string) => api.get(`/eventos/${id}`),
  getStats: () => api.get('/eventos/stats'),
};
