﻿import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import type { CertificateConfig, CertificateDesign } from '@/stores/appStore';
import { DEFAULT_CERTIFICATE_DESIGN } from '@/stores/appStore';
import {
  loadPdfTemplate,
  loadSignatureImage,
  loadFooterLogos,
} from '@/utils/certificateTemplateStorage';

export interface CertificateData {
  nombre: string;
  apellido: string;
  documento: string;
  fecha: string;
  calificacion: string;
  tituloCurso: string;
  numeroCertificado?: string;
}

// Convierte hex #RRGGBB a [r,g,b] escala 0-1
function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  const r = parseInt(clean.substring(0, 2), 16) / 255;
  const g = parseInt(clean.substring(2, 4), 16) / 255;
  const b = parseInt(clean.substring(4, 6), 16) / 255;
  return [isNaN(r) ? 0 : r, isNaN(g) ? 0 : g, isNaN(b) ? 0 : b];
}

// Incrusta una imagen PNG o JPG en el PDF de forma segura
async function embedImg(pdfDoc: PDFDocument, src: string) {
  try {
    const b64 = src.includes(',') ? src.split(',')[1] : src;
    const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
    return src.includes('data:image/png') || src.includes('.png')
      ? await pdfDoc.embedPng(bytes)
      : await pdfDoc.embedJpg(bytes);
  } catch { return null; }
}

// Mapa de fuentes pdf-lib por familia
const FMAP = {
  helvetica: { bold: StandardFonts.HelveticaBold, reg: StandardFonts.Helvetica },
  times:     { bold: StandardFonts.TimesBold,     reg: StandardFonts.TimesRoman },
  courier:   { bold: StandardFonts.CourierBold,   reg: StandardFonts.Courier },
} as const;

/**
 * Genera y descarga un certificado PDF.
 * Si hay plantilla PDF en IndexedDB la usa como fondo y superpone datos.
 * Si no hay plantilla genera un diploma completo con el diseÃ±o configurado.
 */
export async function generarCertificado(
  data: CertificateData,
  config: CertificateConfig,
  companyName: string,
  companyLogo: string | null,
): Promise<void> {
  const stored = await loadPdfTemplate();
  const design: CertificateDesign = { ...DEFAULT_CERTIFICATE_DESIGN, ...(config.design ?? {}) };

  const pdfDoc = stored?.base64
    ? await buildFromTemplate(data, config, design, companyName, stored.base64)
    : await buildDefault(data, config, design, companyName, companyLogo);

  const pdfBytes = await pdfDoc.save();
  const blob = new Blob([pdfBytes], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `Certificado_${data.nombre}_${data.apellido}.pdf`.replace(/\s+/g, '_');
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}

// â”€â”€â”€ Con plantilla PDF de fondo â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// ─── Con plantilla PDF de fondo ─────────────────────────────────────────
async function buildFromTemplate(
  data: CertificateData,
  config: CertificateConfig,
  design: CertificateDesign,
  companyName: string,
  templateBase64: string,
): Promise<PDFDocument> {
  const b64 = templateBase64.includes(',') ? templateBase64.split(',')[1] : templateBase64;
  const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
  const pdfDoc = await PDFDocument.load(bytes);

  const fontKey = (design.fontFamily ?? 'helvetica') as keyof typeof FMAP;
  const fontBold = await pdfDoc.embedFont(FMAP[fontKey].bold);
  const fontReg  = await pdfDoc.embedFont(FMAP[fontKey].reg);
  const page = pdfDoc.getPages()[0];
  const { width, height } = page.getSize();
  const [nr, ng, nb] = hexToRgb(design.nameColor);
  const [tr, tg, tb] = hexToRgb(design.textColor);
  const [ar, ag, ab] = hexToRgb(design.accentColor);

  const activeFields = config.fields.filter((f) => f.enabled);
  const startY = height * 0.45;
  const lineH = 28;

  activeFields.forEach((field, idx) => {
    const value = resolveValue(field.key, data);
    const label = `${field.label}: `;
    const y = startY - idx * lineH;
    const lw = fontBold.widthOfTextAtSize(label, 11);
    page.drawText(label, {
      x: width / 2 - (lw + fontReg.widthOfTextAtSize(value, 13)) / 2,
      y, size: 11, font: fontBold, color: rgb(tr, tg, tb),
    });
    page.drawText(value, {
      x: width / 2 - (lw + fontReg.widthOfTextAtSize(value, 13)) / 2 + lw,
      y, size: 13, font: fontReg, color: rgb(nr, ng, nb),
    });
  });

  if (design.showCertNumber && data.numeroCertificado) {
    const certN = `${design.numberPrefix}${data.numeroCertificado.toString().padStart(6, '0')}`;
    page.drawText(certN, {
      x: width / 2 - fontReg.widthOfTextAtSize(certN, 8) / 2,
      y: 36, size: 8, font: fontReg, color: rgb(tr, tg, tb),
    });
  }
  page.drawText(companyName, {
    x: width / 2 - fontBold.widthOfTextAtSize(companyName, 8) / 2,
    y: 26, size: 8, font: fontBold, color: rgb(ar, ag, ab),
  });
  return pdfDoc;
}

// Divide un texto en líneas que caben dentro de maxWidth
function wrapText(
  text: string,
  font: { widthOfTextAtSize: (t: string, s: number) => number },
  size: number,
  maxWidth: number,
): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let current = '';
  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (font.widthOfTextAtSize(candidate, size) <= maxWidth) {
      current = candidate;
    } else {
      if (current) lines.push(current);
      current = word;
    }
  }
  if (current) lines.push(current);
  return lines.length > 0 ? lines : [text];
}

// ─── Diploma completo generado sin plantilla ─────────────────────────────
async function buildDefault(
  data: CertificateData,
  config: CertificateConfig,
  design: CertificateDesign,
  companyName: string,
  companyLogo: string | null,
): Promise<PDFDocument> {
  const pdfDoc = await PDFDocument.create();
  // Carta apaisada: 11" × 8.5" × 72 pt/in
  const W = 792, H = 612;
  const page = pdfDoc.addPage([W, H]);

  // Fuentes
  const fontKey = (design.fontFamily ?? 'helvetica') as keyof typeof FMAP;
  const fontBold = await pdfDoc.embedFont(FMAP[fontKey].bold);
  const fontReg  = await pdfDoc.embedFont(FMAP[fontKey].reg);

  // Tamaños configurables
  const tSize  = design.titleFontSize  ?? 22;
  const nSize  = design.nameFontSize   ?? 24;
  const bSize  = design.bodyFontSize   ?? 12;
  const csSize = design.courseFontSize ?? 14;
  const LOGO_H_VAL     = design.logoHeight        ?? 62;
  const FLOGO_H_VAL    = design.footerLogoHeight  ?? 32;
  const CONTENT_W      = W - 84; // ancho útil para wrap

  // Colores
  const [bgR, bgG, bgB] = hexToRgb(design.backgroundColor);
  const [boR, boG, boB] = hexToRgb(design.borderColor);
  const [tiR, tiG, tiB] = hexToRgb(design.titleColor);
  const [naR, naG, naB] = hexToRgb(design.nameColor);
  const [teR, teG, teB] = hexToRgb(design.textColor);
  const [acR, acG, acB] = hexToRgb(design.accentColor);

  // Fondo
  page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: rgb(bgR, bgG, bgB) });

  // Bordes dobles
  const m1 = 16, m2 = 26;
  page.drawRectangle({ x: m1, y: m1, width: W - m1 * 2, height: H - m1 * 2,
    borderColor: rgb(boR, boG, boB), borderWidth: 3, color: rgb(bgR, bgG, bgB) });
  page.drawRectangle({ x: m2, y: m2, width: W - m2 * 2, height: H - m2 * 2,
    borderColor: rgb(boR, boG, boB), borderWidth: 1, color: rgb(bgR, bgG, bgB) });

  const LEFT = 42;
  const RIGHT = W - 42;

  // ── Logo superior izquierdo ──
  let logoBottomY = H - 38;
  const primarySrc = (design.showSystemLogo && companyLogo) ? companyLogo : (design.certLogoBase64 ?? null);

  if (primarySrc) {
    const img = await embedImg(pdfDoc, primarySrc);
    if (img) {
      const logoW = Math.min(img.width * (LOGO_H_VAL / img.height), 220);
      page.drawImage(img, { x: LEFT, y: H - 38 - LOGO_H_VAL, width: logoW, height: LOGO_H_VAL });
      logoBottomY = H - 38 - LOGO_H_VAL;

      // Segundo logo (sistema + diploma) a la derecha del primero
      if (design.showSystemLogo && companyLogo && design.certLogoBase64) {
        const img2 = await embedImg(pdfDoc, design.certLogoBase64);
        if (img2) {
          const h2 = Math.round(LOGO_H_VAL * 0.75);
          const w2 = Math.min(img2.width * (h2 / img2.height), 160);
          page.drawImage(img2, { x: LEFT + logoW + 10, y: H - 34 - h2, width: w2, height: h2 });
        }
      }
    }
  }

  // Nombre empresa debajo del logo
  const compText = companyName.toUpperCase();
  page.drawText(compText, {
    x: LEFT, y: logoBottomY - 14, size: 9, font: fontBold, color: rgb(acR, acG, acB),
  });

  // ── Número de certificado (superior derecho) ──
  if (design.showCertNumber && data.numeroCertificado) {
    const certN = `${design.numberPrefix}${data.numeroCertificado.toString().padStart(6, '0')}`;
    const cw = fontReg.widthOfTextAtSize(certN, 9);
    page.drawText(certN, { x: RIGHT - cw, y: H - 42, size: 9, font: fontReg, color: rgb(teR, teG, teB) });
  }

  // ── Título ──
  const titulo = design.certificateTitle;
  const titleLines = wrapText(titulo, fontBold, tSize, CONTENT_W);
  const titleBlockH = titleLines.length * (tSize + 4);
  const titleY = H - 118;
  page.drawLine({ start: { x: m2 + 8, y: titleY + tSize + 8 }, end: { x: W - m2 - 8, y: titleY + tSize + 8 }, thickness: 1.5, color: rgb(acR, acG, acB) });
  titleLines.forEach((line, li) => {
    const lw = fontBold.widthOfTextAtSize(line, tSize);
    page.drawText(line, { x: W / 2 - lw / 2, y: titleY - li * (tSize + 4), size: tSize, font: fontBold, color: rgb(tiR, tiG, tiB) });
  });
  page.drawLine({ start: { x: m2 + 8, y: titleY - titleBlockH + tSize - 6 }, end: { x: W - m2 - 8, y: titleY - titleBlockH + tSize - 6 }, thickness: 1.5, color: rgb(acR, acG, acB) });

  // ── Cuerpo ──
  let curY = titleY - titleBlockH - 20;

  const certifyT = design.certifyText;
  const certifyLines = wrapText(certifyT, fontReg, bSize, CONTENT_W);
  certifyLines.forEach((line, li) => {
    page.drawText(line, { x: W / 2 - fontReg.widthOfTextAtSize(line, bSize) / 2, y: curY - li * (bSize + 3), size: bSize, font: fontReg, color: rgb(teR, teG, teB) });
  });
  curY -= certifyLines.length * (bSize + 3) + 10;

  const nombreCompleto = `${data.nombre} ${data.apellido}`.trim();
  const nombreLines = wrapText(nombreCompleto, fontBold, nSize, CONTENT_W);
  nombreLines.forEach((line, li) => {
    page.drawText(line, { x: W / 2 - fontBold.widthOfTextAtSize(line, nSize) / 2, y: curY - li * (nSize + 4), size: nSize, font: fontBold, color: rgb(naR, naG, naB) });
  });
  const nW = fontBold.widthOfTextAtSize(nombreLines[0], nSize);
  const nombreBlockH = nombreLines.length * (nSize + 4);
  curY -= nombreBlockH;
  page.drawLine({ start: { x: W / 2 - nW / 2, y: curY }, end: { x: W / 2 + nW / 2, y: curY }, thickness: 1, color: rgb(naR, naG, naB) });
  curY -= bSize + 8;

  // ── Documento debajo del nombre ──
  const docField = config.fields.find((f) => f.enabled && f.key === 'documento');
  if (docField) {
    const docLabel = `${docField.label}: `;
    const docValue = data.documento;
    const dlw = fontReg.widthOfTextAtSize(docLabel, bSize);
    const dvw = fontBold.widthOfTextAtSize(docValue, bSize + 1);
    page.drawText(docLabel, { x: W / 2 - (dlw + dvw) / 2, y: curY, size: bSize, font: fontReg, color: rgb(teR, teG, teB) });
    page.drawText(docValue, { x: W / 2 - (dlw + dvw) / 2 + dlw, y: curY, size: bSize + 1, font: fontBold, color: rgb(tiR, tiG, tiB) });
    curY -= bSize + 20;
  }

  // ── "Ha completado satisfactoriamente..." (más abajo) ──
  const introT = design.courseIntroText;
  const introLines = wrapText(introT, fontReg, bSize - 1, CONTENT_W);
  introLines.forEach((line, li) => {
    page.drawText(line, { x: W / 2 - fontReg.widthOfTextAtSize(line, bSize - 1) / 2, y: curY - li * (bSize + 2), size: bSize - 1, font: fontReg, color: rgb(teR, teG, teB) });
  });
  curY -= introLines.length * (bSize + 2) + 8;

  // ── Título del curso (más abajo) ──
  const cursoNombre = `"${data.tituloCurso}"`;
  const cursoLines = wrapText(cursoNombre, fontBold, csSize, CONTENT_W);
  cursoLines.forEach((line, li) => {
    page.drawText(line, { x: W / 2 - fontBold.widthOfTextAtSize(line, csSize) / 2, y: curY - li * (csSize + 4), size: csSize, font: fontBold, color: rgb(tiR, tiG, tiB) });
  });
  curY -= cursoLines.length * (csSize + 4) + 8;

  // ── Calificación debajo del título del curso ──
  const calField = config.fields.find((f) => f.enabled && f.key === 'calificacion');
  if (calField) {
    const calLabel = `${calField.label}: `;
    const calValue = data.calificacion;
    const clw = fontReg.widthOfTextAtSize(calLabel, bSize);
    const cvw = fontBold.widthOfTextAtSize(calValue, bSize + 1);
    page.drawText(calLabel, { x: W / 2 - (clw + cvw) / 2, y: curY, size: bSize, font: fontReg, color: rgb(teR, teG, teB) });
    page.drawText(calValue, { x: W / 2 - (clw + cvw) / 2 + clw, y: curY, size: bSize + 1, font: fontBold, color: rgb(tiR, tiG, tiB) });
    curY -= bSize + 24;
  }

  // ── Fecha más abajo ──
  const fechaField = config.fields.find((f) => f.enabled && f.key === 'fecha');
  if (fechaField) {
    const fechaLabel = `${fechaField.label}: `;
    const fechaValue = data.fecha;
    const flw = fontReg.widthOfTextAtSize(fechaLabel, bSize);
    const fvw = fontReg.widthOfTextAtSize(fechaValue, bSize);
    page.drawText(fechaLabel, { x: W / 2 - (flw + fvw) / 2, y: curY, size: bSize, font: fontReg, color: rgb(teR, teG, teB) });
    page.drawText(fechaValue, { x: W / 2 - (flw + fvw) / 2 + flw, y: curY, size: bSize, font: fontReg, color: rgb(tiR, tiG, tiB) });
  }

  // ── Pie: firma (derecha) + logos pie (izquierda) ──
  const [sigStored, footerLogos] = await Promise.all([loadSignatureImage(), loadFooterLogos()]);
  const FOOT_BASE = 88;
  const SIG_CENTER = W - 160;

  // Imagen de firma
  if (sigStored) {
    const sigImg = await embedImg(pdfDoc, sigStored.base64);
    if (sigImg) {
      const sh = 44, sw = Math.min(sigImg.width * (sh / sigImg.height), 160);
      page.drawImage(sigImg, { x: SIG_CENTER - sw / 2, y: FOOT_BASE + 2, width: sw, height: sh });
    }
  }

  // Línea y nombre del firmante
  page.drawLine({ start: { x: SIG_CENTER - 90, y: FOOT_BASE }, end: { x: SIG_CENTER + 90, y: FOOT_BASE }, thickness: 1, color: rgb(teR, teG, teB) });
  page.drawText(design.signatureName, { x: SIG_CENTER - fontReg.widthOfTextAtSize(design.signatureName, 9) / 2, y: FOOT_BASE - 13, size: 9, font: fontReg, color: rgb(teR, teG, teB) });
  const sigTitle = design.signatureTitle || companyName;
  page.drawText(sigTitle, { x: SIG_CENTER - fontBold.widthOfTextAtSize(sigTitle, 9) / 2, y: FOOT_BASE - 25, size: 9, font: fontBold, color: rgb(acR, acG, acB) });

  // Logos pie de página (izquierda, hasta 3)
  let flX = LEFT;
  for (const ld of footerLogos) {
    if (!ld) continue;
    const fi = await embedImg(pdfDoc, ld.base64);
    if (!fi) continue;
    const fw = Math.min(fi.width * (FLOGO_H_VAL / fi.height), 120);
    page.drawImage(fi, { x: flX, y: FOOT_BASE - FLOGO_H_VAL / 2 - 4, width: fw, height: FLOGO_H_VAL });
    flX += fw + 8;
  }

  // Texto pie de página (centrado)
  if (design.footerText) {
    page.drawText(design.footerText, {
      x: W / 2 - fontReg.widthOfTextAtSize(design.footerText, 7) / 2,
      y: m2 + 4, size: 7, font: fontReg, color: rgb(teR, teG, teB),
    });
  }

  return pdfDoc;
}

function resolveValue(key: string, data: CertificateData): string {
  const map: Record<string, string> = {
    nombre:       data.nombre,
    apellido:     data.apellido,
    documento:    data.documento,
    fecha:        data.fecha,
    calificacion: data.calificacion,
  };
  return map[key] ?? '';
}
