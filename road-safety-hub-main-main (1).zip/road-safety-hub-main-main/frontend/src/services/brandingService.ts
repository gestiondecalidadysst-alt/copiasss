import api from './api';

export interface BrandingPayload {
  company_name: string;
  company_logo: string | null;
}

/** Guarda el branding de la empresa en el backend */
export async function saveBrandingBackend(payload: BrandingPayload): Promise<void> {
  await api.put('/configuracion/branding', payload);
}

/** Carga el branding de la empresa desde el backend */
export async function loadBrandingBackend(): Promise<BrandingPayload | null> {
  try {
    const { data } = await api.get('/configuracion/branding');
    if (!data) return null;
    return {
      company_name: data.company_name ?? null,
      company_logo: data.company_logo ?? null,
    };
  } catch {
    return null;
  }
}
