/**
 * Almacena y recupera la plantilla PDF del certificado fuera de Zustand
 * para evitar el QuotaExceededError de localStorage.
 * Usa IndexedDB como almacén principal (sin límite práctico) y solo
 * guarda el nombre del archivo en localStorage como referencia.
 */

const DB_NAME = 'riskvial-cert';
const STORE_NAME = 'templates';
const KEY = 'cert-pdf-template';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore(STORE_NAME);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

/** Guarda el PDF (base64) en IndexedDB. Lanza error si falla. */
export async function savePdfTemplate(base64: string, name: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put({ base64, name }, KEY);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

/** Recupera el PDF almacenado. Devuelve null si no hay ninguno. */
export async function loadPdfTemplate(): Promise<{ base64: string; name: string } | null> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const req = tx.objectStore(STORE_NAME).get(KEY);
      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

/** Elimina la plantilla almacenada. */
export async function deletePdfTemplate(): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // silenciar errores al borrar
  }
}

// ─── Imagen de firma ──────────────────────────────────────────────────────
const KEY_SIGNATURE = 'cert-signature';

export async function saveSignatureImage(base64: string, name: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put({ base64, name }, KEY_SIGNATURE);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function loadSignatureImage(): Promise<{ base64: string; name: string } | null> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const req = tx.objectStore(STORE_NAME).get(KEY_SIGNATURE);
      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => reject(req.error);
    });
  } catch { return null; }
}

export async function deleteSignatureImage(): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(KEY_SIGNATURE);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch { /* silent */ }
}

// ─── Logos pie de página (hasta 3) ───────────────────────────────────────
const footerKey = (i: number) => `cert-footer-${i}`;

export async function saveFooterLogo(idx: number, base64: string, name: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put({ base64, name }, footerKey(idx));
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function loadFooterLogos(): Promise<Array<{ base64: string; name: string } | null>> {
  try {
    const db = await openDB();
    const results = await Promise.all(
      [0, 1, 2].map((i) =>
        new Promise<{ base64: string; name: string } | null>((resolve, reject) => {
          const tx = db.transaction(STORE_NAME, 'readonly');
          const req = tx.objectStore(STORE_NAME).get(footerKey(i));
          req.onsuccess = () => resolve(req.result ?? null);
          req.onerror = () => reject(req.error);
        }),
      ),
    );
    return results;
  } catch { return [null, null, null]; }
}

export async function deleteFooterLogo(idx: number): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(footerKey(idx));
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch { /* silent */ }
}
