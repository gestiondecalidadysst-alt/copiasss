import { create } from 'zustand';
import { authService } from '../services/authService';
import { ACTIVITY_KEY } from '../hooks/useSessionTimeout';

export interface User {
  id: string;
  email: string;
  nombre: string;
  rol: string;
  roles?: string[];
  empresa?: string;
  conductor_id?: string | null;
}

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  setUser: (user: User) => void;
  clearError: () => void;
  loadUserFromToken: () => Promise<void>;
}

/** Decodifica la payload de un JWT sin verificar la firma (solo lectura del cliente). */
function decodeJwtPayload(token: string): { exp?: number } | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
    return payload as { exp?: number };
  } catch {
    return null;
  }
}

/** Devuelve true si el token existe y no ha expirado. */
function isTokenValid(token: string | null): boolean {
  if (!token) return false;
  const payload = decodeJwtPayload(token);
  if (!payload?.exp) return false;
  // exp está en segundos
  return payload.exp * 1000 > Date.now();
}

const storedToken = localStorage.getItem('token');
const tokenIsValid = isTokenValid(storedToken);
// Limpiar inmediatamente si el token guardado ya expiró
if (storedToken && !tokenIsValid) {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  localStorage.removeItem(ACTIVITY_KEY);
}

export const useAuthStore = create<AuthState>((set) => ({
  user: tokenIsValid ? JSON.parse(localStorage.getItem('user') || 'null') : null,
  token: tokenIsValid ? storedToken : null,
  isAuthenticated: tokenIsValid,
  isLoading: false,
  error: null,

  login: async (email: string, password: string) => {
    set({ isLoading: true, error: null });
    try {
      const response = await authService.login(email, password);
      
      // Guardar token, usuario y marca de inicio de sesión
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response.usuario));
      localStorage.setItem(ACTIVITY_KEY, Date.now().toString());
      
      set({
        user: response.usuario,
        token: response.token,
        isAuthenticated: true,
        isLoading: false
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Error al iniciar sesión';
      set({
        error: errorMessage,
        isLoading: false,
        isAuthenticated: false
      });
      throw error;
    }
  },

  logout: () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem(ACTIVITY_KEY);
    set({
      user: null,
      token: null,
      isAuthenticated: false,
      error: null
    });
  },

  setUser: (user) => set({ user }),

  clearError: () => set({ error: null }),

  loadUserFromToken: async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      set({ isAuthenticated: false, user: null });
      return;
    }

    try {
      set({ isLoading: true });
      const user = await authService.getMe();
      localStorage.setItem('user', JSON.stringify(user));
      set({
        user,
        isAuthenticated: true,
        isLoading: false
      });
    } catch (error) {
      // Token inválido, limpiar sesión
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      set({
        user: null,
        token: null,
        isAuthenticated: false,
        isLoading: false
      });
    }
  }
}));
