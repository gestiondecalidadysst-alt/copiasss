import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface CertificateFieldConfig {
  key: 'nombre' | 'apellido' | 'documento' | 'fecha' | 'calificacion';
  label: string;
  enabled: boolean;
}

export interface CertificateDesign {
  // Colores
  backgroundColor: string;
  borderColor: string;
  titleColor: string;
  nameColor: string;
  textColor: string;
  accentColor: string;
  // Contenido
  certificateTitle: string;
  certifyText: string;
  courseIntroText: string;
  signatureName: string;
  signatureTitle: string;
  footerText: string;
  // Numeración
  numberPrefix: string;
  showCertNumber: boolean;
  // Tipografía
  fontFamily: 'helvetica' | 'times' | 'courier';
  // Tamaños de letra (puntos PDF)
  titleFontSize: number;
  nameFontSize: number;
  bodyFontSize: number;
  courseFontSize: number;
  // Tamaños de logos (puntos PDF)
  logoHeight: number;
  footerLogoHeight: number;
  // Logo exclusivo del diploma (distinto al logo del sistema)
  certLogoBase64: string | null;
  certLogoName: string;
  // Mostrar logo del sistema también
  showSystemLogo: boolean;
}

export interface CertificateConfig {
  templatePdf: string | null;
  templateName: string;
  fields: CertificateFieldConfig[];
  design: CertificateDesign;
}

interface AppState {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  companyName: string;
  companyLogo: string | null;
  setCompanyName: (name: string) => void;
  setCompanyLogo: (logo: string | null) => void;
  reportHeader: string;
  reportFooter: string;
  setReportHeader: (header: string) => void;
  setReportFooter: (footer: string) => void;
  certificateConfig: CertificateConfig;
  setCertificateConfig: (config: CertificateConfig) => void;
  certCounter: number;
  incrementCertCounter: () => void;
}

const DEFAULT_CERTIFICATE_FIELDS: CertificateFieldConfig[] = [
  { key: 'nombre',       label: 'Nombre',             enabled: true },
  { key: 'apellido',     label: 'Apellido',            enabled: true },
  { key: 'documento',    label: 'Número de documento', enabled: true },
  { key: 'fecha',        label: 'Fecha',               enabled: true },
  { key: 'calificacion', label: 'Calificación',        enabled: true },
];

export const DEFAULT_CERTIFICATE_DESIGN: CertificateDesign = {
  backgroundColor: '#FDFAF0',
  borderColor:     '#B8941E',
  titleColor:      '#1A1A2E',
  nameColor:       '#1A3D8A',
  textColor:       '#444444',
  accentColor:     '#B8941E',
  certificateTitle:  'CERTIFICADO DE CAPACITACIÓN',
  certifyText:       'Se certifica que:',
  courseIntroText:   'Ha completado satisfactoriamente la capacitación:',
  signatureName:     'Director de Seguridad Vial',
  signatureTitle:    '',
  footerText:        '',
  numberPrefix:      'CERT-',
  showCertNumber:    true,
  fontFamily:        'helvetica',
  titleFontSize:     22,
  nameFontSize:      24,
  bodyFontSize:      12,
  courseFontSize:    14,
  logoHeight:        62,
  footerLogoHeight:  32,
  certLogoBase64:    null,
  certLogoName:      '',
  showSystemLogo:    true,
};

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      sidebarOpen: true,
      toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      companyName: 'RiskVial Pro',
      companyLogo: null,
      setCompanyName: (name) => set({ companyName: name }),
      setCompanyLogo: (logo) => set({ companyLogo: logo }),
      reportHeader: '',
      reportFooter: '',
      setReportHeader: (header) => set({ reportHeader: header }),
      setReportFooter: (footer) => set({ reportFooter: footer }),
      certificateConfig: {
        templatePdf: null,
        templateName: '',
        fields: DEFAULT_CERTIFICATE_FIELDS,
        design: { ...DEFAULT_CERTIFICATE_DESIGN },
      },
      setCertificateConfig: (config) => set({ certificateConfig: config }),
      certCounter: 1,
      incrementCertCounter: () => set((s) => ({ certCounter: s.certCounter + 1 })),
    }),
    {
      name: 'app-store',
      version: 1,
      // Deep-merge para que campos nuevos de 'design' tomen sus defaults
      // aunque no existan en el localStorage guardado (usuarios en producción).
      merge: (persistedState: unknown, currentState: AppState): AppState => {
        const persisted = persistedState as Partial<AppState> | null;
        return {
          ...currentState,
          ...persisted,
          certificateConfig: {
            ...currentState.certificateConfig,
            ...(persisted?.certificateConfig ?? {}),
            design: {
              ...currentState.certificateConfig.design, // defaults para campos nuevos
              ...(persisted?.certificateConfig?.design ?? {}), // valores guardados del usuario
            },
          },
        };
      },
      partialize: (state) => ({
        companyName: state.companyName,
        companyLogo: state.companyLogo,
        reportHeader: state.reportHeader,
        reportFooter: state.reportFooter,
        // templatePdf se excluye intencionalmente: se persiste aparte
        // para no superar el límite de localStorage (~5 MB).
        certificateConfig: {
          ...state.certificateConfig,
          templatePdf: null,
        },
        certCounter: state.certCounter,
      }),
    }
  )
);
