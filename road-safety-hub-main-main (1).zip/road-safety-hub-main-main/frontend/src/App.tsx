import { lazy, Suspense } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Route, Routes, Navigate } from 'react-router-dom';
import { Toaster as Sonner } from '@/components/ui/sonner';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { RoleProtectedRoute } from '@/components/RoleProtectedRoute';
import MainLayout from '@/layouts/MainLayout';
import PortalConductorLayout from '@/layouts/PortalConductorLayout';
import { useSessionTimeout } from '@/hooks/useSessionTimeout';
import { useAuthStore } from '@/stores/authStore';

/** Activa el cierre automático de sesión por inactividad (20 min). */
const SessionGuard = () => {
  useSessionTimeout();
  return null;
};

/** Redirige según el rol del usuario al entrar a "/" */
const RootRedirect = () => {
  const user = useAuthStore((s) => s.user);
  if (user?.rol === 'conductor') return <Navigate to="/portal/conductor" replace />;
  return <Navigate to="/dashboard" replace />;
};

const Login = lazy(() => import('./pages/Login'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Vehiculos = lazy(() => import('./pages/Vehiculos'));
const Conductores = lazy(() => import('./pages/Conductores'));
const Eventos = lazy(() => import('./pages/Eventos'));
const Mensajes = lazy(() => import('./pages/Mensajes'));
const MapaPage = lazy(() => import('./pages/MapaPage'));
const Reportes = lazy(() => import('./pages/Reportes'));
const Configuracion = lazy(() => import('./pages/Configuracion'));
const Usuarios = lazy(() => import('./pages/Usuarios'));
const Capacitaciones = lazy(() => import('./pages/Capacitaciones'));
const PortalConductorPage = lazy(() => import('./pages/PortalConductorPage'));
const Noticias = lazy(() => import('./pages/Noticias'));

const queryClient = new QueryClient();

const Loading = () => (
  <div className="flex items-center justify-center h-64">
    <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
  </div>
);

const AppContent = () => {
  return (
    <>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <SessionGuard />
            <Suspense fallback={<Loading />}>
              <Routes>
                <Route path="/login" element={<Login />} />

                {/* ── Portal del Conductor ─────────────────────────────── */}
                <Route element={
                  <ProtectedRoute>
                    <RoleProtectedRoute requiredRole="conductor" fallback={<Navigate to="/dashboard" replace />}>
                      <PortalConductorLayout />
                    </RoleProtectedRoute>
                  </ProtectedRoute>
                }>
                  <Route path="/portal/conductor" element={<PortalConductorPage />} />
                </Route>

                {/* ── Panel de administración / usuarios ──────────────── */}
                <Route element={
                  <ProtectedRoute>
                    <RoleProtectedRoute requiredRole={['admin', 'usuario']} fallback={<Navigate to="/portal/conductor" replace />}>
                      <MainLayout />
                    </RoleProtectedRoute>
                  </ProtectedRoute>
                }>
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/vehiculos" element={<Vehiculos />} />
                  <Route path="/conductores" element={<Conductores />} />
                  <Route path="/eventos" element={<Eventos />} />
                  <Route path="/mensajes" element={<Mensajes />} />
                  <Route path="/mapa" element={<MapaPage />} />
                  <Route path="/reportes" element={<Reportes />} />
                  <Route path="/usuarios" element={<Usuarios />} />
                  <Route path="/capacitaciones" element={<Capacitaciones />} />
                  <Route path="/noticias" element={<Noticias />} />
                  <Route path="/configuracion" element={<Configuracion />} />
                </Route>

                <Route path="/" element={<ProtectedRoute><RootRedirect /></ProtectedRoute>} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </Suspense>
          </BrowserRouter>
        </TooltipProvider>
      </QueryClientProvider>
    </>
  );
};

const App = () => <AppContent />;

export default App;

