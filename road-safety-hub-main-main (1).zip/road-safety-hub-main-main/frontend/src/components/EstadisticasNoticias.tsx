import { useState, useEffect } from 'react';
import api from '@/services/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
  BarChart3, Download, Eye, Heart, MessageSquare, Award, 
  AlertCircle, Loader2, TrendingUp, Users 
} from 'lucide-react';
import { toast } from 'sonner';

interface Estadisticas {
  vista_count: number;
  certificacion_count: number;
  comentarios_count: number;
  me_gusta_count: number;
  no_me_gusta_count: number;
  vistas: Array<{
    user_id: string;
    autor: string;
    created_at: string;
  }>;
  certificaciones: Array<{
    user_id: string;
    autor: string;
    created_at: string;
  }>;
}

interface Noticia {
  id: string;
  titulo: string;
  contenido: string;
  autor: string;
  created_at: string;
}

interface EstadisticasNoticiasProps {
  noticias: Noticia[];
}

const EstadisticasNoticias = ({ noticias }: EstadisticasNoticiasProps) => {
  const [estadisticasOpen, setEstadisticasOpen] = useState(false);
  const [selectedNoticia, setSelectedNoticia] = useState<Noticia | null>(null);
  const [estadisticas, setEstadisticas] = useState<Estadisticas | null>(null);
  const [loading, setLoading] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleOpenEstadisticas = async (noticia: Noticia) => {
    setSelectedNoticia(noticia);
    setLoading(true);
    try {
      const { data } = await api.get(`/noticias/${noticia.id}/estadisticas`);
      setEstadisticas(data);
      setEstadisticasOpen(true);
    } catch (err) {
      toast.error('Error al cargar estadísticas');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('es-CO', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const handleDescargarTodasEstadisticas = async () => {
    setDownloading(true);
    try {
      const response = await api.get('/noticias/descargar/todas-estadisticas', {
        responseType: 'blob',
      });

      // Crear elemento de descarga
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `estadisticas_noticias_completo_${new Date().getTime()}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast.success('Reporte descargado exitosamente');
    } catch (err) {
      toast.error('Error al descargar reporte');
      console.error(err);
    } finally {
      setDownloading(false);
    }
  };

  const handleDescargarCSV = async () => {
    if (!selectedNoticia) {
      toast.error('Seleccione una noticia antes de descargar');
      return;
    }

    setDownloading(true);
    try {
      const response = await api.get(`/noticias/${selectedNoticia.id}/descargar-estadisticas`, {
        responseType: 'blob',
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `estadisticas_noticia_${selectedNoticia.id.slice(0, 8)}_${new Date().getTime()}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast.success('Reporte descargado exitosamente');
    } catch (err) {
      toast.error('Error al descargar reporte');
      console.error(err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Botón para abrir selector de noticias */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-semibold">Estadísticas de Noticias</h2>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={handleDescargarTodasEstadisticas}
            disabled={downloading || noticias.length === 0}
            size="sm"
            className="bg-green-600 hover:bg-green-700 text-white"
          >
            {downloading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Descargando...
              </>
            ) : (
              <>
                <Download className="w-4 h-4 mr-2" />
                Descargar Todo
              </>
            )}
          </Button>
          <Button
            onClick={() => setEstadisticasOpen(!estadisticasOpen)}
            variant="outline"
            size="sm"
          >
            {estadisticasOpen ? 'Cerrar' : 'Ver Estadísticas'}
          </Button>
        </div>
      </div>

      {/* Panel de estadísticas */}
      {estadisticasOpen && (
        <Card className="border-primary/20 bg-primary/5">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Selecciona una noticia para ver detalles</span>
              <Badge variant="secondary">{noticias.length} noticias</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Lista de noticias */}
            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {noticias.length === 0 ? (
                <div className="flex items-center justify-center py-8 text-muted-foreground">
                  <AlertCircle className="w-4 h-4 mr-2" />
                  No hay noticias disponibles
                </div>
              ) : (
                noticias.map((noticia) => (
                  <button
                    key={noticia.id}
                    onClick={() => handleOpenEstadisticas(noticia)}
                    className="w-full text-left p-3 rounded-lg border border-border hover:bg-accent hover:border-primary transition-colors"
                  >
                    <div className="font-semibold text-sm line-clamp-1">{noticia.titulo}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      Por: {noticia.autor} • {new Date(noticia.created_at).toLocaleDateString('es-CO')}
                    </div>
                  </button>
                ))
              )}
            </div>

            {/* Detalle de estadísticas cuando se selecciona una noticia */}
            {selectedNoticia && loading && (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-5 h-5 animate-spin text-primary mr-2" />
                <span className="text-sm text-muted-foreground">Cargando estadísticas...</span>
              </div>
            )}

            {selectedNoticia && !loading && estadisticas && (
              <div className="space-y-6 mt-6 pt-6 border-t border-border">
                <div>
                  <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4" />
                    Resumen: {selectedNoticia.titulo}
                  </h3>

                  {/* Cards de métricas */}
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
                    <div className="bg-card border border-border rounded-lg p-3 text-center">
                      <Eye className="w-4 h-4 mx-auto mb-1 text-blue-500" />
                      <div className="text-2xl font-bold text-foreground">{estadisticas.vista_count}</div>
                      <div className="text-xs text-muted-foreground">Vistas</div>
                    </div>

                    <div className="bg-card border border-border rounded-lg p-3 text-center">
                      <Heart className="w-4 h-4 mx-auto mb-1 text-red-500" />
                      <div className="text-2xl font-bold text-foreground">{estadisticas.me_gusta_count}</div>
                      <div className="text-xs text-muted-foreground">Me gusta</div>
                    </div>

                    <div className="bg-card border border-border rounded-lg p-3 text-center">
                      <MessageSquare className="w-4 h-4 mx-auto mb-1 text-amber-500" />
                      <div className="text-2xl font-bold text-foreground">{estadisticas.comentarios_count}</div>
                      <div className="text-xs text-muted-foreground">Comentarios</div>
                    </div>

                    <div className="bg-card border border-border rounded-lg p-3 text-center">
                      <Award className="w-4 h-4 mx-auto mb-1 text-green-500" />
                      <div className="text-2xl font-bold text-foreground">{estadisticas.certificacion_count}</div>
                      <div className="text-xs text-muted-foreground">Certificados</div>
                    </div>

                    <div className="bg-card border border-border rounded-lg p-3 text-center">
                      <Users className="w-4 h-4 mx-auto mb-1 text-purple-500" />
                      <div className="text-2xl font-bold text-foreground">{estadisticas.no_me_gusta_count}</div>
                      <div className="text-xs text-muted-foreground">No me gusta</div>
                    </div>
                  </div>
                </div>

                {/* Tabla de vistas detalladas */}
                {estadisticas.vistas.length > 0 && (
                  <div>
                    <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                      <Eye className="w-4 h-4 text-blue-500" />
                      Vistas Detalladas ({estadisticas.vistas.length})
                    </h4>
                    <div className="max-h-[200px] overflow-y-auto border border-border rounded-lg">
                      <table className="w-full text-sm">
                        <thead className="bg-accent sticky top-0">
                          <tr>
                            <th className="px-3 py-2 text-left font-semibold">Conductor</th>
                            <th className="px-3 py-2 text-left font-semibold">Fecha</th>
                          </tr>
                        </thead>
                        <tbody>
                          {estadisticas.vistas.map((vista, idx) => (
                            <tr key={idx} className="border-t border-border hover:bg-accent/50">
                              <td className="px-3 py-2">{vista.autor}</td>
                              <td className="px-3 py-2 text-muted-foreground text-xs">{formatDate(vista.created_at)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Tabla de certificaciones detalladas */}
                {estadisticas.certificaciones.length > 0 && (
                  <div>
                    <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                      <Award className="w-4 h-4 text-green-500" />
                      Certificaciones Detalladas ({estadisticas.certificaciones.length})
                    </h4>
                    <div className="max-h-[200px] overflow-y-auto border border-border rounded-lg">
                      <table className="w-full text-sm">
                        <thead className="bg-accent sticky top-0">
                          <tr>
                            <th className="px-3 py-2 text-left font-semibold">Conductor</th>
                            <th className="px-3 py-2 text-left font-semibold">Fecha</th>
                          </tr>
                        </thead>
                        <tbody>
                          {estadisticas.certificaciones.map((cert, idx) => (
                            <tr key={idx} className="border-t border-border hover:bg-accent/50">
                              <td className="px-3 py-2">{cert.autor}</td>
                              <td className="px-3 py-2 text-muted-foreground text-xs">{formatDate(cert.created_at)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Botón de descarga */}
                <Button
                  onClick={handleDescargarCSV}
                  disabled={downloading}
                  className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white"
                >
                  {downloading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Descargando...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" />
                      Descargar como CSV
                    </>
                  )}
                </Button>

                {/* Información adicional */}
                <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3">
                  <div className="text-xs text-muted-foreground">
                    <p className="font-semibold text-foreground mb-1">💡 Consejo</p>
                    <p>Descarga los datos para análisis más profundo. Los archivos CSV se pueden abrir en Excel o Google Sheets.</p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default EstadisticasNoticias;
