import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import {
  Loader2,
  ThumbsUp,
  ThumbsDown,
  MessageCircle,
  Award,
  CheckSquare,
  Square,
  ShieldCheck,
  X,
  ChevronDown,
  ChevronUp,
  Globe,
  Lock,
  Pencil,
  Trash2,
  TrendingUp,
} from 'lucide-react';

export interface Noticia {
  id: string;
  titulo: string;
  contenido: string;
  imagen_url: string | null;
  video_youtube: string | null;
  publicado: boolean;
  permite_certificar: boolean;
  autor: string;
  created_at: string;
  updated_at: string | null;
  me_gusta_count: number;
  no_me_gusta_count: number;
  comentarios_count: number;
  certificaciones_count: number;
  vistas_count?: number;
}

export interface Comentario {
  id: string;
  noticia_id: string;
  user_id: string;
  autor: string;
  contenido: string;
  created_at: string;
}

export interface NoticiaCardProps {
  noticia: Noticia;
  isAdmin: boolean;
  userId: string;
  miReaccion: 'me_gusta' | 'no_me_gusta' | null;
  certificado: boolean;
  comentariosAbiertos: boolean;
  comentarios: Comentario[] | null;
  onEdit?: (noticia: Noticia) => void;
  onDelete?: (id: string) => void;
  onVerEstadisticas?: (id: string) => void;
  onReaccionar: (id: string, tipo: 'me_gusta' | 'no_me_gusta') => void;
  onToggleComentarios: (id: string) => void;
  onEnviarComentario: (id: string, texto: string) => Promise<void>;
  onEliminarComentario: (noticiaId: string, cid: string) => void;
  onCertificar: (id: string) => void;
  reaccionando: boolean;
  certificando: boolean;
}

function getYoutubeId(url: string): string | null {
  if (!url) return null;
  const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
  return url.match(regex)?.[1] ?? null;
}

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Ahora mismo';
  if (mins < 60) return `hace ${mins} min`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `hace ${hrs} h`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `hace ${days} día${days > 1 ? 's' : ''}`;
  return new Date(dateStr).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' });
}

const CommentSection = ({
  noticiaId,
  userId,
  isAdmin,
  comentarios,
  onEliminarComentario,
  onEnviarComentario,
}: {
  noticiaId: string;
  userId: string;
  isAdmin: boolean;
  comentarios: Comentario[] | null;
  onEliminarComentario: (noticiaId: string, cid: string) => void;
  onEnviarComentario: (noticiaId: string, texto: string) => Promise<void>;
}) => {
  const [texto, setTexto] = useState('');
  const [enviando, setEnviando] = useState(false);

  const handleEnviar = async () => {
    if (!texto.trim()) return;
    setEnviando(true);
    try {
      await onEnviarComentario(noticiaId, texto.trim());
      setTexto('');
    } catch (error) {
      toast.error('Error al enviar el comentario');
    } finally {
      setEnviando(false);
    }
  };

  return (
    <div className="px-4 pb-4 space-y-3 border-t border-border pt-3">
      {comentarios?.length === 0 ? (
        <p className="text-xs text-muted-foreground text-center py-2">Sé el primero en comentar.</p>
      ) : (
        comentarios?.map((c) => (
          <div key={c.id} className="flex items-start gap-2">
            <div className="w-7 h-7 rounded-full bg-muted flex items-center justify-center flex-shrink-0 text-xs font-bold text-muted-foreground">
              {c.autor.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 bg-muted/50 rounded-xl px-3 py-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-foreground">{c.autor}</span>
                <div className="flex items-center gap-1">
                  <span className="text-[10px] text-muted-foreground">{timeAgo(c.created_at)}</span>
                  {(isAdmin || c.user_id === userId) && (
                    <button
                      onClick={() => onEliminarComentario(noticiaId, c.id)}
                      className="p-0.5 rounded hover:text-red-500 text-muted-foreground/50 transition-colors"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
              <p className="text-sm text-foreground/80 mt-0.5">{c.contenido}</p>
            </div>
          </div>
        ))
      )}

      <div className="flex items-center gap-2">
        <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
          <ShieldCheck className="w-3.5 h-3.5 text-primary" />
        </div>
        <div className="flex-1 flex gap-2">
          <input
            type="text"
            placeholder="Escribe un comentario..."
            value={texto}
            onChange={(e) => setTexto(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleEnviar();
              }
            }}
            className="flex-1 bg-muted/50 rounded-full px-4 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
          />
          <button
            onClick={handleEnviar}
            disabled={enviando || !texto.trim()}
            className="p-1.5 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40"
          >
            {enviando ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <MessageCircle className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
};

const NoticiaCard = ({
  noticia,
  isAdmin,
  userId,
  miReaccion,
  certificado,
  comentariosAbiertos,
  comentarios,
  onEdit,
  onDelete,
  onVerEstadisticas,
  onReaccionar,
  onToggleComentarios,
  onEnviarComentario,
  onEliminarComentario,
  onCertificar,
  reaccionando,
  certificando,
}: NoticiaCardProps) => {
  const [expanded, setExpanded] = useState(false);
  const ytId = getYoutubeId(noticia.video_youtube ?? '');
  const longContent = noticia.contenido.length > 280;
  const displayContent = longContent && !expanded ? noticia.contenido.slice(0, 280) + '…' : noticia.contenido;

  return (
    <Card className={cn('overflow-hidden transition-shadow hover:shadow-md', !noticia.publicado && 'opacity-70 border-dashed')}>
      <CardContent className="p-0">
        <div className="flex items-center justify-between px-4 pt-4 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <ShieldCheck className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="font-semibold text-sm text-foreground leading-tight">{noticia.autor}</p>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span>{timeAgo(noticia.created_at)}</span>
                {noticia.updated_at && noticia.updated_at !== noticia.created_at && <span className="opacity-60">· editado</span>}
                <span>·</span>
                {noticia.publicado ? <Globe className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                {typeof noticia.vistas_count === 'number' && (
                  <span className="opacity-70">· {noticia.vistas_count} vista{noticia.vistas_count === 1 ? '' : 's'}</span>
                )}
              </div>
            </div>
          </div>
          {isAdmin && onEdit && onDelete && (
            <div className="flex items-center gap-1">
              {!noticia.publicado && <Badge variant="outline" className="text-[10px] mr-1">Borrador</Badge>}
              <button
                onClick={() => onEdit(noticia)}
                className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                title="Editar"
              >
                <Pencil className="w-4 h-4" />
              </button>
              <button
                onClick={() => onDelete(noticia.id)}
                className="p-1.5 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-500 transition-colors"
                title="Eliminar"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              {onVerEstadisticas && (
                <button
                  onClick={() => onVerEstadisticas(noticia.id)}
                  className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                  title="Ver estadísticas"
                >
                  <TrendingUp className="w-4 h-4" />
                </button>
              )}
            </div>
          )}
        </div>

        <div className="px-4 pb-2">
          <h3 className="text-base font-bold text-foreground leading-snug">{noticia.titulo}</h3>
        </div>

        <div className="px-4 pb-3">
          <p className="text-sm text-foreground/80 whitespace-pre-wrap leading-relaxed">{displayContent}</p>
          {longContent && (
            <button
              onClick={() => setExpanded((v) => !v)}
              className="text-xs text-primary font-medium mt-1 flex items-center gap-0.5 hover:underline"
            >
              {expanded ? <><ChevronUp className="w-3 h-3" />Ver menos</> : <><ChevronDown className="w-3 h-3" />Ver más</>}
            </button>
          )}
        </div>

        {noticia.imagen_url && (
          <img src={noticia.imagen_url} alt={noticia.titulo} className="w-full max-h-96 object-cover" />
        )}

        {ytId && (
          <div className="aspect-video w-full bg-black">
            <iframe
              src={`https://www.youtube.com/embed/${ytId}`}
              title={noticia.titulo}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full"
            />
          </div>
        )}

        {noticia.permite_certificar && ytId && (
          <div
            className={cn(
              'mx-4 mt-3 mb-1 rounded-xl px-4 py-3 flex items-center justify-between gap-3',
              certificado ? 'bg-green-500/10 border border-green-500/30' : 'bg-muted/60 border border-border',
            )}
          >
            <div className="flex items-center gap-2">
              <Award className={cn('w-5 h-5 flex-shrink-0', certificado ? 'text-green-600' : 'text-muted-foreground')} />
              <div>
                <p className={cn('text-sm font-semibold', certificado ? 'text-green-700' : 'text-foreground')}>
                  {certificado ? '✓ Has certificado que viste el video' : 'Certificar video'}
                </p>
                <p className="text-xs text-muted-foreground">
                  {noticia.certificaciones_count} persona{noticia.certificaciones_count !== 1 ? 's' : ''} certificaron
                </p>
              </div>
            </div>
            <button
              onClick={() => onCertificar(noticia.id)}
              disabled={certificando}
              className={cn(
                'flex items-center gap-1.5 text-sm px-4 py-1.5 rounded-lg font-medium transition-all',
                certificado ? 'bg-green-500 text-white hover:bg-green-600' : 'bg-primary text-primary-foreground hover:bg-primary/90',
                'disabled:opacity-50',
              )}
            >
              {certificando ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : certificado ? <CheckSquare className="w-3.5 h-3.5" /> : <Square className="w-3.5 h-3.5" />}
              {certificado ? 'Certificado' : 'Certificar'}
            </button>
          </div>
        )}

        <div className="flex items-center border-t border-border">
          <button
            onClick={() => onReaccionar(noticia.id, 'me_gusta')}
            disabled={reaccionando}
            className={cn(
              'flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-medium transition-colors hover:bg-muted rounded-bl-xl',
              miReaccion === 'me_gusta' ? 'text-blue-600 bg-blue-50' : 'text-muted-foreground',
            )}
          >
            {reaccionando ? <Loader2 className="w-4 h-4 animate-spin" /> : <ThumbsUp className={cn('w-4 h-4', miReaccion === 'me_gusta' && 'fill-blue-600')} />}
            Me gusta ({noticia.me_gusta_count})
          </button>
          <div className="w-px h-8 bg-border" />
          <button
            onClick={() => onReaccionar(noticia.id, 'no_me_gusta')}
            disabled={reaccionando}
            className={cn(
              'flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-medium transition-colors hover:bg-muted',
              miReaccion === 'no_me_gusta' ? 'text-red-500 bg-red-50' : 'text-muted-foreground',
            )}
          >
            {reaccionando ? <Loader2 className="w-4 h-4 animate-spin" /> : <ThumbsDown className={cn('w-4 h-4', miReaccion === 'no_me_gusta' && 'fill-red-500')} />}
            No me gusta ({noticia.no_me_gusta_count})
          </button>
          <div className="w-px h-8 bg-border" />
          <button
            onClick={() => onToggleComentarios(noticia.id)}
            className={cn(
              'flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-medium transition-colors hover:bg-muted rounded-br-xl',
              comentariosAbiertos ? 'text-primary' : 'text-muted-foreground',
            )}
          >
            <MessageCircle className={cn('w-4 h-4', comentariosAbiertos && 'fill-primary/20')} />
            Comentarios ({noticia.comentarios_count})
          </button>
        </div>

        {comentariosAbiertos && (
          <CommentSection
            noticiaId={noticia.id}
            userId={userId}
            isAdmin={isAdmin}
            comentarios={comentarios}
            onEliminarComentario={onEliminarComentario}
            onEnviarComentario={onEnviarComentario}
          />
        )}
      </CardContent>
    </Card>
  );
};

export default NoticiaCard;
