const fs = require('fs');
const path = require('path');
const file = path.join(__dirname, 'QuizEditor.tsx');
const content = fs.readFileSync(file, 'utf8');
const lines = content.split('\n');

const newLines = [
  '      {/* Encabezado del quiz */}\r',
  '      <div className="flex items-center justify-between bg-muted/40 rounded-lg px-4 py-2.5">\r',
  '        <div className="flex items-center gap-2 text-sm text-muted-foreground">\r',
  '          <ClipboardList className="w-4 h-4" />\r',
  "          <span><strong className=\"text-foreground\">{preguntas.length}</strong> pregunta{preguntas.length !== 1 ? 's' : ''}</span>\r",
  '          <span className="text-muted-foreground/50">\u00b7</span>\r',
  "          <span>Total: <strong className=\"text-foreground\">{totalPuntos} punto{totalPuntos !== 1 ? 's' : ''}</strong></span>\r",
  '        </div>\r',
  '        <Badge variant="outline" className="text-xs gap-1">\r',
  '          Selecci\u00f3n \u00fanica \u00b7 Calificaci\u00f3n autom\u00e1tica\r',
  '        </Badge>\r',
  '      </div>\r',
  '\r',
  '      {/* Porcentaje m\u00ednimo para aprobar */}\r',
  '      <div className="flex items-center gap-3 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg px-4 py-3">\r',
  '        <Percent className="w-4 h-4 text-blue-600 flex-shrink-0" />\r',
  '        <div className="flex-1">\r',
  '          <p className="text-xs font-semibold text-blue-700 dark:text-blue-400">Porcentaje m\u00ednimo para aprobar</p>\r',
  '          <p className="text-xs text-blue-600/70 dark:text-blue-500">El conductor debe obtener al menos este porcentaje. M\u00e1ximo 2 intentos.</p>\r',
  '        </div>\r',
  '        <div className="flex items-center gap-1 flex-shrink-0">\r',
  '          <Input\r',
  '            type="number"\r',
  '            min={1}\r',
  '            max={100}\r',
  '            value={porcentajeAprobacion}\r',
  '            onChange={(e) => setPorcentajeAprobacion(Math.min(100, Math.max(1, parseInt(e.target.value) || 70)))}\r',
  '            className="w-16 text-center text-sm font-bold border-blue-300 dark:border-blue-700"\r',
  '          />\r',
  '          <span className="text-sm font-bold text-blue-700 dark:text-blue-400">%</span>\r',
  '        </div>\r',
  '      </div>\r',
  '\r',
  '      <p className="text-xs text-muted-foreground px-0.5">\r',
  '        Cada pregunta es de <strong>selecci\u00f3n m\u00faltiple con una sola respuesta correcta</strong>.\r',
  '        Marca cu\u00e1l es la opci\u00f3n correcta e indica cu\u00e1ntos puntos vale.\r',
  '        El puntaje se calcula autom\u00e1ticamente seg\u00fan los puntos acumulados.\r',
  '      </p>\r',
  '\r',
];

// Reemplazar líneas 181 a 199 (0-indexed) con el nuevo contenido
const before = lines.slice(0, 181);
const after = lines.slice(200);
const result = before.concat(newLines).concat(after).join('\n');
fs.writeFileSync(file, result, 'utf8');
console.log('OK - QuizEditor actualizado, total lines:', result.split('\n').length);
