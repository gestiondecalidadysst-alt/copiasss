import { useAuthStore } from '@/stores/authStore';
import { useAppStore } from '@/stores/appStore';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Bell, LogOut, Menu } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const AppHeader = () => {
  const { user, logout } = useAuthStore();
  const { sidebarOpen, toggleSidebar } = useAppStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    toast.info('Sesión cerrada');
    navigate('/login');
  };

  return (
    <header
      className={cn(
        'h-16 border-b border-border bg-card/80 backdrop-blur-xl flex items-center justify-between px-4 sm:px-6 sticky top-0 z-30 transition-all',
        sidebarOpen ? 'lg:ml-64' : 'lg:ml-[68px]'
      )}
    >
      <button onClick={toggleSidebar} className="lg:hidden p-2 hover:bg-muted rounded-lg">
        <Menu className="w-5 h-5 text-foreground" />
      </button>

      <div className="flex-1" />

      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="w-5 h-5 text-muted-foreground" />
          <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-destructive text-destructive-foreground text-[10px] rounded-full flex items-center justify-center font-bold">
            3
          </span>
        </Button>

        <div className="hidden sm:block text-right">
          <p className="text-sm font-medium text-foreground">{user?.nombre}</p>
          <p className="text-xs text-muted-foreground">
            {user?.rol === 'admin' ? 'Administrador' : 'Usuario'} {user?.empresa && `• ${user.empresa}`}
          </p>
        </div>

        <Button variant="ghost" size="icon" onClick={handleLogout} title="Cerrar sesión">
          <LogOut className="w-5 h-5 text-muted-foreground" />
        </Button>
      </div>
    </header>
  );
};

export default AppHeader;
