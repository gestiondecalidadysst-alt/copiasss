import { useState, useEffect, useCallback } from 'react';
import api from '@/services/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Plus, Trash2, Save, Loader2, Video, Star,
  ChevronDown, ChevronUp, GripVertical, Link2,
  CheckCircle2, Circle, Percent, ClipboardList, BookMarked
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

// ── Tipos ──────────────────────────────────────────────────────────────────

interface Opcion {
  id: string;
  texto: string;
  es_correcta: boolean;
  orden: number;
}

interface Pregunta {
  id: string;
  pregunta: string;
  puntos: number;
  orden: number;
  opciones: Opcion[];
}

interface Quiz {
  id: string;
  titulo: string;
  porcentaje_aprobacion: number;
  orden: number;
  preguntas: Pregunta[];
}

interface VideoItem {
  id: string;
  titulo: string;
  url: string;
  duracion_minutos: number;
  orden: number;
}

export interface Modulo {
  id: string;
  titulo: string;
  descripcion: string;
  orden: number;
  videos: VideoItem[];
  quizzes: Quiz[];
}

interface ModulosEditorProps {
  capacitacionId?: string;
  onChange?: (modulos: Modulo[]) => void;
}

const uid = () => crypto.randomUUID();

// ── Factories ──────────────────────────────────────────────────────────────

const newOpcion = (orden: number): Opcion => ({
  id: uid(),
  texto: '',
  es_correcta: false,
  orden,
});

const newPregunta = (orden: number): Pregunta => ({
  id: uid(),
  pregunta: '',
  puntos: 1,
  orden,
  opciones: [newOpcion(0), newOpcion(1), newOpcion(2), newOpcion(3)],
});

const newQuiz = (orden: number): Quiz => ({
  id: uid(),
  titulo: `Quiz ${orden + 1}`,
  porcentaje_aprobacion: 70,
  orden,
  preguntas: [newPregunta(0)],
});

const newVideo = (orden: number): VideoItem => ({
  id: uid(),
  titulo: `Video ${orden + 1}`,
  url: '',
  duracion_minutos: 0,
  orden,
});

const newModulo = (orden: number): Modulo => ({
  id: uid(),
  titulo: `Módulo ${orden + 1}`,
  descripcion: '',
  orden,
  videos: [newVideo(0)],
  quizzes: [newQuiz(0)],
});

// ── Sub-componente: Editor de Quiz ─────────────────────────────────────────

const QuizModuloEditor = ({
  quiz,
  onChange,
  onRemove,
  removable,
}: {
  quiz: Quiz;
  onChange: (updated: Quiz) => void;
  onRemove: () => void;
  removable: boolean;
}) => {
  const [open, setOpen] = useState(true);
  const totalPuntos = quiz.preguntas.reduce((a, p) => a + (p.puntos || 1), 0);

  const updateField = <K extends keyof Quiz>(key: K, value: Quiz[K]) =>
    onChange({ ...quiz, [key]: value });

  const addPregunta = () =>
    onChange({ ...quiz, preguntas: [...quiz.preguntas, newPregunta(quiz.preguntas.length)] });

  const removePregunta = (idx: number) =>
    onChange({
      ...quiz,
      preguntas: quiz.preguntas.filter((_, i) => i !== idx).map((p, i) => ({ ...p, orden: i })),
    });

  const updatePregunta = (idx: number, updated: Pregunta) =>
    onChange({ ...quiz, preguntas: quiz.preguntas.map((p, i) => (i === idx ? updated : p)) });

  const setCorrectOpcion = (pIdx: number, oIdx: number) =>
    updatePregunta(pIdx, {
      ...quiz.preguntas[pIdx],
      opciones: quiz.preguntas[pIdx].opciones.map((o, j) => ({ ...o, es_correcta: j === oIdx })),
    });

  const updateOpcionTexto = (pIdx: number, oIdx: number, texto: string) =>
    updatePregunta(pIdx, {
      ...quiz.preguntas[pIdx],
      opciones: quiz.preguntas[pIdx].opciones.map((o, j) => (j === oIdx ? { ...o, texto } : o)),
    });

  const addOpcion = (pIdx: number) =>
    updatePregunta(pIdx, {
      ...quiz.preguntas[pIdx],
      opciones: [...quiz.preguntas[pIdx].opciones, newOpcion(quiz.preguntas[pIdx].opciones.length)],
    });

  const removeOpcion = (pIdx: number, oIdx: number) =>
    updatePregunta(pIdx, {
      ...quiz.preguntas[pIdx],
      opciones: quiz.preguntas[pIdx].opciones
        .filter((_, j) => j !== oIdx)
        .map((o, j) => ({ ...o, orden: j })),
    });

  return (
    <div className="border rounded-lg bg-background overflow-hidden">
      {/* Cabecera del quiz */}
      <Collapsible open={open} onOpenChange={setOpen}>
        <div className="flex items-center gap-2 px-3 py-2 bg-violet-50 dark:bg-violet-950/30 border-b border-violet-200 dark:border-violet-800">
          <Star className="w-3.5 h-3.5 text-violet-600 flex-shrink-0" />
          <CollapsibleTrigger asChild>
            <button className="flex-1 flex items-center gap-2 text-left min-w-0">
              <Input
                value={quiz.titulo}
                onChange={(e) => { e.stopPropagation(); updateField('titulo', e.target.value); }}
                onClick={(e) => e.stopPropagation()}
                className="h-7 text-sm font-medium border-0 bg-transparent px-0 focus-visible:ring-0 flex-1"
                placeholder="Nombre del quiz"
              />
              <Badge variant="outline" className="text-[10px] shrink-0">
                {quiz.preguntas.length} preg · {totalPuntos} pts
              </Badge>
              {open ? <ChevronUp className="w-3.5 h-3.5 text-muted-foreground shrink-0" /> : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
            </button>
          </CollapsibleTrigger>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0 text-destructive hover:text-destructive shrink-0"
            onClick={onRemove}
            disabled={!removable}
            title="Eliminar quiz"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>

        <CollapsibleContent>
          <div className="p-3 space-y-3">
            {/* Porcentaje de aprobación */}
            <div className="flex items-center gap-3 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg px-3 py-2">
              <Percent className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <div className="flex-1">
                <p className="text-xs font-semibold text-blue-700 dark:text-blue-400">Mínimo para aprobar</p>
              </div>
              <div className="flex items-center gap-1">
                <Input
                  type="number"
                  min={1}
                  max={100}
                  value={quiz.porcentaje_aprobacion}
                  onChange={(e) =>
                    updateField('porcentaje_aprobacion', Math.min(100, Math.max(1, parseInt(e.target.value) || 70)))
                  }
                  className="w-14 text-center text-sm font-bold border-blue-300 dark:border-blue-700 h-7"
                />
                <span className="text-sm font-bold text-blue-700 dark:text-blue-400">%</span>
              </div>
            </div>

            {/* Preguntas */}
            {quiz.preguntas.map((p, pIdx) => {
              const correctaMarcada = p.opciones.some((o) => o.es_correcta);
              return (
                <div
                  key={p.id}
                  className={cn(
                    'border rounded-lg p-3 space-y-2 bg-muted/20',
                    !correctaMarcada && 'border-orange-300 dark:border-orange-700'
                  )}
                >
                  <div className="flex items-start gap-2">
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-semibold text-muted-foreground bg-muted rounded px-1.5 py-0.5">
                          P{pIdx + 1}
                        </span>
                        {!correctaMarcada && (
                          <span className="text-[10px] text-orange-500 font-medium">⚠ Marca la respuesta correcta</span>
                        )}
                      </div>
                      <Input
                        value={p.pregunta}
                        onChange={(e) => updatePregunta(pIdx, { ...p, pregunta: e.target.value })}
                        placeholder="Escribe la pregunta aquí..."
                        className="text-sm h-8"
                      />
                    </div>
                    <div className="flex flex-col items-center gap-0.5 shrink-0">
                      <Label className="text-[9px] text-muted-foreground text-center leading-tight">Pts</Label>
                      <Input
                        type="number"
                        min={1}
                        max={100}
                        value={p.puntos}
                        onChange={(e) =>
                          updatePregunta(pIdx, { ...p, puntos: Math.max(1, parseInt(e.target.value) || 1) })
                        }
                        className="w-12 text-center text-sm font-bold h-8"
                      />
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-destructive h-8 w-8 p-0 mt-5 shrink-0"
                      onClick={() => removePregunta(pIdx)}
                      disabled={quiz.preguntas.length === 1}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>

                  {/* Opciones */}
                  <div className="space-y-1">
                    {p.opciones.map((o, oIdx) => (
                      <div
                        key={o.id}
                        className={cn(
                          'flex items-center gap-2 rounded px-2 py-1 transition-colors',
                          o.es_correcta ? 'bg-green-50 dark:bg-green-950/30' : 'bg-transparent'
                        )}
                      >
                        <button
                          type="button"
                          onClick={() => setCorrectOpcion(pIdx, oIdx)}
                          className={cn(
                            'shrink-0 w-4 h-4 rounded-full border-2 flex items-center justify-center transition-all',
                            o.es_correcta
                              ? 'border-green-500 bg-green-500 text-white'
                              : 'border-muted-foreground/40 hover:border-green-400'
                          )}
                          title={o.es_correcta ? 'Respuesta correcta' : 'Marcar como correcta'}
                        >
                          {o.es_correcta
                            ? <CheckCircle2 className="w-3 h-3" />
                            : <Circle className="w-2.5 h-2.5 opacity-0" />}
                        </button>
                        <Input
                          value={o.texto}
                          onChange={(e) => updateOpcionTexto(pIdx, oIdx, e.target.value)}
                          placeholder={`Opción ${oIdx + 1}`}
                          className={cn('flex-1 h-7 text-sm', o.es_correcta && 'border-green-300 dark:border-green-700')}
                        />
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive shrink-0"
                          onClick={() => removeOpcion(pIdx, oIdx)}
                          disabled={p.opciones.length <= 2}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 text-xs gap-1 text-muted-foreground"
                      onClick={() => addOpcion(pIdx)}
                    >
                      <Plus className="w-3 h-3" /> Agregar opción
                    </Button>
                  </div>
                </div>
              );
            })}

            <Button
              size="sm"
              variant="outline"
              className="w-full h-8 text-xs gap-1 border-dashed"
              onClick={addPregunta}
            >
              <Plus className="w-3 h-3" /> Agregar pregunta
            </Button>
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
};

// ── Sub-componente: Editor de Video ────────────────────────────────────────

const VideoEditor = ({
  video,
  onChange,
  onRemove,
  removable,
}: {
  video: VideoItem;
  onChange: (updated: VideoItem) => void;
  onRemove: () => void;
  removable: boolean;
}) => (
  <div className="border rounded-lg p-3 space-y-2 bg-background">
    <div className="flex items-center gap-2">
      <Video className="w-3.5 h-3.5 text-blue-500 shrink-0" />
      <Input
        value={video.titulo}
        onChange={(e) => onChange({ ...video, titulo: e.target.value })}
        placeholder="Título del video"
        className="flex-1 h-7 text-sm"
      />
      <Button
        size="sm"
        variant="ghost"
        className="h-7 w-7 p-0 text-destructive hover:text-destructive shrink-0"
        onClick={onRemove}
        disabled={!removable}
      >
        <Trash2 className="w-3.5 h-3.5" />
      </Button>
    </div>
    <div className="flex gap-2">
      <div className="flex-1 relative">
        <Link2 className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
        <Input
          value={video.url}
          onChange={(e) => onChange({ ...video, url: e.target.value })}
          placeholder="URL del video (YouTube, Vimeo, etc.)"
          className="pl-7 h-7 text-sm"
        />
      </div>
      <div className="flex items-center gap-1 shrink-0">
        <Input
          type="number"
          min={0}
          value={video.duracion_minutos}
          onChange={(e) => onChange({ ...video, duracion_minutos: Math.max(0, parseInt(e.target.value) || 0) })}
          className="w-16 text-center text-sm h-7"
          placeholder="0"
        />
        <span className="text-xs text-muted-foreground">min</span>
      </div>
    </div>
  </div>
);

// ── Componente principal: ModulosEditor ────────────────────────────────────

export const ModulosEditor = ({ capacitacionId, onChange }: ModulosEditorProps) => {
  const [modulos, setModulos] = useState<Modulo[]>([]);
  const [loading, setLoading] = useState(!!capacitacionId);
  const [saving, setSaving] = useState(false);
  const [openModulos, setOpenModulos] = useState<Set<string>>(new Set());

  // Si se pasa `capacitacionId`, cargar desde API; si no, inicializar builder local
  useEffect(() => {
    if (!capacitacionId) {
      const inicial = newModulo(0);
      setModulos([inicial]);
      setOpenModulos(new Set([inicial.id]));
      setLoading(false);
      return;
    }

    api.get(`/capacitaciones/${capacitacionId}/modulos`)
      .then((r) => {
        const list: Modulo[] = Array.isArray(r.data) ? r.data : [];
        if (list.length === 0) {
          const inicial = newModulo(0);
          setModulos([inicial]);
          setOpenModulos(new Set([inicial.id]));
        } else {
          setModulos(list);
          setOpenModulos(new Set([list[0].id]));
        }
      })
      .catch(() => {
        const inicial = newModulo(0);
        setModulos([inicial]);
        setOpenModulos(new Set([inicial.id]));
      })
      .finally(() => setLoading(false));
  }, [capacitacionId]);

  const toggleModulo = useCallback((id: string) => {
    setOpenModulos((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const addModulo = () => {
    const m = newModulo(modulos.length);
    setModulos((prev) => [...prev, m]);
    setOpenModulos((prev) => new Set([...prev, m.id]));
  };

  const removeModulo = (idx: number) =>
    setModulos((prev) => prev.filter((_, i) => i !== idx).map((m, i) => ({ ...m, orden: i })));

  const updateModulo = (idx: number, updated: Modulo) =>
    setModulos((prev) => prev.map((m, i) => (i === idx ? updated : m)));

  const addVideo = (mIdx: number) =>
    updateModulo(mIdx, {
      ...modulos[mIdx],
      videos: [...modulos[mIdx].videos, newVideo(modulos[mIdx].videos.length)],
    });

  const removeVideo = (mIdx: number, vIdx: number) =>
    updateModulo(mIdx, {
      ...modulos[mIdx],
      videos: modulos[mIdx].videos
        .filter((_, i) => i !== vIdx)
        .map((v, i) => ({ ...v, orden: i })),
    });

  const updateVideo = (mIdx: number, vIdx: number, updated: VideoItem) =>
    updateModulo(mIdx, {
      ...modulos[mIdx],
      videos: modulos[mIdx].videos.map((v, i) => (i === vIdx ? updated : v)),
    });

  const addQuiz = (mIdx: number) =>
    updateModulo(mIdx, {
      ...modulos[mIdx],
      quizzes: [...modulos[mIdx].quizzes, newQuiz(modulos[mIdx].quizzes.length)],
    });

  const removeQuiz = (mIdx: number, qIdx: number) =>
    updateModulo(mIdx, {
      ...modulos[mIdx],
      quizzes: modulos[mIdx].quizzes
        .filter((_, i) => i !== qIdx)
        .map((q, i) => ({ ...q, orden: i })),
    });

  const updateQuiz = (mIdx: number, qIdx: number, updated: Quiz) =>
    updateModulo(mIdx, {
      ...modulos[mIdx],
      quizzes: modulos[mIdx].quizzes.map((q, i) => (i === qIdx ? updated : q)),
    });

  const handleSave = async () => {
    // Validaciones
    for (let mIdx = 0; mIdx < modulos.length; mIdx++) {
      const m = modulos[mIdx];
      if (!m.titulo.trim()) {
        toast.error(`Módulo ${mIdx + 1}: el título es requerido`);
        return;
      }
      for (let vIdx = 0; vIdx < m.videos.length; vIdx++) {
        const v = m.videos[vIdx];
        if (!v.url.trim()) {
          toast.error(`Módulo ${mIdx + 1} › Video ${vIdx + 1}: la URL es requerida`);
          return;
        }
      }
      for (let qIdx = 0; qIdx < m.quizzes.length; qIdx++) {
        const q = m.quizzes[qIdx];
        for (let pIdx = 0; pIdx < q.preguntas.length; pIdx++) {
          const p = q.preguntas[pIdx];
          if (!p.pregunta.trim()) {
            toast.error(`Módulo ${mIdx + 1} › ${q.titulo} › Pregunta ${pIdx + 1}: texto requerido`);
            return;
          }
          if (!p.opciones.some((o) => o.es_correcta)) {
            toast.error(`Módulo ${mIdx + 1} › ${q.titulo} › Pregunta ${pIdx + 1}: marca la respuesta correcta`);
            return;
          }
          if (p.opciones.some((o) => !o.texto.trim())) {
            toast.error(`Módulo ${mIdx + 1} › ${q.titulo} › Pregunta ${pIdx + 1}: todas las opciones deben tener texto`);
            return;
          }
        }
      }
    }

    try {
      setSaving(true);
      if (capacitacionId) {
        await api.post(`/capacitaciones/${capacitacionId}/modulos`, { modulos });
        toast.success(`${modulos.length} módulo(s) guardados correctamente`);
      } else {
        toast.success(`${modulos.length} módulo(s) listos`);
      }
    } catch {
      toast.error('Error al guardar los módulos');
    } finally {
      setSaving(false);
    }
  };

  // Notificar cambios al padre (builder mode)
  useEffect(() => {
    if (onChange) onChange(modulos);
  }, [modulos, onChange]);

  if (loading) {
    return (
      <div className="py-8 text-center text-sm text-muted-foreground flex items-center justify-center gap-2">
        <Loader2 className="w-4 h-4 animate-spin" /> Cargando módulos...
      </div>
    );
  }

  const totalVideos = modulos.reduce((a, m) => a + m.videos.length, 0);
  const totalQuizzes = modulos.reduce((a, m) => a + m.quizzes.length, 0);
  const totalPreguntas = modulos.reduce((a, m) => m.quizzes.reduce((b, q) => b + q.preguntas.length, a), 0);

  return (
    <div className="space-y-4">
      {/* Resumen */}
      <div className="flex items-center justify-between bg-muted/40 rounded-lg px-4 py-2.5">
        <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap">
          <span className="flex items-center gap-1">
            <BookMarked className="w-3.5 h-3.5" />
            <strong className="text-foreground">{modulos.length}</strong> módulo{modulos.length !== 1 ? 's' : ''}
          </span>
          <span className="flex items-center gap-1">
            <Video className="w-3.5 h-3.5" />
            <strong className="text-foreground">{totalVideos}</strong> video{totalVideos !== 1 ? 's' : ''}
          </span>
          <span className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5" />
            <strong className="text-foreground">{totalQuizzes}</strong> quiz{totalQuizzes !== 1 ? 'zes' : ''} ·{' '}
            <strong className="text-foreground">{totalPreguntas}</strong> preguntas
          </span>
        </div>
        {capacitacionId && (
          <Button size="sm" onClick={handleSave} disabled={saving} className="gap-1.5 shrink-0">
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
            Guardar módulos
          </Button>
        )}
      </div>

      {/* Lista de módulos */}
      <div className="space-y-3">
        {modulos.map((m, mIdx) => {
          const isOpen = openModulos.has(m.id);
          return (
            <div key={m.id} className="border rounded-xl overflow-hidden shadow-sm">
              {/* Cabecera del módulo */}
              <div
                className="flex items-center gap-2 px-4 py-3 bg-primary/5 border-b cursor-pointer select-none"
                onClick={() => toggleModulo(m.id)}
              >
                <GripVertical className="w-4 h-4 text-muted-foreground/40 shrink-0" />
                <span className="text-xs font-semibold text-muted-foreground bg-primary/10 rounded px-2 py-0.5 shrink-0">
                  Módulo {mIdx + 1}
                </span>
                <Input
                  value={m.titulo}
                  onChange={(e) => { e.stopPropagation(); updateModulo(mIdx, { ...m, titulo: e.target.value }); }}
                  onClick={(e) => e.stopPropagation()}
                  placeholder="Título del módulo"
                  className="flex-1 h-8 text-sm font-medium border-0 bg-transparent px-1 focus-visible:ring-0"
                />
                <div className="flex items-center gap-2 shrink-0">
                  <Badge variant="secondary" className="text-[10px] gap-1 hidden sm:flex">
                    <Video className="w-2.5 h-2.5" />{m.videos.length}
                    <span className="mx-0.5 opacity-40">·</span>
                    <Star className="w-2.5 h-2.5" />{m.quizzes.length}
                  </Badge>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 w-7 p-0 text-destructive hover:text-destructive"
                    onClick={(e) => { e.stopPropagation(); removeModulo(mIdx); }}
                    disabled={modulos.length === 1}
                    title="Eliminar módulo"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                  {isOpen ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                </div>
              </div>

              {/* Cuerpo del módulo */}
              {isOpen && (
                <div className="p-4 space-y-5 bg-background">
                  {/* Descripción */}
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Descripción del módulo (opcional)</Label>
                    <Textarea
                      value={m.descripcion}
                      onChange={(e) => updateModulo(mIdx, { ...m, descripcion: e.target.value })}
                      placeholder="Objetivos, temas que cubre este módulo..."
                      rows={2}
                      className="text-sm resize-none"
                    />
                  </div>

                  {/* Videos */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Video className="w-4 h-4 text-blue-500" />
                        <span className="text-sm font-semibold">Videos</span>
                        <Badge variant="secondary" className="text-[10px]">{m.videos.length}</Badge>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 text-xs gap-1"
                        onClick={() => addVideo(mIdx)}
                      >
                        <Plus className="w-3 h-3" /> Agregar video
                      </Button>
                    </div>
                    <div className="space-y-2">
                      {m.videos.map((v, vIdx) => (
                        <VideoEditor
                          key={v.id}
                          video={v}
                          onChange={(updated) => updateVideo(mIdx, vIdx, updated)}
                          onRemove={() => removeVideo(mIdx, vIdx)}
                          removable={m.videos.length > 1}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Quizzes */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Star className="w-4 h-4 text-violet-500" />
                        <span className="text-sm font-semibold">Quizzes</span>
                        <Badge variant="secondary" className="text-[10px]">{m.quizzes.length}</Badge>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 text-xs gap-1"
                        onClick={() => addQuiz(mIdx)}
                      >
                        <Plus className="w-3 h-3" /> Agregar quiz
                      </Button>
                    </div>
                    <div className="space-y-2">
                      {m.quizzes.map((q, qIdx) => (
                        <QuizModuloEditor
                          key={q.id}
                          quiz={q}
                          onChange={(updated) => updateQuiz(mIdx, qIdx, updated)}
                          onRemove={() => removeQuiz(mIdx, qIdx)}
                          removable={m.quizzes.length > 1}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Agregar módulo */}
      <Button
        variant="outline"
        className="w-full gap-2 border-dashed h-10"
        onClick={addModulo}
      >
        <Plus className="w-4 h-4" />
        Agregar módulo
      </Button>
    </div>
  );
};
