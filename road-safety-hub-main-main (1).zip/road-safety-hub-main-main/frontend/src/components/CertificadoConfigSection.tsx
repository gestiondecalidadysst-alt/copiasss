import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAppStore, DEFAULT_CERTIFICATE_DESIGN } from '@/stores/appStore';
import type { CertificateFieldConfig, CertificateDesign } from '@/stores/appStore';
import {
  savePdfTemplate, loadPdfTemplate, deletePdfTemplate,
  saveSignatureImage, loadSignatureImage, deleteSignatureImage,
  saveFooterLogo, loadFooterLogos, deleteFooterLogo,
} from '@/utils/certificateTemplateStorage';
import { toast } from 'sonner';
import { saveCertificadoConfigBackend, loadCertificadoConfigBackend } from '@/services/configuracionService';
import {
  Upload, X, FileText, CheckCircle2, Circle, RotateCcw,
  Palette, AlignLeft, Image, Star, Eye, Pen,
} from 'lucide-react';

// Mapa CSS de familias tipográficas
const FONT_CSS: Record<string, string> = {
  helvetica: 'Arial, Helvetica, sans-serif',
  times:     '"Times New Roman", Times, serif',
  courier:   '"Courier New", Courier, monospace',
};

// Escala de puntos PDF a px CSS proporcional (diploma 11"×8.5" mostrado ≈1000px de ancho)
const PT_SCALE = 1000 / 792;
const ptToPx = (pt: number) => pt * PT_SCALE;

// ─── Componente Vista Previa ──────────────────────────────────────────────
interface PreviewProps {
  design: CertificateDesign;
  fields: CertificateFieldConfig[];
  companyName: string;
  companyLogo: string | null;
  hasTemplate: boolean;
  signatureImage: string | null;
  footerLogos: Array<string | null>;
}

export const CertificadoPreview = ({ design, fields, companyName, companyLogo, hasTemplate, signatureImage, footerLogos }: PreviewProps) => {
  const nombreCompleto = 'Juan Carlos Pérez';
  const activeFields = fields.filter((f) => f.enabled && f.key !== 'nombre' && f.key !== 'apellido');
  const fontFamily = FONT_CSS[design.fontFamily ?? 'helvetica'];

  // Tamaños escalados a la vista previa
  const tSizePx  = ptToPx(design.titleFontSize  ?? 22);
  const nSizePx  = ptToPx(design.nameFontSize   ?? 24);
  const bSizePx  = ptToPx(design.bodyFontSize   ?? 12);
  const csSizePx = ptToPx(design.courseFontSize ?? 14);
  const logoHPx  = ptToPx(design.logoHeight     ?? 62);
  const fLogoHPx = ptToPx(design.footerLogoHeight ?? 32);

  const sampleValue = (key: string) => {
    if (key === 'documento') return '12.345.678';
    if (key === 'fecha') return new Date().toLocaleDateString('es-CO', { day: '2-digit', month: 'long', year: 'numeric' });
    if (key === 'calificacion') return '95 / 100';
    return '';
  };

  return (
    <div
      className="relative w-full select-none overflow-hidden"
      style={{
        aspectRatio: '11 / 8.5',
        backgroundColor: design.backgroundColor,
        fontFamily,
      }}
    >
      {/* Bordes */}
      <div className="absolute inset-[2.2%] border-[3px]" style={{ borderColor: design.borderColor }} />
      <div className="absolute inset-[3.5%] border" style={{ borderColor: design.borderColor }} />

      {/* Número de certificado (superior derecho) */}
      {design.showCertNumber && (
        <div className="absolute top-[5%] right-[5%]" style={{ color: design.textColor, fontSize: 'clamp(5px, 0.75vw, 9px)' }}>
          {design.numberPrefix}000001
        </div>
      )}

      <div className="absolute inset-[5%] flex flex-col justify-between" style={{ gap: '1%' }}>
        {/* CABECERA: logo(s) izquierda + nombre empresa */}
        <div className="flex flex-col gap-[0.5%]">
          <div className="flex items-end gap-2">
            {design.showSystemLogo && companyLogo && (
              <img src={companyLogo} alt="logo" className="object-contain" style={{ height: logoHPx, maxWidth: logoHPx * 3 }} />
            )}
            {design.certLogoBase64 && (
              <img src={design.certLogoBase64} alt="cert-logo" className="object-contain" style={{ height: logoHPx * 0.75, maxWidth: logoHPx * 2.5 }} />
            )}
          </div>
          <p className="font-bold tracking-widest uppercase" style={{ color: design.accentColor, fontSize: 'clamp(5px, 0.85vw, 9px)' }}>
            {companyName}
          </p>
        </div>

        {/* Línea + Título + Línea */}
        <div className="text-center">
          <div className="border-t-2 w-full mb-1" style={{ borderColor: design.accentColor }} />
          <h1 className="font-bold tracking-wider" style={{ color: design.titleColor, fontSize: tSizePx, lineHeight: 1.1, wordBreak: 'break-word' }}>
            {design.certificateTitle}
          </h1>
          <div className="border-t-2 w-full mt-1" style={{ borderColor: design.accentColor }} />
        </div>

        {/* Cuerpo */}
        <div className="text-center flex flex-col items-center" style={{ gap: '0.7%' }}>
          <p style={{ color: design.textColor, fontSize: bSizePx, wordBreak: 'break-word' }}>{design.certifyText}</p>
          <p className="font-bold" style={{ color: design.nameColor, fontSize: nSizePx, wordBreak: 'break-word', lineHeight: 1.1 }}>{nombreCompleto}</p>
          <div className="border-b w-[40%]" style={{ borderColor: design.nameColor }} />
          {/* Documento debajo del nombre */}
          {fields.find((f) => f.enabled && f.key === 'documento') && (
            <p style={{ color: design.textColor, fontSize: bSizePx * 0.92, wordBreak: 'break-word' }}>
              <span>{fields.find((f) => f.key === 'documento')!.label}: </span>
              <span className="font-bold" style={{ color: design.titleColor }}>12.345.678</span>
            </p>
          )}
          <p style={{ color: design.textColor, fontSize: bSizePx * 0.92, wordBreak: 'break-word', marginTop: '0.5%' }}>{design.courseIntroText}</p>
          <p className="font-semibold" style={{ color: design.titleColor, fontSize: csSizePx, wordBreak: 'break-word', lineHeight: 1.15 }}>
            &ldquo;Manejo Defensivo en Ciudad&rdquo;
          </p>
          {/* Calificación debajo del nombre del curso */}
          {fields.find((f) => f.enabled && f.key === 'calificacion') && (
            <p style={{ color: design.textColor, fontSize: bSizePx * 0.92, wordBreak: 'break-word' }}>
              <span>{fields.find((f) => f.key === 'calificacion')!.label}: </span>
              <span className="font-bold" style={{ color: design.titleColor }}>95 / 100</span>
            </p>
          )}
          {/* Fecha más abajo */}
          {fields.find((f) => f.enabled && f.key === 'fecha') && (
            <p style={{ color: design.textColor, fontSize: bSizePx * 0.92, wordBreak: 'break-word', marginTop: '1%' }}>
              <span>{fields.find((f) => f.key === 'fecha')!.label}: </span>
              <span>{new Date().toLocaleDateString('es-CO', { day: '2-digit', month: 'long', year: 'numeric' })}</span>
            </p>
          )}
        </div>

        {/* PIE: logos izquierda + firma derecha */}
        <div className="flex justify-between items-end">
          {/* Logos pie de página */}
          <div className="flex items-end gap-1">
            {footerLogos.map((src, i) =>
              src ? (
                <img key={i} src={src} alt={`footer-${i}`} className="object-contain" style={{ height: fLogoHPx, maxWidth: fLogoHPx * 3 }} />
              ) : null
            )}
          </div>
          {/* Firma */}
          <div className="flex flex-col items-center">
            {signatureImage && (
              <img src={signatureImage} alt="firma" className="object-contain mb-0.5" style={{ height: 'clamp(12px, 2.5vw, 28px)', maxWidth: '100px' }} />
            )}
            <div className="w-[12vw] max-w-28 border-b" style={{ borderColor: design.textColor }} />
            <p style={{ color: design.textColor, fontSize: 'clamp(5px, 0.7vw, 8px)' }}>{design.signatureName}</p>
            <p className="font-semibold" style={{ color: design.accentColor, fontSize: 'clamp(5px, 0.7vw, 8px)' }}>
              {design.signatureTitle || companyName}
            </p>
          </div>
        </div>

        {/* Texto pie de página */}
        {design.footerText && (
          <p className="text-center" style={{ color: design.textColor, fontSize: 'clamp(4px, 0.65vw, 7px)' }}>{design.footerText}</p>
        )}
      </div>

      {/* Badge plantilla */}
      {hasTemplate && (
        <div className="absolute top-[5%] left-[5%] bg-green-100 text-green-700 text-[0.65vw] px-2 py-0.5 rounded-full font-medium">
          Plantilla PDF activa
        </div>
      )}
    </div>
  );
};

// ─── Componente principal ────────────────────────────────────────────────
const SizeSlider = ({
  label, value, min, max, unit = 'pt', onChange,
}: { label: string; value: number; min: number; max: number; unit?: string; onChange: (v: number) => void }) => (
  <div className="space-y-1">
    <div className="flex items-center justify-between">
      <Label className="text-xs">{label}</Label>
      <span className="text-xs font-mono text-muted-foreground">{value}{unit}</span>
    </div>
    <input
      type="range"
      min={min}
      max={max}
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      className="w-full h-1.5 accent-primary cursor-pointer"
    />
  </div>
);

const ColorField = ({
  label, value, onChange,
}: { label: string; value: string; onChange: (v: string) => void }) => (
  <div className="flex items-center gap-2">
    <input
      type="color"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-8 h-8 rounded cursor-pointer border border-border p-0.5"
    />
    <div className="flex-1">
      <Label className="text-xs">{label}</Label>
      <Input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-7 text-xs font-mono mt-0.5"
        maxLength={7}
      />
    </div>
  </div>
);

const CertificadoConfigSection = () => {
  const {
    certificateConfig, setCertificateConfig,
    companyName, companyLogo,
  } = useAppStore();

  const [fields, setFields] = useState<CertificateFieldConfig[]>(certificateConfig.fields);
  const [design, setDesign] = useState<CertificateDesign>(
    { ...DEFAULT_CERTIFICATE_DESIGN, ...certificateConfig.design }
  );
  const [certTemplatePdf, setCertTemplatePdf] = useState<string | null>(null);
  const [certTemplateName, setCertTemplateName] = useState(certificateConfig.templateName);
  const [signatureImage, setSignatureImage] = useState<string | null>(null);
  const [signatureName, setSignatureName] = useState('');
  const [footerLogos, setFooterLogos] = useState<Array<string | null>>([null, null, null]);
  const [saving, setSaving] = useState(false);

  const certPdfInputRef = useRef<HTMLInputElement>(null);
  const certLogoInputRef = useRef<HTMLInputElement>(null);
  const signatureInputRef = useRef<HTMLInputElement>(null);
  const footerLogoRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  useEffect(() => {
    loadPdfTemplate().then((s) => { if (s) { setCertTemplatePdf(s.base64); setCertTemplateName(s.name); } });
    loadSignatureImage().then((s) => { if (s) { setSignatureImage(s.base64); setSignatureName(s.name); } });
    loadFooterLogos().then((logos) => setFooterLogos(logos.map((l) => l?.base64 ?? null)));
    // Cargar configuración guardada en el backend (tiene prioridad sobre localStorage)
    loadCertificadoConfigBackend().then((saved) => {
      if (saved) {
        setDesign((prev) => ({ ...prev, ...saved.design }));
        setFields(saved.fields);
      }
    });
  }, []);

  const setD = (patch: Partial<CertificateDesign>) =>
    setDesign((prev) => ({ ...prev, ...patch }));

  // ── PDF Template ──
  const handleCertPdfUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.type !== 'application/pdf') { toast.error('Selecciona un archivo PDF'); return; }
    if (file.size > 10 * 1024 * 1024) { toast.error('El PDF debe pesar menos de 10 MB'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => { setCertTemplatePdf(ev.target?.result as string); setCertTemplateName(file.name); };
    reader.readAsDataURL(file);
  };

  const removeCertTemplate = () => {
    setCertTemplatePdf(null); setCertTemplateName('');
    if (certPdfInputRef.current) certPdfInputRef.current.value = '';
    deletePdfTemplate();
  };

  // ── Logo del diploma ──
  const handleCertLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { toast.error('Selecciona una imagen'); return; }
    if (file.size > 2 * 1024 * 1024) { toast.error('La imagen debe pesar menos de 2 MB'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => setD({ certLogoBase64: ev.target?.result as string, certLogoName: file.name });
    reader.readAsDataURL(file);
  };

  // ── Firma ──
  const handleSignatureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { toast.error('Selecciona una imagen (PNG recomendado)'); return; }
    if (file.size > 1 * 1024 * 1024) { toast.error('La firma debe pesar menos de 1 MB'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => { setSignatureImage(ev.target?.result as string); setSignatureName(file.name); };
    reader.readAsDataURL(file);
  };

  const removeSignature = () => {
    setSignatureImage(null); setSignatureName('');
    if (signatureInputRef.current) signatureInputRef.current.value = '';
    deleteSignatureImage();
  };

  // ── Logos pie de página ──
  const handleFooterLogoUpload = (idx: number) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { toast.error('Selecciona una imagen'); return; }
    if (file.size > 1 * 1024 * 1024) { toast.error('El logo debe pesar menos de 1 MB'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const b64 = ev.target?.result as string;
      setFooterLogos((prev) => { const next = [...prev]; next[idx] = b64; return next; });
    };
    reader.readAsDataURL(file);
  };

  const removeFooterLogoLocal = (idx: number) => {
    setFooterLogos((prev) => { const next = [...prev]; next[idx] = null; return next; });
    if (footerLogoRefs[idx].current) footerLogoRefs[idx].current!.value = '';
    deleteFooterLogo(idx);
  };

  // ── Toggle campo ──
  const toggleField = (key: CertificateFieldConfig['key']) =>
    setFields((prev) => prev.map((f) => f.key === key ? { ...f, enabled: !f.enabled } : f));

  const updateFieldLabel = (key: CertificateFieldConfig['key'], label: string) =>
    setFields((prev) => prev.map((f) => f.key === key ? { ...f, label } : f));

  // ── Guardar ──
  const handleSave = async () => {
    setSaving(true);
    try {
      if (certTemplatePdf) await savePdfTemplate(certTemplatePdf, certTemplateName);
      if (signatureImage) await saveSignatureImage(signatureImage, signatureName || 'firma');
      for (let i = 0; i < 3; i++) {
        if (footerLogos[i]) await saveFooterLogo(i, footerLogos[i]!, `footer-logo-${i}`);
      }
      // Guardar en localStorage (store local)
      setCertificateConfig({ templatePdf: null, templateName: certTemplateName, fields, design });
      // Guardar en el backend (Supabase)
      await saveCertificadoConfigBackend(design, fields);
      toast.success('Configuración del diploma guardada');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      toast.error(`Error al guardar: ${msg}`);
    } finally {
      setSaving(false);
    }
  };

  const resetDesign = () => setDesign({ ...DEFAULT_CERTIFICATE_DESIGN });

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">

      {/* ── Panel izquierdo: opciones ── */}
      <div className="space-y-4">
        <Tabs defaultValue="diseno">
          <TabsList className="grid grid-cols-4 h-9">
            <TabsTrigger value="diseno" className="text-xs gap-1"><Palette className="w-3 h-3" />Diseño</TabsTrigger>
            <TabsTrigger value="contenido" className="text-xs gap-1"><AlignLeft className="w-3 h-3" />Texto</TabsTrigger>
            <TabsTrigger value="logos" className="text-xs gap-1"><Image className="w-3 h-3" />Logos</TabsTrigger>
            <TabsTrigger value="campos" className="text-xs gap-1"><Star className="w-3 h-3" />Campos</TabsTrigger>
          </TabsList>

          {/* ── Tab: Diseño ── */}
          <TabsContent value="diseno" className="space-y-4 pt-3">
            <div className="grid grid-cols-2 gap-3">
              <ColorField label="Fondo" value={design.backgroundColor} onChange={(v) => setD({ backgroundColor: v })} />
              <ColorField label="Borde" value={design.borderColor} onChange={(v) => setD({ borderColor: v })} />
              <ColorField label="Título" value={design.titleColor} onChange={(v) => setD({ titleColor: v })} />
              <ColorField label="Nombre conductor" value={design.nameColor} onChange={(v) => setD({ nameColor: v })} />
              <ColorField label="Texto general" value={design.textColor} onChange={(v) => setD({ textColor: v })} />
              <ColorField label="Acento / dorado" value={design.accentColor} onChange={(v) => setD({ accentColor: v })} />
            </div>

            {/* Selector de tipografía */}
            <div className="space-y-2">
              <Label className="text-xs">Tipografía del diploma</Label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { key: 'helvetica', label: 'Helvética', css: 'Arial, sans-serif' },
                  { key: 'times',     label: 'Times',     css: '"Times New Roman", serif' },
                  { key: 'courier',   label: 'Courier',   css: '"Courier New", monospace' },
                ].map(({ key, label, css }) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setD({ fontFamily: key as 'helvetica' | 'times' | 'courier' })}
                    className={`p-2 border rounded-lg text-center transition-colors ${
                      (design.fontFamily ?? 'helvetica') === key
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-border hover:border-primary/50'
                    }`}
                    style={{ fontFamily: css }}
                  >
                    <p className="text-sm font-bold">Aa</p>
                    <p className="text-[11px] mt-0.5">{label}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Tamaños de letra */}
            <div className="space-y-3 pt-1">
              <Label className="text-xs font-semibold text-foreground">Tamaños de letra</Label>
              <SizeSlider label="Título del diploma"      value={design.titleFontSize  ?? 22} min={10} max={36} onChange={(v) => setD({ titleFontSize:  v })} />
              <SizeSlider label="Nombre del conductor"   value={design.nameFontSize   ?? 24} min={12} max={40} onChange={(v) => setD({ nameFontSize:   v })} />
              <SizeSlider label="Texto general"          value={design.bodyFontSize   ?? 12} min={7}  max={20} onChange={(v) => setD({ bodyFontSize:   v })} />
              <SizeSlider label="Nombre del curso"       value={design.courseFontSize ?? 14} min={8}  max={24} onChange={(v) => setD({ courseFontSize: v })} />
            </div>

            {/* Tamaños de logos */}
            <div className="space-y-3 pt-1">
              <Label className="text-xs font-semibold text-foreground">Tamaños de logos</Label>
              <SizeSlider label="Logo superior (altura)" value={design.logoHeight       ?? 62} min={30} max={120} onChange={(v) => setD({ logoHeight:       v })} />
              <SizeSlider label="Logos pie (altura)"     value={design.footerLogoHeight ?? 32} min={16} max={70}  onChange={(v) => setD({ footerLogoHeight: v })} />
            </div>

            <Button variant="outline" size="sm" className="gap-1 text-xs" onClick={resetDesign}>
              <RotateCcw className="w-3 h-3" /> Restablecer
            </Button>
          </TabsContent>

          {/* ── Tab: Texto ── */}
          <TabsContent value="contenido" className="space-y-3 pt-3">
            <div className="space-y-1.5">
              <Label className="text-xs">Título del diploma</Label>
              <Input value={design.certificateTitle} onChange={(e) => setD({ certificateTitle: e.target.value })} className="text-sm" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Texto de certificación</Label>
              <Input value={design.certifyText} onChange={(e) => setD({ certifyText: e.target.value })} className="text-sm" placeholder="Se certifica que:" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Introducción al curso</Label>
              <Input value={design.courseIntroText} onChange={(e) => setD({ courseIntroText: e.target.value })} className="text-sm" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Nombre del firmante</Label>
                <Input value={design.signatureName} onChange={(e) => setD({ signatureName: e.target.value })} className="text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Título del firmante</Label>
                <Input value={design.signatureTitle} onChange={(e) => setD({ signatureTitle: e.target.value })} className="text-sm" placeholder={companyName} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Texto pie de diploma</Label>
              <Input value={design.footerText} onChange={(e) => setD({ footerText: e.target.value })} className="text-sm" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Prefijo de número</Label>
                <Input value={design.numberPrefix} onChange={(e) => setD({ numberPrefix: e.target.value })} className="text-sm font-mono" placeholder="CERT-" />
              </div>
              <div className="flex items-center gap-2 pt-5">
                <label className="flex items-center gap-2 cursor-pointer text-sm">
                  <input type="checkbox" checked={design.showCertNumber} onChange={(e) => setD({ showCertNumber: e.target.checked })} className="w-4 h-4 accent-primary" />
                  Mostrar número
                </label>
              </div>
            </div>
          </TabsContent>

          {/* ── Tab: Logos ── */}
          <TabsContent value="logos" className="space-y-4 pt-3">
            {/* Logo del sistema */}
            <div className="flex items-center gap-3 p-3 border border-border rounded-lg">
              {companyLogo
                ? <img src={companyLogo} alt="system" className="w-10 h-10 object-contain" />
                : <div className="w-10 h-10 bg-muted rounded flex items-center justify-center text-muted-foreground text-xs">Logo</div>
              }
              <div className="flex-1">
                <p className="text-sm font-medium">Logo del sistema</p>
                <p className="text-xs text-muted-foreground">Configurado en Branding</p>
              </div>
              <label className="flex items-center gap-2 cursor-pointer text-sm">
                <input type="checkbox" checked={design.showSystemLogo} onChange={(e) => setD({ showSystemLogo: e.target.checked })} className="w-4 h-4 accent-primary" />
                Incluir
              </label>
            </div>

            {/* Logo exclusivo del diploma */}
            <div className="space-y-2">
              <Label className="text-xs">Logo exclusivo del diploma (superior izquierda)</Label>
              {design.certLogoBase64 ? (
                <div className="flex items-center gap-3 border border-border rounded-lg p-3 bg-muted/40">
                  <img src={design.certLogoBase64} alt="cert-logo" className="w-12 h-12 object-contain" />
                  <div className="flex-1 min-w-0"><p className="text-sm font-medium truncate">{design.certLogoName}</p></div>
                  <div className="flex gap-2">
                    <button onClick={() => certLogoInputRef.current?.click()} className="text-xs text-primary hover:underline">Cambiar</button>
                    <button onClick={() => setD({ certLogoBase64: null, certLogoName: '' })} className="p-1 text-red-500 hover:bg-red-50 rounded"><X className="w-4 h-4" /></button>
                  </div>
                </div>
              ) : (
                <div className="border-2 border-dashed border-border rounded-lg p-4 text-center hover:border-primary transition-colors cursor-pointer" onClick={() => certLogoInputRef.current?.click()}>
                  <Upload className="w-5 h-5 text-muted-foreground mx-auto mb-1" />
                  <p className="text-xs text-muted-foreground">PNG, JPG (máx 2 MB)</p>
                </div>
              )}
              <input ref={certLogoInputRef} type="file" accept="image/*" onChange={handleCertLogoUpload} className="hidden" />
            </div>

            {/* Imagen de firma */}
            <div className="space-y-2 border-t border-border pt-3">
              <Label className="text-xs flex items-center gap-1"><Pen className="w-3 h-3" /> Imagen de firma</Label>
              {signatureImage ? (
                <div className="flex items-center gap-3 border border-border rounded-lg p-3 bg-muted/40">
                  <img src={signatureImage} alt="firma" className="h-10 w-auto object-contain" />
                  <div className="flex-1 min-w-0"><p className="text-sm font-medium truncate">{signatureName || 'Firma cargada'}</p></div>
                  <div className="flex gap-2">
                    <button onClick={() => signatureInputRef.current?.click()} className="text-xs text-primary hover:underline">Cambiar</button>
                    <button onClick={removeSignature} className="p-1 text-red-500 hover:bg-red-50 rounded"><X className="w-4 h-4" /></button>
                  </div>
                </div>
              ) : (
                <div className="border-2 border-dashed border-border rounded-lg p-4 text-center hover:border-primary transition-colors cursor-pointer" onClick={() => signatureInputRef.current?.click()}>
                  <Pen className="w-5 h-5 text-muted-foreground mx-auto mb-1" />
                  <p className="text-xs text-muted-foreground">PNG transparente recomendado (máx 1 MB)</p>
                </div>
              )}
              <input ref={signatureInputRef} type="file" accept="image/*" onChange={handleSignatureUpload} className="hidden" />
            </div>

            {/* Logos pie de página */}
            <div className="space-y-2 border-t border-border pt-3">
              <Label className="text-xs">Logos pie de página (hasta 3 — inferior izquierda)</Label>
              <div className="grid grid-cols-3 gap-2">
                {[0, 1, 2].map((idx) => (
                  <div key={idx} className="space-y-1">
                    <p className="text-xs text-muted-foreground text-center">Logo {idx + 1}</p>
                    {footerLogos[idx] ? (
                      <div className="flex flex-col items-center gap-1 border border-border rounded-lg p-2 bg-muted/40">
                        <img src={footerLogos[idx]!} alt={`footer-${idx}`} className="h-8 object-contain" />
                        <div className="flex gap-1">
                          <button onClick={() => footerLogoRefs[idx].current?.click()} className="text-xs text-primary hover:underline">Cambiar</button>
                          <button onClick={() => removeFooterLogoLocal(idx)} className="text-xs text-red-500 hover:underline">Quitar</button>
                        </div>
                      </div>
                    ) : (
                      <div className="border-2 border-dashed border-border rounded-lg p-3 text-center hover:border-primary transition-colors cursor-pointer" onClick={() => footerLogoRefs[idx].current?.click()}>
                        <Upload className="w-4 h-4 text-muted-foreground mx-auto" />
                      </div>
                    )}
                    <input ref={footerLogoRefs[idx]} type="file" accept="image/*" onChange={handleFooterLogoUpload(idx)} className="hidden" />
                  </div>
                ))}
              </div>
            </div>

            {/* Plantilla PDF base */}
            <div className="space-y-2 border-t border-border pt-3">
              <Label className="text-xs">Plantilla PDF base <span className="text-muted-foreground">(opcional)</span></Label>
              {certTemplatePdf ? (
                <div className="flex items-center gap-3 border border-border rounded-lg p-3 bg-muted/40">
                  <FileText className="w-8 h-8 text-primary flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{certTemplateName}</p>
                    <p className="text-xs text-green-600">PDF cargado</p>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => certPdfInputRef.current?.click()} className="text-xs text-primary hover:underline">Cambiar</button>
                    <button onClick={removeCertTemplate} className="p-1 text-red-500 hover:bg-red-50 rounded"><X className="w-4 h-4" /></button>
                  </div>
                </div>
              ) : (
                <div className="border-2 border-dashed border-border rounded-lg p-4 text-center hover:border-primary transition-colors cursor-pointer" onClick={() => certPdfInputRef.current?.click()}>
                  <Upload className="w-5 h-5 text-muted-foreground mx-auto mb-1" />
                  <p className="text-xs text-muted-foreground">PDF (máx 10 MB) — reemplaza el diseño generado</p>
                </div>
              )}
              <input ref={certPdfInputRef} type="file" accept="application/pdf" onChange={handleCertPdfUpload} className="hidden" />
            </div>
          </TabsContent>

          {/* ── Tab: Campos ── */}
          <TabsContent value="campos" className="space-y-3 pt-3">
            <p className="text-xs text-muted-foreground">
              Activa o desactiva los campos que aparecerán en el diploma y personaliza su etiqueta.
            </p>
            {fields.map((field) => (
              <div key={field.key} className="flex items-center gap-3 border border-border rounded-lg p-3">
                <button type="button" onClick={() => toggleField(field.key)} className="flex-shrink-0">
                  {field.enabled
                    ? <CheckCircle2 className="w-5 h-5 text-primary" />
                    : <Circle className="w-5 h-5 text-muted-foreground" />}
                </button>
                <Input value={field.label} onChange={(e) => updateFieldLabel(field.key, e.target.value)} disabled={!field.enabled} className="h-8 text-sm flex-1" />
                <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded font-mono flex-shrink-0">
                  {`{{${field.key}}}`}
                </span>
              </div>
            ))}
          </TabsContent>
        </Tabs>

        <Button className="gradient-primary text-primary-foreground w-full" onClick={handleSave} disabled={saving}>
          {saving ? 'Guardando...' : 'Guardar configuración del diploma'}
        </Button>
      </div>

      {/* ── Panel derecho: vista previa ── */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4 text-muted-foreground" />
          <p className="text-sm font-medium text-muted-foreground">Vista previa en tiempo real</p>
        </div>
        <div className="border border-border rounded-xl overflow-hidden shadow-sm">
          <CertificadoPreview
            design={design}
            fields={fields}
            companyName={companyName}
            companyLogo={companyLogo}
            hasTemplate={!!certTemplatePdf}
            signatureImage={signatureImage}
            footerLogos={footerLogos}
          />
        </div>
        <p className="text-xs text-muted-foreground text-center">
          Los datos mostrados son de ejemplo.
        </p>
      </div>
    </div>
  );
};

export default CertificadoConfigSection;
