import { Navigate } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';

interface RoleProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: string | string[];
  fallback?: React.ReactNode;
}

/**
 * Componente para proteger rutas basadas en el rol del usuario
 * Si el usuario no tiene el rol requerido, redirige a /dashboard
 */
export const RoleProtectedRoute = ({
  children,
  requiredRole,
  fallback
}: RoleProtectedRouteProps) => {
  const { user, isAuthenticated } = useAuthStore();

  // Si no está autenticado, redirige a login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Si no se especifica un rol requerido, permite acceso
  if (!requiredRole) {
    return <>{children}</>;
  }

  // Verificar si el usuario tiene el rol requerido
  const rolesRequeridos = Array.isArray(requiredRole) ? requiredRole : [requiredRole];
  const tieneAcceso = rolesRequeridos.includes(user?.rol || '');

  if (!tieneAcceso) {
    // Mostrar fallback o redirigir a dashboard
    if (fallback) {
      return <>{fallback}</>;
    }
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
};

/**
 * Hook para verificar permisos del usuario
 */
export const useCanAccess = (requiredRole?: string | string[]) => {
  const { user, isAuthenticated } = useAuthStore();

  if (!isAuthenticated || !user) {
    return false;
  }

  if (!requiredRole) {
    return true;
  }

  const rolesRequeridos = Array.isArray(requiredRole) ? requiredRole : [requiredRole];
  return rolesRequeridos.includes(user.rol);
};

/**
 * Hook para verificar si el usuario es admin
 */
export const useIsAdmin = () => {
  const { user, isAuthenticated } = useAuthStore();
  return isAuthenticated && user?.rol === 'admin';
};

/**
 * Componente condicional que solo muestra contenido si el usuario tiene el rol requerido
 */
export const ConditionalRender = ({
  children,
  requiredRole,
}: {
  children: React.ReactNode;
  requiredRole?: string | string[];
}) => {
  const canAccess = useCanAccess(requiredRole);

  if (!canAccess) {
    return null;
  }

  return <>{children}</>;
};
