import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface KpiCardProps {
  title: string;
  value: string | number;
  icon: ReactNode;
  trend?: string;
  trendUp?: boolean;
  className?: string;
}

const KpiCard = ({ title, value, icon, trend, trendUp, className }: KpiCardProps) => (
  <div className={cn('bg-card rounded-xl border border-border p-5 animate-fade-in', className)}>
    <div className="flex items-start justify-between">
      <div>
        <p className="text-sm text-muted-foreground font-medium">{title}</p>
        <p className="text-3xl font-bold text-foreground mt-1">{value}</p>
        {trend && (
          <p className={cn('text-xs font-medium mt-2', trendUp ? 'text-success' : 'text-destructive')}>
            {trendUp ? '↑' : '↓'} {trend}
          </p>
        )}
      </div>
      <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
        {icon}
      </div>
    </div>
  </div>
);

export default KpiCard;
