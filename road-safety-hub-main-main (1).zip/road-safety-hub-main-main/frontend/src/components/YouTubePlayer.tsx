import { useEffect, useRef, useState } from 'react';

declare global {
  interface Window {
    YT: {
      Player: new (element: HTMLElement, options: object) => YTPlayer;
    };
    onYouTubeIframeAPIReady?: () => void;
  }
}

interface YTPlayer {
  getCurrentTime(): number;
  getDuration(): number;
  destroy(): void;
}

function extractYouTubeId(url: string): string | null {
  const patterns = [
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/watch\?(?:.*&)?v=([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}

interface YouTubePlayerProps {
  url: string;
  onProgress?: (percent: number) => void;
  onUnlock?: () => void;
  unlockThreshold?: number;
}

export const YouTubePlayer = ({
  url,
  onProgress,
  onUnlock,
  unlockThreshold = 80,
}: YouTubePlayerProps) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const playerRef = useRef<YTPlayer | null>(null);
  const unlockedRef = useRef(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [apiReady, setApiReady] = useState(!!window.YT?.Player);
  const [progress, setProgress] = useState(0);

  const videoId = extractYouTubeId(url);
  const directVideo = /\.(mp4|webm|ogg|mov|m4v)(\?.*)?$/i.test(url);

  // Cargar YouTube IFrame API
  useEffect(() => {
    if (directVideo) {
      setApiReady(true);
      return;
    }
    if (window.YT?.Player) {
      setApiReady(true);
      return;
    }
    const prev = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      prev?.();
      setApiReady(true);
    };
    if (!document.querySelector('script[src*="youtube.com/iframe_api"]')) {
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      document.head.appendChild(tag);
    }
    return () => {
      window.onYouTubeIframeAPIReady = prev;
    };
  }, []);

  // Crear el player cuando la API esté lista
  useEffect(() => {
    if (directVideo || !apiReady || !videoId || !containerRef.current) return;

    playerRef.current = new window.YT.Player(containerRef.current, {
      videoId,
      width: '100%',
      height: '100%',
      playerVars: { rel: 0, modestbranding: 1, enablejsapi: 1 },
    });

    intervalRef.current = setInterval(() => {
      try {
        const player = playerRef.current;
        if (!player?.getCurrentTime) return;
        const current = player.getCurrentTime();
        const duration = player.getDuration();
        if (duration > 0) {
          const pct = Math.round((current / duration) * 100);
          setProgress(pct);
          onProgress?.(pct);
          if (pct >= unlockThreshold && !unlockedRef.current) {
            unlockedRef.current = true;
            onUnlock?.();
          }
        }
      } catch {
        // Player aún no inicializado
      }
    }, 3000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      try { playerRef.current?.destroy(); } catch { /* ignore */ }
    };
  }, [apiReady, videoId, unlockThreshold, onProgress, onUnlock]);

  if (!videoId && !directVideo) {
    return (
      <div className="flex items-center justify-center h-48 bg-muted rounded-lg text-muted-foreground text-sm">
        URL de YouTube no válida
      </div>
    );
  }

  if (!apiReady) {
    return <div className="w-full aspect-video bg-muted animate-pulse rounded-lg" />;
  }

  if (directVideo) {
    return (
      <div className="space-y-2">
        <video
          controls
          className="w-full aspect-video rounded-lg bg-black"
          src={url}
          onTimeUpdate={(event) => {
            const target = event.currentTarget;
            const current = target.currentTime;
            const duration = target.duration;
            if (duration > 0) {
              const pct = Math.round((current / duration) * 100);
              setProgress(pct);
              onProgress?.(pct);
              if (pct >= unlockThreshold && !unlockedRef.current) {
                unlockedRef.current = true;
                onUnlock?.();
              }
            }
          }}
        />
        <div className="space-y-1 px-1">
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Progreso del video</span>
            <span className={progress >= unlockThreshold ? 'text-green-600 font-medium' : ''}>
              {progress}%
            </span>
          </div>
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-1000 ${
                progress >= unlockThreshold ? 'bg-green-500' : 'bg-primary'
              }`}
              style={{ width: `${progress}%` }}
            />
          </div>
          {progress < unlockThreshold && (
            <p className="text-xs text-muted-foreground">
              Ve al menos el {unlockThreshold}% del video para continuar
            </p>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="relative w-full aspect-video rounded-lg overflow-hidden bg-black">
        <div ref={containerRef} className="absolute inset-0 w-full h-full" />
      </div>
      <div className="space-y-1 px-1">
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>Progreso del video</span>
          <span className={progress >= unlockThreshold ? 'text-green-600 font-medium' : ''}>
            {progress}%
          </span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-1000 ${
              progress >= unlockThreshold ? 'bg-green-500' : 'bg-primary'
            }`}
            style={{ width: `${progress}%` }}
          />
        </div>
        {progress < unlockThreshold && (
          <p className="text-xs text-muted-foreground">
            Ve al menos el {unlockThreshold}% del video para continuar
          </p>
        )}
      </div>
    </div>
  );
};
