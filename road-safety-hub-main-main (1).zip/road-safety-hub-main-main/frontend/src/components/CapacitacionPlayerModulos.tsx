import { useState, useEffect, useCallback } from 'react';
import api from '@/services/api';
import { YouTubePlayer } from './YouTubePlayer';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import {
  CheckCircle2, ChevronRight, Loader2, Star, BookOpen, Award,
  Video, BookMarked, ExternalLink, Link2, AlertCircle, Lock,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

// ── Tipos ──────────────────────────────────────────────────────────────────

interface Opcion {
  id: string;
  texto: string;
  orden: number;
}
interface Pregunta {
  id: string;
  pregunta: string;
  puntos: number;
  orden: number;
  opciones: Opcion[];
}
interface QuizModulo {
  id: string;
  titulo: string;
  porcentaje_aprobacion: number;
  preguntas: Pregunta[];
}
interface VideoModulo {
  id: string;
  titulo: string;
  url: string;
  duracion_minutos: number;
}
interface Modulo {
  id: string;
  titulo: string;
  descripcion: string;
  orden: number;
  videos: VideoModulo[];
  quizzes: QuizModulo[];
}
interface QuizResultado {
  quiz_id: string;
  titulo: string;
  puntaje: number;
  aprobado: boolean;
  intentos_restantes: number;
}
interface ModuloResultado {
  nota: number;
  quizzes: QuizResultado[];
}

export interface AsignacionPlayerModulos {
  id: string;
  estado: string;
  progreso_modulos?: Record<string, unknown>;
  capacitacion: {
    titulo: string;
    descripcion?: string;
    modulos?: { id: string }[];
  };
}

interface Props {
  asignacion: AsignacionPlayerModulos;
  open: boolean;
  onClose: () => void;
  onComplete: (asignacionId: string, notaFinal: number) => void;
}

// ── Helpers ────────────────────────────────────────────────────────────────

const THRESHOLD = 80; // % del video para desbloquear siguiente

const notaColor = (nota: number) =>
  nota >= 8 ? 'text-green-600' : nota >= 5 ? 'text-yellow-600' : 'text-red-500';

const notaBg = (nota: number) =>
  nota >= 8 ? 'bg-green-50 border-green-200 dark:bg-green-950/30 dark:border-green-800'
    : nota >= 5 ? 'bg-yellow-50 border-yellow-200 dark:bg-yellow-950/30 dark:border-yellow-800'
    : 'bg-red-50 border-red-200 dark:bg-red-950/30 dark:border-red-800';

// ── Componente ─────────────────────────────────────────────────────────────

export const CapacitacionPlayerModulos = ({ asignacion, open, onClose, onComplete }: Props) => {
  // ── Estado global del player
  const [modulos, setModulos] = useState<Modulo[]>([]);
  const [loadingModulos, setLoadingModulos] = useState(true);
  const [moduloIdx, setModuloIdx] = useState(0);

  // ── Estado dentro de un módulo
  type ModuloStep = 'videos' | 'quizzes' | 'resultado_modulo';
  const [moduloStep, setModuloStep] = useState<ModuloStep>('videos');
  const [videoIdx, setVideoIdx] = useState(0);
  const [videoDesbloqueado, setVideoDesbloqueado] = useState(false);

  // ── Estado del quiz actual
  const [quizIdx, setQuizIdx] = useState(0);
  const [respuestas, setRespuestas] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [quizResultados, setQuizResultados] = useState<QuizResultado[]>([]);

  // ── Resultados acumulados por módulo
  const [moduloResultados, setModuloResultados] = useState<(ModuloResultado | null)[]>([]);
  const [notaFinal, setNotaFinal] = useState<number | null>(null);
  const [completado, setCompletado] = useState(false);
  const [savingFinal, setSavingFinal] = useState(false);

  // ── Cargar módulos al abrir
  useEffect(() => {
    if (!open) return;
    setLoadingModulos(true);
    setModuloIdx(0);
    setModuloStep('videos');
    setVideoIdx(0);
    setVideoDesbloqueado(false);
    setQuizIdx(0);
    setRespuestas({});
    setQuizResultados([]);
    setModuloResultados([]);
    setNotaFinal(null);
    setCompletado(false);

    api.get(`/portal/conductor/capacitaciones/${asignacion.id}/modulos`)
      .then(r => {
        let list: Modulo[] = Array.isArray(r.data.modulos) ? r.data.modulos : [];
        // Asegurar orden estable por campo `orden`
        list = list.slice().sort((a, b) => (a.orden ?? 0) - (b.orden ?? 0));
        setModulos(list);

        // Inicializar resultados por módulo según lo que devuelva el servidor
        const pm = r.data.progreso_modulos || {};
        const resultadosInit: (ModuloResultado | null)[] = new Array(list.length).fill(null);

        if (pm && Array.isArray(pm.modulos)) {
          for (let i = 0; i < list.length; i++) {
            const m = list[i];
            const mr = pm.modulos.find((x: any) => x.modulo_id === m.id);
            if (mr) {
              resultadosInit[i] = {
                nota: typeof mr.nota === 'number' ? mr.nota : 0,
                quizzes: Array.isArray(mr.quizzes) ? mr.quizzes : []
              };
            }
          }
        }

        setModuloResultados(resultadosInit);

        if (pm && typeof pm.nota_final === 'number') {
          setNotaFinal(pm.nota_final);
          setCompletado(true);
        } else {
          const firstIncomplete = resultadosInit.findIndex(r => r === null);
          // Si no hay módulos incompletos, iniciar en el primer módulo (índice 0)
          setModuloIdx(firstIncomplete !== -1 ? firstIncomplete : 0);
        }
      })
      .catch(() => toast.error('No se pudieron cargar los módulos'))
      .finally(() => setLoadingModulos(false));
  }, [open, asignacion.id]);

  // Resetear desbloqueo al cambiar de video
  useEffect(() => {
    setVideoDesbloqueado(false);
  }, [videoIdx, moduloIdx]);

  // Resetear respuestas al cambiar de quiz
  useEffect(() => {
    setRespuestas({});
  }, [quizIdx, moduloIdx]);

  const currentModulo = modulos[moduloIdx];
  const isVideoFile = (url: string) => /\.(mp4|webm|ogg|mov|m4v)(\?.*)?$/i.test(url);

  // ── Progreso de video → backend (cada 10%)
  const handleVideoProgress = useCallback(async (pct: number) => {
    if (!currentModulo) return;
    const video = currentModulo.videos[videoIdx];
    if (!video) return;
    if (pct > 0 && pct % 10 === 0) {
      try {
        await api.put(`/portal/conductor/capacitaciones/${asignacion.id}/modulos/video-progreso`, {
          modulo_id: currentModulo.id,
          video_id: video.id,
          progreso: pct,
        });
      } catch { /* silent */ }
    }
  }, [asignacion.id, currentModulo, videoIdx]);

  // ── Video alcanza 80% → desbloquear botón (sin detener video)
  const handleVideoUnlock = useCallback(() => {
    setVideoDesbloqueado(true);
  }, []);

  // ── Click en "Siguiente" dentro de videos
  const handleSiguienteVideo = async () => {
    if (!currentModulo) return;
    const video = currentModulo.videos[videoIdx];
    if (video) {
      try {
        await api.put(`/portal/conductor/capacitaciones/${asignacion.id}/modulos/video-progreso`, {
          modulo_id: currentModulo.id,
          video_id: video.id,
          progreso: 100,
        });
      } catch { /* silent */ }
    }

    if (videoIdx < currentModulo.videos.length - 1) {
      // Siguiente video del módulo
      setVideoIdx(v => v + 1);
    } else if (currentModulo.quizzes.length > 0) {
      // Pasar a quizzes
      setModuloStep('quizzes');
      setQuizIdx(0);
    } else {
      // Módulo sin quiz → completar módulo con nota máxima
      finalizarModulo([]);
    }
  };

  // ── Enviar respuestas del quiz actual
  const handleSubmitQuiz = async () => {
    if (!currentModulo) return;
    const quiz = currentModulo.quizzes[quizIdx];
    if (!quiz) return;

    const sinResponder = quiz.preguntas.some(p => !respuestas[p.id]);
    if (sinResponder) {
      toast.error('Responde todas las preguntas antes de enviar');
      return;
    }

    try {
      setSubmitting(true);
      const payload = quiz.preguntas.map(p => ({
        pregunta_id: p.id,
        opcion_id: respuestas[p.id],
      }));
      const res = await api.post(
        `/portal/conductor/capacitaciones/${asignacion.id}/modulos/quiz/responder`,
        { modulo_id: currentModulo.id, quiz_id: quiz.id, respuestas: payload }
      );

      const resultado: QuizResultado = {
        quiz_id: quiz.id,
        titulo: quiz.titulo,
        puntaje: res.data.puntaje,
        aprobado: res.data.aprobado,
        intentos_restantes: res.data.intentos_restantes,
      };
      const nuevosResultados = [...quizResultados, resultado];
      setQuizResultados(nuevosResultados);

      if (res.data.modulo_completado) {
        finalizarModulo(nuevosResultados, res.data.nota_modulo);
      } else if (quizIdx < currentModulo.quizzes.length - 1) {
        setQuizIdx(q => q + 1);
        toast.success(`Quiz completado — ${res.data.puntaje}%`);
      }
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { error?: string } } })?.response?.data?.error;
      toast.error(msg || 'Error al enviar el quiz');
    } finally {
      setSubmitting(false);
    }
  };

  // ── Cuando se terminan todos los quizzes del módulo
  const finalizarModulo = (resultados: QuizResultado[], notaModulo?: number) => {
    const nota = notaModulo
      ?? (resultados.length > 0
        ? Math.round((resultados.reduce((a, r) => a + r.puntaje, 0) / resultados.length) / 10 * 10) / 10
        : 10);
    setModuloResultados(prev => {
      const next = [...prev];
      next[moduloIdx] = { nota, quizzes: resultados };
      return next;
    });
    // Mostrar calificación al usuario inmediatamente
    toast.success(`Nota del módulo "${currentModulo?.titulo ?? ''}": ${nota.toFixed(1)}`);
    setModuloStep('resultado_modulo');
  };

  // ── Pasar al siguiente módulo (o calcular nota final si es el último)
  const finalizarCapacitacion = async (nf: number) => {
    setNotaFinal(nf);
    setCompletado(true);
    setSavingFinal(true);
    try {
      await api.post(`/portal/conductor/capacitaciones/${asignacion.id}/modulos/completar`, {
        modulos_resultados: modulos.map((mod, idx) => ({
          modulo_id: mod.id,
          nota: moduloResultados[idx]?.nota ?? 0,
          quizzes: moduloResultados[idx]?.quizzes ?? []
        }))
      });
    } catch {
      toast.error('No se pudo guardar el resultado final de la capacitación');
    } finally {
      setSavingFinal(false);
    }
    onComplete(asignacion.id, nf);
  };

  const handleSiguienteModulo = async () => {
    if (moduloIdx < modulos.length - 1) {
      setModuloIdx(m => m + 1);
      setModuloStep('videos');
      setVideoIdx(0);
      setVideoDesbloqueado(false);
      setQuizIdx(0);
      setRespuestas({});
      setQuizResultados([]);
    } else {
      const notas = moduloResultados.map(r => r?.nota ?? 0);
      const nf = Math.round((notas.reduce((a, b) => a + b, 0) / notas.length) * 10) / 10;
      await finalizarCapacitacion(nf);
    }
  };

  const allAnswered = currentModulo
    ? currentModulo.quizzes[quizIdx]?.preguntas.every(p => respuestas[p.id]) ?? false
    : false;

  // ── Render: cargando
  if (loadingModulos) {
    return (
      <Dialog open={open} onOpenChange={o => { if (!o) onClose(); }}>
        <DialogContent className="max-w-2xl" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle className="sr-only">Cargando capacitación</DialogTitle>
          </DialogHeader>
          <div className="py-16 flex items-center justify-center gap-2 text-muted-foreground">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span className="text-sm">Cargando módulos...</span>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={o => { if (!o) onClose(); }}>
      <DialogContent className="max-w-2xl max-h-[92vh] overflow-y-auto" aria-describedby={undefined}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <BookOpen className="w-5 h-5 text-primary shrink-0" />
            <span className="truncate">{asignacion.capacitacion.titulo}</span>
          </DialogTitle>
        </DialogHeader>

        {/* ── Stepper de módulos */}
        {!completado && (
          <div className="flex items-center gap-1 overflow-x-auto py-1 scrollbar-hide">
            {modulos.slice(0, moduloIdx + 1).map((m, i) => {
              const done = moduloResultados[i] != null;
              const active = i === moduloIdx && !completado;
              return (
                <div key={m.id} className="flex items-center gap-1 shrink-0">
                  <div className={cn(
                    'flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium transition-colors',
                    done ? 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400'
                      : active ? 'bg-primary/10 text-primary ring-1 ring-primary/30'
                      : 'bg-muted text-muted-foreground'
                  )}>
                    {done
                      ? <CheckCircle2 className="w-3 h-3" />
                      : <BookMarked className="w-3 h-3" />}
                    <span className="hidden sm:inline truncate max-w-[100px]">{m.titulo}</span>
                    <span className="sm:hidden">{i + 1}</span>
                    {done && moduloResultados[i] && (
                      <span className={cn('font-bold', notaColor(moduloResultados[i]!.nota))}>
                        {moduloResultados[i]!.nota.toFixed(1)}
                      </span>
                    )}
                  </div>
                  {i < moduloIdx && <div className="w-4 h-px bg-border shrink-0" />}
                </div>
              );
            })}
            {modulos.length > moduloIdx + 1 && (
              <div className="flex items-center gap-1 shrink-0">
                <div className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-muted text-muted-foreground">
                  <Lock className="w-3 h-3" />
                  <span>{modulos.length - moduloIdx - 1} módulo{modulos.length - moduloIdx - 1 !== 1 ? 's' : ''} bloqueado{modulos.length - moduloIdx - 1 !== 1 ? 's' : ''}</span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── PANTALLA FINAL */}
        {completado && notaFinal !== null && (
          <div className="py-8 text-center space-y-6">
            <div className={cn(
              'w-24 h-24 rounded-full flex items-center justify-center mx-auto',
              notaFinal >= 8 ? 'bg-green-100 dark:bg-green-900/30' : 'bg-orange-100 dark:bg-orange-900/30'
            )}>
              <Award className={cn('w-12 h-12', notaFinal >= 8 ? 'text-green-600' : 'text-orange-500')} />
            </div>
            <div className="space-y-1">
              <h3 className="text-xl font-bold text-foreground">
                {notaFinal >= 8 ? '¡Capacitación aprobada!' : 'Capacitación completada'}
              </h3>
              <p className="text-sm text-muted-foreground">{asignacion.capacitacion.titulo}</p>
            </div>

            {/* Nota final grande */}
            <div className={cn('border rounded-2xl p-6 max-w-xs mx-auto space-y-2', notaBg(notaFinal))}>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Nota Final</p>
              <div className={cn('text-6xl font-black', notaColor(notaFinal))}>
                {notaFinal.toFixed(1)}
              </div>
              <p className="text-xs text-muted-foreground">escala 1 – 10 · mínimo para aprobar: 8.0</p>
              <Progress value={notaFinal * 10} className="h-2" />
              <Badge variant={notaFinal >= 8 ? 'default' : 'destructive'} className="gap-1 text-xs">
                <Award className="w-3 h-3" />
                {notaFinal >= 8 ? 'Aprobado' : 'No aprobado'}
              </Badge>
            </div>

            {/* Desglose por módulo */}
            <div className="space-y-2 max-w-sm mx-auto text-left">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide text-center">
                Desglose por módulo
              </p>
              {modulos.map((m, i) => {
                const r = moduloResultados[i];
                return (
                  <div key={m.id} className="flex items-center justify-between text-sm border rounded-lg px-3 py-2 bg-muted/30">
                    <span className="truncate flex-1 text-foreground">{m.titulo}</span>
                    {r ? (
                      <span className={cn('font-bold ml-2 shrink-0', notaColor(r.nota))}>
                        {r.nota.toFixed(1)}
                      </span>
                    ) : (
                      <span className="text-muted-foreground ml-2">—</span>
                    )}
                  </div>
                );
              })}
            </div>

            <Button onClick={onClose} className="gap-2">
              <CheckCircle2 className="w-4 h-4" /> Cerrar
            </Button>
          </div>
        )}

        {/* ── MÓDULO ACTUAL */}
        {!completado && currentModulo && (
          <div className="space-y-4">
            {/* Título del módulo */}
            <div className="bg-muted/40 rounded-lg px-4 py-2.5 flex items-center gap-2">
              <BookMarked className="w-4 h-4 text-primary shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">{currentModulo.titulo}</p>
                {currentModulo.descripcion && (
                  <p className="text-xs text-muted-foreground truncate">{currentModulo.descripcion}</p>
                )}
              </div>
              <Badge variant="outline" className="text-[10px] shrink-0">
                {moduloIdx + 1}/{modulos.length}
              </Badge>
            </div>

            {/* ── ETAPA VIDEOS */}
            {moduloStep === 'videos' && (() => {
              const video = currentModulo.videos[videoIdx];
              if (!video) return null;
              const isYT = /youtu\.?be/i.test(video.url);

              return (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Video className="w-4 h-4 text-blue-500" />
                    <span>{video.titulo}</span>
                    <Badge variant="secondary" className="text-[10px] ml-auto">
                      Video {videoIdx + 1}/{currentModulo.videos.length}
                    </Badge>
                  </div>

                  {isYT ? (
                    <YouTubePlayer
                      url={video.url}
                      onProgress={handleVideoProgress}
                      onUnlock={handleVideoUnlock}
                      unlockThreshold={THRESHOLD}
                    />
                  ) : isVideoFile(video.url) ? (
                    <div className="space-y-3">
                      <video
                        controls
                        className="w-full aspect-video rounded-lg bg-black"
                        onTimeUpdate={(event) => {
                          const target = event.currentTarget;
                          const current = target.currentTime;
                          const duration = target.duration;
                          if (duration > 0) {
                            const pct = Math.round((current / duration) * 100);
                            handleVideoProgress(pct);
                            if (pct >= THRESHOLD) handleVideoUnlock();
                          }
                        }}
                        src={video.url}
                      />
                    </div>
                  ) : (
                    <div className="border rounded-lg p-6 text-center space-y-3 bg-muted/30">
                      <Link2 className="w-8 h-8 mx-auto text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">Abre el video antes de continuar.</p>
                      <a href={video.url} target="_blank" rel="noopener noreferrer"
                        onClick={() => setVideoDesbloqueado(true)}>
                        <Button variant="outline" size="sm" className="gap-2">
                          <ExternalLink className="w-4 h-4" /> Abrir video
                        </Button>
                      </a>
                    </div>
                  )}

                  {/* Indicador de desbloqueo */}
                  {!videoDesbloqueado && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/40 rounded-lg px-3 py-2">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      Ve al menos el {THRESHOLD}% del video para continuar. El video seguirá reproduciéndose.
                    </div>
                  )}

                  <div className="flex justify-end pt-1">
                    <Button
                      onClick={handleSiguienteVideo}
                      disabled={!videoDesbloqueado}
                      className="gap-2"
                    >
                      <ChevronRight className="w-4 h-4" />
                      {videoDesbloqueado
                        ? videoIdx < currentModulo.videos.length - 1
                          ? 'Siguiente video'
                          : currentModulo.quizzes.length > 0 ? 'Ir al quiz' : 'Completar módulo'
                        : `Ve el ${THRESHOLD}% para continuar`}
                    </Button>
                  </div>
                </div>
              );
            })()}

            {/* ── ETAPA QUIZZES */}
            {moduloStep === 'quizzes' && (() => {
              const quiz = currentModulo.quizzes[quizIdx];
              if (!quiz) return null;

              return (
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-violet-500" />
                    <span className="text-sm font-medium">{quiz.titulo}</span>
                    <Badge variant="secondary" className="text-[10px] ml-auto">
                      Quiz {quizIdx + 1}/{currentModulo.quizzes.length}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Responde las {quiz.preguntas.length} preguntas. Mínimo para aprobar: {quiz.porcentaje_aprobacion}%.
                    Máximo 2 intentos por quiz.
                  </p>

                  {[...quiz.preguntas].sort((a, b) => a.orden - b.orden).map((p, idx) => (
                    <div key={p.id} className={cn(
                      'border rounded-lg p-4 space-y-3 transition-colors',
                      respuestas[p.id] ? 'border-primary/40 bg-primary/5' : ''
                    )}>
                      <p className="text-sm font-medium">{idx + 1}. {p.pregunta}</p>
                      <div className="space-y-2">
                        {[...p.opciones].sort((a, b) => a.orden - b.orden).map(o => {
                          const sel = respuestas[p.id] === o.id;
                          return (
                            <label key={o.id} className={cn(
                              'flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors select-none',
                              sel ? 'border-primary bg-primary/10 font-medium' : 'hover:bg-muted/60'
                            )}>
                              <input
                                type="radio"
                                name={`q-${p.id}`}
                                value={o.id}
                                checked={sel}
                                onChange={() => setRespuestas(prev => ({ ...prev, [p.id]: o.id }))}
                                className="w-4 h-4 accent-primary shrink-0"
                              />
                              <span className="text-sm">{o.texto}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  ))}

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-xs text-muted-foreground">
                      {Object.keys(respuestas).length}/{quiz.preguntas.length} respondidas
                    </span>
                    <Button
                      onClick={handleSubmitQuiz}
                      disabled={!allAnswered || submitting}
                      className="gap-2"
                    >
                      {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                      <CheckCircle2 className="w-4 h-4" />
                      Enviar respuestas
                    </Button>
                  </div>
                </div>
              );
            })()}

            {/* ── RESULTADO DEL MÓDULO */}
            {moduloStep === 'resultado_modulo' && moduloResultados[moduloIdx] && (() => {
              const r = moduloResultados[moduloIdx]!;
              return (
                <div className="py-4 space-y-5">
                  <div className="text-center space-y-3">
                    <div className={cn(
                      'w-16 h-16 rounded-full flex items-center justify-center mx-auto',
                      r.nota >= 8 ? 'bg-green-100 dark:bg-green-900/30' : 'bg-orange-100 dark:bg-orange-900/30'
                    )}>
                      <Award className={cn('w-8 h-8', r.nota >= 8 ? 'text-green-600' : 'text-orange-500')} />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                        Nota del {currentModulo.titulo}
                      </p>
                      <div className={cn('text-5xl font-black mt-1', notaColor(r.nota))}>
                        {r.nota.toFixed(1)}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">escala 1–10</p>
                    </div>
                    <Progress value={r.nota * 10} className="h-2 max-w-xs mx-auto" />
                    <p className="text-sm text-muted-foreground">Progreso del módulo: 100%</p>
                    <Badge variant={r.nota >= 8 ? 'default' : 'destructive'} className="gap-1">
                      <Award className="w-3 h-3" />
                      {r.nota >= 8 ? 'Módulo aprobado' : 'Módulo no aprobado'}
                    </Badge>
                  </div>

                  {/* Detalle por quiz */}
                  {r.quizzes.length > 0 && (
                    <div className="space-y-2">
                      {r.quizzes.map(qr => (
                        <div key={qr.quiz_id} className="flex items-center justify-between text-sm border rounded-lg px-3 py-2 bg-muted/30">
                          <span className="text-foreground truncate flex-1">{qr.titulo}</span>
                          <div className="flex items-center gap-2 ml-2 shrink-0">
                            <span className={cn('font-bold', qr.aprobado ? 'text-green-600' : 'text-red-500')}>
                              {qr.puntaje}%
                            </span>
                            <Badge variant={qr.aprobado ? 'default' : 'destructive'} className="text-[10px] h-4 px-1.5">
                              {qr.aprobado ? 'OK' : 'No ap.'}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex justify-end">
                    <Button onClick={handleSiguienteModulo} className="gap-2">
                      <ChevronRight className="w-4 h-4" />
                      {moduloIdx < modulos.length - 1 ? 'Siguiente módulo' : 'Ver nota final'}
                    </Button>
                  </div>
                </div>
              );
            })()}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
