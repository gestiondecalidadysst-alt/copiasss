﻿import { useState, useEffect } from 'react';
import api from '@/services/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Save, Loader2, CheckCircle2, Circle, ClipboardList, Percent } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface Opcion {
  id?: string;
  texto: string;
  es_correcta: boolean;
  orden: number;
}

interface Pregunta {
  id?: string;
  pregunta: string;
  tipo: 'multiple_choice';
  puntos: number;
  orden: number;
  opciones: Opcion[];
}

interface QuizEditorProps {
  capacitacionId: string;
}

const emptyOpcion = (orden: number): Opcion => ({ texto: '', es_correcta: false, orden });

const emptyPregunta = (orden: number): Pregunta => ({
  pregunta: '',
  tipo: 'multiple_choice',
  puntos: 1,
  orden,
  opciones: [
    emptyOpcion(0),
    emptyOpcion(1),
    emptyOpcion(2),
    emptyOpcion(3),
  ],
});

export const QuizEditor = ({ capacitacionId }: QuizEditorProps) => {
  const [preguntas, setPreguntas] = useState<Pregunta[]>([]);
  const [porcentajeAprobacion, setPorcentajeAprobacion] = useState(70);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get(`/capacitaciones/${capacitacionId}/quiz`)
      .then((r) => {
        const raw = r.data;
        const list: Pregunta[] = Array.isArray(raw) ? raw : (raw?.preguntas ?? []);
        setPorcentajeAprobacion(raw?.porcentaje_aprobacion ?? 70);
        if (list.length > 0) {
          setPreguntas(
            list.map((p, i) => ({
              ...p,
              tipo: 'multiple_choice' as const,
              puntos: p.puntos ?? 1,
              orden: i,
              opciones: [...(p.opciones || [])].sort((a, b) => a.orden - b.orden),
            }))
          );
        } else {
          setPreguntas([emptyPregunta(0)]);
        }
      })
      .catch(() => setPreguntas([emptyPregunta(0)]))
      .finally(() => setLoading(false));
  }, [capacitacionId]);

  const totalPuntos = preguntas.reduce((acc, p) => acc + (p.puntos || 1), 0);

  const addPregunta = () =>
    setPreguntas((prev) => [...prev, emptyPregunta(prev.length)]);

  const removePregunta = (idx: number) =>
    setPreguntas((prev) =>
      prev.filter((_, i) => i !== idx).map((p, i) => ({ ...p, orden: i }))
    );

  const updatePreguntaTexto = (idx: number, value: string) =>
    setPreguntas((prev) =>
      prev.map((p, i) => (i === idx ? { ...p, pregunta: value } : p))
    );

  const updatePuntos = (idx: number, value: number) =>
    setPreguntas((prev) =>
      prev.map((p, i) => (i === idx ? { ...p, puntos: Math.max(1, Math.min(100, value || 1)) } : p))
    );

  const setCorrectOption = (pIdx: number, oIdx: number) =>
    setPreguntas((prev) =>
      prev.map((p, i) =>
        i !== pIdx
          ? p
          : { ...p, opciones: p.opciones.map((o, j) => ({ ...o, es_correcta: j === oIdx })) }
      )
    );

  const updateOpcionTexto = (pIdx: number, oIdx: number, texto: string) =>
    setPreguntas((prev) =>
      prev.map((p, i) =>
        i !== pIdx
          ? p
          : { ...p, opciones: p.opciones.map((o, j) => (j === oIdx ? { ...o, texto } : o)) }
      )
    );

  const addOpcion = (pIdx: number) =>
    setPreguntas((prev) =>
      prev.map((p, i) =>
        i !== pIdx
          ? p
          : { ...p, opciones: [...p.opciones, emptyOpcion(p.opciones.length)] }
      )
    );

  const removeOpcion = (pIdx: number, oIdx: number) =>
    setPreguntas((prev) =>
      prev.map((p, i) =>
        i !== pIdx
          ? p
          : {
              ...p,
              opciones: p.opciones
                .filter((_, j) => j !== oIdx)
                .map((o, j) => ({ ...o, orden: j })),
            }
      )
    );

  const handleSave = async () => {
    for (let i = 0; i < preguntas.length; i++) {
      const p = preguntas[i];
      if (!p.pregunta.trim()) {
        toast.error(`Pregunta ${i + 1}: el texto es requerido`);
        return;
      }
      if (p.opciones.filter(o => o.texto.trim()).length < 2) {
        toast.error(`Pregunta ${i + 1}: necesita al menos 2 opciones con texto`);
        return;
      }
      if (!p.opciones.some((o) => o.es_correcta)) {
        toast.error(`Pregunta ${i + 1}: debes marcar cuÃ¡l es la respuesta correcta`);
        return;
      }
      if (p.opciones.some((o) => !o.texto.trim())) {
        toast.error(`Pregunta ${i + 1}: todas las opciones deben tener texto`);
        return;
      }
      if (!p.puntos || p.puntos < 1) {
        toast.error(`Pregunta ${i + 1}: los puntos deben ser al menos 1`);
        return;
      }
    }
    try {
      setSaving(true);
      await api.post(`/capacitaciones/${capacitacionId}/quiz`, { preguntas, porcentaje_aprobacion: porcentajeAprobacion });
      toast.success(`Quiz guardado — ${preguntas.length} preguntas, ${totalPuntos} puntos · mínimo para aprobar: ${porcentajeAprobacion}%`);
    } catch {
      toast.error('Error al guardar el quiz');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="py-6 text-center text-sm text-muted-foreground flex items-center justify-center gap-2">
        <Loader2 className="w-4 h-4 animate-spin" /> Cargando quiz...
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Encabezado del quiz */}
      <div className="flex items-center justify-between bg-muted/40 rounded-lg px-4 py-2.5">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <ClipboardList className="w-4 h-4" />
          <span><strong className="text-foreground">{preguntas.length}</strong> pregunta{preguntas.length !== 1 ? 's' : ''}</span>
          <span className="text-muted-foreground/50">·</span>
          <span>Total: <strong className="text-foreground">{totalPuntos} punto{totalPuntos !== 1 ? 's' : ''}</strong></span>
        </div>
        <Badge variant="outline" className="text-xs gap-1">
          Selección única · Calificación automática
        </Badge>
      </div>

      {/* Porcentaje mínimo para aprobar */}
      <div className="flex items-center gap-3 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg px-4 py-3">
        <Percent className="w-4 h-4 text-blue-600 flex-shrink-0" />
        <div className="flex-1">
          <p className="text-xs font-semibold text-blue-700 dark:text-blue-400">Porcentaje mínimo para aprobar</p>
          <p className="text-xs text-blue-600/70 dark:text-blue-500">El conductor debe obtener al menos este porcentaje. Máximo 2 intentos.</p>
        </div>
        <div className="flex items-center gap-1 flex-shrink-0">
          <Input
            type="number"
            min={1}
            max={100}
            value={porcentajeAprobacion}
            onChange={(e) => setPorcentajeAprobacion(Math.min(100, Math.max(1, parseInt(e.target.value) || 70)))}
            className="w-16 text-center text-sm font-bold border-blue-300 dark:border-blue-700"
          />
          <span className="text-sm font-bold text-blue-700 dark:text-blue-400">%</span>
        </div>
      </div>

      <p className="text-xs text-muted-foreground px-0.5">
        Cada pregunta es de <strong>selección múltiple con una sola respuesta correcta</strong>.
        Marca cuál es la opción correcta e indica cuántos puntos vale.
        El puntaje se calcula automáticamente según los puntos acumulados.
      </p>

      {preguntas.map((p, pIdx) => {
        const correctaSeleccionada = p.opciones.some(o => o.es_correcta);
        return (
          <div
            key={pIdx}
            className={cn(
              'border rounded-lg p-4 space-y-3 bg-background',
              !correctaSeleccionada && 'border-orange-300 dark:border-orange-700'
            )}
          >
            {/* Cabecera de la pregunta */}
            <div className="flex items-start gap-2">
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-muted-foreground bg-muted rounded px-2 py-0.5">
                    Pregunta {pIdx + 1}
                  </span>
                  {!correctaSeleccionada && (
                    <span className="text-xs text-orange-500 font-medium">âš  Marca la respuesta correcta</span>
                  )}
                </div>
                <Input
                  value={p.pregunta}
                  onChange={(e) => updatePreguntaTexto(pIdx, e.target.value)}
                  placeholder="Escribe la pregunta aquÃ­..."
                  className="text-sm font-medium"
                />
              </div>

              {/* Puntos */}
              <div className="flex flex-col items-center gap-0.5 flex-shrink-0">
                <Label className="text-[10px] text-muted-foreground text-center leading-tight">Puntos</Label>
                <Input
                  type="number"
                  min={1}
                  max={100}
                  value={p.puntos}
                  onChange={(e) => updatePuntos(pIdx, parseInt(e.target.value))}
                  className="w-16 text-center text-sm font-bold"
                />
              </div>

              <Button
                size="sm"
                variant="ghost"
                className="text-destructive h-8 w-8 p-0 mt-5 flex-shrink-0"
                onClick={() => removePregunta(pIdx)}
                disabled={preguntas.length === 1}
                title="Eliminar pregunta"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>

            {/* Opciones */}
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground font-medium flex items-center gap-1">
                Opciones de respuesta
                <span className="text-muted-foreground/60">â€” haz clic en el cÃ­rculo para marcar la correcta</span>
              </p>
              {p.opciones.map((o, oIdx) => (
                <div key={oIdx} className={cn(
                  'flex items-center gap-2 rounded-md px-2 py-1 transition-colors',
                  o.es_correcta ? 'bg-green-50 dark:bg-green-950/30' : 'bg-transparent'
                )}>
                  {/* BotÃ³n de marcar correcta */}
                  <button
                    type="button"
                    onClick={() => setCorrectOption(pIdx, oIdx)}
                    className={cn(
                      'flex-shrink-0 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all',
                      o.es_correcta
                        ? 'border-green-500 bg-green-500 text-white'
                        : 'border-muted-foreground/40 hover:border-green-400'
                    )}
                    title={o.es_correcta ? 'Respuesta correcta' : 'Marcar como correcta'}
                  >
                    {o.es_correcta
                      ? <CheckCircle2 className="w-3.5 h-3.5" />
                      : <Circle className="w-3 h-3 opacity-0" />
                    }
                  </button>

                  <Input
                    value={o.texto}
                    onChange={(e) => updateOpcionTexto(pIdx, oIdx, e.target.value)}
                    placeholder={`OpciÃ³n ${oIdx + 1}...`}
                    className={cn(
                      'text-sm flex-1 h-8',
                      o.es_correcta && 'border-green-400 font-medium'
                    )}
                  />

                  {o.es_correcta && (
                    <Badge variant="outline" className="text-[10px] text-green-600 border-green-400 px-1.5 h-5 flex-shrink-0">
                      Correcta
                    </Badge>
                  )}

                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive flex-shrink-0"
                    onClick={() => removeOpcion(pIdx, oIdx)}
                    disabled={p.opciones.length <= 2}
                    title="Eliminar opciÃ³n"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              ))}

              {p.opciones.length < 6 && (
                <Button
                  size="sm"
                  variant="ghost"
                  className="text-xs gap-1 h-7 text-muted-foreground ml-7"
                  onClick={() => addOpcion(pIdx)}
                >
                  <Plus className="w-3 h-3" /> Agregar opciÃ³n
                </Button>
              )}
            </div>
          </div>
        );
      })}

      {/* Acciones */}
      <div className="flex items-center justify-between pt-1">
        <Button variant="outline" size="sm" className="gap-1.5" onClick={addPregunta}>
          <Plus className="w-3.5 h-3.5" /> Agregar pregunta
        </Button>
        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground">
            Total: <strong className="text-foreground">{totalPuntos} pts</strong>
          </span>
          <Button size="sm" className="gap-1.5" onClick={handleSave} disabled={saving}>
            {saving ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Save className="w-3.5 h-3.5" />
            )}
            Guardar quiz
          </Button>
        </div>
      </div>
    </div>
  );
};
