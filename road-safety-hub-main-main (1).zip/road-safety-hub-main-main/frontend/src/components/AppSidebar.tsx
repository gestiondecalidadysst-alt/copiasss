import { NavLink, useLocation } from 'react-router-dom';
import { useAppStore } from '@/stores/appStore';
import { useAuthStore } from '@/stores/authStore';
import {
  LayoutDashboard, Truck, Users, AlertTriangle,
  Map, FileText, Settings, Shield, ChevronLeft, MessageSquare, UserPlus, BookOpen, Newspaper
} from 'lucide-react';
import { cn } from '@/lib/utils';

const getNavItems = (isAdmin: boolean) => {
  const baseItems = [
    { title: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { title: 'Vehículos', path: '/vehiculos', icon: Truck },
    { title: 'Conductores', path: '/conductores', icon: Users },
    { title: 'Eventos', path: '/eventos', icon: AlertTriangle },
    { title: 'Mensajes', path: '/mensajes', icon: MessageSquare },
    { title: 'Mapa', path: '/mapa', icon: Map },
    { title: 'Reportes', path: '/reportes', icon: FileText },
    { title: 'Capacitaciones', path: '/capacitaciones', icon: BookOpen },
  ];

  // Agregar opciones solo si es admin
  if (isAdmin) {
    baseItems.push({ title: 'Usuarios', path: '/usuarios', icon: UserPlus });
    baseItems.push({ title: 'Noticias', path: '/noticias', icon: Newspaper });
  }

  baseItems.push({ title: 'Configuración', path: '/configuracion', icon: Settings });

  return baseItems;
};

const AppSidebar = () => {
  const { sidebarOpen, toggleSidebar, companyName, companyLogo } = useAppStore();
  const { user } = useAuthStore();
  const location = useLocation();
  const isAdmin = user?.rol === 'admin';
  const navItems = getNavItems(isAdmin);

  return (
    <aside
      className={cn(
        'fixed inset-y-0 left-0 z-40 flex flex-col border-r border-sidebar-border bg-sidebar transition-all duration-300',
        sidebarOpen
          ? 'translate-x-0 w-full max-w-xs lg:w-64 shadow-xl lg:shadow-none'
          : 'lg:w-[68px] -translate-x-full lg:translate-x-0'
      )}
    >
      {/* Logo */}
      <div className="h-16 flex items-center px-4 border-b border-sidebar-border">
        {companyLogo ? (
          <img 
            src={companyLogo} 
            alt={companyName} 
            className="w-9 h-9 rounded-lg object-cover flex-shrink-0"
          />
        ) : (
          <div className="w-9 h-9 rounded-lg gradient-primary flex items-center justify-center flex-shrink-0">
            <Shield className="w-5 h-5 text-primary-foreground" />
          </div>
        )}
        {sidebarOpen && (
          <span className="ml-3 font-bold text-sidebar-primary-foreground text-lg tracking-tight">
            {companyName}
          </span>
        )}
        <button
          onClick={toggleSidebar}
          className={cn(
            'ml-auto p-1.5 rounded-md hover:bg-sidebar-accent text-sidebar-muted transition-transform',
            !sidebarOpen && 'ml-0 mt-2 rotate-180'
          )}
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all',
                isActive
                  ? 'bg-sidebar-primary/15 text-sidebar-primary'
                  : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
              )}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {sidebarOpen && <span>{item.title}</span>}
            </NavLink>
          );
        })}
      </nav>

      {/* Footer */}
      {sidebarOpen && (
        <div className="p-4 border-t border-sidebar-border">
          <p className="text-xs text-sidebar-muted">© 2026 RiskVial Pro</p>
        </div>
      )}
    </aside>
  );
};

export default AppSidebar;
