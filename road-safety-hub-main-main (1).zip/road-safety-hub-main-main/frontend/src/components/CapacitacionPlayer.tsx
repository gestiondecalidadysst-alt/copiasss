import { useState, useEffect } from 'react';
import api from '@/services/api';
import { YouTubePlayer } from './YouTubePlayer';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import {
  CheckCircle2, FileText, ExternalLink, ChevronRight,
  Loader2, Star, BookOpen, Award,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface Opcion {
  id: string;
  texto: string;
  orden: number;
}

interface Pregunta {
  id: string;
  pregunta: string;
  tipo: string;
  orden: number;
  opciones: Opcion[];
}

export interface AsignacionPlayer {
  id: string;
  estado: string;
  etapa?: string;
  progreso_video?: number;
  quiz_puntaje?: number;
  quiz_completado?: boolean;
  capacitacion: {
    titulo: string;
    descripcion?: string;
    contenido_url?: string;
    tipo: string;
    duracion_minutos: number;
  };
}

interface CapacitacionPlayerProps {
  asignacion: AsignacionPlayer;
  open: boolean;
  onClose: () => void;
  onComplete: (asignacionId: string, puntaje?: number) => void;
}

const THRESHOLD = 80; // % del video requerido

const etapaOrder = ['contenido', 'quiz', 'completado'] as const;
type Etapa = (typeof etapaOrder)[number];

export const CapacitacionPlayer = ({
  asignacion,
  open,
  onClose,
  onComplete,
}: CapacitacionPlayerProps) => {
  const [etapa, setEtapa] = useState<Etapa>(
    (asignacion.etapa as Etapa) || 'contenido'
  );
  const [videoUnlocked, setVideoUnlocked] = useState(false);
  const [preguntas, setPreguntas] = useState<Pregunta[]>([]);
  const [respuestas, setRespuestas] = useState<Record<string, string>>({});
  const [loadingQuiz, setLoadingQuiz] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [resultado, setResultado] = useState<{
    puntaje: number;
    correctas: number;
    total: number;
  } | null>(null);

  const tipo = asignacion.capacitacion.tipo;
  const url = asignacion.capacitacion.contenido_url || '';
  const hasVideo = tipo === 'video' && !!url;
  const hasDoc = (tipo === 'documento' || tipo === 'presencial') && !!url;

  // Reset al abrir
  useEffect(() => {
    if (open) {
      const initialEtapa = (asignacion.etapa as Etapa) || 'contenido';
      setEtapa(initialEtapa);
      setVideoUnlocked((asignacion.progreso_video ?? 0) >= THRESHOLD);
      setRespuestas({});
      setResultado(null);
      setPreguntas([]);
    }
  }, [open, asignacion]);

  // Cargar quiz al entrar a esa etapa
  useEffect(() => {
    if (etapa === 'quiz' && preguntas.length === 0) {
      setLoadingQuiz(true);
      api
        .get(`/portal/conductor/capacitaciones/${asignacion.id}/quiz`)
        .then((r) => setPreguntas(r.data.preguntas || []))
        .catch(() => toast.error('No se pudo cargar el quiz'))
        .finally(() => setLoadingQuiz(false));
    }
  }, [etapa, asignacion.id, preguntas.length]);

  // Guarda progreso en servidor cada 10 puntos (silent)
  const handleVideoProgress = async (pct: number) => {
    if (pct > 0 && pct % 10 === 0) {
      try {
        await api.put(
          `/portal/conductor/capacitaciones/${asignacion.id}/progreso-video`,
          { progreso: pct }
        );
      } catch { /* silent */ }
    }
  };

  // Se llama al alcanzar el 80% del video
  const handleVideoUnlock = () => {
    setVideoUnlocked(true);
  };

  // Botón "Siguiente" después del video / documento
  const handleSiguiente = async () => {
    try {
      const res = await api.put(
        `/portal/conductor/capacitaciones/${asignacion.id}/progreso-video`,
        { progreso: 100 }
      );
      const newEtapa = (res.data.etapa as Etapa) || 'completado';
      setEtapa(newEtapa);
      if (newEtapa === 'completado') {
        onComplete(asignacion.id);
        toast.success('¡Capacitación completada!');
      }
    } catch {
      toast.error('Error al avanzar a la siguiente etapa');
    }
  };

  // Enviar respuestas del quiz
  const handleSubmitQuiz = async () => {
    const todasRespondidas = preguntas.every((p) => respuestas[p.id]);
    if (!todasRespondidas) {
      toast.error('Responde todas las preguntas antes de completar');
      return;
    }
    try {
      setSubmitting(true);
      const payload = preguntas.map((p) => ({
        pregunta_id: p.id,
        opcion_id: respuestas[p.id],
      }));
      const res = await api.post(
        `/portal/conductor/capacitaciones/${asignacion.id}/quiz/responder`,
        { respuestas: payload }
      );
      setResultado(res.data);
      setEtapa('completado');
      onComplete(asignacion.id, res.data.puntaje);
      toast.success(`¡Quiz completado! Puntaje: ${res.data.puntaje}%`);
    } catch {
      toast.error('Error al enviar el quiz');
    } finally {
      setSubmitting(false);
    }
  };

  const allAnswered =
    preguntas.length > 0 && preguntas.every((p) => respuestas[p.id]);

  // Stepper visual
  const StepDot = ({ step }: { step: Etapa }) => {
    const current = etapaOrder.indexOf(etapa);
    const target = etapaOrder.indexOf(step);
    if (target < current)
      return <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />;
    if (target === current)
      return (
        <div className="w-3 h-3 rounded-full bg-primary flex-shrink-0 ring-2 ring-primary/30" />
      );
    return (
      <div className="w-3 h-3 rounded-full bg-muted-foreground/25 flex-shrink-0" />
    );
  };

  const stepLabel: Record<Etapa, string> = {
    contenido: 'Contenido',
    quiz: 'Quiz',
    completado: 'Completado',
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-2xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <BookOpen className="w-5 h-5 text-primary flex-shrink-0" />
            <span className="truncate">{asignacion.capacitacion.titulo}</span>
          </DialogTitle>
        </DialogHeader>

        {/* Stepper */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground py-1">
          {etapaOrder.map((step, i) => (
            <div key={step} className="flex items-center gap-2 flex-1">
              <div className="flex items-center gap-1.5">
                <StepDot step={step} />
                <span
                  className={cn(
                    'hidden sm:inline',
                    etapa === step && 'text-foreground font-medium'
                  )}
                >
                  {stepLabel[step]}
                </span>
              </div>
              {i < etapaOrder.length - 1 && (
                <div className="flex-1 h-px bg-border" />
              )}
            </div>
          ))}
        </div>

        {/* ── ETAPA: Contenido ──────────────────────────────────────────── */}
        {etapa === 'contenido' && (
          <div className="space-y-4">
            {asignacion.capacitacion.descripcion && (
              <p className="text-sm text-muted-foreground">
                {asignacion.capacitacion.descripcion}
              </p>
            )}

            {hasVideo ? (
              <YouTubePlayer
                url={url}
                onProgress={handleVideoProgress}
                onUnlock={handleVideoUnlock}
                unlockThreshold={THRESHOLD}
              />
            ) : hasDoc ? (
              <div className="border rounded-lg p-6 text-center space-y-3 bg-muted/30">
                <FileText className="w-10 h-10 mx-auto text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Abre y revisa el material antes de continuar.
                </p>
                <a href={url} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="sm" className="gap-2">
                    <ExternalLink className="w-4 h-4" />
                    Abrir material
                  </Button>
                </a>
              </div>
            ) : (
              <div className="border rounded-lg p-6 text-center text-muted-foreground text-sm bg-muted/30">
                Capacitación presencial — confirma tu asistencia para continuar.
              </div>
            )}

            <div className="flex justify-end pt-2">
              <Button
                onClick={handleSiguiente}
                disabled={hasVideo && !videoUnlocked}
                className="gap-2"
              >
                <ChevronRight className="w-4 h-4" />
                {hasVideo && !videoUnlocked
                  ? `Ve el ${THRESHOLD}% del video para continuar`
                  : 'Siguiente'}
              </Button>
            </div>
          </div>
        )}

        {/* ── ETAPA: Quiz ───────────────────────────────────────────────── */}
        {etapa === 'quiz' && (
          <div className="space-y-4">
            {loadingQuiz ? (
              <div className="flex items-center justify-center py-10 gap-2 text-muted-foreground">
                <Loader2 className="w-5 h-5 animate-spin" />
                <span className="text-sm">Cargando quiz...</span>
              </div>
            ) : preguntas.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                Esta capacitación no tiene preguntas configuradas.
              </p>
            ) : (
              <>
                <p className="text-sm text-muted-foreground">
                  Responde las {preguntas.length} preguntas para completar la capacitación.
                  Puedes cambiar tus respuestas antes de enviar.
                </p>

                {[...preguntas]
                  .sort((a, b) => a.orden - b.orden)
                  .map((p, idx) => (
                    <div
                      key={p.id}
                      className={cn(
                        'border rounded-lg p-4 space-y-3 transition-colors',
                        respuestas[p.id] ? 'border-primary/40 bg-primary/5' : ''
                      )}
                    >
                      <p className="text-sm font-medium">
                        {idx + 1}. {p.pregunta}
                      </p>
                      <div className="space-y-2">
                        {[...p.opciones]
                          .sort((a, b) => a.orden - b.orden)
                          .map((o) => {
                            const selected = respuestas[p.id] === o.id;
                            return (
                              <label
                                key={o.id}
                                className={cn(
                                  'flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors select-none',
                                  selected
                                    ? 'border-primary bg-primary/10 font-medium'
                                    : 'hover:bg-muted/60'
                                )}
                              >
                                <input
                                  type="radio"
                                  name={`q-${p.id}`}
                                  value={o.id}
                                  checked={selected}
                                  onChange={() =>
                                    setRespuestas((prev) => ({
                                      ...prev,
                                      [p.id]: o.id,
                                    }))
                                  }
                                  className="w-4 h-4 accent-primary flex-shrink-0"
                                />
                                <span className="text-sm">{o.texto}</span>
                              </label>
                            );
                          })}
                      </div>
                    </div>
                  ))}

                <div className="flex items-center justify-between pt-2">
                  <span className="text-xs text-muted-foreground">
                    {Object.keys(respuestas).length}/{preguntas.length} respondidas
                  </span>
                  <Button
                    onClick={handleSubmitQuiz}
                    disabled={!allAnswered || submitting}
                    className="gap-2"
                  >
                    {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                    <CheckCircle2 className="w-4 h-4" />
                    Completar capacitación
                  </Button>
                </div>
              </>
            )}
          </div>
        )}

        {/* ── ETAPA: Completado ─────────────────────────────────────────── */}
        {etapa === 'completado' && (
          <div className="py-8 text-center space-y-5">
            <div className="w-20 h-20 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10 text-green-600" />
            </div>
            <div className="space-y-1">
              <h3 className="text-lg font-semibold text-foreground">
                ¡Capacitación completada!
              </h3>
              <p className="text-sm text-muted-foreground">
                {asignacion.capacitacion.titulo}
              </p>
            </div>

            {/* Resultado del quiz si existe */}
            {resultado && resultado.total > 0 && (
              <div className="bg-muted/40 rounded-xl p-5 space-y-3 max-w-xs mx-auto">
                <p className="text-sm font-medium text-muted-foreground flex items-center justify-center gap-1.5">
                  <Star className="w-4 h-4 text-yellow-500" /> Resultado del quiz
                </p>
                <div className="text-4xl font-bold text-foreground">
                  {resultado.puntaje}%
                </div>
                <p className="text-xs text-muted-foreground">
                  {resultado.correctas} de {resultado.total} respuestas correctas
                </p>
                <Progress value={resultado.puntaje} className="h-2" />
                <Badge
                  variant={resultado.puntaje >= 70 ? 'default' : 'destructive'}
                  className="gap-1"
                >
                  <Award className="w-3 h-3" />
                  {resultado.puntaje >= 70 ? 'Aprobado' : 'No aprobado'}
                </Badge>
              </div>
            )}

            {/* Puntaje previo (ya completado antes) */}
            {!resultado && asignacion.quiz_completado && asignacion.quiz_puntaje != null && (
              <div className="bg-muted/40 rounded-xl p-4 space-y-2 max-w-xs mx-auto">
                <p className="text-sm text-muted-foreground">
                  Puntaje obtenido: <strong>{asignacion.quiz_puntaje}%</strong>
                </p>
                <Badge
                  variant={asignacion.quiz_puntaje >= 70 ? 'default' : 'destructive'}
                  className="gap-1"
                >
                  <Award className="w-3 h-3" />
                  {asignacion.quiz_puntaje >= 70 ? 'Aprobado' : 'No aprobado'}
                </Badge>
              </div>
            )}

            <Button onClick={onClose} variant="outline" className="mx-auto">
              Cerrar
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
