import { useEffect } from 'react';
import { X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { SpeedNotification, getSpeedConfig } from '@/types/notifications';

interface SpeedNotificationItemProps {
  notification: SpeedNotification;
  onClose: (id: string) => void;
}

const SpeedNotificationItem = ({ notification, onClose }: SpeedNotificationItemProps) => {
  const config = getSpeedConfig(notification.level);
  
  const colorClasses = {
    green: 'bg-green-100 border-green-300 text-green-900',
    yellow: 'bg-yellow-100 border-yellow-300 text-yellow-900',
    orange: 'bg-orange-100 border-orange-300 text-orange-900',
    red: 'bg-red-100 border-red-300 text-red-900',
  };

  const progressClasses = {
    green: 'bg-green-500',
    yellow: 'bg-yellow-500',
    orange: 'bg-orange-500',
    red: 'bg-red-600',
  };

  return (
    <div
      className={cn(
        'relative flex items-start gap-3 p-4 rounded-lg border-2 shadow-lg animate-in slide-in-from-right-full duration-300',
        colorClasses[config.color as keyof typeof colorClasses]
      )}
      role="alert"
    >
      {/* Icono */}
      <div className="flex-shrink-0 text-xl mt-0.5">
        {config.icon}
      </div>

      {/* Contenido */}
      <div className="flex-1 min-w-0">
        <h3 className="font-semibold text-sm">
          {config.label} - {notification.velocidad} km/h
        </h3>
        <p className="text-xs opacity-90 line-clamp-2">
          Placa: <span className="font-mono font-bold">{notification.placa}</span>
          {notification.ruta && ` • ${notification.ruta}`}
        </p>
      </div>

      {/* Botón cerrar */}
      <button
        onClick={() => onClose(notification.id)}
        className="flex-shrink-0 p-1 hover:bg-white/30 rounded transition-colors"
        aria-label="Cerrar notificación"
      >
        <X className="w-4 h-4" />
      </button>

      {/* Barra de progreso */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/10 rounded-b-[calc(0.5rem-1px)]">
        <div
          className={cn(
            'h-full rounded-b-lg transition-all duration-300',
            progressClasses[config.color as keyof typeof progressClasses]
          )}
          style={{
            animation: 'shrink 5s linear forwards',
          }}
        />
      </div>
    </div>
  );
};

interface SpeedNotificationCenterProps {
  notifications: SpeedNotification[];
  onClose: (id: string) => void;
  maxVisible?: number;
}

export const SpeedNotificationCenter = ({
  notifications,
  onClose,
  maxVisible = 3,
}: SpeedNotificationCenterProps) => {
  const visibleNotifications = notifications.slice(-maxVisible);

  // Agregar estilos de animación
  useEffect(() => {
    if (!document.getElementById('speed-notification-styles')) {
      const style = document.createElement('style');
      style.id = 'speed-notification-styles';
      style.textContent = `
        @keyframes shrink {
          from {
            width: 100%;
          }
          to {
            width: 0%;
          }
        }
      `;
      document.head.appendChild(style);
    }
  }, []);

  if (visibleNotifications.length === 0) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
      {visibleNotifications.map((notification) => (
        <div key={notification.id} className="pointer-events-auto">
          <SpeedNotificationItem notification={notification} onClose={onClose} />
        </div>
      ))}
    </div>
  );
};
