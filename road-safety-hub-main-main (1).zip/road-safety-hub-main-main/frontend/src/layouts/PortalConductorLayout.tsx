import { Outlet } from 'react-router-dom';
import { Shield, LogOut, User } from 'lucide-react';
import { useAuthStore } from '@/stores/authStore';
import { useAppStore } from '@/stores/appStore';
import { Button } from '@/components/ui/button';

const PortalConductorLayout = () => {
  const { user, logout } = useAuthStore();
  const { companyLogo, companyName, sidebarOpen, toggleSidebar } = useAppStore();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border bg-card/95 backdrop-blur-xl flex flex-wrap items-center justify-between gap-3 px-4 sm:px-6 py-3">
        <button onClick={toggleSidebar} className="lg:hidden p-2 rounded-lg hover:bg-muted">
          <svg className="w-5 h-5 text-foreground" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <div className="flex items-center gap-3 min-w-0 overflow-hidden">
          {companyLogo ? (
            <img
              src={companyLogo}
              alt={`${companyName || 'Empresa'} logo`}
              className="w-10 h-10 rounded-lg object-cover border border-border"
            />
          ) : (
            <div className="w-10 h-10 rounded-lg gradient-primary flex items-center justify-center">
              <Shield className="w-5 h-5 text-primary-foreground" />
            </div>
          )}
          <div className="min-w-0 overflow-hidden">
            <span className="font-bold text-lg text-foreground block truncate">Portal del Conductor</span>
            <span className="text-sm text-muted-foreground block truncate">{companyName || 'RiskVial Pro'}</span>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2 justify-end">
          <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground min-w-0 overflow-hidden">
            <User className="w-4 h-4 flex-shrink-0" />
            <span className="truncate">{user?.nombre}</span>
          </div>
          <Button variant="ghost" size="sm" onClick={logout} className="gap-2 text-muted-foreground hover:text-destructive">
            <LogOut className="w-4 h-4" />
            Salir
          </Button>
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 p-6">
        <Outlet />
      </main>

      <footer className="border-t border-border px-6 py-3 text-center text-xs text-muted-foreground">
        © 2026 RiskVial Pro — Portal exclusivo para conductores
      </footer>
    </div>
  );
};

export default PortalConductorLayout;
