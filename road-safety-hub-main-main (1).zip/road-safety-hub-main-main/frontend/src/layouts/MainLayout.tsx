import { Outlet } from 'react-router-dom';
import AppSidebar from '@/components/AppSidebar';
import AppHeader from '@/components/AppHeader';
import { useAppStore } from '@/stores/appStore';
import { cn } from '@/lib/utils';

const MainLayout = () => {
  const sidebarOpen = useAppStore((s) => s.sidebarOpen);
  const setSidebarOpen = useAppStore((s) => s.setSidebarOpen);

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      <AppSidebar />
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-black/40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}
      <div className={cn('flex flex-col h-screen transition-all duration-300', sidebarOpen ? 'lg:ml-64' : 'lg:ml-[68px]')}>
        <AppHeader />
        <main className="flex-1 p-6 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default MainLayout;
