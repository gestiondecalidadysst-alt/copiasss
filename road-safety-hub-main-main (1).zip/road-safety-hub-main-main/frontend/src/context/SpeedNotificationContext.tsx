import { createContext, useContext, ReactNode } from 'react';
import { useSpeedNotification } from '@/hooks/useSpeedNotification';
import { SpeedNotification } from '@/types/notifications';

interface SpeedNotificationContextType {
  notifications: SpeedNotification[];
  addNotification: (placa: string, velocidad: number, ruta?: string) => string;
  removeNotification: (id: string) => void;
  clearAll: () => void;
}

const SpeedNotificationContext = createContext<SpeedNotificationContextType | undefined>(
  undefined
);

export const SpeedNotificationProvider = ({ children }: { children: ReactNode }) => {
  const { notifications, addNotification, removeNotification, clearAll } = useSpeedNotification();

  return (
    <SpeedNotificationContext.Provider
      value={{ notifications, addNotification, removeNotification, clearAll }}
    >
      {children}
    </SpeedNotificationContext.Provider>
  );
};

export const useSpeedNotificationContext = () => {
  const context = useContext(SpeedNotificationContext);
  if (context === undefined) {
    throw new Error(
      'useSpeedNotificationContext debe ser usado dentro de SpeedNotificationProvider'
    );
  }
  return context;
};
