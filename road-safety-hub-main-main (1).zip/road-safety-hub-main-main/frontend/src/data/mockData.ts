export const mockVehiculos = [
  { id: '1', placa: 'ABC-123', tipo: 'Camión', gps_id: 'GPS-001', estado: 'activo', conductor: 'Carlos Méndez' },
  { id: '2', placa: 'DEF-456', tipo: 'Furgón', gps_id: 'GPS-002', estado: 'activo', conductor: 'Ana Torres' },
  { id: '3', placa: 'GHI-789', tipo: 'Tractocamión', gps_id: 'GPS-003', estado: 'mantenimiento', conductor: 'Luis García' },
  { id: '4', placa: 'JKL-012', tipo: 'Camioneta', gps_id: 'GPS-004', estado: 'activo', conductor: 'María López' },
  { id: '5', placa: 'MNO-345', tipo: 'Camión', gps_id: 'GPS-005', estado: 'inactivo', conductor: 'Pedro Ruiz' },
  { id: '6', placa: 'PQR-678', tipo: 'Furgón', gps_id: 'GPS-006', estado: 'activo', conductor: 'Rosa Díaz' },
];

export const mockConductores = [
  { id: '1', nombre: 'Carlos Méndez', cedula: '12345678', licencia: 'A2', telefono: '300-111-2222', vehiculo: 'ABC-123', score: 92 },
  { id: '2', nombre: 'Ana Torres', cedula: '23456789', licencia: 'B1', telefono: '300-222-3333', vehiculo: 'DEF-456', score: 78 },
  { id: '3', nombre: 'Luis García', cedula: '34567890', licencia: 'C1', telefono: '300-333-4444', vehiculo: 'GHI-789', score: 45 },
  { id: '4', nombre: 'María López', cedula: '45678901', licencia: 'A2', telefono: '300-444-5555', vehiculo: 'JKL-012', score: 88 },
  { id: '5', nombre: 'Pedro Ruiz', cedula: '56789012', licencia: 'B1', telefono: '300-555-6666', vehiculo: 'MNO-345', score: 35 },
  { id: '6', nombre: 'Rosa Díaz', cedula: '67890123', licencia: 'C1', telefono: '300-666-7777', vehiculo: 'PQR-678', score: 67 },
];

export const mockEventos = [
  { id: '1', tipo_evento: 'Exceso de velocidad', velocidad: 120, fecha: '2026-04-14 08:30', ubicacion: 'Cra 7 #45-12', conductor: 'Carlos Méndez', lat: 4.6486, lng: -74.0833, severidad: 'alta' },
  { id: '2', tipo_evento: 'Frenado brusco', velocidad: 65, fecha: '2026-04-14 09:15', ubicacion: 'Av 68 #23-45', conductor: 'Ana Torres', lat: 4.6597, lng: -74.1009, severidad: 'media' },
  { id: '3', tipo_evento: 'Aceleración brusca', velocidad: 80, fecha: '2026-04-14 10:00', ubicacion: 'Calle 80 #12-34', conductor: 'Luis García', lat: 4.6932, lng: -74.0678, severidad: 'baja' },
  { id: '4', tipo_evento: 'Exceso de velocidad', velocidad: 135, fecha: '2026-04-14 10:45', ubicacion: 'Autopista Norte km 12', conductor: 'Pedro Ruiz', lat: 4.7123, lng: -74.0456, severidad: 'alta' },
  { id: '5', tipo_evento: 'Giro peligroso', velocidad: 55, fecha: '2026-04-13 14:20', ubicacion: 'Cra 30 #67-89', conductor: 'María López', lat: 4.6345, lng: -74.0912, severidad: 'media' },
  { id: '6', tipo_evento: 'Fatiga detectada', velocidad: 45, fecha: '2026-04-13 22:10', ubicacion: 'Ruta 50 km 34', conductor: 'Rosa Díaz', lat: 4.6789, lng: -74.1123, severidad: 'alta' },
  { id: '7', tipo_evento: 'Exceso de velocidad', velocidad: 110, fecha: '2026-04-12 16:30', ubicacion: 'Av Boyacá #89-01', conductor: 'Carlos Méndez', lat: 4.6654, lng: -74.1234, severidad: 'media' },
  { id: '8', tipo_evento: 'Frenado brusco', velocidad: 70, fecha: '2026-04-12 11:00', ubicacion: 'Calle 26 #56-78', conductor: 'Ana Torres', lat: 4.6234, lng: -74.0789, severidad: 'baja' },
];

export const mockDashboardStats = {
  totalEventos: 847,
  conductoresEnRiesgo: 12,
  eventosHoy: 23,
  vehiculosActivos: 45,
};

export const mockEventosPorDia = [
  { dia: 'Lun', eventos: 12 },
  { dia: 'Mar', eventos: 19 },
  { dia: 'Mié', eventos: 8 },
  { dia: 'Jue', eventos: 15 },
  { dia: 'Vie', eventos: 23 },
  { dia: 'Sáb', eventos: 6 },
  { dia: 'Dom', eventos: 3 },
];

export const mockEventosPorTipo = [
  { tipo: 'Exceso velocidad', cantidad: 34, fill: 'hsl(0, 84%, 60%)' },
  { tipo: 'Frenado brusco', cantidad: 22, fill: 'hsl(38, 92%, 50%)' },
  { tipo: 'Aceleración', cantidad: 18, fill: 'hsl(217, 91%, 50%)' },
  { tipo: 'Giro peligroso', cantidad: 11, fill: 'hsl(280, 70%, 55%)' },
  { tipo: 'Fatiga', cantidad: 8, fill: 'hsl(142, 71%, 45%)' },
];

export const mockRankingConductores = [
  { nombre: 'Pedro Ruiz', score: 35, eventos: 28 },
  { nombre: 'Luis García', score: 45, eventos: 22 },
  { nombre: 'Rosa Díaz', score: 67, eventos: 14 },
  { nombre: 'Ana Torres', score: 78, eventos: 9 },
  { nombre: 'María López', score: 88, eventos: 5 },
  { nombre: 'Carlos Méndez', score: 92, eventos: 3 },
];
