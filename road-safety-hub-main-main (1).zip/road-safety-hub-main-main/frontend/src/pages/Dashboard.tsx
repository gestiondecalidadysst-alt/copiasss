import { useState, useEffect, useMemo } from 'react';
import KpiCard from '@/components/KpiCard';
import { AlertTriangle, Users, Truck, Activity, Loader2 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { cn } from '@/lib/utils';
import api from '@/services/api';

interface Exceso { id: string; velocidad: number; placa: string; fecha: string; ruta: string; created_at: string; }
interface Conductor { id: string; nombre: string; cedula: string; licencia: string; telefono: string; vehiculo: string; score: number; estado: string; }
interface Vehiculo { id: string; placa: string; tipo: string; gps_id: string; estado: string; conductor: string; }

const COLORS = ['hsl(217 91% 50%)', 'hsl(0 84% 60%)', 'hsl(142 71% 45%)', 'hsl(38 92% 50%)', 'hsl(250 80% 60%)'];

const Dashboard = () => {
  const [eventos, setEventos] = useState<Exceso[]>([]);
  const [conductores, setConductores] = useState<Conductor[]>([]);
  const [vehiculos, setVehiculos] = useState<Vehiculo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [resE, resC, resV] = await Promise.all([
          api.get('/eventos'),
          api.get('/conductores'),
          api.get('/vehiculos')
        ]);
        setEventos(resE.data);
        setConductores(resC.data);
        setVehiculos(resV.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const stats = useMemo(() => {
    const now = new Date();
    const hace24Horas = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    
    const eventosHoy = eventos.filter(e => {
      if (!e.created_at) return false;
      const fechaEvento = new Date(e.created_at);
      return fechaEvento >= hace24Horas && fechaEvento <= now;
    }).length;
    
    const conductoresEnRiesgo = conductores.filter(c => c.score < 60).length;
    const vehiculosActivos = vehiculos.filter(v => v.estado === 'activo').length;
    
    return {
      totalEventos: eventos.length,
      conductoresEnRiesgo,
      eventosHoy,
      vehiculosActivos
    };
  }, [eventos, conductores, vehiculos]);

  const chartDataBar = useMemo(() => {
    const agg: Record<string, number> = {};
    eventos.forEach(e => {
        if (!e.created_at) return;
        const dStr = new Date(e.created_at).toLocaleDateString('en-CA');
        agg[dStr] = (agg[dStr] || 0) + 1;
    });
    const result = Object.entries(agg)
        .sort(([a], [b]) => a.localeCompare(b))
        .slice(-7)
        .map(([dia, count]) => ({ dia: dia.slice(5), eventos: count })); 
    
    // Fallback if empty
    return result.length > 0 ? result : [{ dia: 'Sin datos', eventos: 0 }];
  }, [eventos]);

  const chartDataPie = useMemo(() => {
    const rutas: Record<string, number> = {};
    eventos.forEach(e => {
      const r = e.ruta || 'Desconocida';
      rutas[r] = (rutas[r] || 0) + 1;
    });
    const result = Object.entries(rutas).map(([ruta, count], index) => ({
      tipo: ruta,
      cantidad: count,
      fill: COLORS[index % COLORS.length]
    }));
    return result.length > 0 ? result : [{ tipo: 'Sin datos', cantidad: 1, fill: '#ccc' }];
  }, [eventos]);

  const ranking = useMemo(() => {
    // Agrupar excesos por placa (trim para limpiar saltos de línea)
    const porPlaca: Record<string, number> = {};
    eventos.forEach(e => {
      const p = e.placa?.trim();
      if (p) porPlaca[p] = (porPlaca[p] || 0) + 1;
    });

    // Construir ranking: priorizar conductores vinculados, luego solo placa
    const conductoresMapped = conductores.map(c => ({
      id: c.id,
      nombre: c.nombre,
      vehiculo: c.vehiculo?.trim() || '-',
      score: c.score,
      estado: c.estado,
      eventosCount: porPlaca[c.vehiculo?.trim() || ''] || 0,
      tipo: 'conductor' as const,
    }));

    const placasConConductor = new Set(conductores.map(c => c.vehiculo?.trim()));
    const soloPlacas = Object.entries(porPlaca)
      .filter(([p]) => !placasConConductor.has(p))
      .map(([p, cnt]) => ({
        id: p,
        nombre: '—',
        vehiculo: p,
        score: -1,
        estado: '',
        eventosCount: cnt,
        tipo: 'placa' as const,
      }));

    return [...conductoresMapped, ...soloPlacas]
      .sort((a, b) => b.eventosCount - a.eventosCount)
      .slice(0, 10);
  }, [conductores, eventos]);

  const chartDataPlacas = useMemo(() => {
    const placaCount: Record<string, number> = {};
    eventos.forEach(e => {
      const placa = e.placa?.trim();
      if (placa) placaCount[placa] = (placaCount[placa] || 0) + 1;
    });
    const result = Object.entries(placaCount)
      .map(([placa, cantidad]) => ({ placa, cantidad }))
      .sort((a, b) => b.cantidad - a.cantidad)
      .slice(0, 10)
      .map((item, idx) => ({ ...item, fill: COLORS[idx % COLORS.length] }));
    return result.length > 0 ? result : [];
  }, [eventos]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh]">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
        <p className="mt-4 text-muted-foreground">Cargando métricas del sistema...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground text-sm">Resumen de riesgo vial en tiempo real desde Supabase</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          title="Total Excesos"
          value={stats.totalEventos}
          icon={<AlertTriangle className="w-5 h-5" />}
          trend="Histórico"
          trendUp={false}
        />
        <KpiCard
          title="Conductores en Riesgo"
          value={stats.conductoresEnRiesgo}
          icon={<Users className="w-5 h-5" />}
          trend="Score < 60"
          trendUp={false}
        />
        <KpiCard
          title="Excesos Hoy"
          value={stats.eventosHoy}
          icon={<Activity className="w-5 h-5" />}
          trend="Últimas 24h"
          trendUp={false}
        />
        <KpiCard
          title="Vehículos Activos"
          value={stats.vehiculosActivos}
          icon={<Truck className="w-5 h-5" />}
          trend={`De ${vehiculos.length} totales`}
          trendUp
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bar chart */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h3 className="font-semibold text-foreground mb-4">Excesos en los últimos días</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={chartDataBar}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 13% 91%)" />
              <XAxis dataKey="dia" tick={{ fontSize: 12 }} stroke="hsl(220 10% 46%)" />
              <YAxis tick={{ fontSize: 12 }} stroke="hsl(220 10% 46%)" />
              <Tooltip
                contentStyle={{ backgroundColor: 'hsl(0 0% 100%)', border: '1px solid hsl(220 13% 91%)', borderRadius: '8px', fontSize: '13px' }}
              />
              <Bar dataKey="eventos" fill="hsl(217 91% 50%)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Pie chart */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h3 className="font-semibold text-foreground mb-4">Excesos agrupados por Ruta</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={chartDataPie} dataKey="cantidad" nameKey="tipo" cx="50%" cy="50%" outerRadius={100} strokeWidth={2} stroke="hsl(0 0% 100%)">
                {chartDataPie.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-3 mt-2 justify-center">
            {chartDataPie.map((e) => (
              <div key={e.tipo} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: e.fill }} />
                {e.tipo} ({e.cantidad})
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top 10 Placas Chart */}
      <div className="bg-card border border-border rounded-xl p-5">
        <h3 className="font-semibold text-foreground mb-4">🚗 Top 10 Placas Más Frecuentes</h3>
        {chartDataPlacas.length > 0 ? (
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={chartDataPlacas} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 13% 91%)" />
              <XAxis type="number" tick={{ fontSize: 12 }} stroke="hsl(220 10% 46%)" />
              <YAxis dataKey="placa" type="category" tick={{ fontSize: 11 }} stroke="hsl(220 10% 46%)" />
              <Tooltip
                contentStyle={{ backgroundColor: 'hsl(0 0% 100%)', border: '1px solid hsl(220 13% 91%)', borderRadius: '8px', fontSize: '13px' }}
                formatter={(value) => [value, 'Eventos']}
              />
              <Bar dataKey="cantidad" radius={[0, 6, 6, 0]}>
                {chartDataPlacas.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex items-center justify-center h-[350px] text-muted-foreground">
            Sin datos disponibles
          </div>
        )}
      </div>

      {/* Ranking */}
      <div className="bg-card border border-border rounded-xl p-5">
        <h3 className="font-semibold text-foreground mb-4">Ranking de Conductores (Mayor cantidad de Excesos)</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">#</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Conductor</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Placa</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Excesos</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Score</th>
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Estado</th>
              </tr>
            </thead>
            <tbody>
              {ranking.map((c, i) => (
                <tr key={c.id} className="border-b border-border/50 hover:bg-muted/50 transition-colors">
                  <td className="py-3 px-4 font-bold text-foreground">{i + 1}</td>
                  <td className="py-3 px-4 text-foreground">
                    {c.nombre !== '—' ? c.nombre : <span className="text-muted-foreground italic">Sin conductor</span>}
                  </td>
                  <td className="py-3 px-4 font-mono text-muted-foreground">{c.vehiculo}</td>
                  <td className="py-3 px-4">
                    <span className={cn(
                      'inline-flex items-center justify-center min-w-[2rem] px-2 py-0.5 rounded-full text-xs font-bold',
                      c.eventosCount >= 10 ? 'bg-destructive/15 text-destructive' :
                      c.eventosCount >= 5  ? 'bg-warning/15 text-warning' :
                                             'bg-muted text-muted-foreground'
                    )}>
                      {c.eventosCount}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    {c.score >= 0 ? (
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 rounded-full bg-muted overflow-hidden">
                          <div
                            className={cn('h-full rounded-full', c.score >= 80 ? 'bg-success' : c.score >= 60 ? 'bg-warning' : 'bg-destructive')}
                            style={{ width: `${c.score}%` }}
                          />
                        </div>
                        <span className="text-foreground font-medium">{c.score}</span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground text-xs">—</span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    {c.score >= 0 ? (
                      <span className={cn(
                        'px-2 py-1 rounded-full text-xs font-medium',
                        c.score >= 80 ? 'bg-success/15 text-success' : c.score >= 60 ? 'bg-warning/15 text-warning' : 'bg-destructive/15 text-destructive'
                      )}>
                        {c.score >= 80 ? 'Seguro' : c.score >= 60 ? 'Moderado' : 'En riesgo'}
                      </span>
                    ) : (
                      <span className="text-muted-foreground text-xs italic">Sin datos</span>
                    )}
                  </td>
                </tr>
              ))}
              {ranking.length === 0 && (
                <tr>
                  <td colSpan={6} className="text-center py-6 text-muted-foreground">Sin datos de excesos</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
