import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../stores/authStore';
import { RoleProtectedRoute, useIsAdmin } from '../components/RoleProtectedRoute';
import { usuariosService } from '../services/usuariosService';
import api from '@/services/api';
import { Plus, Trash2, Edit2, Eye, EyeOff, UserPlus } from 'lucide-react';

interface Usuario {
  id: string;
  email: string;
  nombre: string;
  empresa?: string;
  activo: boolean;
  roles: string[];
  created_at: string;
}

interface Conductor {
  id: string;
  nombre: string;
  cedula: string;
  vehiculo: string;
}

interface FormData {
  email: string;
  nombre: string;
  empresa: string;
  password: string;
  rol: 'admin' | 'usuario' | 'conductor';
  conductor_id: string;
}

export default function Usuarios() {
  const isAdmin = useIsAdmin();
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [conductores, setConductores] = useState<Conductor[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);

  const [formData, setFormData] = useState<FormData>({
    email: '',
    nombre: '',
    empresa: '',
    password: '',
    rol: 'usuario',
    conductor_id: ''
  });

  // Cargar usuarios
  useEffect(() => {
    if (isAdmin) {
      cargarUsuarios();
      api.get('/conductores').then(r => setConductores(Array.isArray(r.data) ? r.data : [])).catch(() => {});
    }
  }, [isAdmin]);

  const cargarUsuarios = async () => {
    try {
      setLoading(true);
      const data = await usuariosService.getAll();
      setUsuarios(data.usuarios);
      setError(null);
    } catch (err) {
      setError('Error al cargar usuarios');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      if (editingId) {
        // Actualizar usuario
        await usuariosService.actualizar(editingId, {
          nombre: formData.nombre,
          empresa: formData.empresa
        });
        setSuccess('Usuario actualizado correctamente');
      } else {
        // Crear nuevo usuario
        await usuariosService.crear({
          email: formData.email,
          nombre: formData.nombre,
          empresa: formData.empresa,
          password: formData.password,
          rol: formData.rol,
          conductor_id: formData.conductor_id || undefined
        });
        setSuccess('Usuario creado correctamente');
      }

      // Limpiar formulario y recargar
      setFormData({
        email: '',
        nombre: '',
        empresa: '',
        password: '',
        rol: 'usuario',
        conductor_id: ''
      });
      setShowForm(false);
      setEditingId(null);
      await cargarUsuarios();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al guardar usuario');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (usuario: Usuario) => {
    setFormData({
      email: usuario.email,
      nombre: usuario.nombre,
      empresa: usuario.empresa || '',
      password: '',
      rol: (usuario.roles[0] as 'admin' | 'usuario' | 'conductor') || 'usuario',
      conductor_id: ''
    });
    setEditingId(usuario.id);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('¿Estás seguro de que deseas eliminar este usuario?')) {
      try {
        setLoading(true);
        await usuariosService.eliminar(id);
        setSuccess('Usuario eliminado correctamente');
        await cargarUsuarios();
      } catch (err) {
        setError('Error al eliminar usuario');
      } finally {
        setLoading(false);
      }
    }
  };

  const handleToggleActivo = async (id: string) => {
    try {
      setLoading(true);
      await usuariosService.toggleActivo(id);
      setSuccess('Estado del usuario actualizado');
      await cargarUsuarios();
    } catch (err) {
      setError('Error al actualizar estado');
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingId(null);
    setFormData({
      email: '',
      nombre: '',
      empresa: '',
      password: '',
      rol: 'usuario',
      conductor_id: ''
    });
  };

  if (!isAdmin) {
    return (
      <div className="p-8 text-center">
        <p className="text-red-600">No tienes permiso para acceder a esta página</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          {/* Header */}
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Gestión de Usuarios</h1>
              <p className="text-gray-600 mt-1">Administra los usuarios de la aplicación</p>
            </div>
            <button
              onClick={() => {
                setShowForm(true);
                setEditingId(null);
                setFormData({
                  email: '',
                  nombre: '',
                  empresa: '',
                  password: '',
                  rol: 'usuario',
                  conductor_id: ''
                });
              }}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition"
            >
              <UserPlus size={20} />
              Crear Usuario
            </button>
          </div>

          {/* Mensajes */}
          {error && (
            <div className="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
              {error}
            </div>
          )}
          {success && (
            <div className="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded">
              {success}
            </div>
          )}

          {/* Formulario */}
          {showForm && (
            <div className="mb-8 bg-white p-6 rounded-lg shadow">
              <h2 className="text-xl font-bold mb-4">
                {editingId ? 'Editar Usuario' : 'Crear Nuevo Usuario'}
              </h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      disabled={!!editingId}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Nombre
                    </label>
                    <input
                      type="text"
                      name="nombre"
                      value={formData.nombre}
                      onChange={handleInputChange}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Empresa
                    </label>
                    <input
                      type="text"
                      name="empresa"
                      value={formData.empresa}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Rol
                    </label>
                    <select
                      name="rol"
                      value={formData.rol}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="usuario">Usuario/Cliente</option>
                      <option value="admin">Administrador</option>
                      <option value="conductor">Conductor</option>
                    </select>
                  </div>
                </div>

                {/* Campo conductor_id solo si rol = conductor */}
                {formData.rol === 'conductor' && !editingId && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Vincular con conductor
                    </label>
                    <select
                      name="conductor_id"
                      value={formData.conductor_id}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">-- Seleccionar conductor --</option>
                      {conductores.map(c => (
                        <option key={c.id} value={c.id}>
                          {c.nombre} · {c.cedula} · {c.vehiculo}
                        </option>
                      ))}
                    </select>
                    <p className="text-xs text-gray-500 mt-1">El conductor podrá ver sus propios eventos, mensajes y capacitaciones.</p>
                  </div>
                )}

                {!editingId && (
                  <div className="relative">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Contraseña
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        name="password"
                        value={formData.password}
                        onChange={handleInputChange}
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-8 text-gray-500"
                      >
                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                    </div>
                  </div>
                )}

                <div className="flex gap-2 pt-4">
                  <button
                    type="submit"
                    disabled={loading}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-400"
                  >
                    {loading ? 'Guardando...' : 'Guardar'}
                  </button>
                  <button
                    type="button"
                    onClick={handleCancel}
                    className="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400 transition"
                  >
                    Cancelar
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Tabla de usuarios */}
          <div className="bg-white rounded-lg shadow overflow-hidden">
            {loading && !showForm ? (
              <div className="p-8 text-center text-gray-500">Cargando usuarios...</div>
            ) : usuarios.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                No hay usuarios registrados
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-100 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">
                        Email
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">
                        Nombre
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">
                        Empresa
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">
                        Rol
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">
                        Estado
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">
                        Acciones
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {usuarios.map(usuario => (
                      <tr key={usuario.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm text-gray-900">{usuario.email}</td>
                        <td className="px-6 py-4 text-sm text-gray-900">{usuario.nombre}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {usuario.empresa || '-'}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            usuario.roles.includes('admin')
                              ? 'bg-purple-100 text-purple-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}>
                            {usuario.roles[0] === 'admin' ? 'Administrador' : 'Usuario'}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <button
                            onClick={() => handleToggleActivo(usuario.id)}
                            className={`px-3 py-1 rounded text-xs font-medium transition ${
                              usuario.activo
                                ? 'bg-green-100 text-green-800 hover:bg-green-200'
                                : 'bg-red-100 text-red-800 hover:bg-red-200'
                            }`}
                          >
                            {usuario.activo ? 'Activo' : 'Inactivo'}
                          </button>
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleEdit(usuario)}
                              className="text-blue-600 hover:text-blue-800 transition"
                              title="Editar"
                            >
                              <Edit2 size={18} />
                            </button>
                            <button
                              onClick={() => handleDelete(usuario.id)}
                              className="text-red-600 hover:text-red-800 transition"
                              title="Eliminar"
                            >
                              <Trash2 size={18} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
