import { useState, useEffect, useRef } from 'react';
import api from '@/services/api';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import NoticiaCard from '@/components/NoticiaCard';
import EstadisticasNoticias from '@/components/EstadisticasNoticias';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { useAuthStore } from '@/stores/authStore';
import { useAppStore } from '@/stores/appStore';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import {
  Image, Youtube, Send, Pencil, Trash2, X, Globe, Lock,
  Loader2, Plus, ChevronDown, ChevronUp, Shield,
  ThumbsUp, ThumbsDown, MessageCircle, Award, CheckSquare, Square,
} from 'lucide-react';

// ── Tipos ─────────────────────────────────────────────────────────────────────────────────────────
interface Noticia {
  id: string;
  titulo: string;
  contenido: string;
  imagen_url: string | null;
  video_youtube: string | null;
  publicado: boolean;
  permite_certificar: boolean;
  autor: string;
  created_at: string;
  updated_at: string | null;
  me_gusta_count: number;
  no_me_gusta_count: number;
  comentarios_count: number;
  certificaciones_count: number;
}

interface Comentario {
  id: string;
  noticia_id: string;
  user_id: string;
  autor: string;
  contenido: string;
  created_at: string;
}

interface EstadisticaItem {
  user_id: string;
  autor: string;
  created_at: string;
}

interface NoticiaEstadisticas {
  vista_count: number;
  certificacion_count: number;
  comentarios_count: number;
  me_gusta_count: number;
  no_me_gusta_count: number;
  vistas: EstadisticaItem[];
  certificaciones: EstadisticaItem[];
}

// ── Helpers ────────────────────────────────────────────────────────────────────────────────────
function getYoutubeId(url: string): string | null {
  if (!url) return null;
  const regex = /(?:youtube\.com\/(?:[^/]+\/.+\/(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?/\s]{11})/;
  return url.match(regex)?.[1] ?? null;
}

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Ahora mismo';
  if (mins < 60) return `hace ${mins} min`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `hace ${hrs} h`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `hace ${days} día${days > 1 ? 's' : ''}`;
  return new Date(dateStr).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' });
}

// ── Formulario de publicación ────────────────────────────────────────────────────────────
interface PostFormProps {
  initial?: Noticia | null;
  onSave: (n: Noticia) => void;
  onCancel?: () => void;
}

const PostForm = ({ initial, onSave, onCancel }: PostFormProps) => {
  const [titulo, setTitulo] = useState(initial?.titulo ?? '');
  const [contenido, setContenido] = useState(initial?.contenido ?? '');
  const [imagenUrl, setImagenUrl] = useState(initial?.imagen_url ?? '');
  const [videoUrl, setVideoUrl] = useState(initial?.video_youtube ?? '');
  const [publicado, setPublicado] = useState(initial?.publicado ?? true);
  const [permiteCertificar, setPermiteCertificar] = useState(initial?.permite_certificar ?? false);
  const [showImageInput, setShowImageInput] = useState(!!initial?.imagen_url);
  const [showVideoInput, setShowVideoInput] = useState(!!initial?.video_youtube);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const isEditing = !!initial;
  const ytId = getYoutubeId(videoUrl);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('imagen', file);
      const { data } = await api.post('/noticias/upload-imagen', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      setImagenUrl(data.url);
      toast.success('Imagen cargada');
    } catch { toast.error('Error al subir la imagen'); }
    finally { setUploading(false); }
  };

  const handleSubmit = async () => {
    if (!titulo.trim() || !contenido.trim()) { toast.error('El título y el contenido son obligatorios'); return; }
    setSaving(true);
    try {
      const payload = { titulo: titulo.trim(), contenido: contenido.trim(), imagen_url: imagenUrl || null, video_youtube: videoUrl || null, publicado, permite_certificar: permiteCertificar };
      const { data } = isEditing
        ? await api.put(`/noticias/${initial!.id}`, payload)
        : await api.post('/noticias', payload);
      toast.success(isEditing ? 'Publicación actualizada' : '¡Publicación creada!');
      onSave(data);
    } catch { toast.error('Error al guardar la publicación'); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-4">
      <input type="text" placeholder="Título de la noticia *" value={titulo} onChange={(e) => setTitulo(e.target.value)}
        className="w-full bg-transparent border-b border-border text-lg font-semibold placeholder:text-muted-foreground focus:outline-none focus:border-primary pb-2 transition-colors" maxLength={200} />
      <textarea placeholder="¿Qué quieres compartir con tus conductores?" value={contenido} onChange={(e) => setContenido(e.target.value)} rows={4}
        className="w-full resize-none bg-transparent text-sm placeholder:text-muted-foreground focus:outline-none rounded-lg border border-border p-3 focus:border-primary transition-colors" />

      {/* Preview imagen */}
      {imagenUrl && (
        <div className="relative rounded-xl overflow-hidden border border-border">
          <img src={imagenUrl} alt="Preview" className="w-full max-h-64 object-cover" />
          <button onClick={() => setImagenUrl('')} className="absolute top-2 right-2 bg-black/60 text-white rounded-full p-1 hover:bg-black/80"><X className="w-4 h-4" /></button>
        </div>
      )}

      {/* Preview YouTube */}
      {ytId && (
        <div className="relative rounded-xl overflow-hidden border border-border aspect-video">
          <iframe src={`https://www.youtube.com/embed/${ytId}`} title="YouTube preview"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen className="w-full h-full" />
          <button onClick={() => setVideoUrl('')} className="absolute top-2 right-2 bg-black/60 text-white rounded-full p-1 hover:bg-black/80"><X className="w-4 h-4" /></button>
        </div>
      )}

      {/* Campo imagen URL */}
      {showImageInput && !imagenUrl && (
        <div className="flex gap-2 items-center">
          <input type="url" placeholder="URL de la imagen (https://...)" value={imagenUrl} onChange={(e) => setImagenUrl(e.target.value)}
            className="flex-1 border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary bg-transparent" />
          <span className="text-xs text-muted-foreground">o</span>
          <Button size="sm" variant="outline" disabled={uploading} onClick={() => fileRef.current?.click()}>
            {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Subir archivo'}
          </Button>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
        </div>
      )}

      {/* Campo YouTube URL */}
      {showVideoInput && (
        <div className="flex gap-2 items-center">
          <Youtube className="w-4 h-4 text-red-500 flex-shrink-0" />
          <input type="url" placeholder="URL de YouTube (https://youtube.com/watch?v=...)" value={videoUrl} onChange={(e) => setVideoUrl(e.target.value)}
            className="flex-1 border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary bg-transparent" />
        </div>
      )}

      {/* Opción certificar video (solo si hay video) */}
      {(videoUrl || ytId) && (
        <button onClick={() => setPermiteCertificar((v) => !v)}
          className={cn('flex items-center gap-2 text-sm px-3 py-2 rounded-lg border transition-colors w-full',
            permiteCertificar ? 'border-green-500 bg-green-500/10 text-green-700' : 'border-border text-muted-foreground hover:bg-muted')}>
          {permiteCertificar ? <CheckSquare className="w-4 h-4 text-green-600" /> : <Square className="w-4 h-4" />}
          <span className="font-medium">Habilitar "Certificar video" para los espectadores</span>
          {permiteCertificar && <Badge className="ml-auto text-[10px] bg-green-500">Activo</Badge>}
        </button>
      )}

      {/* Barra de herramientas */}
      <div className="flex items-center justify-between pt-2 border-t border-border">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground font-medium mr-1">Agregar:</span>
          <button onClick={() => { setShowImageInput((v) => !v); setShowVideoInput(false); }}
            className={cn('flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition-colors font-medium',
              showImageInput ? 'bg-green-500/10 text-green-600' : 'hover:bg-muted text-muted-foreground hover:text-foreground')}>
            <Image className="w-4 h-4" /> Foto
          </button>
          <button onClick={() => { setShowVideoInput((v) => !v); setShowImageInput(false); }}
            className={cn('flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition-colors font-medium',
              showVideoInput ? 'bg-red-500/10 text-red-600' : 'hover:bg-muted text-muted-foreground hover:text-foreground')}>
            <Youtube className="w-4 h-4" /> Video
          </button>
          <button onClick={() => setPublicado((v) => !v)}
            className={cn('flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition-colors font-medium ml-2',
              publicado ? 'bg-blue-500/10 text-blue-600' : 'bg-muted text-muted-foreground')}>
            {publicado ? <Globe className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
            {publicado ? 'Publicado' : 'Borrador'}
          </button>
        </div>
        <div className="flex items-center gap-2">
          {(isEditing || onCancel) && <Button size="sm" variant="ghost" onClick={onCancel}>Cancelar</Button>}
          <Button size="sm" onClick={handleSubmit} disabled={saving || !titulo.trim() || !contenido.trim()} className="gap-1.5">
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
            {isEditing ? 'Guardar cambios' : 'Publicar'}
          </Button>
        </div>
      </div>
    </div>
  );
};


const Noticias = () => {
  const { user } = useAuthStore();
  const { companyName } = useAppStore();
  const isAdmin = user?.rol === 'admin';
  const userId = user?.id ?? '';

  const [noticias, setNoticias] = useState<Noticia[]>([]);
  const [loading, setLoading] = useState(true);
  const [creatorOpen, setCreatorOpen] = useState(false);
  const [editingNoticia, setEditingNoticia] = useState<Noticia | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Interacciones del usuario actual
  const [misReacciones, setMisReacciones] = useState<Record<string, 'me_gusta' | 'no_me_gusta'>>({});
  const [misCertificaciones, setMisCertificaciones] = useState<Set<string>>(new Set());
  const [reaccionando, setReaccionando] = useState<string | null>(null);    // noticiaId en progreso
  const [certificando, setCertificando] = useState<string | null>(null);    // noticiaId en progreso

  // Comentarios (cargados bajo demanda)
  const [comentariosPor, setComentariosPor] = useState<Record<string, Comentario[]>>({});
  const [comentariosAbiertos, setComentariosAbiertos] = useState<Set<string>>(new Set());
  const [statsOpen, setStatsOpen] = useState(false);
  const [statsLoading, setStatsLoading] = useState(false);
  const [statsNoticia, setStatsNoticia] = useState<Noticia | null>(null);
  const [statsData, setStatsData] = useState<NoticiaEstadisticas | null>(null);

  useEffect(() => {
    Promise.all([
      api.get('/noticias'),
      api.get('/noticias/mis-interacciones'),
    ])
      .then(([{ data: ns }, { data: inter }]) => {
        setNoticias(Array.isArray(ns) ? ns : []);
        const reacMap: Record<string, 'me_gusta' | 'no_me_gusta'> = {};
        (inter.reacciones ?? []).forEach((r: { noticia_id: string; tipo: 'me_gusta' | 'no_me_gusta' }) => {
          reacMap[r.noticia_id] = r.tipo;
        });
        setMisReacciones(reacMap);
        setMisCertificaciones(new Set(inter.certificaciones ?? []));
      })
      .catch(() => toast.error('Error al cargar las noticias'))
      .finally(() => setLoading(false));
  }, []);

  const handleSave = (saved: Noticia) => {
    const withCounts = { me_gusta_count: 0, no_me_gusta_count: 0, comentarios_count: 0, certificaciones_count: 0, ...saved };
    if (editingNoticia) {
      setNoticias((prev) => prev.map((n) => n.id === saved.id ? withCounts : n));
      setEditingNoticia(null);
    } else {
      setNoticias((prev) => [withCounts, ...prev]);
      setCreatorOpen(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('¿Seguro que deseas eliminar esta publicación?')) return;
    setDeletingId(id);
    try {
      await api.delete(`/noticias/${id}`);
      setNoticias((prev) => prev.filter((n) => n.id !== id));
      toast.success('Publicación eliminada');
    } catch { toast.error('Error al eliminar la publicación'); }
    finally { setDeletingId(null); }
  };

  const handleReaccionar = async (noticiaId: string, tipo: 'me_gusta' | 'no_me_gusta') => {
    if (reaccionando) return;
    setReaccionando(noticiaId);
    const prev = misReacciones[noticiaId] ?? null;
    try {
      const { data } = await api.post(`/noticias/${noticiaId}/reaccionar`, { tipo });
      // Actualizar estado local
      setMisReacciones((m) => {
        const next = { ...m };
        if (data.accion === 'removido') delete next[noticiaId];
        else next[noticiaId] = data.tipo;
        return next;
      });
      // Actualizar contadores en la noticia
      setNoticias((ns) => ns.map((n) => {
        if (n.id !== noticiaId) return n;
        const delta = (field: 'me_gusta_count' | 'no_me_gusta_count', t: 'me_gusta' | 'no_me_gusta') => {
          if (data.accion === 'removido' && prev === t) return n[field] - 1;
          if (data.accion === 'creado' && tipo === t) return n[field] + 1;
          if (data.accion === 'cambiado') {
            if (tipo === t) return n[field] + 1;
            if (prev === t) return n[field] - 1;
          }
          return n[field];
        };
        return { ...n, me_gusta_count: delta('me_gusta_count', 'me_gusta'), no_me_gusta_count: delta('no_me_gusta_count', 'no_me_gusta') };
      }));
    } catch { toast.error('Error al registrar la reacción'); }
    finally { setReaccionando(null); }
  };

  const handleToggleComentarios = async (noticiaId: string) => {
    const isOpen = comentariosAbiertos.has(noticiaId);
    setComentariosAbiertos((prev) => {
      const next = new Set(prev);
      if (isOpen) next.delete(noticiaId); else next.add(noticiaId);
      return next;
    });
    // Cargar comentarios si no están cargados aún
    if (!isOpen && !comentariosPor[noticiaId]) {
      try {
        const { data } = await api.get(`/noticias/${noticiaId}/comentarios`);
        setComentariosPor((prev) => ({ ...prev, [noticiaId]: data }));
      } catch { toast.error('Error al cargar los comentarios'); }
    }
  };

  const handleEliminarComentario = (noticiaId: string, cid: string) => {
    setComentariosPor((prev) => ({ ...prev, [noticiaId]: (prev[noticiaId] ?? []).filter((c) => c.id !== cid) }));
    setNoticias((ns) => ns.map((n) => n.id === noticiaId ? { ...n, comentarios_count: Math.max(0, n.comentarios_count - 1) } : n));
  };

  const handleCertificar = async (noticiaId: string) => {
    if (certificando) return;
    setCertificando(noticiaId);
    try {
      const { data } = await api.post(`/noticias/${noticiaId}/certificar`);
      setMisCertificaciones((prev) => {
        const next = new Set(prev);
        if (data.accion === 'removido') next.delete(noticiaId); else next.add(noticiaId);
        return next;
      });
      setNoticias((ns) => ns.map((n) => {
        if (n.id !== noticiaId) return n;
        const delta = data.accion === 'certificado' ? 1 : -1;
        return { ...n, certificaciones_count: Math.max(0, n.certificaciones_count + delta) };
      }));
      toast.success(data.accion === 'certificado' ? '¡Video certificado!' : 'Certificación removida');
    } catch { toast.error('Error al certificar'); }
    finally { setCertificando(null); }
  };

  const handleVerEstadisticas = async (noticiaId: string) => {
    const noticia = noticias.find((item) => item.id === noticiaId);
    if (!noticia) return;
    setStatsOpen(true);
    setStatsNoticia(noticia);
    setStatsLoading(true);
    setStatsData(null);
    try {
      const { data } = await api.get(`/noticias/${noticia.id}/estadisticas`);
      setStatsData(data);
    } catch {
      toast.error('Error al cargar estadísticas');
      setStatsData(null);
    } finally {
      setStatsLoading(false);
    }
  };

  const handleExportEstadisticasPdf = () => {
    if (!statsData || !statsNoticia) return;

    const doc = new jsPDF();
    let y = 18;
    doc.setFontSize(16);
    doc.text('Reporte de estadísticas de la noticia', 14, y);
    y += 8;
    doc.setFontSize(11);
    doc.text(`Noticia: ${statsNoticia.titulo}`, 14, y);
    y += 7;
    doc.text(`Publicado: ${new Date(statsNoticia.created_at).toLocaleString('es-CO')}`, 14, y);
    y += 7;
    doc.text(`Generado: ${new Date().toLocaleString('es-CO')}`, 14, y);
    y += 10;

    const summary = [
      ['Vistas', String(statsData.vista_count)],
      ['Certificaciones', String(statsData.certificacion_count)],
      ['Comentarios', String(statsData.comentarios_count)],
      ['Me gusta', String(statsData.me_gusta_count)],
      ['No me gusta', String(statsData.no_me_gusta_count)],
    ];
    autoTable(doc, {
      startY: y,
      head: [['Métrica', 'Cantidad']],
      body: summary,
      theme: 'plain',
      headStyles: { fillColor: [44, 118, 255], textColor: '#fff' },
      styles: { fontSize: 10 },
    });
    const summaryTable = (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable;
    y = (summaryTable?.finalY ?? y) + 10;

    if (statsData.vistas.length > 0) {
      doc.setFontSize(12);
      doc.text('Vistas', 14, y);
      y += 6;
      autoTable(doc, {
        startY: y,
        head: [['#', 'Conductor', 'Visto en']],
        body: statsData.vistas.map((item, index) => [String(index + 1), item.autor || item.user_id, new Date(item.created_at).toLocaleString('es-CO')]),
        styles: { fontSize: 9 },
      });
      const viewTable = (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable;
      y = (viewTable?.finalY ?? y) + 10;
    }

    if (statsData.certificaciones.length > 0) {
      doc.setFontSize(12);
      doc.text('Certificaciones', 14, y);
      y += 6;
      autoTable(doc, {
        startY: y,
        head: [['#', 'Conductor', 'Certificado en']],
        body: statsData.certificaciones.map((item, index) => [String(index + 1), item.autor || item.user_id, new Date(item.created_at).toLocaleString('es-CO')]),
        styles: { fontSize: 9 },
      });
    }

    doc.save(`estadisticas-noticia-${statsNoticia.id}.pdf`);
  };

  const publicadas = noticias.filter((n) => n.publicado);
  const borradores = noticias.filter((n) => !n.publicado);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const renderCard = (n: Noticia) =>
    editingNoticia?.id === n.id ? (
      <Card key={n.id} className="border-2 border-primary/20">
        <CardContent className="pt-4 pb-4">
          <PostForm initial={editingNoticia} onSave={handleSave} onCancel={() => setEditingNoticia(null)} />
        </CardContent>
      </Card>
    ) : (
      <NoticiaCard
        key={n.id}
        noticia={n}
        isAdmin={isAdmin}
        userId={userId}
        miReaccion={misReacciones[n.id] ?? null}
        certificado={misCertificaciones.has(n.id)}
        comentariosAbiertos={comentariosAbiertos.has(n.id)}
        comentarios={comentariosPor[n.id] ?? null}
        onEdit={(noticia) => { setEditingNoticia(noticia); setCreatorOpen(false); }}
        onDelete={handleDelete}
        onVerEstadisticas={handleVerEstadisticas}
        onReaccionar={handleReaccionar}
        onToggleComentarios={handleToggleComentarios}
        onEnviarComentario={async (id, texto) => {
          const { data } = await api.post(`/noticias/${id}/comentarios`, { contenido: texto });
          setComentariosPor((prev) => ({ ...prev, [id]: [...(prev[id] ?? []), data] }));
          setNoticias((prev) => prev.map((item) => item.id === id ? { ...item, comentarios_count: item.comentarios_count + 1 } : item));
        }}
        onEliminarComentario={handleEliminarComentario}
        onCertificar={handleCertificar}
        reaccionando={reaccionando === n.id}
        certificando={certificando === n.id}
      />
    );

  return (
    <div className="max-w-2xl mx-auto space-y-5 pb-10 animate-fade-in">
      {/* Encabezado */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Noticias</h1>
          <p className="text-sm text-muted-foreground">{companyName} · {publicadas.length} publicación{publicadas.length !== 1 ? 'es' : ''}</p>
        </div>
        {isAdmin && !creatorOpen && (
          <Button onClick={() => { setCreatorOpen(true); setEditingNoticia(null); }} className="gap-2">
            <Plus className="w-4 h-4" /> Nueva publicación
          </Button>
        )}
      </div>

      {/* Módulo de Estadísticas de Noticias */}
      {isAdmin && (
        <EstadisticasNoticias noticias={noticias} />
      )}

      {/* Creador de posts */}
      {isAdmin && creatorOpen && !editingNoticia && (
        <Card className="border-2 border-primary/20">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Shield className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-semibold text-sm">{user?.nombre || user?.email}</p>
                <p className="text-xs text-muted-foreground">Nueva publicación</p>
              </div>
            </div>
            <PostForm onSave={handleSave} onCancel={() => setCreatorOpen(false)} />
          </CardContent>
        </Card>
      )}

      {/* Borradores */}
      {isAdmin && borradores.length > 0 && !creatorOpen && (
        <div className="space-y-3">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Borradores ({borradores.length})</p>
          {borradores.map(renderCard)}
        </div>
      )}

      {/* Feed publicadas */}
      <div className="space-y-4">
        {publicadas.length === 0 && !creatorOpen ? (
          <Card>
            <CardContent className="py-16 text-center space-y-3">
              <Globe className="w-12 h-12 mx-auto text-muted-foreground/30" />
              <p className="text-muted-foreground">No hay publicaciones todavía.</p>
              {isAdmin && (
                <Button variant="outline" onClick={() => setCreatorOpen(true)} className="gap-2">
                  <Plus className="w-4 h-4" /> Crear la primera publicación
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          publicadas.map(renderCard)
        )}
      </div>

      {deletingId && (
        <div className="fixed inset-0 bg-black/20 flex items-center justify-center z-50">
          <div className="bg-card border border-border rounded-xl px-6 py-4 flex items-center gap-3 shadow-xl">
            <Loader2 className="w-5 h-5 animate-spin text-primary" />
            <span className="text-sm font-medium">Eliminando…</span>
          </div>
        </div>
      )}

      <Dialog open={statsOpen} onOpenChange={(open) => { if (!open) { setStatsOpen(false); setStatsNoticia(null); setStatsData(null); } }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Estadísticas de la noticia</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            {statsLoading ? (
              <div className="flex justify-center py-10">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : statsData && statsNoticia ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-xl border border-border p-4">
                    <p className="text-xs uppercase text-muted-foreground">Vistas</p>
                    <p className="text-2xl font-semibold">{statsData.vista_count}</p>
                  </div>
                  <div className="rounded-xl border border-border p-4">
                    <p className="text-xs uppercase text-muted-foreground">Certificaciones</p>
                    <p className="text-2xl font-semibold">{statsData.certificacion_count}</p>
                  </div>
                  <div className="rounded-xl border border-border p-4">
                    <p className="text-xs uppercase text-muted-foreground">Comentarios</p>
                    <p className="text-2xl font-semibold">{statsData.comentarios_count}</p>
                  </div>
                  <div className="rounded-xl border border-border p-4">
                    <p className="text-xs uppercase text-muted-foreground">Reacciones</p>
                    <p className="text-2xl font-semibold">{statsData.me_gusta_count + statsData.no_me_gusta_count}</p>
                  </div>
                </div>
                <div className="grid gap-3 lg:grid-cols-2">
                  <div className="rounded-xl border border-border p-4">
                    <p className="text-sm font-semibold">Vistas recientes</p>
                    <div className="mt-3 space-y-2 max-h-52 overflow-y-auto">
                      {statsData.vistas.length === 0 ? (
                        <p className="text-sm text-muted-foreground">Nadie ha visto esta noticia aún.</p>
                      ) : statsData.vistas.map((item) => (
                        <div key={`${item.user_id}-${item.created_at}`} className="rounded-xl bg-muted/50 p-3">
                          <p className="font-medium text-sm">{item.autor || item.user_id}</p>
                          <p className="text-xs text-muted-foreground">{new Date(item.created_at).toLocaleString('es-CO')}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="rounded-xl border border-border p-4">
                    <p className="text-sm font-semibold">Certificaciones recientes</p>
                    <div className="mt-3 space-y-2 max-h-52 overflow-y-auto">
                      {statsData.certificaciones.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No hay certificaciones aún.</p>
                      ) : statsData.certificaciones.map((item) => (
                        <div key={`${item.user_id}-${item.created_at}`} className="rounded-xl bg-muted/50 p-3">
                          <p className="font-medium text-sm">{item.autor || item.user_id}</p>
                          <p className="text-xs text-muted-foreground">{new Date(item.created_at).toLocaleString('es-CO')}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setStatsOpen(false)}>Cerrar</Button>
                  <Button onClick={handleExportEstadisticasPdf}>Exportar PDF</Button>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Selecciona una noticia para ver sus estadísticas.</p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Noticias;
