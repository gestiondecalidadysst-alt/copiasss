import { useState, useEffect } from 'react';
import api from '@/services/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Search, Pencil, Trash2, Loader2, Building2 } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { useAppStore } from '@/stores/appStore';
import { loadBrandingBackend } from '@/services/brandingService';

interface Conductor {
  id: string;
  nombre: string;
  cedula: string;
  licencia: string;
  telefono: string;
  vehiculo: string;
  score: number;
  estado: string;
}

const ESTADOS_CONDUCTOR = ['activo', 'inactivo', 'suspendido'] as const;

const emptyForm = { nombre: '', cedula: '', licencia: '', telefono: '', vehiculo: '', estado: 'activo', score: 100 };

const Conductores = () => {
  const { companyName, companyLogo, setCompanyName, setCompanyLogo } = useAppStore();
  const [conductores, setConductores] = useState<Conductor[]>([]);
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Conductor | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [placas, setPlacas] = useState<string[]>([]);

  // Cargar branding desde el backend
  useEffect(() => {
    loadBrandingBackend().then((saved) => {
      if (saved) {
        if (saved.company_name) setCompanyName(saved.company_name);
        if (saved.company_logo) setCompanyLogo(saved.company_logo);
      }
    });
  }, []);

  useEffect(() => {
    api.get('/vehiculos')
      .then(r => setPlacas([...new Set((r.data as { placa: string }[]).map(v => v.placa?.trim()).filter(Boolean) as string[])]))
      .catch(() => {});
  }, []);

  const fetchConductores = async () => {
    try {
      const res = await api.get('/conductores');
      setConductores(Array.isArray(res.data) ? res.data : []);
    } catch { toast.error('Error al cargar conductores: verifica que el servidor esté activo'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchConductores(); }, []);

  const filtered = conductores.filter((c) =>
    c.nombre.toLowerCase().includes(search.toLowerCase()) ||
    c.cedula.includes(search) ||
    (c.vehiculo ?? '').toLowerCase().includes(search.toLowerCase())
  );

  const handleSave = async () => {
    if (!form.nombre.trim() || !form.cedula.trim()) return toast.error('Nombre y cédula son requeridos');

    const normalizedCedula = form.cedula.trim();
    const duplicate = conductores.some((c) => c.cedula.trim() === normalizedCedula && (!editing || c.id !== editing.id));
    if (duplicate) {
      return toast.error('Ya existe un conductor con esta cédula');
    }

    setSaving(true);
    try {
      const payload = {
        nombre: form.nombre.trim(),
        cedula: normalizedCedula,
        licencia: (form.licencia ?? '').trim(),
        telefono: (form.telefono ?? '').trim(),
        vehiculo: (form.vehiculo ?? '').trim(),
        estado: form.estado,
        score: Number(form.score),
      };
      if (editing) {
        await api.put(`/conductores/${editing.id}`, payload);
        toast.success('Conductor actualizado');
      } else {
        await api.post('/conductores', payload);
        toast.success('Conductor creado');
      }
      setDialogOpen(false);
      setEditing(null);
      setForm(emptyForm);
      // Recargar lista desde el servidor para garantizar sincronía
      setLoading(true);
      await fetchConductores();
    } catch (err) {
      const message =
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        (err instanceof Error ? err.message : 'Error al guardar');
      toast.error(message);
    } finally { setSaving(false); }
  };

  const handleEdit = (c: Conductor) => {
    setEditing(c);
    setForm({
      nombre: c.nombre ?? '',
      cedula: c.cedula ?? '',
      licencia: c.licencia ?? '',
      telefono: c.telefono ?? '',
      vehiculo: c.vehiculo ?? '',
      estado: c.estado ?? 'activo',
      score: c.score ?? 100,
    });
    setDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await api.delete(`/conductores/${deleteId}`);
      setConductores(conductores.filter(c => c.id !== deleteId));
      toast.success('Conductor eliminado');
    } catch { toast.error('Error al eliminar conductor'); }
    finally { setDeleteId(null); }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Encabezado con branding */}
      <div className="flex items-center justify-between flex-wrap gap-4 pb-4 border-b">
        <div className="flex items-center gap-4">
          {companyLogo && (
            <img 
              src={companyLogo} 
              alt="Logo empresa" 
              className="h-12 max-w-[150px] object-contain"
            />
          )}
          <div>
            <div className="flex items-center gap-2">
              {!companyLogo && <Building2 className="w-5 h-5 text-muted-foreground" />}
              <h1 className="text-2xl font-bold text-foreground">
                {companyName ? `${companyName} - Conductores` : 'Conductores'}
              </h1>
            </div>
            <p className="text-muted-foreground text-sm">{conductores.length} conductores registrados</p>
          </div>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(o) => {
          setDialogOpen(o);
          if (!o) { setEditing(null); setForm(emptyForm); }
        }}>
          <DialogTrigger asChild>
            <Button className="gradient-primary text-primary-foreground">
              <Plus className="w-4 h-4 mr-2" />Nuevo conductor
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editing ? 'Editar conductor' : 'Nuevo conductor'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-2 max-h-[70vh] overflow-y-auto pr-1">
              <div>
                <Label>Nombre completo <span className="text-destructive">*</span></Label>
                <Input value={form.nombre} onChange={(e) => setForm({ ...form, nombre: e.target.value })} placeholder="Ej: Juan Pérez García" />
              </div>
              <div>
                <Label>Cédula <span className="text-destructive">*</span></Label>
                <Input value={form.cedula} onChange={(e) => setForm({ ...form, cedula: e.target.value })} placeholder="Ej: 12345678" />
              </div>
              <div>
                <Label>Licencia de conducción</Label>
                <Input value={form.licencia} onChange={(e) => setForm({ ...form, licencia: e.target.value })} placeholder="Ej: C1, C2..." />
              </div>
              <div>
                <Label>Teléfono</Label>
                <Input value={form.telefono} onChange={(e) => setForm({ ...form, telefono: e.target.value })} placeholder="Ej: 3001234567" />
              </div>
              <div>
                <Label>Vehículo asignado (placa)</Label>
                <Select value={form.vehiculo} onValueChange={(v) => setForm({ ...form, vehiculo: v })}>
                  <SelectTrigger><SelectValue placeholder="Selecciona una placa" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="-">Sin asignar</SelectItem>
                    {placas.map(p => (
                      <SelectItem key={p} value={p}>{p}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Estado</Label>
                <Select value={form.estado} onValueChange={(v) => setForm({ ...form, estado: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {ESTADOS_CONDUCTOR.map(e => (
                      <SelectItem key={e} value={e} className="capitalize">{e}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Score de seguridad (0–100)</Label>
                <Input
                  type="number"
                  min={0} max={100}
                  value={form.score}
                  onChange={(e) => setForm({ ...form, score: Math.min(100, Math.max(0, Number(e.target.value))) })}
                />
              </div>
              <Button onClick={handleSave} disabled={saving} className="w-full gradient-primary text-primary-foreground">
                {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
                {editing ? 'Guardar cambios' : 'Crear conductor'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Buscador */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar por nombre, cédula o placa..." className="pl-9" />
      </div>

      {/* Tabla */}
      {loading ? (
        <div className="flex justify-center items-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2 text-muted-foreground">Cargando conductores...</span>
        </div>
      ) : (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  {['Nombre', 'Cédula', 'Licencia', 'Teléfono', 'Vehículo', 'Estado', 'Score', 'Acciones'].map((h) => (
                    <th key={h} className="text-left py-3 px-4 text-muted-foreground font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-muted-foreground">
                      {search ? 'Sin resultados para la búsqueda.' : 'No hay conductores registrados.'}
                    </td>
                  </tr>
                ) : (
                  filtered.map((c) => (
                    <tr key={c.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                      <td className="py-3 px-4 font-medium text-foreground">{c.nombre}</td>
                      <td className="py-3 px-4 text-muted-foreground">{c.cedula}</td>
                      <td className="py-3 px-4 text-foreground">{c.licencia || '-'}</td>
                      <td className="py-3 px-4 text-muted-foreground">{c.telefono || '-'}</td>
                      <td className="py-3 px-4 font-mono text-xs text-foreground">{c.vehiculo || '-'}</td>
                      <td className="py-3 px-4">
                        <span className={cn(
                          'px-2 py-1 rounded-full text-xs font-medium capitalize',
                          c.estado === 'activo' ? 'bg-success/15 text-success'
                          : c.estado === 'suspendido' ? 'bg-destructive/15 text-destructive'
                          : 'bg-muted text-muted-foreground'
                        )}>{c.estado || '-'}</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={cn(
                          'px-2.5 py-1 rounded-full text-xs font-bold',
                          (c.score ?? 100) >= 80 ? 'bg-success/15 text-success'
                          : (c.score ?? 100) >= 60 ? 'bg-warning/15 text-warning'
                          : 'bg-destructive/15 text-destructive'
                        )}>{c.score ?? '-'}</span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" onClick={() => handleEdit(c)}>
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => setDeleteId(c.id)}>
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Confirmación borrado */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => { if (!o) setDeleteId(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar conductor?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. El conductor será eliminado permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Conductores;
