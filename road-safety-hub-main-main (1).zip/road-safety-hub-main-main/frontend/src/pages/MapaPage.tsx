import { useEffect, useRef, useState, useMemo } from 'react';
import api from '@/services/api';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Loader2, Calendar, AlertTriangle, Search, Layers, Download, FileSpreadsheet, FileText, Maximize2, Minimize2 } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import html2canvas from 'html2canvas';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';

import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({ iconRetinaUrl: markerIcon2x, iconUrl: markerIcon, shadowUrl: markerShadow });

// ── Map tile layers ──────────────────────────────────────────────────────────
const MAP_LAYERS: Record<string, { url: string; attribution: string; label: string }> = {
  carto: {
    url: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
    attribution: '&copy; OpenStreetMap &copy; CARTO',
    label: '🗺️ Claro',
  },
  cartoDark: {
    url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    attribution: '&copy; OpenStreetMap &copy; CARTO',
    label: '🌙 Oscuro',
  },
  osm: {
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; OpenStreetMap contributors',
    label: '🌍 Estándar',
  },
  satellite: {
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: '&copy; Esri',
    label: '🛰️ Satélite',
  },
};

// ── Speed tiers ──────────────────────────────────────────────────────────────
const TIERS = {
  peligro: { label: 'Peligro', color: '#ef4444', bg: '#fef2f2', range: '> 100 km/h' },
  alerta:  { label: 'Alerta',  color: '#f59e0b', bg: '#fffbeb', range: '81–100 km/h' },
  limite:  { label: 'Límite',  color: '#22c55e', bg: '#f0fdf4', range: '≤ 80 km/h' },
};

function getTier(v: number) {
  if (v > 100) return 'peligro';
  if (v > 80)  return 'alerta';
  return 'limite';
}

function formatDateLocal(d: string | Date | null | undefined): string {
  if (!d) return '';
  try {
    const dt = new Date(d);
    if (isNaN(dt.getTime())) return '';
    return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
  } catch { return ''; }
}

interface Exceso {
  id: string | number;
  created_at: string;
  velocidad: number;
  placa: string;
  fecha: string;
  ruta: string;
  latitud?: number | string | null;
  longitud?: number | string | null;
}

// ── Component ────────────────────────────────────────────────────────────────
const MapaPage = () => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstance     = useRef<L.Map | null>(null);
  const layerGroupRef   = useRef<L.LayerGroup | null>(null);
  const tileLayerRef    = useRef<L.TileLayer | null>(null);
  const chartNivelesRef = useRef<HTMLDivElement>(null);
  const chartPlacasRef  = useRef<HTMLDivElement>(null);

  const [eventos,    setEventos]    = useState<Exceso[]>([]);
  const [loading,    setLoading]    = useState(true);
  const [error,      setError]      = useState<string | null>(null);
  const today = formatDateLocal(new Date());
  const [fechaInicio, setFechaInicio] = useState(today);
  const [fechaFin,    setFechaFin]    = useState(today);
  const [filtroPlaca, setFiltroPlaca] = useState('');
  const [showPlacasDropdown, setShowPlacasDropdown] = useState(false);
  const [activeLayer, setActiveLayer] = useState<keyof typeof MAP_LAYERS>('carto');
  const [tiersActive, setTiersActive] = useState<Record<string, boolean>>({ peligro: true, alerta: true, limite: true });
  const [showLayers,  setShowLayers]  = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Fetch
  useEffect(() => {
    api.get('/eventos')
      .then(r => setEventos(r.data))
      .catch(() => setError('No se pudo conectar con el backend.'))
      .finally(() => setLoading(false));
  }, []);

  // Init map
  useEffect(() => {
    if (loading || !mapContainerRef.current || mapInstance.current) return;
    const map = L.map(mapContainerRef.current, { center: [8.81, -75.84], zoom: 12, zoomControl: true });
    mapInstance.current = map;
    const layer = L.tileLayer(MAP_LAYERS[activeLayer].url, { attribution: MAP_LAYERS[activeLayer].attribution, maxZoom: 20 });
    layer.addTo(map);
    tileLayerRef.current = layer;
    const lg = L.layerGroup().addTo(map);
    layerGroupRef.current = lg;
    setTimeout(() => map.invalidateSize(), 300);
    return () => { if (mapInstance.current) { mapInstance.current.remove(); mapInstance.current = null; } };
  }, [loading]);

  // Switch tile layer
  useEffect(() => {
    const map = mapInstance.current;
    if (!map) return;
    if (tileLayerRef.current) map.removeLayer(tileLayerRef.current);
    const l = L.tileLayer(MAP_LAYERS[activeLayer].url, { attribution: MAP_LAYERS[activeLayer].attribution, maxZoom: 20 });
    l.addTo(map);
    tileLayerRef.current = l;
  }, [activeLayer]);

  // Filtered events
  const filtered = useMemo(() => eventos.filter(e => {
    const lat = parseFloat(String(e.latitud));
    const lng = parseFloat(String(e.longitud));
    if (isNaN(lat) || isNaN(lng) || lat === 0) return false;
    if (!tiersActive[getTier(e.velocidad)]) return false;
    const dateStr = formatDateLocal(e.created_at);
    if (fechaInicio && dateStr < fechaInicio) return false;
    if (fechaFin   && dateStr > fechaFin)    return false;
    if (filtroPlaca && !e.placa?.toUpperCase().includes(filtroPlaca.toUpperCase().trim())) return false;
    return true;
  }), [eventos, fechaInicio, fechaFin, filtroPlaca, tiersActive]);

  // Unique placas for dropdown
  const placasDisponibles = useMemo(() => {
    const uniquePlacas = new Set(eventos.map(e => e.placa?.trim()).filter(Boolean));
    return Array.from(uniquePlacas).sort();
  }, [eventos]);

  // Draw markers
  useEffect(() => {
    const map = mapInstance.current;
    const lg  = layerGroupRef.current;
    if (!map || !lg) return;
    lg.clearLayers();
    if (!filtered.length) return;
    const bounds = L.latLngBounds([]);
    filtered.forEach(e => {
      const lat = parseFloat(String(e.latitud));
      const lng = parseFloat(String(e.longitud));
      const tier  = getTier(e.velocidad);
      const color = TIERS[tier].color;
      const pulse = tier === 'peligro' ? `<span style="position:absolute;top:-4px;left:-4px;width:28px;height:28px;border-radius:50%;background:${color};opacity:0.3;animation:ping 1.5s cubic-bezier(0,0,0.2,1) infinite;"></span>` : '';
      const icon = L.divIcon({
        className: '',
        iconSize:   [20, 20],
        iconAnchor: [10, 10],
        html: `<div style="position:relative;width:20px;height:20px;">${pulse}<div style="width:20px;height:20px;border-radius:50%;background:${color};border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.3);"></div></div>`,
      });
      const m = L.marker([lat, lng], { icon });
      m.bindPopup(`
        <div style="font-family:'Segoe UI',sans-serif;min-width:180px;padding:4px">
          <div style="background:${color};color:#fff;border-radius:6px 6px 0 0;margin:-4px -4px 8px -4px;padding:8px 10px;">
            <strong style="font-size:14px">🚗 ${e.placa?.trim()}</strong>
            <div style="font-size:18px;font-weight:900">${e.velocidad} km/h</div>
          </div>
          <p style="margin:4px 0;font-size:11px;color:#444">📍 ${e.ruta}</p>
          <p style="margin:4px 0;font-size:10px;color:#888">${new Date(e.created_at).toLocaleString('es-CO')}</p>
        </div>`);
      lg.addLayer(m);
      bounds.extend([lat, lng]);
    });
    if (filtered.length === 1) map.setView([parseFloat(String(filtered[0].latitud)), parseFloat(String(filtered[0].longitud))], 15);
    else map.fitBounds(bounds, { padding: [60, 60] });
    setTimeout(() => map.invalidateSize(), 100);
  }, [filtered]);

  // Stats
  const counts = useMemo(() => {
    const desde = fechaInicio || formatDateLocal(new Date());
    const hasta = fechaFin    || formatDateLocal(new Date());
    const rango = eventos.filter(e => {
      const d = formatDateLocal(e.created_at);
      return d >= desde && d <= hasta;
    });
    return {
      total:   rango.length,
      peligro: rango.filter(e => getTier(e.velocidad) === 'peligro').length,
      alerta:  rango.filter(e => getTier(e.velocidad) === 'alerta').length,
      limite:  rango.filter(e => getTier(e.velocidad) === 'limite').length,
      enMapa:  filtered.length,
    };
  }, [eventos, fechaInicio, fechaFin, filtered]);

  // Chart data - Eventos por nivel de velocidad
  const chartDataNiveles = useMemo(() => [
    { nombre: 'Peligro', cantidad: counts.peligro, fill: TIERS.peligro.color },
    { nombre: 'Alerta', cantidad: counts.alerta, fill: TIERS.alerta.color },
    { nombre: 'Límite', cantidad: counts.limite, fill: TIERS.limite.color },
  ], [counts]);

  // Chart data - Top 5 placas más frecuentes
  const chartDataPlacas = useMemo(() => {
    const placaCount: Record<string, number> = {};
    filtered.forEach(e => {
      const placa = e.placa?.trim();
      if (placa) placaCount[placa] = (placaCount[placa] || 0) + 1;
    });
    return Object.entries(placaCount)
      .map(([placa, cantidad]) => ({ placa, cantidad }))
      .sort((a, b) => b.cantidad - a.cantidad)
      .slice(0, 5);
  }, [filtered]);

  // ── Export PDF ──
  const exportPDF = async () => {
    try {
      const doc = new jsPDF();
      let currentY = 15;

      // Title
      doc.setFontSize(16);
      doc.text('Reporte de Excesos de Velocidad', 14, currentY);
      currentY += 8;

      // Metadata
      doc.setFontSize(10);
      const rangoLabel = fechaInicio === fechaFin ? fechaInicio || 'Todos' : `${fechaInicio || '?'} → ${fechaFin || '?'}`;
      doc.text(`Período: ${rangoLabel}  |  Generado: ${new Date().toLocaleString('es-CO')}`, 14, currentY);
      currentY += 8;

      // Summary stats
      doc.setFontSize(9);
      doc.text(`Total: ${counts.total} | Peligro: ${counts.peligro} | Alerta: ${counts.alerta} | Límite: ${counts.limite}`, 14, currentY);
      currentY += 6;

      // Line separator
      doc.setDrawColor(200, 200, 200);
      doc.line(14, currentY, 196, currentY);
      currentY += 8;

      // Chart 1 - Niveles
      if (chartNivelesRef.current) {
        try {
          const canvas = await html2canvas(chartNivelesRef.current, { scale: 2, backgroundColor: '#fff' });
          const imgData = canvas.toDataURL('image/png');
          doc.addImage(imgData, 'PNG', 14, currentY, 85, 50);
        } catch (err) {
          console.error('Error capturando gráfico de niveles:', err);
        }
      }

      // Chart 2 - Placas
      if (chartPlacasRef.current) {
        try {
          const canvas = await html2canvas(chartPlacasRef.current, { scale: 2, backgroundColor: '#fff' });
          const imgData = canvas.toDataURL('image/png');
          doc.addImage(imgData, 'PNG', 105, currentY, 85, 50);
        } catch (err) {
          console.error('Error capturando gráfico de placas:', err);
        }
      }

      currentY += 55;

      // Line separator
      doc.setDrawColor(200, 200, 200);
      doc.line(14, currentY, 196, currentY);
      currentY += 6;

      // Table
      autoTable(doc, {
        startY: currentY,
        head: [['Placa', 'Velocidad', 'Nivel', 'Ruta', 'Fecha/Hora']],
        body: filtered.map(e => [
          e.placa?.trim(),
          `${e.velocidad} km/h`,
          TIERS[getTier(e.velocidad)].label,
          e.ruta,
          new Date(e.created_at).toLocaleString('es-CO'),
        ]),
        headStyles: { fillColor: [37, 99, 235], textColor: [255, 255, 255] },
        alternateRowStyles: { fillColor: [243, 244, 246] },
        margin: { left: 14, right: 14 },
      });

      doc.save(`excesos_${fechaInicio || 'todos'}_${fechaFin || 'todos'}.pdf`);
    } catch (error) {
      console.error('Error generando PDF:', error);
    }
  };

  // ── Export Excel ──
  const exportExcel = () => {
    const data = filtered.map(e => ({
      Placa: e.placa?.trim(),
      Velocidad: e.velocidad,
      Nivel: TIERS[getTier(e.velocidad)].label,
      Ruta: e.ruta,
      Latitud: e.latitud,
      Longitud: e.longitud,
      FechaHora: new Date(e.created_at).toLocaleString('es-CO'),
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Excesos');
    XLSX.writeFile(wb, `excesos_${fechaInicio || 'todos'}_${fechaFin || 'todos'}.xlsx`);
  };

  // ── Fullscreen toggle ──
  const toggleFullscreen = async () => {
    try {
      const mapContainer = mapContainerRef.current;
      if (!mapContainer) return;

      if (!isFullscreen) {
        // Enter fullscreen
        if (mapContainer.requestFullscreen) {
          await mapContainer.requestFullscreen();
        } else if ((mapContainer as any).webkitRequestFullscreen) {
          await (mapContainer as any).webkitRequestFullscreen();
        } else if ((mapContainer as any).mozRequestFullScreen) {
          await (mapContainer as any).mozRequestFullScreen();
        }
        setIsFullscreen(true);
      } else {
        // Exit fullscreen
        if (document.fullscreenElement) {
          await document.exitFullscreen();
        } else if ((document as any).webkitFullscreenElement) {
          await (document as any).webkitExitFullscreen();
        } else if ((document as any).mozFullScreenElement) {
          await (document as any).mozCancelFullScreen();
        }
        setIsFullscreen(false);
      }
    } catch (error) {
      console.error('Fullscreen error:', error);
    }
  };

  // Handle fullscreen change events
  useEffect(() => {
    const handleFullscreenChange = () => {
      const isCurrentlyFullscreen = !!(document.fullscreenElement || (document as any).webkitFullscreenElement || (document as any).mozFullScreenElement);
      setIsFullscreen(isCurrentlyFullscreen);
      // Trigger map resize after fullscreen changes
      setTimeout(() => mapInstance.current?.invalidateSize(), 300);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
    };
  }, []);

  // ── Loading / Error states ──
  if (loading) return (
    <div className="flex flex-col items-center justify-center h-[550px] bg-card border border-border rounded-xl">
      <Loader2 className="w-10 h-10 animate-spin text-primary" />
      <p className="mt-4 text-muted-foreground font-medium">Cargando mapa...</p>
    </div>
  );
  if (error) return (
    <div className="flex flex-col items-center justify-center h-[550px] bg-card border border-border rounded-xl">
      <AlertTriangle className="w-10 h-10 text-destructive mb-3" />
      <p className="text-destructive font-semibold">{error}</p>
    </div>
  );

  return (
    <div className={`space-y-5 animate-fade-in ${isFullscreen ? 'fixed inset-0 z-[9999] bg-black flex flex-col' : ''}`}>

      {isFullscreen && (
        // Fullscreen header with controls
        <div className="bg-card border-b border-border p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 flex-shrink-0">
          <div>
            <h1 className="text-lg font-bold text-foreground">Mapa de Seguridad Vial</h1>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {/* Placa filter */}
            <div className="relative">
              <div className="flex items-center gap-2 bg-background border border-border px-3 py-1.5 rounded-lg shadow-sm">
                <Search className="w-4 h-4 text-muted-foreground" />
                <Input type="text" placeholder="Filtrar por placa..." value={filtroPlaca} 
                  onChange={e => setFiltroPlaca(e.target.value)}
                  onFocus={() => setShowPlacasDropdown(true)}
                  className="h-7 border-none focus-visible:ring-0 px-0 w-32 bg-transparent text-sm uppercase" />
              </div>
              {showPlacasDropdown && placasDisponibles.length > 0 && (
                <div className="absolute top-9 left-0 z-[2000] bg-white border border-border rounded-xl shadow-xl p-2 min-w-[180px] max-h-56 overflow-y-auto">
                  {placasDisponibles.map(placa => (
                    <button key={placa} onClick={() => { setFiltroPlaca(placa); setShowPlacasDropdown(false); }}
                      className="w-full text-left px-3 py-2 rounded-lg text-xs transition-colors hover:bg-blue-100 hover:text-blue-900 font-mono">
                      {placa}
                    </button>
                  ))}
                </div>
              )}
            </div>
            {filtroPlaca && <Button variant="ghost" size="sm" onClick={() => setFiltroPlaca('')} className="text-xs">Limpiar placa</Button>}

            {/* Date range filter */}
            <div className="flex items-center gap-1.5 bg-background border border-border px-3 py-1.5 rounded-lg shadow-sm">
              <Calendar className="w-4 h-4 text-muted-foreground shrink-0" />
              <Input type="date" value={fechaInicio} onChange={e => setFechaInicio(e.target.value)}
                className="h-7 border-none focus-visible:ring-0 px-0 w-32 bg-transparent text-sm" />
              <span className="text-muted-foreground text-xs">—</span>
              <Input type="date" value={fechaFin} onChange={e => setFechaFin(e.target.value)}
                min={fechaInicio}
                className="h-7 border-none focus-visible:ring-0 px-0 w-32 bg-transparent text-sm" />
            </div>
            <Button variant="ghost" size="sm" onClick={() => { setFechaInicio(today); setFechaFin(today); }} className="text-xs">Hoy</Button>

            {/* Layer switcher */}
            <div className="relative">
              <Button variant="outline" size="sm" onClick={() => setShowLayers(p => !p)} className="gap-1.5 text-xs">
                <Layers className="w-3.5 h-3.5" /> Capa
              </Button>
              {showLayers && (
                <div className="absolute right-0 top-9 z-[2000] bg-white border border-border rounded-xl shadow-xl p-2 min-w-[140px]">
                  {Object.entries(MAP_LAYERS).map(([key, val]) => (
                    <button key={key} onClick={() => { setActiveLayer(key as any); setShowLayers(false); }}
                      className={`w-full text-left px-3 py-1.5 rounded-lg text-xs transition-colors ${activeLayer === key ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'}`}>
                      {val.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Exit fullscreen button */}
            <Button variant="outline" size="sm" onClick={toggleFullscreen} className="gap-1.5 text-xs">
              <Minimize2 className="w-3.5 h-3.5" /> Salir
            </Button>
          </div>
        </div>
      )}

      {!isFullscreen && (
        <>
          {/* ── Header ── */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Mapa de Seguridad Vial</h1>
              <p className="text-muted-foreground text-sm">Monitoreo geográfico en tiempo real</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {/* Placa filter */}
              <div className="relative">
                <div className="flex items-center gap-2 bg-card border border-border px-3 py-1.5 rounded-lg shadow-sm">
                  <Search className="w-4 h-4 text-muted-foreground" />
                  <Input type="text" placeholder="Filtrar por placa..." value={filtroPlaca} 
                    onChange={e => setFiltroPlaca(e.target.value)}
                    onFocus={() => setShowPlacasDropdown(true)}
                    className="h-7 border-none focus-visible:ring-0 px-0 w-32 bg-transparent text-sm uppercase" />
                </div>
                {showPlacasDropdown && placasDisponibles.length > 0 && (
                  <div className="absolute top-9 left-0 z-[2000] bg-white border border-border rounded-xl shadow-xl p-2 min-w-[180px] max-h-56 overflow-y-auto">
                    {placasDisponibles.map(placa => (
                      <button key={placa} onClick={() => { setFiltroPlaca(placa); setShowPlacasDropdown(false); }}
                        className="w-full text-left px-3 py-2 rounded-lg text-xs transition-colors hover:bg-blue-100 hover:text-blue-900 font-mono">
                        {placa}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {filtroPlaca && <Button variant="ghost" size="sm" onClick={() => setFiltroPlaca('')} className="text-xs">Limpiar placa</Button>}

              {/* Date range filter */}
              <div className="flex items-center gap-1.5 bg-card border border-border px-3 py-1.5 rounded-lg shadow-sm">
                <Calendar className="w-4 h-4 text-muted-foreground shrink-0" />
                <Input type="date" value={fechaInicio} onChange={e => setFechaInicio(e.target.value)}
                  className="h-7 border-none focus-visible:ring-0 px-0 w-32 bg-transparent text-sm" />
                <span className="text-muted-foreground text-xs">—</span>
                <Input type="date" value={fechaFin} onChange={e => setFechaFin(e.target.value)}
                  min={fechaInicio}
                  className="h-7 border-none focus-visible:ring-0 px-0 w-32 bg-transparent text-sm" />
              </div>
              <Button variant="ghost" size="sm" onClick={() => { setFechaInicio(today); setFechaFin(today); }} className="text-xs">Hoy</Button>

              {/* Layer switcher */}
              <div className="relative">
                <Button variant="outline" size="sm" onClick={() => setShowLayers(p => !p)} className="gap-1.5 text-xs">
                  <Layers className="w-3.5 h-3.5" /> Capa
                </Button>
                {showLayers && (
                  <div className="absolute right-0 top-9 z-[2000] bg-white border border-border rounded-xl shadow-xl p-2 min-w-[140px]">
                    {Object.entries(MAP_LAYERS).map(([key, val]) => (
                      <button key={key} onClick={() => { setActiveLayer(key as any); setShowLayers(false); }}
                        className={`w-full text-left px-3 py-1.5 rounded-lg text-xs transition-colors ${activeLayer === key ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'}`}>
                        {val.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Export */}
              <Button variant="outline" size="sm" onClick={exportPDF} className="gap-1.5 text-xs">
                <FileText className="w-3.5 h-3.5 text-red-500" /> PDF
              </Button>
              <Button variant="outline" size="sm" onClick={exportExcel} className="gap-1.5 text-xs">
                <FileSpreadsheet className="w-3.5 h-3.5 text-green-600" /> Excel
              </Button>
            </div>
          </div>

          {/* ── Tier filter chips + KPIs ── */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {(Object.keys(TIERS) as Array<keyof typeof TIERS>).map(key => {
              const t = TIERS[key];
              const active = tiersActive[key];
              const cnt = key === 'peligro' ? counts.peligro : key === 'alerta' ? counts.alerta : counts.limite;
              return (
                <button key={key} onClick={() => setTiersActive(p => ({ ...p, [key]: !p[key] }))}
                  className="rounded-xl p-4 border-2 text-left transition-all shadow-sm hover:shadow-md"
                  style={{ borderColor: active ? t.color : '#e5e7eb', background: active ? t.bg : '#fff', opacity: active ? 1 : 0.55 }}>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-3 h-3 rounded-full" style={{ background: t.color }} />
                    <span className="text-xs font-bold" style={{ color: t.color }}>{t.label}</span>
                    {active && <span className="ml-auto text-[10px] bg-white/70 px-1.5 py-0.5 rounded-full font-mono" style={{ color: t.color }}>ON</span>}
                  </div>
                  <p className="text-2xl font-black" style={{ color: t.color }}>{cnt}</p>
                  <p className="text-[10px] text-gray-400 mt-0.5">{t.range}</p>
                </button>
              );
            })}
            <div className="rounded-xl p-4 border border-border bg-card shadow-sm flex flex-col justify-between">
              <p className="text-xs text-muted-foreground font-bold uppercase">En el mapa</p>
              <p className="text-2xl font-black text-primary">{counts.enMapa}</p>
              <p className="text-[10px] text-muted-foreground">con coordenadas</p>
            </div>
          </div>
        </>
      )}

      {/* ── Map ── */}
      <div 
        className={`rounded-2xl overflow-hidden shadow-xl border border-border ${isFullscreen ? 'flex-1' : ''}`}
        style={{ height: isFullscreen ? '100%' : '520px', position: 'relative' }}>
        <div ref={mapContainerRef} style={{ height: '100%', width: '100%' }} />

        {/* Fullscreen button */}
        <button
          onClick={toggleFullscreen}
          className="absolute top-3 right-3 z-[500] p-2 bg-white hover:bg-muted rounded-lg shadow-md border border-border transition-all hover:shadow-lg"
          title={isFullscreen ? 'Salir de vista completa' : 'Ver en vista completa'}
        >
          {isFullscreen ? (
            <Minimize2 className="w-4 h-4 text-foreground" />
          ) : (
            <Maximize2 className="w-4 h-4 text-foreground" />
          )}
        </button>

        {/* CSS pulse animation injected inline */}
        <style>{`@keyframes ping{75%,100%{transform:scale(2);opacity:0}}`}</style>

        {/* Empty overlay */}
        {filtered.length === 0 && (
          <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: 'rgba(255,255,255,0.75)', backdropFilter: 'blur(4px)', zIndex: 1000, pointerEvents: 'none' }}>
            <div className="bg-card p-8 rounded-2xl shadow-2xl border border-border text-center max-w-xs">
              <div className="w-14 h-14 bg-muted rounded-full flex items-center justify-center mx-auto mb-3">
                <Search className="w-7 h-7 text-muted-foreground" />
              </div>
              <p className="font-bold text-lg text-foreground">Sin puntos</p>
              <p className="text-sm text-muted-foreground mt-1">
                {(fechaInicio || fechaFin)
                  ? `Sin coordenadas del ${fechaInicio || '?'} al ${fechaFin || '?'}`
                  : 'No hay registros históricos con coordenadas.'}
              </p>
            </div>
          </div>
        )}
      </div>

      {!isFullscreen && (
        <>
          {/* ── Charts ── */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Chart 1: Eventos por Nivel */}
        <div ref={chartNivelesRef} className="bg-card border border-border rounded-xl shadow-sm p-5">
          <h3 className="font-bold text-sm mb-4 text-foreground">📊 Distribución por Nivel de Velocidad</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartDataNiveles}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="nombre" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                formatter={(value) => [value, 'Cantidad']}
              />
              <Bar dataKey="cantidad" radius={[8, 8, 0, 0]}>
                {chartDataNiveles.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-3 text-center text-xs text-muted-foreground">
            Total período: <span className="font-bold text-foreground">{counts.total}</span>
          </div>
        </div>

        {/* Chart 2: Top 5 Placas */}
        <div ref={chartPlacasRef} className="bg-card border border-border rounded-xl shadow-sm p-5">
          <h3 className="font-bold text-sm mb-4 text-foreground">🚗 Top 5 Placas Más Frecuentes</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartDataPlacas} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis type="number" tick={{ fontSize: 12 }} />
              <YAxis dataKey="placa" type="category" tick={{ fontSize: 11 }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                formatter={(value) => [value, 'Eventos']}
              />
              <Bar dataKey="cantidad" fill="#3b82f6" radius={[0, 8, 8, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-3 text-center text-xs text-muted-foreground">
            {chartDataPlacas.length === 0 ? 'Sin datos para mostrar' : `${chartDataPlacas.length} placas en el período`}
          </div>
        </div>
      </div>

      {/* ── Detail table ── */}
      <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-border bg-muted/30 flex justify-between items-center">
          <h3 className="font-bold text-sm">Registros del período</h3>
          <span className="text-xs text-muted-foreground">{filtered.length} visibles · {counts.total} total</span>
        </div>
        <div className="max-h-72 overflow-y-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-muted/50 sticky top-0">
              <tr>
                {['Placa','Velocidad','Nivel','Ruta','Fecha/Hora','Ubicación'].map(h => (
                  <th key={h} className="p-2 border-b font-semibold text-muted-foreground">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={6} className="p-8 text-center text-muted-foreground italic">Sin registros para los filtros actuales.</td></tr>
              ) : filtered.map(e => {
                const tier = getTier(e.velocidad);
                const t = TIERS[tier];
                return (
                  <tr key={e.id} className="border-b hover:bg-muted/20 transition-colors">
                    <td className="p-2 font-bold">{e.placa?.trim()}</td>
                    <td className="p-2 font-bold" style={{ color: t.color }}>{e.velocidad} km/h</td>
                    <td className="p-2">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold" style={{ background: t.bg, color: t.color }}>{t.label}</span>
                    </td>
                    <td className="p-2 truncate max-w-[160px] text-muted-foreground">{e.ruta}</td>
                    <td className="p-2 text-muted-foreground whitespace-nowrap">{new Date(e.created_at).toLocaleString('es-CO')}</td>
                    <td className="p-2 text-center">
                      {e.latitud && e.longitud
                        ? <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded-full font-bold">📍 OK</span>
                        : <span className="px-2 py-0.5 bg-red-50 text-red-400 rounded-full">Sin GPS</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ── Download bar ── */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Download className="w-5 h-5 text-blue-600" />
          <div>
            <p className="font-semibold text-blue-900 text-sm">Exportar datos filtrados</p>
            <p className="text-xs text-blue-600">{filtered.length} registros listos para descargar</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={exportPDF} className="bg-red-600 hover:bg-red-700 text-white gap-2 text-xs">
            <FileText className="w-4 h-4" /> Descargar PDF
          </Button>
          <Button onClick={exportExcel} className="bg-green-600 hover:bg-green-700 text-white gap-2 text-xs">
            <FileSpreadsheet className="w-4 h-4" /> Descargar Excel
          </Button>
        </div>
      </div>
        </>
      )}

    </div>
  );
};

export default MapaPage;
