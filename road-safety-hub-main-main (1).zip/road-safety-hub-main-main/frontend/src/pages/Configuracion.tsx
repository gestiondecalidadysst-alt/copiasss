import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuthStore } from '@/stores/authStore';
import { useAppStore } from '@/stores/appStore';
import { authService } from '@/services/authService';
import CertificadoConfigSection from '@/components/CertificadoConfigSection';
import { toast } from 'sonner';
import { useState, useRef, useEffect } from 'react';
import { Upload, X, FileText, Award } from 'lucide-react';
import { saveBrandingBackend, loadBrandingBackend } from '@/services/brandingService';

const Configuracion = () => {
  const { user, setUser } = useAuthStore();
  const {
    companyName, companyLogo, setCompanyName, setCompanyLogo,
    reportHeader, reportFooter, setReportHeader, setReportFooter,
  } = useAppStore();
  const [tempCompanyName, setTempCompanyName] = useState(companyName);
  const [tempCompanyLogo, setTempCompanyLogo] = useState<string | null>(companyLogo);
  const [tempReportHeader, setTempReportHeader] = useState(reportHeader);
  const [tempReportFooter, setTempReportFooter] = useState(reportFooter);
  const [perfilNombre, setPerfilNombre] = useState(user?.nombre ?? '');
  const [perfilEmpresa, setPerfilEmpresa] = useState(user?.empresa ?? '');
  const [savingPerfil, setSavingPerfil] = useState(false);
  const [savingBranding, setSavingBranding] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Cargar branding desde la BD al montar
  useEffect(() => {
    loadBrandingBackend().then((saved) => {
      if (saved) {
        if (saved.company_name) { setTempCompanyName(saved.company_name); setCompanyName(saved.company_name); }
        if (saved.company_logo !== undefined) { setTempCompanyLogo(saved.company_logo); setCompanyLogo(saved.company_logo); }
      }
    });
  }, []);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validar que sea una imagen
      if (!file.type.startsWith('image/')) {
        toast.error('Por favor selecciona una imagen');
        return;
      }
      
      // Validar tamaño (máx 2MB)
      if (file.size > 2 * 1024 * 1024) {
        toast.error('La imagen debe pesar menos de 2MB');
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        setTempCompanyLogo(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeLogo = () => {
    setTempCompanyLogo(null);
  };

  const handleTemplateUpload = async (file: File) => {
    try {
      if (!file.type.includes('sheet') && !file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
        toast.error('Por favor selecciona un archivo Excel (.xlsx o .xls)');
        return;
      }

      const envApiUrl = import.meta.env.VITE_API_URL;
      const fallbackLocalApi = 'http://localhost:5000/api';
      const isLocalhost = ['localhost', '127.0.0.1', '::1'].includes(window.location.hostname);
      const apiBaseUrl = envApiUrl && envApiUrl !== '/api'
        ? envApiUrl.replace(/\/$/, '')
        : isLocalhost
        ? fallbackLocalApi
        : '/api';
      const formData = new FormData();
      formData.append('file', file);
      formData.append('templateName', 'default');

      const response = await fetch(`${apiBaseUrl}/configuracion/plantillas/importar`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        },
        body: formData
      });

      if (!response.ok) {
        const text = await response.text();
        let errorMessage = 'Error importando plantilla';
        try {
          const errorBody = JSON.parse(text);
          errorMessage = errorBody.error || errorBody.message || errorMessage;
        } catch {
          console.error('Error response not JSON:', text);
          errorMessage = text || errorMessage;
        }
        throw new Error(errorMessage);
      }

      const result = await response.json();
      toast.success(result.message || 'Plantilla importada correctamente');
      
      // Limpiar input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      console.error('Error uploading template:', error);
      toast.error(error instanceof Error ? error.message : 'Error importando plantilla');
    }
  };

  const saveBrandingChanges = async () => {
    setSavingBranding(true);
    try {
      await saveBrandingBackend({ company_name: tempCompanyName, company_logo: tempCompanyLogo });
      setCompanyName(tempCompanyName);
      setCompanyLogo(tempCompanyLogo);
      toast.success('Branding actualizado correctamente');
    } catch {
      toast.error('Error al guardar el branding');
    } finally {
      setSavingBranding(false);
    }
  };

  const saveReportSettings = () => {
    setReportHeader(tempReportHeader);
    setReportFooter(tempReportFooter);
    toast.success('Configuración de informes guardada correctamente');
  };

  const savePerfilChanges = async () => {
    if (!perfilNombre.trim()) {
      toast.error('El nombre es requerido');
      return;
    }
    setSavingPerfil(true);
    try {
      const response = await authService.actualizarPerfil(perfilNombre, perfilEmpresa);
      if (user) {
        setUser({ ...user, nombre: response.usuario.nombre, empresa: response.usuario.empresa });
        // Actualizar localStorage
        localStorage.setItem('user', JSON.stringify({ ...user, nombre: response.usuario.nombre, empresa: response.usuario.empresa }));
      }
      toast.success('Perfil actualizado correctamente');
    } catch {
      toast.error('Error al guardar el perfil');
    } finally {
      setSavingPerfil(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-5xl">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Configuración</h1>
        <p className="text-muted-foreground text-sm">Ajustes de cuenta, empresa y branding</p>
      </div>

      {/* Branding */}
      <div className="bg-card border border-border rounded-xl p-6 space-y-4">
        <h3 className="font-semibold text-foreground">Branding de Empresa</h3>
        
        {/* Logo */}
        <div className="space-y-3">
          <Label>Logo de la empresa</Label>
          <div className="flex gap-4 items-start">
            <div className="flex-1">
              {tempCompanyLogo ? (
                <div className="flex gap-3 items-end">
                  <img 
                    src={tempCompanyLogo} 
                    alt="Company logo" 
                    className="w-16 h-16 rounded-lg object-cover border border-border"
                  />
                  <button
                    onClick={removeLogo}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">Haz clic para seleccionar una imagen</p>
                  <p className="text-xs text-muted-foreground mt-1">PNG, JPG (máx 2MB)</p>
                </div>
              )}
              <input 
                ref={fileInputRef}
                type="file" 
                accept="image/*"
                onChange={handleLogoUpload}
                className="hidden"
              />
            </div>
          </div>
          {tempCompanyLogo && (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="text-sm text-primary hover:underline"
            >
              Cambiar logo
            </button>
          )}
        </div>

        {/* Nombre de empresa */}
        <div>
          <Label htmlFor="companyName">Nombre de la empresa</Label>
          <Input 
            id="companyName"
            value={tempCompanyName}
            onChange={(e) => setTempCompanyName(e.target.value)}
            placeholder="Ej: Mi Empresa de Transporte"
            className="mt-2"
          />
        </div>

        <Button 
          className="gradient-primary text-primary-foreground w-full"
          onClick={saveBrandingChanges}
          disabled={savingBranding}
        >
          {savingBranding ? 'Guardando...' : 'Guardar cambios de branding'}
        </Button>
      </div>

      {/* Configuración de Informes */}
      <div className="bg-card border border-border rounded-xl p-6 space-y-4">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          <h3 className="font-semibold text-foreground">Configuración de Informes</h3>
        </div>
        <p className="text-xs text-muted-foreground">
          Este texto aparecerá en todos los informes PDF generados por el sistema.
        </p>

        {/* Encabezado */}
        <div className="space-y-2">
          <Label htmlFor="reportHeader">Texto del encabezado</Label>
          <Input
            id="reportHeader"
            value={tempReportHeader}
            onChange={(e) => setTempReportHeader(e.target.value)}
            placeholder="Ej: Av. Principal 123, Ciudad · Tel: +1 234 567 890"
            maxLength={200}
          />
          <p className="text-xs text-muted-foreground">
            Se muestra bajo el nombre de empresa en la cabecera del informe. Máx 200 caracteres.
          </p>
        </div>

        {/* Vista previa encabezado */}
        {tempReportHeader && (
          <div className="border border-dashed border-primary/40 rounded-lg p-3 bg-primary/5">
            <p className="text-xs font-medium text-muted-foreground mb-1">Vista previa encabezado:</p>
            <p className="text-sm text-foreground">{tempReportHeader}</p>
          </div>
        )}

        {/* Pie de página */}
        <div className="space-y-2">
          <Label htmlFor="reportFooter">Texto del pie de página</Label>
          <Input
            id="reportFooter"
            value={tempReportFooter}
            onChange={(e) => setTempReportFooter(e.target.value)}
            placeholder="Ej: Documento confidencial · contacto@empresa.com"
            maxLength={200}
          />
          <p className="text-xs text-muted-foreground">
            Se muestra en el pie de cada página del informe. Máx 200 caracteres.
          </p>
        </div>

        {/* Vista previa pie de página */}
        {tempReportFooter && (
          <div className="border border-dashed border-primary/40 rounded-lg p-3 bg-primary/5">
            <p className="text-xs font-medium text-muted-foreground mb-1">Vista previa pie de página:</p>
            <p className="text-sm text-foreground">{tempReportFooter}</p>
          </div>
        )}

        <Button
          className="gradient-primary text-primary-foreground w-full"
          onClick={saveReportSettings}
        >
          Guardar configuración de informes
        </Button>
      </div>

      {/* Perfil */}
      <div className="bg-card border border-border rounded-xl p-6 space-y-4">
        <h3 className="font-semibold text-foreground">Perfil</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <Label>Nombre</Label>
            <Input value={perfilNombre} onChange={(e) => setPerfilNombre(e.target.value)} />
          </div>
          <div>
            <Label>Email</Label>
            <Input defaultValue={user?.email} disabled />
          </div>
          <div>
            <Label>Empresa</Label>
            <Input value={perfilEmpresa} onChange={(e) => setPerfilEmpresa(e.target.value)} />
          </div>
          <div>
            <Label>Rol</Label>
            <Input defaultValue={user?.rol} disabled />
          </div>
        </div>
        <Button
          className="gradient-primary text-primary-foreground"
          onClick={savePerfilChanges}
          disabled={savingPerfil}
        >
          {savingPerfil ? 'Guardando...' : 'Guardar cambios'}
        </Button>
      </div>

      {/* Certificado de Capacitación */}
      <div className="bg-card border border-border rounded-xl p-6 space-y-5">
        <div className="flex items-center gap-2">
          <Award className="w-5 h-5 text-primary" />
          <h3 className="font-semibold text-foreground">Diploma / Certificado de Capacitación</h3>
        </div>
        <p className="text-xs text-muted-foreground">
          Diseña el diploma que se entregará al conductor al completar una capacitación.
          La vista previa se actualiza en tiempo real.
        </p>
        <CertificadoConfigSection />
      </div>

      {/* Plantillas de Capacitación */}
      <div className="bg-card border border-border rounded-xl p-6 space-y-5">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          <h3 className="font-semibold text-foreground">Plantillas de Reportes</h3>
        </div>
        <p className="text-xs text-muted-foreground">
          Importa plantillas en formato XLSX para personalizar el diseño de los reportes de capacitación.
          El sistema extraerá automáticamente el encabezado, pie de página, columnas y estilos.
        </p>
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
            >
              <Upload className="w-4 h-4" />
              Importar plantilla XLSX
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  handleTemplateUpload(file);
                }
              }}
              className="hidden"
            />
          </div>
          <p className="text-xs text-muted-foreground">
            📋 La plantilla debe contener encabezados en la primera fila con los nombres de las columnas.
          </p>
        </div>
      </div>

      {/* Notificaciones */}
      <div className="bg-card border border-border rounded-xl p-6 space-y-4">
        <h3 className="font-semibold text-foreground">Notificaciones</h3>
        <div className="space-y-3">
          {['Eventos de alta severidad', 'Resumen diario por email', 'Alertas de fatiga'].map((n) => (
            <label key={n} className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" defaultChecked className="w-4 h-4 accent-primary rounded" />
              <span className="text-sm text-foreground">{n}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Opciones adicionales */}
      <div className="bg-card border border-border rounded-xl p-6 space-y-4">
        <h3 className="font-semibold text-foreground">Experiencia de usuario</h3>
        <div className="space-y-3">
          {['Tema oscuro', 'Notificaciones de sonido', 'Datos en tiempo real'].map((option) => (
            <label key={option} className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" defaultChecked className="w-4 h-4 accent-primary rounded" />
              <span className="text-sm text-foreground">{option}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Configuracion;
