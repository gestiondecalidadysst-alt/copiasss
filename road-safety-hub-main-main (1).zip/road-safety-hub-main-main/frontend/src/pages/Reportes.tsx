import { useState, useEffect } from 'react';
import api from '@/services/api';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { FileText, Download, Eye, Filter, Loader2, Trash2, FilePlus, RefreshCw, Users, X, TrendingUp, AlertTriangle, Activity, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { useAuthStore } from '@/stores/authStore';
import { useAppStore } from '@/stores/appStore';


interface Evento {
  id: number;
  created_at: string;
  velocidad: number;
  placa: string;
  fecha: string;
  ruta: string;
  latitud?: number;
  longitud?: number;
}

interface Conductor {
  id: string;
  nombre: string;
  cedula: string;
  vehiculo: string;
  score: number;
  estado: string;
}

interface ReporteGuardado {
  id: number;
  created_at: string;
  nombre: string;
  placa: string;
  fecha_desde: string;
  fecha_hasta: string;
  tipo_evento: string;
  total_eventos: number;
  velocidad_promedio: number;
  usuario: string;
  empresa: string;
}

// ── Canvas chart helpers para embeber imágenes en PDF ─────────────────────
const makeBarChartImg = (
  data: { label: string; value: number; color?: string }[],
  w: number, h: number, title: string
): string => {
  const canvas = document.createElement('canvas');
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';
  // El fontSize del título puede ser > 26px, lo que haría que la parte superior del glyph
  // quedara fuera del canvas (y < 0). Calculamos la posición segura dinámicamente.
  const titleFS = Math.round(w / 26);
  const PAD = { top: titleFS + 24, right: 18, bottom: 52, left: 50 };
  const cw = w - PAD.left - PAD.right;
  const ch = h - PAD.top - PAD.bottom;
  const maxVal = Math.max(...data.map(d => d.value), 1);
  ctx.fillStyle = '#f8fafc'; ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = '#1e3a5f'; ctx.font = `bold ${titleFS}px Arial`;
  ctx.textAlign = 'center'; ctx.fillText(title, w / 2, titleFS + 4);
  for (let i = 0; i <= 4; i++) {
    const y = PAD.top + ch - (i / 4) * ch;
    ctx.strokeStyle = '#e2e8f0'; ctx.lineWidth = 0.8;
    ctx.beginPath(); ctx.moveTo(PAD.left, y); ctx.lineTo(PAD.left + cw, y); ctx.stroke();
    ctx.fillStyle = '#94a3b8'; ctx.font = `${Math.round(w / 44)}px Arial`;
    ctx.textAlign = 'right';
    ctx.fillText(Math.round((i / 4) * maxVal).toString(), PAD.left - 5, y + 4);
  }
  ctx.strokeStyle = '#334155'; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(PAD.left, PAD.top); ctx.lineTo(PAD.left, PAD.top + ch);
  ctx.lineTo(PAD.left + cw, PAD.top + ch); ctx.stroke();
  const bw = (cw / data.length) * 0.68;
  const bs = cw / data.length;
  data.forEach((d, i) => {
    const bh = d.value > 0 ? (d.value / maxVal) * ch : 0;
    const bx = PAD.left + i * bs + (bs - bw) / 2;
    const by = PAD.top + ch - bh;
    ctx.fillStyle = d.color || '#3b82f6'; ctx.fillRect(bx, by, bw, bh);
    if (d.value > 0) {
      ctx.fillStyle = '#1e293b'; ctx.font = `bold ${Math.round(w / 52)}px Arial`;
      ctx.textAlign = 'center'; ctx.fillText(d.value.toString(), bx + bw / 2, by - 3);
    }
    ctx.save();
    ctx.translate(bx + bw / 2, PAD.top + ch + 13);
    if (data.length > 8) ctx.rotate(-Math.PI / 4);
    ctx.fillStyle = '#475569'; ctx.font = `${Math.round(w / 50)}px Arial`;
    ctx.textAlign = data.length > 8 ? 'right' : 'center';
    ctx.fillText(d.label, 0, 0);
    ctx.restore();
  });
  return canvas.toDataURL('image/png');
};

const makePieChartImg = (
  data: { label: string; value: number; color: string }[],
  w: number, h: number, title: string
): string => {
  const canvas = document.createElement('canvas');
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';
  ctx.fillStyle = '#f8fafc'; ctx.fillRect(0, 0, w, h);
  const titleFSP = Math.round(w / 22);
  ctx.fillStyle = '#1e3a5f'; ctx.font = `bold ${titleFSP}px Arial`;
  ctx.textAlign = 'center'; ctx.fillText(title, w / 2, titleFSP + 4);
  const total = data.reduce((s, d) => s + d.value, 0);
  if (total === 0) {
    ctx.fillStyle = '#94a3b8'; ctx.font = `${Math.round(w / 22)}px Arial`;
    ctx.fillText('Sin datos', w / 2, h / 2); return canvas.toDataURL('image/png');
  }
  const cx = w * 0.38, cy = h * 0.56, r = Math.min(w * 0.32, h * 0.38);
  let angle = -Math.PI / 2;
  data.forEach(d => {
    const slice = (d.value / total) * 2 * Math.PI;
    ctx.fillStyle = d.color; ctx.beginPath(); ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, r, angle, angle + slice); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2.5; ctx.stroke();
    angle += slice;
  });
  let ly = h * 0.28; const lx = w * 0.7;
  data.forEach(d => {
    ctx.fillStyle = d.color; ctx.fillRect(lx - 16, ly - 12, 14, 14);
    ctx.fillStyle = '#334155'; ctx.font = `${Math.round(w / 28)}px Arial`;
    ctx.textAlign = 'left';
    const pct = ((d.value / total) * 100).toFixed(0);
    ctx.fillText(`${d.label}: ${d.value} (${pct}%)`, lx + 2, ly);
    ly += 26;
  });
  return canvas.toDataURL('image/png');
};

const Reportes = () => {
  const [eventos, setEventos] = useState<Evento[]>([]);
  const [conductores, setConductores] = useState<Conductor[]>([]);
  const [reportesGuardados, setReportesGuardados] = useState<ReporteGuardado[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [previewConductor, setPreviewConductor] = useState<null | { nombre: string; cedula: string; vehiculo: string; estado: string; excesosCount: number; velProm: number; excesos: Evento[] }>(null);
  const [previewReporte, setPreviewReporte] = useState<null | { reporte: ReporteGuardado; eventos: Evento[] }>(null);
  const [conductorAEliminar, setConductorAEliminar] = useState<null | { id: string; nombre: string }>(null);

  // Formulario de creación de reporte
  const [nombreReporte, setNombreReporte] = useState('');
  const [conductorSeleccionado, setConductorSeleccionado] = useState<string>('todos');
  const [placaSeleccionada, setPlacaSeleccionada] = useState<string>('todas');
  const [fechaDesde, setFechaDesde] = useState('');
  const [fechaHasta, setFechaHasta] = useState('');
  const [tipoEvento, setTipoEvento] = useState<string>('todos');
  
  const user = useAuthStore((s) => s.user);
  const { companyName, companyLogo, reportHeader, reportFooter } = useAppStore();

  // Cargar eventos y reportes guardados
  useEffect(() => {
    cargarDatos();
  }, []);

  const cargarDatos = async () => {
    setLoading(true);
    try {
      const [eventosRes, reportesRes, conductoresRes] = await Promise.all([
        api.get('/eventos'),
        api.get('/reportes'),
        api.get('/conductores')
      ]);

      const eventosData = eventosRes.data;
      setEventos(eventosData);
      if (eventosData.length > 0) {
        const fechas = eventosData.map((e: Evento) => new Date(e.created_at)).filter((d: Date) => !isNaN(d.getTime()));
        if (fechas.length > 0) {
          const minFecha = new Date(Math.min(...fechas.map((d: Date) => d.getTime())));
          const maxFecha = new Date(Math.max(...fechas.map((d: Date) => d.getTime())));
          setFechaDesde(minFecha.toISOString().split('T')[0]);
          setFechaHasta(maxFecha.toISOString().split('T')[0]);
        }
      }

      const reportesData = reportesRes.data;
      const reportes = reportesData.data || reportesData;
      setReportesGuardados(Array.isArray(reportes) ? reportes : []);

      setConductores(conductoresRes.data);
    } catch (err) {
      console.error('Error al cargar datos:', err);
      toast.error('Error al cargar datos');
      // Limpiar estado en caso de error
      setReportesGuardados([]);
    } finally {
      setLoading(false);
    }
  };

  // Obtener placas únicas
  const placasUnicas = Array.from(new Set(eventos.map(e => e.placa?.trim()).filter(Boolean)));

  // Filtrar eventos según criterios
  const filtrarEventos = (placa: string, desde: string, hasta: string, tipo: string): Evento[] => {
    let filtered = [...eventos];

    if (placa !== 'todas') {
      filtered = filtered.filter(e => e.placa?.trim() === placa);
    }

    if (desde) {
      const desdeDate = new Date(desde);
      filtered = filtered.filter(e => new Date(e.created_at) >= desdeDate);
    }

    if (hasta) {
      const hastaDate = new Date(hasta);
      hastaDate.setHours(23, 59, 59, 999);
      filtered = filtered.filter(e => new Date(e.created_at) <= hastaDate);
    }

    if (tipo !== 'todos') {
      if (tipo === 'alta') {
        filtered = filtered.filter(e => e.velocidad > 100);
      } else if (tipo === 'media') {
        filtered = filtered.filter(e => e.velocidad > 80 && e.velocidad <= 100);
      } else if (tipo === 'baja') {
        filtered = filtered.filter(e => e.velocidad <= 80);
      }
    }

    return filtered;
  };

  // Crear y guardar reporte
  const crearReporte = async () => {
    if (!nombreReporte.trim()) {
      toast.error('Debes ingresar un nombre para el reporte');
      return;
    }

    setSaving(true);

    try {
      const eventosFiltrados = filtrarEventos(placaSeleccionada, fechaDesde, fechaHasta, tipoEvento);
      const velocidadPromedio = eventosFiltrados.length > 0
        ? eventosFiltrados.reduce((sum, e) => sum + e.velocidad, 0) / eventosFiltrados.length
        : 0;

      const nuevoReporte = {
        nombre: nombreReporte,
        placa: placaSeleccionada,
        fecha_desde: fechaDesde,
        fecha_hasta: fechaHasta,
        tipo_evento: tipoEvento,
        total_eventos: eventosFiltrados.length,
        velocidad_promedio: parseFloat(velocidadPromedio.toFixed(2)),
        usuario: user?.nombre || 'Usuario',
        empresa: companyName
      };

      const { data: reporteCreado } = await api.post('/reportes', nuevoReporte);
      const reportesActuales = Array.isArray(reportesGuardados) ? reportesGuardados : [];
      setReportesGuardados([reporteCreado, ...reportesActuales]);
      toast.success('Reporte creado y guardado correctamente');
      setNombreReporte('');
      setPlacaSeleccionada('todas');
      setTipoEvento('todos');
    } catch (err) {
      console.error('Error:', err);
      toast.error('Error al crear el reporte');
    } finally {
      setSaving(false);
    }
  };

  // Eliminar conductor
  const eliminarConductor = async (id: string) => {
    try {
      await api.delete(`/conductores/${id}`);
      setConductores(prev => prev.filter(c => c.id !== id));
      toast.success('Conductor eliminado');
    } catch {
      toast.error('Error al eliminar el conductor');
    } finally {
      setConductorAEliminar(null);
    }
  };

  // Eliminar reporte
  const eliminarReporte = async (id: number) => {
    if (!confirm('\u00bfEstás seguro de eliminar este reporte?')) return;

    try {
      await api.delete(`/reportes/${id}`);
      // Asegurarse de que reportesGuardados es un array
      const reportesActuales = Array.isArray(reportesGuardados) ? reportesGuardados : [];
      setReportesGuardados(reportesActuales.filter(r => r.id !== id));
      toast.success('Reporte eliminado');
    } catch (err) {
      console.error('Error:', err);
      toast.error('Error al eliminar el reporte');
    }
  };

  // Ver reporte (aplicar filtros del reporte guardado)
  const verReporte = (reporte: ReporteGuardado) => {
    const eventosFiltrados = filtrarEventos(
      reporte.placa,
      reporte.fecha_desde,
      reporte.fecha_hasta,
      reporte.tipo_evento
    );
    setPreviewReporte({ reporte, eventos: eventosFiltrados });
  };

  // Generar PDF para un reporte específico
  const generarPDF = (reporte: ReporteGuardado) => {
    const eventosFiltrados = filtrarEventos(
      reporte.placa,
      reporte.fecha_desde,
      reporte.fecha_hasta,
      reporte.tipo_evento
    );

    const pdf = new jsPDF('l', 'mm', 'letter');
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const LOGO_H = 22;
    const LOGO_W = 33;
    const MARGIN = 14;
    let yPos = MARGIN;

    // ── ENCABEZADO ────────────────────────────────────────────
    // Logo de empresa (si existe)
    if (companyLogo) {
      try {
        const format = companyLogo.startsWith('data:image/png') ? 'PNG' : 'JPEG';
        pdf.addImage(companyLogo, format, MARGIN, yPos, LOGO_W, LOGO_H);
      } catch {
        // Si la imagen falla, continuar sin logo
      }
    }

    // Título del reporte centrado
    pdf.setFontSize(18);
    pdf.setTextColor(13, 110, 253);
    pdf.setFont('helvetica', 'bold');
    pdf.text(reporte.nombre.toUpperCase(), pageWidth / 2, yPos + LOGO_H / 2 + 2, { align: 'center' });

    yPos += LOGO_H + 5;
    pdf.setLineWidth(0.5);
    pdf.setDrawColor(13, 110, 253);
    pdf.line(MARGIN, yPos, pageWidth - MARGIN, yPos);
    yPos += 7;

    // Texto configurable del encabezado
    if (reportHeader) {
      pdf.setFontSize(9);
      pdf.setTextColor(90, 90, 90);
      pdf.setFont('helvetica', 'italic');
      pdf.text(reportHeader, pageWidth / 2, yPos, { align: 'center' });
      yPos += 7;
    }

    // Datos del reporte
    pdf.setFontSize(10);
    pdf.setTextColor(50, 50, 50);
    pdf.setFont('helvetica', 'normal');
    pdf.text(`Empresa: ${reporte.empresa}`, MARGIN + 5, yPos);
    pdf.text(`Fecha de creación: ${new Date(reporte.created_at).toLocaleString('es-ES')}`, pageWidth - MARGIN, yPos, { align: 'right' });
    yPos += 6;
    pdf.text(`Usuario: ${reporte.usuario}`, MARGIN + 5, yPos);
    pdf.text(`Total eventos: ${reporte.total_eventos}`, pageWidth - MARGIN, yPos, { align: 'right' });
    yPos += 6;
    pdf.text(`Velocidad promedio: ${reporte.velocidad_promedio} km/h`, MARGIN + 5, yPos);
    yPos += 10;

    // ── ANALÍTICAS ────────────────────────────────────────────
    const _st = (() => {
      const evs = eventosFiltrados;
      const total = evs.length;
      const velMax = total > 0 ? Math.max(...evs.map(e => e.velocidad)) : 0;
      const velMin = total > 0 ? Math.min(...evs.map(e => e.velocidad)) : 0;
      const velProm = total > 0 ? parseFloat((evs.reduce((s, e) => s + e.velocidad, 0) / total).toFixed(1)) : 0;
      const alta = evs.filter(e => e.velocidad > 100).length;
      const media = evs.filter(e => e.velocidad > 80 && e.velocidad <= 100).length;
      const baja = evs.filter(e => e.velocidad <= 80).length;
      const pp: Record<string, number> = {};
      evs.forEach(e => { const p = e.placa?.trim(); if (p) pp[p] = (pp[p] || 0) + 1; });
      const topPlacas = Object.entries(pp).sort((a, b) => b[1] - a[1]).slice(0, 5);
      const ph: Record<string, number> = {};
      evs.forEach(e => { const h = new Date(e.created_at).getHours().toString(); ph[h] = (ph[h] || 0) + 1; });
      const horaRiesgo = Object.entries(ph).sort((a, b) => b[1] - a[1])[0] as [string, number] | undefined;
      const nivel = alta / (total || 1) > 0.5 ? 'ALTO' : media / (total || 1) > 0.4 ? 'MODERADO' : 'BAJO';
      return { total, velMax, velMin, velProm, alta, media, baja, topPlacas, ph, horaRiesgo, nivel };
    })();
    if (_st.total > 0) {
      pdf.setFontSize(11); pdf.setTextColor(13, 110, 253); pdf.setFont('helvetica', 'bold');
      pdf.text('ESTADÍSTICAS ANALÍTICAS', MARGIN + 5, yPos);
      yPos += 5;
      pdf.autoTable({
        startY: yPos,
        head: [['Indicador', 'Valor']],
        body: [
          ['Total excesos', _st.total.toString()],
          ['Velocidad máxima (km/h)', _st.velMax.toString()],
          ['Velocidad mínima (km/h)', _st.velMin.toString()],
          ['Velocidad promedio (km/h)', _st.velProm.toString()],
          ['Alta severidad >100 km/h', `${_st.alta} (${((_st.alta / (_st.total || 1)) * 100).toFixed(0)}%)`],
          ['Media severidad 80-100 km/h', `${_st.media} (${((_st.media / (_st.total || 1)) * 100).toFixed(0)}%)`],
          ['Baja severidad ≤80 km/h', `${_st.baja} (${((_st.baja / (_st.total || 1)) * 100).toFixed(0)}%)`],
          ['Hora de mayor riesgo', _st.horaRiesgo ? `${_st.horaRiesgo[0]}:00 h (${_st.horaRiesgo[1]} eventos)` : '—'],
          ['Placa con más excesos', _st.topPlacas.length > 0 ? `${_st.topPlacas[0][0]} (${_st.topPlacas[0][1]} eventos)` : '—'],
          ['Nivel de riesgo general', _st.nivel],
        ],
        theme: 'striped',
        headStyles: { fillColor: [13, 110, 253], textColor: 255, fontSize: 9, fontStyle: 'bold' },
        styles: { fontSize: 8, cellPadding: 2.5 },
        columnStyles: { 0: { cellWidth: 80, fontStyle: 'bold' as const }, 1: { cellWidth: 'auto' } },
        margin: { left: MARGIN + 4, right: MARGIN + 4 }
      });
      yPos = (pdf as any).lastAutoTable.finalY + 5;
      if (_st.topPlacas.length > 0) {
        pdf.setFontSize(10); pdf.setTextColor(13, 110, 253); pdf.setFont('helvetica', 'bold');
        pdf.text('TOP PLACAS', MARGIN + 5, yPos);
        yPos += 4;
        pdf.autoTable({
          startY: yPos,
          head: [['#', 'Placa', 'Excesos']],
          body: _st.topPlacas.map((e, i) => [(i + 1).toString(), e[0], e[1].toString()]),
          theme: 'striped',
          headStyles: { fillColor: [80, 80, 200], textColor: 255, fontSize: 8 },
          styles: { fontSize: 8, cellPadding: 2, halign: 'center' as const },
          columnStyles: { 0: { cellWidth: 15 }, 1: { cellWidth: 40 }, 2: { cellWidth: 25 } },
          margin: { left: MARGIN + 5, right: MARGIN + 5 }
        });
        yPos = (pdf as any).lastAutoTable.finalY + 5;
      }
      pdf.setFontSize(10); pdf.setTextColor(13, 110, 253); pdf.setFont('helvetica', 'bold');
      pdf.text('RECOMENDACIONES PARA TOMA DE DECISIONES', MARGIN + 5, yPos);
      yPos += 5;
      pdf.setFontSize(9); pdf.setTextColor(60, 60, 60); pdf.setFont('helvetica', 'normal');
      [
        `• Se registraron ${_st.total} excesos en el período analizado.`,
        _st.alta > 0 ? `• ${_st.alta} excesos de ALTA severidad (>100 km/h) — se recomienda revisión disciplinaria inmediata.` : '• No se registraron excesos de alta severidad en este período.',
        `• Velocidad máxima: ${_st.velMax} km/h — promedio: ${_st.velProm} km/h.`,
        _st.horaRiesgo ? `• Franja crítica: ${_st.horaRiesgo[0]}:00 h con ${_st.horaRiesgo[1]} eventos — reforzar controles en ese horario.` : null,
        _st.topPlacas.length > 0 ? `• Placa de mayor riesgo: ${_st.topPlacas[0][0]} con ${_st.topPlacas[0][1]} excesos.` : null,
        `• Nivel de riesgo general del período: ${_st.nivel}.`,
      ].filter(Boolean).forEach(rec => {
        const lines = pdf.splitTextToSize(rec as string, pageWidth - MARGIN * 2 - 10);
        pdf.text(lines, MARGIN + 5, yPos);
        yPos += (lines.length as number) * 5 + 1;
      });
      yPos += 6;

      // ── GRÁFICAS ──────────────────────────────────────────────
      // Carta horizontal: 279.4 × 215.9 mm. Márgenes: 14 mm. Área útil: 251.4 × 187.9 mm.
      // Pie de página: ~18 mm. Área de contenido: ~169.9 mm de alto.
      const CONTENT_BOTTOM = pageHeight - 22; // límite inferior antes del footer
      const CW = (pageWidth - MARGIN * 2 - 6) / 2;  // ~122.7 mm cada gráfica
      const CH = 50;  // altura gráfica: 50 mm para que título canvas quede visible
      // Asegurar que toda la sección entra (título 8 + fila1 50+6 + fila2 50+8 = 122 mm)
      if (yPos + 122 > CONTENT_BOTTOM) { pdf.addPage(); yPos = MARGIN; }
      pdf.setFontSize(10); pdf.setTextColor(13, 110, 253); pdf.setFont('helvetica', 'bold');
      pdf.text('VISUALIZACIÓN DE DATOS', MARGIN, yPos);
      yPos += 7;
      // — Gráfica 1: Pie de severidad (izquierda)
      const _pieImg = makePieChartImg(
        [
          { label: 'Alta >100', value: _st.alta, color: '#ef4444' },
          { label: 'Media 80-100', value: _st.media, color: '#f97316' },
          { label: 'Baja ≤80', value: _st.baja, color: '#22c55e' },
        ], 560, 320, 'Distribución por Severidad'
      );
      if (_pieImg) pdf.addImage(_pieImg, 'PNG', MARGIN, yPos, CW, CH);
      // — Gráfica 2: Bar top placas (derecha)
      if (_st.topPlacas.length > 0) {
        const _topBarImg = makeBarChartImg(
          _st.topPlacas.map(([p, n]) => ({ label: p, value: n, color: '#6366f1' })),
          560, 340, 'Top Placas con más Excesos'
        );
        if (_topBarImg) pdf.addImage(_topBarImg, 'PNG', MARGIN + CW + 6, yPos, CW, CH);
      }
      yPos += CH + 6;
      // — Gráfica 3: Excesos por hora (ancho completo). Canvas 1200×420 da mejor proporción.
      // Aspecto real en PDF: 251.4mm × 50mm → ratio 5.03:1 que coincide con 1200:238 (área útil)
      if (yPos + CH + 8 > CONTENT_BOTTOM) { pdf.addPage(); yPos = MARGIN; }
      const _hourlyData = Array.from({ length: 24 }, (_, hh) => ({
        label: `${hh}h`, value: _st.ph[hh.toString()] || 0, color: '#3b82f6'
      }));
      const _hourlyImg = makeBarChartImg(_hourlyData, 1200, 420, 'Excesos por Hora del Día (0-23 h)');
      if (_hourlyImg) pdf.addImage(_hourlyImg, 'PNG', MARGIN, yPos, pageWidth - MARGIN * 2, CH);
      yPos += CH + 8;
    }

    // ── TABLA ─────────────────────────────────────────────────
    const tableData = eventosFiltrados.map(e => [
      e.id.toString(),
      e.placa?.trim() || 'N/A',
      `${e.velocidad} km/h`,
      new Date(e.created_at).toLocaleString('es-ES', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      (e.ruta || 'N/A').substring(0, 60)
    ]);

    pdf.autoTable({
      startY: yPos,
      head: [['ID', 'Placa', 'Velocidad', 'Fecha/Hora', 'Ruta']],
      body: tableData,
      theme: 'striped',
      headStyles: {
        fillColor: [13, 110, 253],
        textColor: 255,
        fontSize: 9,
        fontStyle: 'bold'
      },
      styles: {
        fontSize: 8,
        cellPadding: 2.5,
        overflow: 'linebreak' as const
      },
      columnStyles: {
        0: { cellWidth: 13 },
        1: { cellWidth: 22 },
        2: { cellWidth: 22 },
        3: { cellWidth: 36 },
        4: { cellWidth: 'auto' }
      },
      margin: { left: MARGIN + 4, right: MARGIN + 4 }
    });

    // ── PIE DE PÁGINA ─────────────────────────────────────────
    const totalPages = (pdf as any).internal.getNumberOfPages();
    const fechaGeneracion = new Date().toLocaleString('es-ES');
    // Calcular altura del pie según si hay texto configurable
    const footerExtraHeight = reportFooter ? 12 : 0;
    for (let i = 1; i <= totalPages; i++) {
      pdf.setPage(i);
      pdf.setFontSize(8);
      pdf.setTextColor(150, 150, 150);
      pdf.setDrawColor(200, 200, 200);
      pdf.setLineWidth(0.3);
      const footerY = pageHeight - 14 - footerExtraHeight;
      // Línea separadora
      pdf.line(MARGIN, footerY, pageWidth - MARGIN, footerY);
      // Texto configurable del pie de página (fila superior del pie)
      if (reportFooter) {
        pdf.setFont('helvetica', 'italic');
        pdf.text(reportFooter, pageWidth / 2, footerY + 6, { align: 'center' });
        pdf.setFont('helvetica', 'normal');
      }
      // Fila inferior: empresa | fecha | página
      const rowY = footerY + 6 + footerExtraHeight;
      pdf.text(reporte.empresa || companyName, MARGIN, rowY);
      pdf.text(`Generado el ${fechaGeneracion}`, pageWidth / 2, rowY, { align: 'center' });
      pdf.text(`Página ${i} de ${totalPages}`, pageWidth - MARGIN, rowY, { align: 'right' });
    }

    pdf.save(`${reporte.nombre.replace(/\s+/g, '_')}.pdf`);
    toast.success('PDF descargado');
  };

  // Generar Excel para un reporte específico
  const generarExcel = (reporte: ReporteGuardado) => {
    const eventosFiltrados = filtrarEventos(
      reporte.placa,
      reporte.fecha_desde,
      reporte.fecha_hasta,
      reporte.tipo_evento
    );

    const workbook = XLSX.utils.book_new();

    const infoData = [
      [reporte.nombre.toUpperCase()],
      [''],
      ['Empresa:', reporte.empresa],
      ['Fecha de creación:', new Date(reporte.created_at).toLocaleString('es-ES')],
      ['Usuario:', reporte.usuario],
      [''],
      ['FILTROS'],
      ['Placa:', reporte.placa],
      ['Fecha desde:', reporte.fecha_desde],
      ['Fecha hasta:', reporte.fecha_hasta],
      ['Tipo de evento:', reporte.tipo_evento],
      [''],
      ['Total de eventos:', reporte.total_eventos],
      ['Velocidad promedio:', `${reporte.velocidad_promedio} km/h`]
    ];
    const infoSheet = XLSX.utils.aoa_to_sheet(infoData);
    infoSheet['!cols'] = [{ wch: 20 }, { wch: 50 }];
    XLSX.utils.book_append_sheet(workbook, infoSheet, 'Información');

    const eventosData = eventosFiltrados.map(e => ({
      'ID': e.id,
      'Placa': e.placa?.trim() || 'N/A',
      'Velocidad (km/h)': e.velocidad,
      'Fecha/Hora Original': e.fecha || 'N/A',
      'Fecha de Registro': new Date(e.created_at).toLocaleString('es-ES'),
      'Ruta': e.ruta || 'N/A',
      'Latitud': e.latitud || '',
      'Longitud': e.longitud || ''
    }));
    const eventosSheet = XLSX.utils.json_to_sheet(eventosData);
    eventosSheet['!cols'] = [
      { wch: 8 },
      { wch: 12 },
      { wch: 15 },
      { wch: 18 },
      { wch: 20 },
      { wch: 50 },
      { wch: 12 },
      { wch: 12 }
    ];
    XLSX.utils.book_append_sheet(workbook, eventosSheet, 'Eventos');

    // Hoja analítica
    const _ast = (() => {
      const evs = eventosFiltrados;
      const total = evs.length;
      const velMax = total > 0 ? Math.max(...evs.map(e => e.velocidad)) : 0;
      const velMin = total > 0 ? Math.min(...evs.map(e => e.velocidad)) : 0;
      const velProm = total > 0 ? parseFloat((evs.reduce((s, e) => s + e.velocidad, 0) / total).toFixed(1)) : 0;
      const alta = evs.filter(e => e.velocidad > 100).length;
      const media = evs.filter(e => e.velocidad > 80 && e.velocidad <= 100).length;
      const baja = evs.filter(e => e.velocidad <= 80).length;
      const pp: Record<string, number> = {};
      evs.forEach(e => { const p = e.placa?.trim(); if (p) pp[p] = (pp[p] || 0) + 1; });
      const topPlacas = Object.entries(pp).sort((a, b) => b[1] - a[1]).slice(0, 5);
      const ph: Record<string, number> = {};
      evs.forEach(e => { const h = new Date(e.created_at).getHours().toString(); ph[h] = (ph[h] || 0) + 1; });
      const horaRiesgo = Object.entries(ph).sort((a, b) => b[1] - a[1])[0];
      const nivel = alta / (total || 1) > 0.5 ? 'ALTO' : media / (total || 1) > 0.4 ? 'MODERADO' : 'BAJO';
      return { total, velMax, velMin, velProm, alta, media, baja, topPlacas, ph, horaRiesgo, nivel };
    })();
    const analyticsAoa: (string | number)[][] = [
      ['ESTADÍSTICAS ANALÍTICAS', ''],
      [''],
      ['Total excesos', _ast.total],
      ['Velocidad máxima (km/h)', _ast.velMax],
      ['Velocidad mínima (km/h)', _ast.velMin],
      ['Velocidad promedio (km/h)', _ast.velProm],
      ['Alta severidad >100 km/h', _ast.alta],
      ['Media severidad 80-100 km/h', _ast.media],
      ['Baja severidad ≤80 km/h', _ast.baja],
      ['% Alta severidad', _ast.total > 0 ? parseFloat(((_ast.alta / _ast.total) * 100).toFixed(1)) : 0],
      ['Hora de mayor riesgo', _ast.horaRiesgo ? `${_ast.horaRiesgo[0]}:00 h (${_ast.horaRiesgo[1]} eventos)` : '—'],
      ['Placa con más excesos', _ast.topPlacas.length > 0 ? `${_ast.topPlacas[0][0]} (${_ast.topPlacas[0][1]} eventos)` : '—'],
      ['Nivel de riesgo general', _ast.nivel],
      [''],
      ['TOP PLACAS', ''],
    ];
    _ast.topPlacas.forEach((e, i) => analyticsAoa.push([`${i + 1}. ${e[0]}`, e[1]]));
    analyticsAoa.push([''], ['EXCESOS POR HORA', '']);
    Array.from({ length: 24 }, (_, h) => analyticsAoa.push([`${h}:00 h`, _ast.ph[h.toString()] || 0]));
    analyticsAoa.push(
      [''],
      ['RECOMENDACIONES', ''],
      [`Se registraron ${_ast.total} excesos en el período analizado.`, ''],
      [_ast.alta > 0 ? `${_ast.alta} excesos de ALTA severidad — revisión disciplinaria recomendada.` : 'Sin excesos de alta severidad.', ''],
      [`Velocidad máxima: ${_ast.velMax} km/h — promedio: ${_ast.velProm} km/h.`, ''],
      [_ast.horaRiesgo ? `Franja crítica: ${_ast.horaRiesgo[0]}:00 h (${_ast.horaRiesgo[1]} eventos).` : '', ''],
      [_ast.topPlacas.length > 0 ? `Placa de mayor riesgo: ${_ast.topPlacas[0][0]} (${_ast.topPlacas[0][1]} excesos).` : '', ''],
      [`Nivel de riesgo: ${_ast.nivel}.`, '']
    );
    const analyticsSheet = XLSX.utils.aoa_to_sheet(analyticsAoa);
    analyticsSheet['!cols'] = [{ wch: 40 }, { wch: 25 }];
    XLSX.utils.book_append_sheet(workbook, analyticsSheet, 'Analíticas');

    XLSX.writeFile(workbook, `${reporte.nombre.replace(/\s+/g, '_')}.xlsx`);
    toast.success('Excel descargado');
  };

  // Generar JSON para un reporte específico
  const generarJSON = (reporte: ReporteGuardado) => {
    const eventosFiltrados = filtrarEventos(
      reporte.placa,
      reporte.fecha_desde,
      reporte.fecha_hasta,
      reporte.tipo_evento
    );

    const data = {
      nombre_reporte: reporte.nombre,
      empresa: reporte.empresa,
      fecha_creacion: reporte.created_at,
      usuario: reporte.usuario,
      filtros: {
        placa: reporte.placa,
        fecha_desde: reporte.fecha_desde,
        fecha_hasta: reporte.fecha_hasta,
        tipo_evento: reporte.tipo_evento
      },
      estadisticas: {
        total_eventos: reporte.total_eventos,
        velocidad_promedio: reporte.velocidad_promedio
      },
      eventos: eventosFiltrados
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${reporte.nombre.replace(/\s+/g, '_')}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('JSON descargado');
  };

  // ── Ranking conductores con excesos ──────────────────────────
  const rankingConductores = conductores.map(c => {
    const placa = c.vehiculo?.trim();
    const excesos = placa ? eventos.filter(e => e.placa?.trim() === placa) : [];
    const velProm = excesos.length > 0
      ? parseFloat((excesos.reduce((s, e) => s + e.velocidad, 0) / excesos.length).toFixed(1))
      : 0;
    return { ...c, excesosCount: excesos.length, velProm };
  }).sort((a, b) => b.excesosCount - a.excesosCount);

  // PDF reporte de conductores
  const generarPDFConductores = () => {
    const pdf = new jsPDF('l', 'mm', 'letter');
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const MARGIN = 14;
    let yPos = MARGIN;

    if (companyLogo) {
      try {
        const format = companyLogo.startsWith('data:image/png') ? 'PNG' : 'JPEG';
        pdf.addImage(companyLogo, format, MARGIN, yPos, 33, 22);
      } catch { /* continuar sin logo */ }
    }
    pdf.setFontSize(18); pdf.setTextColor(13, 110, 253); pdf.setFont('helvetica', 'bold');
    pdf.text('REPORTE DE CONDUCTORES', pageWidth / 2, yPos + 12, { align: 'center' });
    yPos += 27;
    pdf.setLineWidth(0.5); pdf.setDrawColor(13, 110, 253);
    pdf.line(MARGIN, yPos, pageWidth - MARGIN, yPos);
    yPos += 7;

    pdf.setFontSize(10); pdf.setTextColor(50, 50, 50); pdf.setFont('helvetica', 'normal');
    pdf.text(`Empresa: ${companyName}`, MARGIN + 5, yPos);
    pdf.text(`Generado: ${new Date().toLocaleString('es-ES')}`, pageWidth - MARGIN, yPos, { align: 'right' });
    yPos += 10;

    const tableData = rankingConductores.map((c, i) => [
      (i + 1).toString(),
      c.nombre,
      c.cedula || '—',
      c.vehiculo?.trim() || '—',
      c.excesosCount.toString(),
      c.excesosCount > 0 ? `${c.velProm} km/h` : '—',
      c.estado || '—'
    ]);

    pdf.autoTable({
      startY: yPos,
      head: [['#', 'Conductor', 'Documento', 'Placa', 'Excesos', 'Vel. Promedio', 'Estado']],
      body: tableData,
      theme: 'striped',
      headStyles: { fillColor: [13, 110, 253], textColor: 255, fontSize: 9, fontStyle: 'bold' },
      styles: { fontSize: 8, cellPadding: 3 },
      columnStyles: { 0: { cellWidth: 10 }, 3: { cellWidth: 22 }, 4: { cellWidth: 18 }, 5: { cellWidth: 25 } },
      margin: { left: MARGIN + 5, right: MARGIN + 5 }
    });

    // Analíticas globales de conductores
    {
      const _yAn = (pdf as any).lastAutoTable.finalY + 8;
      const _totalEx = rankingConductores.reduce((s, c) => s + c.excesosCount, 0);
      const _conEx = rankingConductores.filter(c => c.excesosCount > 0).length;
      const _allEvs = rankingConductores.flatMap(c => {
        const p = c.vehiculo?.trim();
        return p ? eventos.filter(e => e.placa?.trim() === p) : [];
      });
      const _velPG = _allEvs.length > 0 ? parseFloat((_allEvs.reduce((s, e) => s + e.velocidad, 0) / _allEvs.length).toFixed(1)) : 0;
      const _velMG = _allEvs.length > 0 ? Math.max(..._allEvs.map(e => e.velocidad)) : 0;
      const _top = rankingConductores[0];
      pdf.setFontSize(11); pdf.setTextColor(13, 110, 253); pdf.setFont('helvetica', 'bold');
      pdf.text('RESUMEN ANALÍTICO', MARGIN + 5, _yAn);
      pdf.autoTable({
        startY: _yAn + 4,
        head: [['Indicador', 'Valor']],
        body: [
          ['Total conductores registrados', rankingConductores.length.toString()],
          ['Conductores con excesos', _conEx.toString()],
          ['Conductores sin excesos', (rankingConductores.length - _conEx).toString()],
          ['Total excesos registrados', _totalEx.toString()],
          ['Vel. promedio global (km/h)', _velPG.toString()],
          ['Vel. máxima registrada (km/h)', _velMG.toString()],
          ['Conductor de mayor riesgo', _top ? `${_top.nombre} (${_top.excesosCount} excesos)` : '—'],
          ['Placa de mayor riesgo', _top?.vehiculo?.trim() || '—'],
        ],
        theme: 'striped',
        headStyles: { fillColor: [13, 110, 253], textColor: 255, fontSize: 9, fontStyle: 'bold' },
        styles: { fontSize: 8, cellPadding: 2.5 },
        columnStyles: { 0: { cellWidth: 80, fontStyle: 'bold' as const }, 1: { cellWidth: 'auto' } },
        margin: { left: MARGIN + 4, right: MARGIN + 4 }
      });
    }

    // ── GRÁFICAS CONDUCTORES ──────────────────────────────────
    {
      const _topC = rankingConductores.filter(c => c.excesosCount > 0).slice(0, 8);
      if (_topC.length > 0) {
        yPos = (pdf as any).lastAutoTable.finalY + 8;
        const CONTENT_BOTTOM_C = pageHeight - 22;
        const CH_C = 52;
        if (yPos + CH_C + 10 > CONTENT_BOTTOM_C) { pdf.addPage(); yPos = MARGIN; }
        pdf.setFontSize(10); pdf.setTextColor(13, 110, 253); pdf.setFont('helvetica', 'bold');
        pdf.text('RANKING VISUAL — EXCESOS POR CONDUCTOR (TOP 8)', MARGIN, yPos);
        yPos += 6;
        const _barImgC = makeBarChartImg(
          _topC.map(c => ({ label: c.nombre.split(' ')[0], value: c.excesosCount, color: '#ef4444' })),
          1200, 420, 'Excesos por Conductor'
        );
        if (_barImgC) pdf.addImage(_barImgC, 'PNG', MARGIN, yPos, pageWidth - MARGIN * 2, CH_C);
        yPos += CH_C + 8;
      }
    }

    const totalPages = (pdf as any).internal.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      pdf.setPage(i);
      pdf.setFontSize(8); pdf.setTextColor(150, 150, 150);
      const footerY = pageHeight - 10;
      pdf.line(MARGIN, footerY - 4, pageWidth - MARGIN, footerY - 4);
      pdf.text(companyName, MARGIN, footerY);
      pdf.text(`Generado el ${new Date().toLocaleString('es-ES')}`, pageWidth / 2, footerY, { align: 'center' });
      pdf.text(`Página ${i} de ${totalPages}`, pageWidth - MARGIN, footerY, { align: 'right' });
    }

    pdf.save('Reporte_Conductores.pdf');
    toast.success('PDF de conductores descargado');
  };

  // Excel reporte de conductores
  const generarExcelConductores = () => {
    const workbook = XLSX.utils.book_new();
    const data = rankingConductores.map((c, i) => ({
      '#': i + 1,
      'Conductor': c.nombre,
      'Documento (Cédula)': c.cedula || '',
      'Placa Asignada': c.vehiculo?.trim() || '',
      'Nº Excesos': c.excesosCount,
      'Vel. Promedio (km/h)': c.excesosCount > 0 ? c.velProm : '',
      'Estado': c.estado || ''
    }));
    const sheet = XLSX.utils.json_to_sheet(data);
    sheet['!cols'] = [{ wch: 5 }, { wch: 30 }, { wch: 20 }, { wch: 15 }, { wch: 12 }, { wch: 20 }, { wch: 12 }];
    XLSX.utils.book_append_sheet(workbook, sheet, 'Conductores');

    // Hoja analítica global
    const _gAllEvs = rankingConductores.flatMap(c => {
      const p = c.vehiculo?.trim();
      return p ? eventos.filter(e => e.placa?.trim() === p) : [];
    });
    const _gVelProm = _gAllEvs.length > 0 ? parseFloat((_gAllEvs.reduce((s, e) => s + e.velocidad, 0) / _gAllEvs.length).toFixed(1)) : 0;
    const _gVelMax = _gAllEvs.length > 0 ? Math.max(..._gAllEvs.map(e => e.velocidad)) : 0;
    const _gTotalEx = rankingConductores.reduce((s, c) => s + c.excesosCount, 0);
    const _gConEx = rankingConductores.filter(c => c.excesosCount > 0).length;
    const _gTop = rankingConductores[0];
    const analyticsAoa2: (string | number)[][] = [
      ['ANÁLISIS GLOBAL DE CONDUCTORES', ''],
      [''],
      ['Total conductores registrados', rankingConductores.length],
      ['Conductores con excesos', _gConEx],
      ['Conductores sin excesos', rankingConductores.length - _gConEx],
      ['Total excesos registrados', _gTotalEx],
      ['Vel. promedio global (km/h)', _gVelProm],
      ['Vel. máxima registrada (km/h)', _gVelMax],
      ['Conductor de mayor riesgo', _gTop ? `${_gTop.nombre} (${_gTop.excesosCount} excesos)` : '—'],
      ['Placa de mayor riesgo', _gTop?.vehiculo?.trim() || '—'],
      [''],
      ['DISTRIBUCIÓN POR CONDUCTOR', ''],
      ['Conductor', 'Placa', 'Excesos', 'Vel. Promedio (km/h)'],
    ];
    rankingConductores.forEach(c => analyticsAoa2.push([c.nombre, c.vehiculo?.trim() || '—', c.excesosCount, c.excesosCount > 0 ? c.velProm : '—']));
    const analyticsSheet2 = XLSX.utils.aoa_to_sheet(analyticsAoa2);
    analyticsSheet2['!cols'] = [{ wch: 35 }, { wch: 15 }, { wch: 12 }, { wch: 20 }];
    XLSX.utils.book_append_sheet(workbook, analyticsSheet2, 'Analíticas');

    XLSX.writeFile(workbook, 'Reporte_Conductores.xlsx');
    toast.success('Excel de conductores descargado');
  };

  type ConductorRanking = (typeof rankingConductores)[number];

  const generarPDFConductorIndividual = (c: ConductorRanking) => {
    const pdf = new jsPDF('l', 'mm', 'letter');
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const MARGIN = 14;
    let yPos = MARGIN;

    if (companyLogo) {
      try {
        const format = companyLogo.startsWith('data:image/png') ? 'PNG' : 'JPEG';
        pdf.addImage(companyLogo, format, MARGIN, yPos, 33, 22);
      } catch { /* sin logo */ }
    }
    pdf.setFontSize(16); pdf.setTextColor(13, 110, 253); pdf.setFont('helvetica', 'bold');
    pdf.text(`REPORTE: ${c.nombre.toUpperCase()}`, pageWidth / 2, yPos + 12, { align: 'center' });
    yPos += 27;
    pdf.setLineWidth(0.5); pdf.setDrawColor(13, 110, 253);
    pdf.line(MARGIN, yPos, pageWidth - MARGIN, yPos);
    yPos += 8;

    pdf.setFontSize(10); pdf.setTextColor(50, 50, 50); pdf.setFont('helvetica', 'normal');
    pdf.text(`Empresa: ${companyName}`, MARGIN + 5, yPos);
    pdf.text(`Generado: ${new Date().toLocaleString('es-ES')}`, pageWidth - MARGIN, yPos, { align: 'right' });
    yPos += 6;
    pdf.text(`Cédula: ${c.cedula || '—'}`, MARGIN + 5, yPos);
    pdf.text(`Placa: ${c.vehiculo?.trim() || '—'}`, MARGIN + 78, yPos);
    pdf.text(`Estado: ${c.estado || '—'}`, MARGIN + 148, yPos);
    yPos += 6;
    pdf.text(`Total excesos: ${c.excesosCount}`, MARGIN + 5, yPos);
    pdf.text(`Vel. promedio: ${c.excesosCount > 0 ? c.velProm + ' km/h' : '—'}`, MARGIN + 80, yPos);
    yPos += 10;

    const placa = c.vehiculo?.trim();
    const excesosDelConductor = placa ? eventos.filter(e => e.placa?.trim() === placa) : [];

    // Analíticas individuales del conductor
    if (excesosDelConductor.length > 0) {
      const _evs = excesosDelConductor;
      const _total = _evs.length;
      const _velMax = Math.max(..._evs.map(e => e.velocidad));
      const _velMin = Math.min(..._evs.map(e => e.velocidad));
      const _alta = _evs.filter(e => e.velocidad > 100).length;
      const _media = _evs.filter(e => e.velocidad > 80 && e.velocidad <= 100).length;
      const _baja = _evs.filter(e => e.velocidad <= 80).length;
      const _ph: Record<string, number> = {};
      _evs.forEach(e => { const h = new Date(e.created_at).getHours().toString(); _ph[h] = (_ph[h] || 0) + 1; });
      const _horaRiesgo = Object.entries(_ph).sort((a, b) => b[1] - a[1])[0] as [string, number] | undefined;
      const _nivel = _alta / _total > 0.5 ? 'ALTO' : _media / _total > 0.4 ? 'MODERADO' : 'BAJO';
      pdf.setFontSize(11); pdf.setTextColor(13, 110, 253); pdf.setFont('helvetica', 'bold');
      pdf.text('ESTADÍSTICAS ANALÍTICAS', MARGIN + 5, yPos);
      yPos += 5;
      pdf.autoTable({
        startY: yPos,
        head: [['Indicador', 'Valor']],
        body: [
          ['Total excesos', _total.toString()],
          ['Velocidad máxima (km/h)', _velMax.toString()],
          ['Velocidad mínima (km/h)', _velMin.toString()],
          ['Velocidad promedio (km/h)', c.velProm.toString()],
          ['Alta severidad >100 km/h', `${_alta} (${((_alta / _total) * 100).toFixed(0)}%)`],
          ['Media severidad 80-100 km/h', `${_media} (${((_media / _total) * 100).toFixed(0)}%)`],
          ['Baja severidad ≤80 km/h', `${_baja} (${((_baja / _total) * 100).toFixed(0)}%)`],
          ['Hora de mayor riesgo', _horaRiesgo ? `${_horaRiesgo[0]}:00 h (${_horaRiesgo[1]} eventos)` : '—'],
          ['Nivel de riesgo', _nivel],
        ],
        theme: 'striped',
        headStyles: { fillColor: [13, 110, 253], textColor: 255, fontSize: 9, fontStyle: 'bold' },
        styles: { fontSize: 8, cellPadding: 2.5 },
        columnStyles: { 0: { cellWidth: 80, fontStyle: 'bold' as const }, 1: { cellWidth: 'auto' } },
        margin: { left: MARGIN + 4, right: MARGIN + 4 }
      });
      yPos = (pdf as any).lastAutoTable.finalY + 5;
      pdf.setFontSize(10); pdf.setTextColor(13, 110, 253); pdf.setFont('helvetica', 'bold');
      pdf.text('RECOMENDACIONES', MARGIN + 5, yPos);
      yPos += 5;
      pdf.setFontSize(9); pdf.setTextColor(60, 60, 60); pdf.setFont('helvetica', 'normal');
      [
        `• Conductor: ${c.nombre} — ${_total} excesos de velocidad registrados.`,
        _alta > 0 ? `• ${_alta} excesos de ALTA severidad (>100 km/h) — se recomienda revisión disciplinaria.` : '• No se registraron excesos de alta severidad.',
        `• Velocidad máxima: ${_velMax} km/h — promedio: ${c.velProm} km/h.`,
        _horaRiesgo ? `• Franja horaria crítica: ${_horaRiesgo[0]}:00 h con ${_horaRiesgo[1]} eventos.` : null,
        `• Nivel de riesgo: ${_nivel}.`,
      ].filter(Boolean).forEach(rec => {
        const lines = pdf.splitTextToSize(rec as string, pageWidth - MARGIN * 2 - 10);
        pdf.text(lines, MARGIN + 5, yPos);
        yPos += (lines.length as number) * 5 + 1;
      });
      yPos += 6;

      // ── GRÁFICAS INDIVIDUALES ────────────────────────────────
      // Carta horizontal: área útil 251.4 mm × ~170 mm de contenido
      const CONTENT_BOTTOM_I = pageHeight - 22;
      const _CW = (pageWidth - MARGIN * 2 - 6) / 2;  // ~122.7 mm cada gráfica
      const _CH = 50;
      if (yPos + _CH + 14 > CONTENT_BOTTOM_I) { pdf.addPage(); yPos = MARGIN; }
      pdf.setFontSize(10); pdf.setTextColor(13, 110, 253); pdf.setFont('helvetica', 'bold');
      pdf.text('VISUALIZACIÓN DE DATOS', MARGIN, yPos);
      yPos += 7;
      // — Pie severidad (izquierda)
      const _pieImgI = makePieChartImg(
        [
          { label: 'Alta >100', value: _alta, color: '#ef4444' },
          { label: 'Media 80-100', value: _media, color: '#f97316' },
          { label: 'Baja ≤80', value: _baja, color: '#22c55e' },
        ], 560, 320, 'Distribución por Severidad'
      );
      if (_pieImgI) pdf.addImage(_pieImgI, 'PNG', MARGIN, yPos, _CW, _CH);
      // — Bar horaria (derecha)
      const _phGrI: Record<string, number> = {};
      _evs.forEach(e => { const hh = new Date(e.created_at).getHours().toString(); _phGrI[hh] = (_phGrI[hh] || 0) + 1; });
      const _hourlyImgI = makeBarChartImg(
        Array.from({ length: 24 }, (_, hh) => ({ label: `${hh}h`, value: _phGrI[hh.toString()] || 0, color: '#6366f1' })),
        800, 420, 'Excesos por Hora del Día'
      );
      if (_hourlyImgI) pdf.addImage(_hourlyImgI, 'PNG', MARGIN + _CW + 6, yPos, _CW, _CH);
      yPos += _CH + 8;
    }

    const tableData = excesosDelConductor.map((e, i) => [
      (i + 1).toString(),
      e.placa?.trim() || '—',
      `${e.velocidad} km/h`,
      new Date(e.created_at).toLocaleString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }),
      (e.ruta || '—').substring(0, 60)
    ]);

    pdf.autoTable({
      startY: yPos,
      head: [['#', 'Placa', 'Velocidad', 'Fecha/Hora', 'Ruta']],
      body: tableData.length > 0 ? tableData : [['—', '—', '—', '—', 'Sin excesos registrados']],
      theme: 'striped',
      headStyles: { fillColor: [13, 110, 253], textColor: 255, fontSize: 9, fontStyle: 'bold' },
      styles: { fontSize: 8, cellPadding: 3 },
      margin: { left: MARGIN + 5, right: MARGIN + 5 }
    });

    const totalPages = (pdf as any).internal.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      pdf.setPage(i);
      pdf.setFontSize(8); pdf.setTextColor(150, 150, 150);
      const footerY = pageHeight - 10;
      pdf.line(MARGIN, footerY - 4, pageWidth - MARGIN, footerY - 4);
      pdf.text(companyName, MARGIN, footerY);
      pdf.text(`Generado el ${new Date().toLocaleString('es-ES')}`, pageWidth / 2, footerY, { align: 'center' });
      pdf.text(`Página ${i} de ${totalPages}`, pageWidth - MARGIN, footerY, { align: 'right' });
    }
    pdf.save(`Reporte_${c.nombre.replace(/\s+/g, '_')}.pdf`);
    toast.success('PDF descargado');
  };

  const generarExcelConductorIndividual = (c: ConductorRanking) => {
    const workbook = XLSX.utils.book_new();
    const info = [
      [`REPORTE: ${c.nombre.toUpperCase()}`],
      [''],
      ['Empresa:', companyName],
      ['Cédula:', c.cedula || ''],
      ['Placa:', c.vehiculo?.trim() || ''],
      ['Estado:', c.estado || ''],
      ['Total excesos:', c.excesosCount],
      ['Vel. promedio:', c.excesosCount > 0 ? `${c.velProm} km/h` : '']
    ];
    const infoSheet = XLSX.utils.aoa_to_sheet(info);
    infoSheet['!cols'] = [{ wch: 20 }, { wch: 40 }];
    XLSX.utils.book_append_sheet(workbook, infoSheet, 'Resumen');

    const placa = c.vehiculo?.trim();
    const excesosDelConductor = placa ? eventos.filter(e => e.placa?.trim() === placa) : [];
    const data = excesosDelConductor.map((e, i) => ({
      '#': i + 1,
      'Placa': e.placa?.trim() || '',
      'Velocidad (km/h)': e.velocidad,
      'Fecha': new Date(e.created_at).toLocaleString('es-ES'),
      'Ruta': e.ruta || ''
    }));
    const sheet = XLSX.utils.json_to_sheet(data.length > 0 ? data : [{ '#': '', 'Placa': '', 'Velocidad (km/h)': '', 'Fecha': '', 'Ruta': 'Sin excesos registrados' }]);
    sheet['!cols'] = [{ wch: 5 }, { wch: 12 }, { wch: 16 }, { wch: 22 }, { wch: 50 }];
    XLSX.utils.book_append_sheet(workbook, sheet, 'Excesos');

    // Hoja analítica por conductor
    if (excesosDelConductor.length > 0) {
      const _evs = excesosDelConductor;
      const _total = _evs.length;
      const _velMax = Math.max(..._evs.map(e => e.velocidad));
      const _velMin = Math.min(..._evs.map(e => e.velocidad));
      const _alta = _evs.filter(e => e.velocidad > 100).length;
      const _media = _evs.filter(e => e.velocidad > 80 && e.velocidad <= 100).length;
      const _baja = _evs.filter(e => e.velocidad <= 80).length;
      const _ph2: Record<string, number> = {};
      _evs.forEach(e => { const h = new Date(e.created_at).getHours().toString(); _ph2[h] = (_ph2[h] || 0) + 1; });
      const _horaR = Object.entries(_ph2).sort((a, b) => b[1] - a[1])[0];
      const _nivel = _alta / _total > 0.5 ? 'ALTO' : _media / _total > 0.4 ? 'MODERADO' : 'BAJO';
      const anAoa: (string | number)[][] = [
        [`ANALÍTICAS — ${c.nombre.toUpperCase()}`, ''],
        [''],
        ['Total excesos', _total],
        ['Velocidad máxima (km/h)', _velMax],
        ['Velocidad mínima (km/h)', _velMin],
        ['Velocidad promedio (km/h)', c.velProm],
        ['Alta severidad >100 km/h', _alta],
        ['Media severidad 80-100 km/h', _media],
        ['Baja severidad ≤80 km/h', _baja],
        ['% Alta severidad', parseFloat(((_alta / _total) * 100).toFixed(1))],
        ['Hora de mayor riesgo', _horaR ? `${_horaR[0]}:00 h (${_horaR[1]} eventos)` : '—'],
        ['Nivel de riesgo', _nivel],
        [''],
        ['EXCESOS POR HORA', ''],
      ];
      Array.from({ length: 24 }, (_, h) => anAoa.push([`${h}:00 h`, _ph2[h.toString()] || 0]));
      anAoa.push(
        [''],
        ['RECOMENDACIONES', ''],
        [`${c.nombre}: ${_total} excesos registrados.`, ''],
        [_alta > 0 ? `${_alta} excesos de alta severidad — revisión disciplinaria recomendada.` : 'Sin excesos de alta severidad.', ''],
        [`Velocidad máxima: ${_velMax} km/h — promedio: ${c.velProm} km/h.`, ''],
        [_horaR ? `Franja crítica: ${_horaR[0]}:00 h (${_horaR[1]} eventos).` : '', ''],
        [`Nivel de riesgo: ${_nivel}.`, '']
      );
      const anSheet = XLSX.utils.aoa_to_sheet(anAoa);
      anSheet['!cols'] = [{ wch: 35 }, { wch: 20 }];
      XLSX.utils.book_append_sheet(workbook, anSheet, 'Analíticas');
    }

    XLSX.writeFile(workbook, `Reporte_${c.nombre.replace(/\s+/g, '_')}.xlsx`);
    toast.success('Excel descargado');
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh]">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
        <p className="mt-4 text-muted-foreground">Cargando datos...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Gestión de Reportes</h1>
        <p className="text-muted-foreground text-sm">Crea, guarda y gestiona tus reportes de excesos de velocidad</p>
      </div>

      {/* Formulario de Creación de Reporte */}
      <div className="bg-card border border-border rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <FilePlus className="w-5 h-5 text-primary" />
          <h3 className="font-semibold text-foreground">Crear Nuevo Reporte</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
          {/* Nombre del Reporte */}
          <div className="lg:col-span-3">
            <label className="text-sm text-muted-foreground block mb-2">Nombre del Reporte *</label>
            <Input 
              type="text" 
              placeholder="Ej: Reporte Mensual Abril 2026"
              value={nombreReporte} 
              onChange={(e) => setNombreReporte(e.target.value)}
            />
          </div>

          {/* Filtro de Conductor */}
          <div>
            <label className="text-sm text-muted-foreground block mb-2">Conductor</label>
            <Select
              value={conductorSeleccionado}
              onValueChange={(v) => {
                setConductorSeleccionado(v);
                if (v === 'todos') {
                  setPlacaSeleccionada('todas');
                } else {
                  const c = conductores.find(c => c.id === v);
                  setPlacaSeleccionada(c?.vehiculo?.trim() || 'todas');
                }
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar conductor" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos los conductores</SelectItem>
                {conductores.map(c => (
                  <SelectItem key={c.id} value={c.id}>{c.nombre} — {c.vehiculo?.trim()}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Filtro de Placa */}
          <div>
            <label className="text-sm text-muted-foreground block mb-2">Placa</label>
            <Select value={placaSeleccionada} onValueChange={setPlacaSeleccionada}>
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar placa" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas las placas</SelectItem>
                {placasUnicas.map(placa => (
                  <SelectItem key={placa} value={placa}>{placa}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Filtro de Fecha Desde */}
          <div>
            <label className="text-sm text-muted-foreground block mb-2">Fecha Desde</label>
            <Input 
              type="date" 
              value={fechaDesde} 
              onChange={(e) => setFechaDesde(e.target.value)}
            />
          </div>

          {/* Filtro de Fecha Hasta */}
          <div>
            <label className="text-sm text-muted-foreground block mb-2">Fecha Hasta</label>
            <Input 
              type="date" 
              value={fechaHasta} 
              onChange={(e) => setFechaHasta(e.target.value)}
            />
          </div>

          {/* Filtro de Tipo de Evento */}
          <div className="lg:col-span-3">
            <label className="text-sm text-muted-foreground block mb-2">Tipo de Evento</label>
            <Select value={tipoEvento} onValueChange={setTipoEvento}>
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos los tipos</SelectItem>
                <SelectItem value="alta">Alta Velocidad (&gt; 100 km/h)</SelectItem>
                <SelectItem value="media">Velocidad Media (80-100 km/h)</SelectItem>
                <SelectItem value="baja">Velocidad Baja (&lt;= 80 km/h)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button 
          onClick={crearReporte} 
          className="w-full md:w-auto gradient-primary text-primary-foreground"
          disabled={saving}
        >
          {saving ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Guardando...
            </>
          ) : (
            <>
              <FilePlus className="w-4 h-4 mr-2" />
              Crear y Guardar Reporte
            </>
          )}
        </Button>
      </div>

      {/* Tabla de Reportes Guardados */}
      <div className="bg-card border border-border rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <FileText className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-foreground">
              Reportes Guardados ({Array.isArray(reportesGuardados) ? reportesGuardados.length : 0})
            </h3>
          </div>
          <Button
            onClick={() => {
              toast.info('Recargando reportes desde la base de datos...');
              cargarDatos();
            }}
            variant="outline"
            size="sm"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Recargar
          </Button>
        </div>
        
        <div className="w-full overflow-x-auto border rounded-lg">
          <table className="w-full text-sm" style={{ borderCollapse: 'collapse' }}>
            <thead>
              <tr className="bg-gray-100">
                <th className="border px-4 py-3 text-left font-semibold text-foreground">Nombre</th>
                <th className="border px-4 py-3 text-left font-semibold text-foreground">Placa</th>
                <th className="border px-4 py-3 text-left font-semibold text-foreground">Fecha Desde</th>
                <th className="border px-4 py-3 text-left font-semibold text-foreground">Fecha Hasta</th>
                <th className="border px-4 py-3 text-left font-semibold text-foreground">Tipo</th>
                <th className="border px-4 py-3 text-left font-semibold text-foreground">Eventos</th>
                <th className="border px-4 py-3 text-left font-semibold text-foreground">Vel. Prom.</th>
                <th className="border px-4 py-3 text-left font-semibold text-foreground">Creado</th>
                <th className="border px-4 py-3 text-center font-semibold text-foreground">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {Array.isArray(reportesGuardados) && reportesGuardados.length > 0 ? (
                reportesGuardados.map((reporte, idx) => (
                  <tr key={reporte.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="border px-4 py-2 text-foreground font-medium">{reporte.nombre}</td>
                    <td className="border px-4 py-2 text-foreground">{reporte.placa}</td>
                    <td className="border px-4 py-2 text-muted-foreground text-xs">{reporte.fecha_desde}</td>
                    <td className="border px-4 py-2 text-muted-foreground text-xs">{reporte.fecha_hasta}</td>
                    <td className="border px-4 py-2 text-foreground text-xs">{reporte.tipo_evento}</td>
                    <td className="border px-4 py-2 text-center font-semibold">{reporte.total_eventos}</td>
                    <td className="border px-4 py-2 text-center">{reporte.velocidad_promedio} km/h</td>
                    <td className="border px-4 py-2 text-muted-foreground text-xs">
                      {new Date(reporte.created_at).toLocaleDateString('es-ES')}
                    </td>
                    <td className="border px-4 py-2">
                      <div className="flex items-center justify-center gap-2 flex-wrap">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => verReporte(reporte)}
                          title="Ver detalles"
                        >
                          <Eye className="w-3 h-3" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="default"
                          className="bg-red-600 hover:bg-red-700 text-white"
                          onClick={() => generarPDF(reporte)}
                          title="Descargar PDF"
                        >
                          PDF
                        </Button>
                        <Button 
                          size="sm" 
                          variant="default"
                          className="bg-green-600 hover:bg-green-700 text-white"
                          onClick={() => generarExcel(reporte)}
                          title="Descargar Excel"
                        >
                          Excel
                        </Button>
                        <Button 
                          size="sm" 
                          variant="default"
                          className="bg-blue-600 hover:bg-blue-700 text-white"
                          onClick={() => generarJSON(reporte)}
                          title="Descargar JSON"
                        >
                          JSON
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => eliminarReporte(reporte.id)}
                          title="Eliminar reporte"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={9} className="border px-4 py-8 text-center text-muted-foreground">
                    No hay reportes guardados. Crea tu primer reporte usando el formulario de arriba.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reporte de Conductores */}
      <div className="bg-card border border-border rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
            <Users className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-foreground">Reporte de Conductores — Excesos por Conductor</h3>
          </div>

        {rankingConductores.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">No hay conductores registrados</p>
        ) : (
          <div className="overflow-x-auto border rounded-lg">
            <table className="w-full text-sm" style={{ borderCollapse: 'collapse' }}>
              <thead>
                <tr className="bg-gray-100">
                  <th className="border px-4 py-3 text-left font-semibold text-foreground">#</th>
                  <th className="border px-4 py-3 text-left font-semibold text-foreground">Conductor</th>
                  <th className="border px-4 py-3 text-left font-semibold text-foreground">Documento (Cédula)</th>
                  <th className="border px-4 py-3 text-left font-semibold text-foreground">Placa</th>
                  <th className="border px-4 py-3 text-center font-semibold text-foreground">Nº Excesos</th>
                  <th className="border px-4 py-3 text-center font-semibold text-foreground">Vel. Promedio</th>
                  <th className="border px-4 py-3 text-left font-semibold text-foreground">Estado</th>
                  <th className="border px-4 py-3 text-center font-semibold text-foreground">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {rankingConductores.map((c, i) => (
                  <tr key={c.id} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="border px-4 py-2 text-foreground font-medium">{i + 1}</td>
                    <td className="border px-4 py-2 text-foreground font-medium">{c.nombre}</td>
                    <td className="border px-4 py-2 text-muted-foreground font-mono">{c.cedula || '—'}</td>
                    <td className="border px-4 py-2 font-mono text-muted-foreground">{c.vehiculo?.trim() || '—'}</td>
                    <td className="border px-4 py-2 text-center">
                      <span className={`inline-flex items-center justify-center min-w-[2rem] px-2 py-0.5 rounded-full text-xs font-bold ${
                        c.excesosCount >= 10 ? 'bg-red-100 text-red-700' :
                        c.excesosCount >= 5  ? 'bg-yellow-100 text-yellow-700' :
                        c.excesosCount > 0   ? 'bg-blue-100 text-blue-700' :
                                               'bg-gray-100 text-gray-500'
                      }`}>
                        {c.excesosCount}
                      </span>
                    </td>
                    <td className="border px-4 py-2 text-center text-muted-foreground text-xs">
                      {c.excesosCount > 0 ? `${c.velProm} km/h` : '—'}
                    </td>
                    <td className="border px-4 py-2 text-xs capitalize text-muted-foreground">{c.estado || '—'}</td>
                    <td className="border px-4 py-2">
                      <div className="flex items-center justify-center gap-1.5 flex-wrap">
                        <Button
                          size="sm"
                          variant="outline"
                          title="Vista previa"
                          onClick={() => {
                            const placa = c.vehiculo?.trim();
                            const excesos = placa ? eventos.filter(e => e.placa?.trim() === placa) : [];
                            setPreviewConductor({ nombre: c.nombre, cedula: c.cedula, vehiculo: c.vehiculo, estado: c.estado, excesosCount: c.excesosCount, velProm: c.velProm, excesos });
                          }}
                        >
                          <Eye className="w-3 h-3" />
                        </Button>
                        <Button size="sm" className="bg-red-600 hover:bg-red-700 text-white text-xs px-2 py-1 h-auto" title="Descargar PDF" onClick={() => generarPDFConductorIndividual(c)}>
                          PDF
                        </Button>
                        <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white text-xs px-2 py-1 h-auto" title="Descargar Excel" onClick={() => generarExcelConductorIndividual(c)}>
                          Excel
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          title="Eliminar conductor"
                          className="border-red-300 text-red-600 hover:bg-red-50"
                          onClick={() => setConductorAEliminar({ id: c.id, nombre: c.nombre })}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal vista previa reporte guardado */}
      <Dialog open={!!previewReporte} onOpenChange={(open) => !open && setPreviewReporte(null)}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              Vista previa — {previewReporte?.reporte.nombre}
            </DialogTitle>
          </DialogHeader>
          {previewReporte && (() => {
            const evs = previewReporte.eventos;
            const total = evs.length;
            const velMax = total > 0 ? Math.max(...evs.map(e => e.velocidad)) : 0;
            const velMin = total > 0 ? Math.min(...evs.map(e => e.velocidad)) : 0;
            const velProm = total > 0 ? parseFloat((evs.reduce((s, e) => s + e.velocidad, 0) / total).toFixed(1)) : 0;
            const alta = evs.filter(e => e.velocidad > 100).length;
            const media = evs.filter(e => e.velocidad > 80 && e.velocidad <= 100).length;
            const baja = evs.filter(e => e.velocidad <= 80).length;

            // Excesos por día
            const porDia: Record<string, number> = {};
            evs.forEach(e => {
              const d = new Date(e.created_at).toLocaleDateString('en-CA');
              porDia[d] = (porDia[d] || 0) + 1;
            });
            const chartDia = Object.entries(porDia).sort(([a],[b]) => a.localeCompare(b)).map(([dia, cnt]) => ({ dia: dia.slice(5), excesos: cnt }));

            // Velocidades en el tiempo
            const chartVel = evs.slice().sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()).map((e, i) => ({ i: i + 1, vel: e.velocidad }));

            // Distribución por tipo
            const chartTipo = [
              { tipo: 'Alta (>100)', cantidad: alta, fill: '#ef4444' },
              { tipo: 'Media (80-100)', cantidad: media, fill: '#f59e0b' },
              { tipo: 'Baja (≤80)', cantidad: baja, fill: '#3b82f6' },
            ].filter(d => d.cantidad > 0);

            // Top 5 placas
            const porPlaca: Record<string, number> = {};
            evs.forEach(e => { const p = e.placa?.trim(); if (p) porPlaca[p] = (porPlaca[p] || 0) + 1; });
            const chartPlacas = Object.entries(porPlaca).sort(([,a],[,b]) => b - a).slice(0, 5).map(([placa, cantidad]) => ({ placa, cantidad }));

            // Franjas horarias
            const porHora: Record<number, number> = {};
            evs.forEach(e => { const h = new Date(e.created_at).getHours(); porHora[h] = (porHora[h] || 0) + 1; });
            const chartHora = Array.from({ length: 24 }, (_, h) => ({ hora: `${h}h`, excesos: porHora[h] || 0 }));
            const horaRiesgo = Object.entries(porHora).sort(([,a],[,b]) => b - a)[0];

            const nivelRiesgo = alta / (total || 1) > 0.5 ? { label: 'ALTO', color: 'text-red-600 bg-red-50 border-red-200' } :
                                media / (total || 1) > 0.4 ? { label: 'MODERADO', color: 'text-yellow-600 bg-yellow-50 border-yellow-200' } :
                                                             { label: 'BAJO', color: 'text-green-600 bg-green-50 border-green-200' };

            return (
              <div className="space-y-5">
                {/* Datos generales */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm bg-muted/40 rounded-lg p-4">
                  <div><span className="text-muted-foreground text-xs block">Empresa</span><span className="font-medium">{previewReporte.reporte.empresa}</span></div>
                  <div><span className="text-muted-foreground text-xs block">Usuario</span><span className="font-medium">{previewReporte.reporte.usuario}</span></div>
                  <div><span className="text-muted-foreground text-xs block">Período</span><span className="font-medium">{previewReporte.reporte.fecha_desde} → {previewReporte.reporte.fecha_hasta}</span></div>
                  <div><span className="text-muted-foreground text-xs block">Placa / Tipo</span><span className="font-medium">{previewReporte.reporte.placa} — {previewReporte.reporte.tipo_evento}</span></div>
                </div>

                {/* KPIs */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="border rounded-xl p-4 text-center bg-card">
                    <Activity className="w-5 h-5 mx-auto text-primary mb-1" />
                    <p className="text-2xl font-bold text-foreground">{total}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Total excesos</p>
                  </div>
                  <div className="border rounded-xl p-4 text-center bg-card">
                    <TrendingUp className="w-5 h-5 mx-auto text-red-500 mb-1" />
                    <p className="text-2xl font-bold text-red-600">{velMax}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Vel. máxima (km/h)</p>
                  </div>
                  <div className="border rounded-xl p-4 text-center bg-card">
                    <Activity className="w-5 h-5 mx-auto text-yellow-500 mb-1" />
                    <p className="text-2xl font-bold text-yellow-600">{velProm}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Vel. promedio (km/h)</p>
                  </div>
                  <div className={`border rounded-xl p-4 text-center ${nivelRiesgo.color}`}>
                    <AlertTriangle className="w-5 h-5 mx-auto mb-1" />
                    <p className="text-2xl font-bold">{nivelRiesgo.label}</p>
                    <p className="text-xs mt-0.5">Nivel de riesgo</p>
                  </div>
                </div>

                {/* Gráficos fila 1 */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Excesos por día */}
                  <div className="border rounded-xl p-4 bg-card">
                    <h4 className="text-sm font-semibold mb-3">Excesos por día</h4>
                    {chartDia.length > 0 ? (
                      <ResponsiveContainer width="100%" height={180}>
                        <BarChart data={chartDia}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                          <XAxis dataKey="dia" tick={{ fontSize: 10 }} />
                          <YAxis tick={{ fontSize: 10 }} />
                          <Tooltip contentStyle={{ fontSize: 12 }} />
                          <Bar dataKey="excesos" fill="hsl(217 91% 50%)" radius={[4,4,0,0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    ) : <p className="text-center text-muted-foreground text-xs py-10">Sin datos</p>}
                  </div>

                  {/* Distribución por tipo */}
                  <div className="border rounded-xl p-4 bg-card">
                    <h4 className="text-sm font-semibold mb-3">Distribución por severidad</h4>
                    {chartTipo.length > 0 ? (
                      <>
                        <ResponsiveContainer width="100%" height={150}>
                          <PieChart>
                            <Pie data={chartTipo} dataKey="cantidad" nameKey="tipo" cx="50%" cy="50%" outerRadius={60} strokeWidth={2} stroke="#fff">
                              {chartTipo.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                            </Pie>
                            <Tooltip contentStyle={{ fontSize: 12 }} />
                          </PieChart>
                        </ResponsiveContainer>
                        <div className="flex flex-wrap gap-2 justify-center mt-1">
                          {chartTipo.map(d => (
                            <span key={d.tipo} className="flex items-center gap-1 text-xs text-muted-foreground">
                              <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ background: d.fill }} />
                              {d.tipo} ({d.cantidad})
                            </span>
                          ))}
                        </div>
                      </>
                    ) : <p className="text-center text-muted-foreground text-xs py-10">Sin datos</p>}
                  </div>
                </div>

                {/* Gráficos fila 2 */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Velocidad en el tiempo */}
                  <div className="border rounded-xl p-4 bg-card">
                    <h4 className="text-sm font-semibold mb-3">Velocidad por evento (km/h)</h4>
                    {chartVel.length > 0 ? (
                      <ResponsiveContainer width="100%" height={180}>
                        <LineChart data={chartVel}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                          <XAxis dataKey="i" tick={{ fontSize: 10 }} label={{ value: 'Evento', position: 'insideBottom', fontSize: 10, offset: -2 }} />
                          <YAxis tick={{ fontSize: 10 }} domain={['auto', 'auto']} />
                          <Tooltip contentStyle={{ fontSize: 12 }} formatter={(v) => [`${v} km/h`, 'Velocidad']} />
                          <Line type="monotone" dataKey="vel" stroke="#ef4444" strokeWidth={1.5} dot={false} />
                        </LineChart>
                      </ResponsiveContainer>
                    ) : <p className="text-center text-muted-foreground text-xs py-10">Sin datos</p>}
                  </div>

                  {/* Franja horaria */}
                  <div className="border rounded-xl p-4 bg-card">
                    <h4 className="text-sm font-semibold mb-1">Excesos por franja horaria</h4>
                    {horaRiesgo && <p className="text-xs text-muted-foreground mb-2">Hora de mayor riesgo: <span className="font-semibold text-red-600">{horaRiesgo[0]}:00 ({horaRiesgo[1]} excesos)</span></p>}
                    {chartHora.some(h => h.excesos > 0) ? (
                      <ResponsiveContainer width="100%" height={160}>
                        <BarChart data={chartHora}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                          <XAxis dataKey="hora" tick={{ fontSize: 8 }} interval={3} />
                          <YAxis tick={{ fontSize: 10 }} />
                          <Tooltip contentStyle={{ fontSize: 12 }} />
                          <Bar dataKey="excesos" fill="#f59e0b" radius={[3,3,0,0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    ) : <p className="text-center text-muted-foreground text-xs py-10">Sin datos</p>}
                  </div>
                </div>

                {/* Top placas */}
                {chartPlacas.length > 1 && (
                  <div className="border rounded-xl p-4 bg-card">
                    <h4 className="text-sm font-semibold mb-3">Top placas con más excesos</h4>
                    <ResponsiveContainer width="100%" height={160}>
                      <BarChart data={chartPlacas} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                        <XAxis type="number" tick={{ fontSize: 10 }} />
                        <YAxis dataKey="placa" type="category" tick={{ fontSize: 11 }} width={60} />
                        <Tooltip contentStyle={{ fontSize: 12 }} formatter={(v) => [v, 'Excesos']} />
                        <Bar dataKey="cantidad" fill="hsl(250 80% 60%)" radius={[0,4,4,0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}

                {/* Recomendación automática */}
                <div className="border rounded-xl p-4 bg-amber-50 border-amber-200">
                  <h4 className="text-sm font-semibold text-amber-800 mb-2 flex items-center gap-1.5"><AlertTriangle className="w-4 h-4" /> Resumen para toma de decisiones</h4>
                  <ul className="text-xs text-amber-900 space-y-1 list-disc list-inside">
                    <li>Se registraron <strong>{total}</strong> excesos en el período analizado.</li>
                    {alta > 0 && <li><strong>{alta} excesos de alta severidad</strong> (&gt;100 km/h) — se recomienda revisión disciplinaria inmediata.</li>}
                    {velMax > 0 && <li>Velocidad máxima registrada: <strong>{velMax} km/h</strong> — vel. promedio: <strong>{velProm} km/h</strong>.</li>}
                    {horaRiesgo && <li>Franja horaria de mayor riesgo: <strong>{horaRiesgo[0]}:00 h</strong> con {horaRiesgo[1]} eventos — considerar reforzar controles en ese horario.</li>}
                    {chartPlacas.length > 0 && <li>Placa con más excesos: <strong>{chartPlacas[0].placa}</strong> ({chartPlacas[0].cantidad} eventos).</li>}
                    <li>Nivel de riesgo general del período: <strong>{nivelRiesgo.label}</strong>.</li>
                  </ul>
                </div>

                {/* Tabla de eventos */}
                <div>
                  <h4 className="text-sm font-semibold text-foreground mb-2">Detalle de eventos ({total})</h4>
                  {total === 0 ? (
                    <p className="text-center text-muted-foreground py-4 text-sm">Sin eventos para los filtros seleccionados</p>
                  ) : (
                    <div className="overflow-x-auto border rounded-lg">
                      <table className="w-full text-xs" style={{ borderCollapse: 'collapse' }}>
                        <thead>
                          <tr className="bg-gray-100">
                            <th className="border px-3 py-2 text-left font-semibold">#</th>
                            <th className="border px-3 py-2 text-left font-semibold">Placa</th>
                            <th className="border px-3 py-2 text-left font-semibold">Velocidad</th>
                            <th className="border px-3 py-2 text-left font-semibold">Fecha / Hora</th>
                            <th className="border px-3 py-2 text-left font-semibold">Ruta</th>
                          </tr>
                        </thead>
                        <tbody>
                          {previewReporte.eventos.map((e, i) => (
                            <tr key={e.id} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                              <td className="border px-3 py-1.5 text-muted-foreground">{i + 1}</td>
                              <td className="border px-3 py-1.5 font-mono">{e.placa?.trim() || '—'}</td>
                              <td className={`border px-3 py-1.5 font-semibold ${e.velocidad > 100 ? 'text-red-600' : e.velocidad > 80 ? 'text-yellow-600' : 'text-blue-600'}`}>{e.velocidad} km/h</td>
                              <td className="border px-3 py-1.5 text-muted-foreground whitespace-nowrap">
                                {new Date(e.created_at).toLocaleString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                              </td>
                              <td className="border px-3 py-1.5 text-muted-foreground">{e.ruta || '—'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      {/* Modal vista previa conductor */}
      <Dialog open={!!previewConductor} onOpenChange={(open) => !open && setPreviewConductor(null)}>
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              Vista previa — {previewConductor?.nombre}
            </DialogTitle>
          </DialogHeader>

          {previewConductor && (
            <div className="space-y-4">
              {/* Datos del conductor */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-sm bg-muted/40 rounded-lg p-4">
                <div><span className="text-muted-foreground text-xs block">Cédula</span><span className="font-mono font-medium">{previewConductor.cedula || '—'}</span></div>
                <div><span className="text-muted-foreground text-xs block">Placa</span><span className="font-mono font-medium">{previewConductor.vehiculo?.trim() || '—'}</span></div>
                <div><span className="text-muted-foreground text-xs block">Estado</span><span className="capitalize font-medium">{previewConductor.estado || '—'}</span></div>
                <div><span className="text-muted-foreground text-xs block">Total Excesos</span>
                  <span className={`font-bold ${previewConductor.excesosCount >= 10 ? 'text-red-600' : previewConductor.excesosCount >= 5 ? 'text-yellow-600' : 'text-blue-600'}`}>
                    {previewConductor.excesosCount}
                  </span>
                </div>
                <div><span className="text-muted-foreground text-xs block">Vel. Promedio</span><span className="font-medium">{previewConductor.excesosCount > 0 ? `${previewConductor.velProm} km/h` : '—'}</span></div>
              </div>

              {/* Tabla de excesos */}
              <div>
                <h4 className="text-sm font-semibold text-foreground mb-2">Historial de excesos de velocidad</h4>
                {previewConductor.excesos.length === 0 ? (
                  <p className="text-center text-muted-foreground py-4 text-sm">Sin excesos registrados</p>
                ) : (
                  <div className="overflow-x-auto border rounded-lg">
                    <table className="w-full text-xs" style={{ borderCollapse: 'collapse' }}>
                      <thead>
                        <tr className="bg-gray-100">
                          <th className="border px-3 py-2 text-left font-semibold">#</th>
                          <th className="border px-3 py-2 text-left font-semibold">Velocidad</th>
                          <th className="border px-3 py-2 text-left font-semibold">Fecha / Hora</th>
                          <th className="border px-3 py-2 text-left font-semibold">Ruta</th>
                        </tr>
                      </thead>
                      <tbody>
                        {previewConductor.excesos.map((e, i) => (
                          <tr key={e.id} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                            <td className="border px-3 py-1.5 text-muted-foreground">{i + 1}</td>
                            <td className="border px-3 py-1.5 font-semibold text-red-600">{e.velocidad} km/h</td>
                            <td className="border px-3 py-1.5 text-muted-foreground whitespace-nowrap">
                              {new Date(e.created_at).toLocaleString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                            </td>
                            <td className="border px-3 py-1.5 text-muted-foreground">{e.ruta || '—'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Diálogo confirmación eliminar conductor */}
      <Dialog open={!!conductorAEliminar} onOpenChange={(open) => !open && setConductorAEliminar(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <Trash2 className="w-5 h-5" />
              Eliminar conductor
            </DialogTitle>
            <DialogDescription>
              Confirma la eliminación del conductor seleccionado.
            </DialogDescription>
          </DialogHeader>
          <p className="text-sm text-muted-foreground mt-2">
            ¿Estás seguro de que deseas eliminar a{' '}
            <span className="font-semibold text-foreground">{conductorAEliminar?.nombre}</span>?
            Esta acción no se puede deshacer.
          </p>
          <div className="flex justify-end gap-2 mt-4">
            <Button variant="outline" onClick={() => setConductorAEliminar(null)}>
              Cancelar
            </Button>
            <Button
              className="bg-red-600 hover:bg-red-700 text-white"
              onClick={() => conductorAEliminar && eliminarConductor(conductorAEliminar.id)}
            >
              Eliminar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Reportes;
