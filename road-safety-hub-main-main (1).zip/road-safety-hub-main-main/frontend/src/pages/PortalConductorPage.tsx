import { useState, useEffect } from 'react';
import api from '@/services/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import NoticiaCard from '@/components/NoticiaCard';
import { Progress } from '@/components/ui/progress';
import {
  AlertTriangle, BookOpen, MessageSquare, Star,
  CheckCircle2, Clock, PlayCircle, FileText, Video, Users, Calendar, Download, Loader2,
  Newspaper, ChevronRight, User, TrendingUp, ShieldCheck, Bell,
  ThumbsUp, ThumbsDown, MessageCircle, Award, CheckSquare, Square, Globe, Lock, ChevronDown, ChevronUp, Send, X
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { CapacitacionPlayer, type AsignacionPlayer } from '@/components/CapacitacionPlayer';
import { CapacitacionPlayerModulos, type AsignacionPlayerModulos } from '@/components/CapacitacionPlayerModulos';
import { useAppStore } from '@/stores/appStore';
import { useAuthStore } from '@/stores/authStore';
import { loadBrandingBackend } from '@/services/brandingService';
import { generarCertificado } from '@/services/certificateService';

// ── Tipos ─────────────────────────────────────────────────────────────────
interface Resumen {
  score: number;
  eventos_mes: number;
  mensajes: number;
  capacitaciones: { pendientes: number; completadas: number; total: number };
}

interface Perfil {
  id: string;
  nombre: string;
  cedula: string;
  licencia: string;
  telefono: string;
  vehiculo: string;
  score: number;
  estado: string;
}

interface Evento {
  id: string | number;
  placa?: string;
  velocidad?: number;
  ruta?: string;
  fecha?: string;
  created_at: string;
}

interface Mensaje {
  id: string;
  titulo: string;
  contenido: string;
  tipo: string;
  prioridad: string;
  created_at: string;
}

interface Noticia {
  id: string;
  titulo: string;
  contenido: string;
  imagen_url: string | null;
  video_youtube: string | null;
  publicado: boolean;
  permite_certificar: boolean;
  autor: string;
  created_at: string;
  updated_at: string | null;
  me_gusta_count: number;
  no_me_gusta_count: number;
  comentarios_count: number;
  certificaciones_count: number;
}

interface Comentario {
  id: string;
  noticia_id: string;
  user_id: string;
  autor: string;
  contenido: string;
  created_at: string;
}

function getYoutubeId(url: string): string | null {
  if (!url) return null;
  const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
  return url.match(regex)?.[1] ?? null;
}

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Ahora mismo';
  if (mins < 60) return `hace ${mins} min`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `hace ${hrs} h`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `hace ${days} día${days > 1 ? 's' : ''}`;
  return new Date(dateStr).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' });
}

interface Asignacion {
  id: string;
  estado: 'pendiente' | 'en_progreso' | 'completado';
  etapa?: string;
  progreso_video?: number;
  quiz_puntaje?: number;
  quiz_completado?: boolean;
  fecha_asignacion: string;
  fecha_completado?: string;
  capacitacion: {
    id?: string;
    titulo: string;
    descripcion?: string;
    contenido_url?: string;
    tipo: string;
    duracion_minutos: number;
    modulos?: { id: string }[];
  };
}

// ── Score visual ───────────────────────────────────────────────────────────
const ScoreCircle = ({ score }: { score: number }) => {
  const color = score >= 80 ? 'text-green-500' : score >= 60 ? 'text-yellow-500' : 'text-red-500';
  const bg = score >= 80 ? 'stroke-green-500' : score >= 60 ? 'stroke-yellow-500' : 'stroke-red-500';
  const dash = (score / 100) * 283;
  return (
    <div className="relative w-32 h-32 mx-auto">
      <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="8" className="text-muted/20" />
        <circle cx="50" cy="50" r="45" fill="none" strokeWidth="8" strokeLinecap="round"
          strokeDasharray={`${dash} ${283 - dash}`} className={bg} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className={cn('text-3xl font-bold', color)}>{score}</span>
        <span className="text-xs text-muted-foreground">/ 100</span>
      </div>
    </div>
  );
};

// ── Íconos por tipo de capacitación ───────────────────────────────────────
const TipoIcon = ({ tipo }: { tipo: string }) => {
  const icons: Record<string, React.ReactNode> = {
    video: <Video className="w-4 h-4" />,
    documento: <FileText className="w-4 h-4" />,
    quiz: <Star className="w-4 h-4" />,
    presencial: <Users className="w-4 h-4" />,
  };
  return <>{icons[tipo] || <FileText className="w-4 h-4" />}</>;
};

const estadoBadge = (estado: string) => {
  const map: Record<string, { label: string; variant: 'default' | 'secondary' | 'outline' }> = {
    pendiente: { label: 'Pendiente', variant: 'outline' },
    en_progreso: { label: 'En progreso', variant: 'secondary' },
    completado: { label: 'Completado', variant: 'default' },
  };
  return map[estado] || { label: estado, variant: 'outline' };
};

// ── Componente principal ──────────────────────────────────────────────────
const PortalConductorPage = () => {
  const {
    certificateConfig,
    companyName,
    companyLogo,
    certCounter,
    incrementCertCounter,
    setCompanyName,
    setCompanyLogo,
    sidebarOpen,
    toggleSidebar,
  } = useAppStore();
  const { user } = useAuthStore();
  const userId = user?.id ?? '';
  const [resumen, setResumen] = useState<Resumen | null>(null);
  const [perfil, setPerfil] = useState<Perfil | null>(null);
  const [eventos, setEventos] = useState<Evento[]>([]);
  const [mensajes, setMensajes] = useState<Mensaje[]>([]);
  const [noticias, setNoticias] = useState<Noticia[]>([]);
  const [misReacciones, setMisReacciones] = useState<Record<string, 'me_gusta' | 'no_me_gusta'>>({});
  const [misCertificaciones, setMisCertificaciones] = useState<Set<string>>(new Set());
  const [comentariosPor, setComentariosPor] = useState<Record<string, Comentario[]>>({});
  const [comentariosAbiertos, setComentariosAbiertos] = useState<Set<string>>(new Set());
  const [capacitaciones, setCapacitaciones] = useState<Asignacion[]>([]);
  const [loading, setLoading] = useState(true);
  const [noticiasLoading, setNoticiasLoading] = useState(true);
  const [playerAsig, setPlayerAsig] = useState<Asignacion | null>(null);
  const [playerOpen, setPlayerOpen] = useState(false);
  const [playerModulosAsig, setPlayerModulosAsig] = useState<AsignacionPlayerModulos | null>(null);
  const [playerModulosOpen, setPlayerModulosOpen] = useState(false);
  const [generandoCert, setGenerandoCert] = useState<string | null>(null);
  const [reaccionando, setReaccionando] = useState<string | null>(null);
  const [certificando, setCertificando] = useState<string | null>(null);
  const [seccion, setSeccion] = useState<'noticias' | 'capacitaciones' | 'eventos' | 'mensajes' | 'perfil'>('noticias');

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [resRes, perfilRes, evRes, msRes, capRes] = await Promise.all([
          api.get('/portal/conductor/resumen'),
          api.get('/portal/conductor/perfil'),
          api.get('/portal/conductor/eventos'),
          api.get('/portal/conductor/mensajes'),
          api.get('/portal/conductor/capacitaciones'),
        ]);
        setResumen(resRes.data);
        setPerfil(perfilRes.data);
        setEventos(Array.isArray(evRes.data) ? evRes.data : []);
        setMensajes(Array.isArray(msRes.data) ? msRes.data : []);
        setCapacitaciones(Array.isArray(capRes.data) ? capRes.data : []);
      } catch {
        toast.error('Error al cargar el portal');
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  useEffect(() => {
    loadBrandingBackend().then((saved) => {
      if (!saved) return;
      if (saved.company_name) setCompanyName(saved.company_name);
      if (saved.company_logo) setCompanyLogo(saved.company_logo);
    });
  }, [setCompanyLogo, setCompanyName]);

  useEffect(() => {
    const fetchNoticias = async () => {
      setNoticiasLoading(true);
      try {
        const [noticiasRes, interRes] = await Promise.all([
          api.get('/noticias'),
          api.get('/noticias/mis-interacciones'),
        ]);
        const incomingNoticias = Array.isArray(noticiasRes.data) ? noticiasRes.data : [];
        setNoticias(incomingNoticias);
        const publishedIds = incomingNoticias.filter((n) => n.publicado).map((n) => n.id);
        await Promise.allSettled(publishedIds.map((id) => api.post(`/noticias/${id}/visto`)));
        const reacMap: Record<string, 'me_gusta' | 'no_me_gusta'> = {};
        (interRes.data.reacciones ?? []).forEach((r: { noticia_id: string; tipo: 'me_gusta' | 'no_me_gusta' }) => {
          reacMap[r.noticia_id] = r.tipo;
        });
        setMisReacciones(reacMap);
        setMisCertificaciones(new Set(interRes.data.certificaciones ?? []));
      } catch {
        toast.error('Error al cargar las noticias');
      } finally {
        setNoticiasLoading(false);
      }
    };

    fetchNoticias();
  }, []);

  const handleToggleComentarios = async (noticiaId: string) => {
    const isOpen = comentariosAbiertos.has(noticiaId);
    setComentariosAbiertos((prev) => {
      const next = new Set(prev);
      if (isOpen) next.delete(noticiaId); else next.add(noticiaId);
      return next;
    });

    if (!isOpen && !comentariosPor[noticiaId]) {
      try {
        const { data } = await api.get(`/noticias/${noticiaId}/comentarios`);
        setComentariosPor((prev) => ({ ...prev, [noticiaId]: data }));
      } catch {
        toast.error('Error al cargar los comentarios');
      }
    }
  };

  const handleEnviarComentario = async (noticiaId: string, texto: string, onSuccess?: () => void) => {
    if (!texto.trim()) return;
    try {
      const { data } = await api.post(`/noticias/${noticiaId}/comentarios`, { contenido: texto.trim() });
      setComentariosPor((prev) => ({ ...prev, [noticiaId]: [...(prev[noticiaId] ?? []), data] }));
      setNoticias((prev) => prev.map((n) => n.id === noticiaId ? { ...n, comentarios_count: n.comentarios_count + 1 } : n));
      onSuccess?.();
    } catch (error) {
      throw error;
    }
  };

  const handleEliminarComentario = (noticiaId: string, cid: string) => {
    setComentariosPor((prev) => ({ ...prev, [noticiaId]: (prev[noticiaId] ?? []).filter((c) => c.id !== cid) }));
    setNoticias((prev) => prev.map((n) => n.id === noticiaId ? { ...n, comentarios_count: Math.max(0, n.comentarios_count - 1) } : n));
  };

  const handleReaccionar = async (noticiaId: string, tipo: 'me_gusta' | 'no_me_gusta') => {
    if (reaccionando) return;
    setReaccionando(noticiaId);
    const prev = misReacciones[noticiaId] ?? null;
    try {
      const { data } = await api.post(`/noticias/${noticiaId}/reaccionar`, { tipo });
      setMisReacciones((m) => {
        const next = { ...m };
        if (data.accion === 'removido') delete next[noticiaId];
        else next[noticiaId] = data.tipo;
        return next;
      });
      setNoticias((ns) => ns.map((n) => {
        if (n.id !== noticiaId) return n;
        const delta = (field: 'me_gusta_count' | 'no_me_gusta_count', t: 'me_gusta' | 'no_me_gusta') => {
          if (data.accion === 'removido' && prev === t) return n[field] - 1;
          if (data.accion === 'creado' && tipo === t) return n[field] + 1;
          if (data.accion === 'cambiado') {
            if (tipo === t) return n[field] + 1;
            if (prev === t) return n[field] - 1;
          }
          return n[field];
        };
        return { ...n, me_gusta_count: delta('me_gusta_count', 'me_gusta'), no_me_gusta_count: delta('no_me_gusta_count', 'no_me_gusta') };
      }));
    } catch {
      toast.error('Error al registrar la reacción');
    } finally {
      setReaccionando(null);
    }
  };

  const handleCertificar = async (noticiaId: string) => {
    if (certificando) return;
    setCertificando(noticiaId);
    try {
      const { data } = await api.post(`/noticias/${noticiaId}/certificar`);
      setMisCertificaciones((prev) => {
        const next = new Set(prev);
        if (data.accion === 'removido') next.delete(noticiaId); else next.add(noticiaId);
        return next;
      });
      setNoticias((ns) => ns.map((n) => {
        if (n.id !== noticiaId) return n;
        const delta = data.accion === 'certificado' ? 1 : -1;
        return { ...n, certificaciones_count: Math.max(0, n.certificaciones_count + delta) };
      }));
      toast.success(data.accion === 'certificado' ? '¡Video certificado!' : 'Certificación removida');
    } catch {
      toast.error('Error al certificar');
    } finally {
      setCertificando(null);
    }
  };

  const actualizarEstado = async (asignacionId: string, estado: 'en_progreso' | 'completado') => {
    try {
      await api.put(`/portal/conductor/capacitaciones/${asignacionId}/estado`, { estado });
      setCapacitaciones((prev) =>
        prev.map((c) => c.id === asignacionId
          ? { ...c, estado, fecha_completado: estado === 'completado' ? new Date().toISOString() : c.fecha_completado }
          : c
        )
      );
      if (resumen) {
        setResumen({
          ...resumen,
          capacitaciones: {
            ...resumen.capacitaciones,
            pendientes: estado === 'en_progreso' ? resumen.capacitaciones.pendientes - 1 : resumen.capacitaciones.pendientes,
            completadas: estado === 'completado' ? resumen.capacitaciones.completadas + 1 : resumen.capacitaciones.completadas,
          }
        });
      }
      toast.success(estado === 'completado' ? '¡Capacitación completada!' : 'Capacitación iniciada');
    } catch {
      toast.error('No se pudo actualizar el estado');
    }
  };

  const handleDescargarCertificado = async (asig: Asignacion) => {
    if (!perfil) return;
    setGenerandoCert(asig.id);
    try {
      const nombreParts = perfil.nombre.trim().split(' ');
      const nombre = nombreParts[0] ?? '';
      const apellido = nombreParts.slice(1).join(' ') || '';
      const fecha = asig.fecha_completado
        ? new Date(asig.fecha_completado).toLocaleDateString('es-CO', { day: '2-digit', month: 'long', year: 'numeric' })
        : new Date().toLocaleDateString('es-CO', { day: '2-digit', month: 'long', year: 'numeric' });
      const calificacion = asig.quiz_puntaje != null ? `${asig.quiz_puntaje} / 100` : 'Aprobado';

      await generarCertificado(
        {
          nombre,
          apellido,
          documento: perfil.cedula ?? '',
          fecha,
          calificacion,
          tituloCurso: asig.capacitacion?.titulo ?? '',
          numeroCertificado: String(certCounter),
        },
        certificateConfig,
        companyName,
        companyLogo,
      );
      incrementCertCounter();
      toast.success('Certificado descargado correctamente');
    } catch (err) {
      console.error(err);
      toast.error('Error al generar el certificado');
    } finally {
      setGenerandoCert(null);
    }
  };

  const handlePlayerComplete = (asignacionId: string, puntaje?: number) => {
    setCapacitaciones((prev) =>
      prev.map((c) =>
        c.id === asignacionId
          ? {
              ...c,
              estado: 'completado',
              etapa: 'completado',
              fecha_completado: new Date().toISOString(),
              quiz_completado: puntaje != null ? true : c.quiz_completado,
              quiz_puntaje: puntaje ?? c.quiz_puntaje,
            }
          : c
      )
    );
    if (resumen) {
      setResumen({
        ...resumen,
        capacitaciones: {
          ...resumen.capacitaciones,
          pendientes: Math.max(0, resumen.capacitaciones.pendientes - 1),
          completadas: resumen.capacitaciones.completadas + 1,
        },
      });
    }
  };

  const publishedNoticias = noticias.filter((n) => n.publicado);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // ── Items del menú lateral ────────────────────────────────────────────
  const navItems = [
    { id: 'noticias',       label: 'Noticias',        icon: <Newspaper className="w-5 h-5" /> },
    { id: 'capacitaciones', label: 'Capacitaciones',  icon: <BookOpen className="w-5 h-5" />,
      badge: resumen?.capacitaciones.pendientes ?? 0 },
    { id: 'eventos',        label: 'Mis Eventos',     icon: <AlertTriangle className="w-5 h-5" /> },
    { id: 'mensajes',       label: 'Mensajes',        icon: <MessageSquare className="w-5 h-5" />,
      badge: resumen?.mensajes ?? 0 },
    { id: 'perfil',         label: 'Mi Perfil',       icon: <User className="w-5 h-5" /> },
  ] as const;

  return (
    <div className="flex flex-col lg:flex-row gap-0 min-h-full pb-6 animate-fade-in">
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-black/40 lg:hidden" onClick={toggleSidebar} />
      )}

      {/* ── Sidebar izquierdo ────────────────────────────────────────── */}
      <aside className={cn(
        'fixed inset-y-0 left-0 z-40 w-72 transform overflow-y-auto border-r border-border bg-card p-4 shadow-xl transition-transform duration-300 lg:static lg:w-56 lg:translate-x-0 lg:shadow-none lg:border-r lg:p-4',
        sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      )}>
        {/* Avatar / nombre */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <User className="w-5 h-5 text-primary" />
            </div>
            <div className="min-w-0">
              <p className="font-semibold text-sm text-foreground truncate">{perfil?.nombre || 'Conductor'}</p>
              <p className="text-xs text-muted-foreground truncate">{perfil?.vehiculo || '—'}</p>
            </div>
          </div>
          {/* Mini score */}
          <div className="mt-3 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-green-500 flex-shrink-0" />
            <div className="flex-1">
              <Progress value={resumen?.score ?? 100} className="h-1.5" />
            </div>
            <span className="text-xs font-bold text-foreground">{resumen?.score ?? 100}</span>
          </div>

          {/* Branding empresa */}
          <div className="mt-4 rounded-2xl bg-muted/70 p-3">
            <div className="flex items-center gap-3">
              {companyLogo ? (
                <img
                  src={companyLogo}
                  alt={`${companyName || 'Empresa'} logo`}
                  className="w-12 h-12 rounded-lg object-cover border border-border"
                />
              ) : (
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center border border-border">
                  <ShieldCheck className="w-5 h-5 text-primary" />
                </div>
              )}
              <div className="min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{companyName || 'Mi Empresa'}</p>
                <p className="text-xs text-muted-foreground">Portal del conductor</p>
              </div>
            </div>
          </div>
        </div>

        {/* Nav items */}
        <nav className="p-2 space-y-0.5">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setSeccion(item.id);
                if (sidebarOpen) toggleSidebar();
              }}
              className={cn(
                'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-left',
                seccion === item.id
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              )}
            >
              {item.icon}
              <span className="flex-1">{item.label}</span>
              {'badge' in item && (item.badge as number) > 0 && (
                <span className={cn(
                  'text-[10px] font-bold rounded-full px-1.5 py-0.5 min-w-[18px] text-center',
                  seccion === item.id ? 'bg-white/20 text-white' : 'bg-primary text-primary-foreground'
                )}>
                  {item.badge as number}
                </span>
              )}
            </button>
          ))}
        </nav>
      </aside>

      {/* ── Contenido principal ──────────────────────────────────────── */}
      <main className="flex-1 p-4 sm:p-6 space-y-6 min-w-0">

        {/* ══ NOTICIAS ════════════════════════════════════════════════ */}
        {seccion === 'noticias' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-foreground">Bienvenido, {perfil?.nombre?.split(' ')[0] || 'Conductor'} 👋</h2>
              <p className="text-muted-foreground text-sm">Aquí puedes ver las noticias de tu empresa y participar en ellas.</p>
            </div>

            {/* KPIs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
              <Card className="border-l-4 border-l-green-500">
                <CardContent className="pt-4 pb-4 flex items-center gap-3">
                  <TrendingUp className="w-8 h-8 text-green-500 flex-shrink-0" />
                  <div>
                    <p className="text-2xl font-bold text-foreground">{resumen?.score ?? 100}</p>
                    <p className="text-xs text-muted-foreground">Score de seguridad</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-l-4 border-l-orange-500">
                <CardContent className="pt-4 pb-4 flex items-center gap-3">
                  <AlertTriangle className="w-8 h-8 text-orange-500 flex-shrink-0" />
                  <div>
                    <p className="text-2xl font-bold text-foreground">{resumen?.eventos_mes ?? 0}</p>
                    <p className="text-xs text-muted-foreground">Eventos este mes</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-l-4 border-l-blue-500">
                <CardContent className="pt-4 pb-4 flex items-center gap-3">
                  <MessageSquare className="w-8 h-8 text-blue-500 flex-shrink-0" />
                  <div>
                    <p className="text-2xl font-bold text-foreground">{resumen?.mensajes ?? 0}</p>
                    <p className="text-xs text-muted-foreground">Mensajes</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-l-4 border-l-purple-500">
                <CardContent className="pt-4 pb-4 flex items-center gap-3">
                  <BookOpen className="w-8 h-8 text-purple-500 flex-shrink-0" />
                  <div>
                    <p className="text-2xl font-bold text-foreground">{resumen?.capacitaciones.pendientes ?? 0}</p>
                    <p className="text-xs text-muted-foreground">Capacitaciones pendientes</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Progreso capacitaciones */}
            {resumen && resumen.capacitaciones.total > 0 && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-purple-500" />
                    Progreso de capacitaciones
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">
                      {resumen.capacitaciones.completadas} de {resumen.capacitaciones.total} completadas
                    </span>
                    <span className="font-semibold">
                      {Math.round((resumen.capacitaciones.completadas / resumen.capacitaciones.total) * 100)}%
                    </span>
                  </div>
                  <Progress value={(resumen.capacitaciones.completadas / resumen.capacitaciones.total) * 100} className="h-2" />
                </CardContent>
              </Card>
            )}

            {/* Feed de noticias */}
            <div className="space-y-4 max-w-2xl mx-auto w-full">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h3 className="text-lg font-semibold text-foreground">Noticias</h3>
                  <p className="text-sm text-muted-foreground">Participa con comentarios, me gusta y certificaciones cuando haya video.</p>
                </div>
                <span className="text-xs text-muted-foreground">{publishedNoticias.length} noticia{publishedNoticias.length !== 1 ? 's' : ''}</span>
              </div>

              {noticiasLoading ? (
                <div className="flex justify-center py-16">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : publishedNoticias.length === 0 ? (
                <Card>
                  <CardContent className="py-16 text-center text-muted-foreground">
                    <Bell className="w-10 h-10 mx-auto mb-3 opacity-40" />
                    No hay noticias publicadas por el momento.
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {publishedNoticias.map((noticia) => {
                    const comentarios = comentariosPor[noticia.id] ?? [];
                    const estaAbierta = comentariosAbiertos.has(noticia.id);
                    const miReaccion = misReacciones[noticia.id] ?? null;
                    const certificado = misCertificaciones.has(noticia.id);

                    return (
                      <NoticiaCard
                        key={noticia.id}
                        noticia={noticia}
                        isAdmin={false}
                        userId={userId}
                        miReaccion={miReaccion}
                        certificado={certificado}
                        comentariosAbiertos={estaAbierta}
                        comentarios={comentarios}
                        onReaccionar={handleReaccionar}
                        onToggleComentarios={handleToggleComentarios}
                        onEnviarComentario={(id, texto) => handleEnviarComentario(id, texto)}
                        onEliminarComentario={handleEliminarComentario}
                        onCertificar={handleCertificar}
                        reaccionando={reaccionando === noticia.id}
                        certificando={certificando === noticia.id}
                      />
                    );
                  })}
                </div>
              )}
            </div>

            {/* Últimas noticias / mensajes recientes */}
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Bell className="w-4 h-4 text-blue-500" />
                    Últimos mensajes
                  </CardTitle>
                  {mensajes.length > 3 && (
                    <button
                      onClick={() => setSeccion('mensajes')}
                      className="text-xs text-primary flex items-center gap-1 hover:underline"
                    >
                      Ver todos <ChevronRight className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {mensajes.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">No hay mensajes recientes.</p>
                ) : (
                  mensajes.slice(0, 3).map((msg) => {
                    const prioColors: Record<string, string> = {
                      alta: 'border-l-red-500',
                      normal: 'border-l-blue-500',
                      baja: 'border-l-gray-400',
                    };
                    return (
                      <div key={msg.id} className={cn('border-l-4 pl-3 py-1 rounded-r', prioColors[msg.prioridad] || 'border-l-border')}>
                        <div className="flex items-center justify-between gap-2">
                          <p className="font-medium text-sm text-foreground">{msg.titulo}</p>
                          {msg.prioridad === 'alta' && <Badge variant="destructive" className="text-[10px] h-4 px-1.5">Urgente</Badge>}
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{msg.contenido}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(msg.created_at).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' })}
                        </p>
                      </div>
                    );
                  })
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* ══ CAPACITACIONES ═════════════════════════════════════════ */}
        {seccion === 'capacitaciones' && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-foreground">Capacitaciones</h2>
            {capacitaciones.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <BookOpen className="w-10 h-10 mx-auto mb-3 opacity-40" />
                  No tienes capacitaciones asignadas por el momento.
                </CardContent>
              </Card>
            ) : (
              capacitaciones.map((asig) => {
                const badge = estadoBadge(asig.estado);
                return (
                  <Card key={asig.id} className={cn(asig.estado === 'completado' && 'opacity-75')}>
                    <CardContent className="pt-4 pb-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center gap-2">
                            <TipoIcon tipo={asig.capacitacion?.tipo} />
                            <span className="font-semibold text-foreground">{asig.capacitacion?.titulo}</span>
                          </div>
                          {asig.capacitacion?.descripcion && (
                            <p className="text-sm text-muted-foreground">{asig.capacitacion.descripcion}</p>
                          )}
                          {((asig.capacitacion?.modulos?.length ?? 0) > 0 || (!asig.capacitacion?.contenido_url && asig.capacitacion.tipo === 'video')) && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {asig.capacitacion?.modulos?.length
                                ? `${asig.capacitacion.modulos.length} módulo${asig.capacitacion.modulos.length !== 1 ? 's' : ''}`
                                : 'Capacitación por módulos'}
                            </p>
                          )}
                          <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mt-2">
                            {asig.capacitacion?.duracion_minutos > 0 && (
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />{asig.capacitacion.duracion_minutos} min
                              </span>
                            )}
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              Asignado: {new Date(asig.fecha_asignacion).toLocaleDateString('es-CO')}
                            </span>
                            {asig.fecha_completado && (
                              <span className="flex items-center gap-1 text-green-600">
                                <CheckCircle2 className="w-3 h-3" />
                                Completado: {new Date(asig.fecha_completado).toLocaleDateString('es-CO')}
                              </span>
                            )}
                          </div>
                          {(asig.progreso_video ?? 0) > 0 && asig.estado !== 'completado' && (
                            <div className="flex items-center gap-2 mt-1">
                              <Progress value={asig.progreso_video} className="h-1.5 flex-1 max-w-32" />
                              <span className="text-xs text-muted-foreground">{asig.progreso_video}% visto</span>
                            </div>
                          )}
                          {asig.quiz_completado && asig.quiz_puntaje != null && (
                            <div className="flex items-center gap-1 text-xs mt-1">
                              <Star className="w-3 h-3 text-yellow-500" />
                              <span className="text-muted-foreground">Quiz: <strong>{asig.quiz_puntaje}%</strong></span>
                              <Badge variant={asig.quiz_puntaje >= 70 ? 'default' : 'destructive'} className="text-[10px] h-4 px-1.5 ml-1">
                                {asig.quiz_puntaje >= 70 ? 'Aprobado' : 'No aprobado'}
                              </Badge>
                            </div>
                          )}
                        </div>
                        <div className="flex flex-col items-end gap-2 flex-shrink-0">
                          <Badge variant={badge.variant}>{badge.label}</Badge>
                          <Button
                            size="sm"
                            variant={asig.estado === 'completado' ? 'outline' : 'default'}
                            className="gap-1 text-xs"
                            onClick={() => {
                              const hasModulos = Array.isArray(asig.capacitacion?.modulos) && asig.capacitacion.modulos.length > 0;
                              const likelyModulo = !hasModulos && !asig.capacitacion?.contenido_url && asig.capacitacion.tipo === 'video';
                              if (hasModulos || likelyModulo) {
                                setPlayerModulosAsig(asig as unknown as AsignacionPlayerModulos);
                                setPlayerModulosOpen(true);
                              } else {
                                setPlayerAsig(asig);
                                setPlayerOpen(true);
                              }
                            }}
                          >
                            <PlayCircle className="w-3.5 h-3.5" />
                            {(() => {
                              const hasModulos = Array.isArray(asig.capacitacion?.modulos) && asig.capacitacion.modulos.length > 0;
                              const likelyModulo = !hasModulos && !asig.capacitacion?.contenido_url && asig.capacitacion.tipo === 'video';
                              const isModuloTraining = hasModulos || likelyModulo;
                              if (asig.estado === 'completado') return 'Ver';
                              if (isModuloTraining) return asig.estado === 'en_progreso' ? 'Continuar módulo' : 'Iniciar módulo';
                              return asig.estado === 'en_progreso' ? 'Continuar' : 'Iniciar';
                            })()}
                          </Button>
                          {asig.estado === 'completado' && (
                            <Button
                              size="sm" variant="secondary"
                              className="gap-1 text-xs w-full"
                              disabled={generandoCert === asig.id}
                              onClick={() => handleDescargarCertificado(asig)}
                            >
                              {generandoCert === asig.id
                                ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                : <Download className="w-3.5 h-3.5" />}
                              Certificado
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>
        )}

        {/* ══ EVENTOS ════════════════════════════════════════════════ */}
        {seccion === 'eventos' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-foreground">Mis Eventos</h2>
                <p className="text-sm text-muted-foreground">
                  Vehículo asignado: <span className="font-semibold text-foreground">{perfil?.vehiculo || '—'}</span>
                </p>
              </div>
              {eventos.length > 0 && (
                <div className="text-right">
                  <p className="text-2xl font-bold text-orange-500">{eventos.length}</p>
                  <p className="text-xs text-muted-foreground">excesos registrados</p>
                </div>
              )}
            </div>

            {eventos.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <AlertTriangle className="w-10 h-10 mx-auto mb-3 opacity-40" />
                  No se encontraron eventos de velocidad para tu vehículo.
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="p-0 overflow-x-auto">
                  {/* Header de tabla */}
                  <div className="min-w-[560px] grid grid-cols-[auto_1fr_auto_auto] gap-x-4 px-4 py-2 bg-muted/50 rounded-t-lg border-b border-border text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    <span>Placa</span>
                    <span>Ruta</span>
                    <span className="text-center">Velocidad</span>
                    <span className="text-right">Fecha y Hora</span>
                  </div>
                  <div className="divide-y divide-border">
                    {eventos.slice(0, 100).map((ev, idx) => {
                      const vel = ev.velocidad ?? 0;
                      const severity = vel > 100 ? 'red' : vel > 80 ? 'orange' : 'yellow';
                      const dotColor = severity === 'red' ? 'bg-red-500' : severity === 'orange' ? 'bg-orange-500' : 'bg-yellow-500';
                      const velColor = severity === 'red' ? 'text-red-500' : severity === 'orange' ? 'text-orange-500' : 'text-yellow-600';
                      const fecha = ev.fecha
                        ? new Date(ev.fecha).toLocaleString('es-CO', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })
                        : new Date(ev.created_at).toLocaleString('es-CO', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
                      return (
                        <div key={ev.id ?? idx} className="grid grid-cols-[auto_1fr_auto_auto] gap-x-4 items-center px-4 py-3">
                          {/* Placa */}
                          <div className="flex items-center gap-2">
                            <div className={cn('rounded-full w-2 h-2 flex-shrink-0', dotColor)} />
                            <Badge variant="outline" className="text-xs font-mono">
                              {ev.placa || perfil?.vehiculo || '—'}
                            </Badge>
                          </div>
                          {/* Ruta */}
                          <p className="text-sm text-muted-foreground truncate">
                            {ev.ruta || '—'}
                          </p>
                          {/* Velocidad */}
                          <div className="text-center">
                            <span className={cn('font-bold text-sm', velColor)}>{vel} km/h</span>
                          </div>
                          {/* Fecha */}
                          <p className="text-xs text-muted-foreground text-right whitespace-nowrap">{fecha}</p>
                        </div>
                      );
                    })}
                  </div>
                  {eventos.length > 100 && (
                    <p className="text-center text-xs text-muted-foreground py-3 border-t border-border">
                      Mostrando los 100 eventos más recientes de {eventos.length} totales
                    </p>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* ══ MENSAJES ═══════════════════════════════════════════════ */}
        {seccion === 'mensajes' && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-foreground">Mensajes</h2>
            {mensajes.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <MessageSquare className="w-10 h-10 mx-auto mb-3 opacity-40" />
                  No tienes mensajes de tu empresa por el momento.
                </CardContent>
              </Card>
            ) : (
              mensajes.map((msg) => {
                const prioColors: Record<string, string> = {
                  alta: 'border-l-red-500',
                  normal: 'border-l-blue-500',
                  baja: 'border-l-gray-400',
                };
                return (
                  <Card key={msg.id} className={cn('border-l-4', prioColors[msg.prioridad] || 'border-l-border')}>
                    <CardContent className="pt-4 pb-4 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-semibold text-foreground">{msg.titulo}</h3>
                        <div className="flex gap-2 flex-shrink-0">
                          <Badge variant="outline" className="text-xs">{msg.tipo}</Badge>
                          {msg.prioridad === 'alta' && <Badge variant="destructive" className="text-xs">Urgente</Badge>}
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">{msg.contenido}</p>
                      <p className="text-xs text-muted-foreground">
                        Recibido: {new Date(msg.created_at).toLocaleString('es-CO')}
                      </p>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>
        )}

        {/* ══ MI PERFIL ══════════════════════════════════════════════ */}
        {seccion === 'perfil' && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-foreground">Mi Perfil</h2>
            <Card>
              <CardContent className="pt-6 space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="w-8 h-8 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-foreground">{perfil?.nombre}</h3>
                    <p className="text-sm text-muted-foreground">Conductor activo</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  {[
                    { label: 'Cédula', value: perfil?.cedula },
                    { label: 'Licencia', value: perfil?.licencia },
                    { label: 'Teléfono', value: perfil?.telefono },
                    { label: 'Vehículo asignado', value: perfil?.vehiculo },
                    { label: 'Score de seguridad', value: `${perfil?.score ?? 100} / 100` },
                    { label: 'Estado', value: perfil?.estado },
                  ].map(({ label, value }) => (
                    <div key={label} className="space-y-1">
                      <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">{label}</p>
                      <p className="text-sm font-semibold text-foreground">{value || '—'}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

      </main>

      {/* Players */}
      {playerAsig && (
        <CapacitacionPlayer
          asignacion={playerAsig as AsignacionPlayer}
          open={playerOpen}
          onClose={() => { setPlayerOpen(false); setPlayerAsig(null); }}
          onComplete={handlePlayerComplete}
        />
      )}
      {playerModulosAsig && (
        <CapacitacionPlayerModulos
          asignacion={playerModulosAsig as AsignacionPlayerModulos}
          open={playerModulosOpen}
          onClose={() => { setPlayerModulosOpen(false); setPlayerModulosAsig(null); }}
          onComplete={handlePlayerComplete}
        />
      )}
    </div>
  );
};

export default PortalConductorPage;
