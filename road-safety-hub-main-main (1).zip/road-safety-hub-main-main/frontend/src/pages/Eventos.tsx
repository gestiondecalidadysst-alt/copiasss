import { useState, useEffect, useMemo, useCallback } from 'react';
import api from '@/services/api';
import { Input } from '@/components/ui/input';
import { Search, Loader2, Plus, Pencil, Trash2, Calendar, Database } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface Exceso {
  id: string;
  created_at: string;
  velocidad: number;
  placa: string;
  fecha: string;
  ruta: string;
  latitud?: number;
  longitud?: number;
}

function toDateStr(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

const today = toDateStr(new Date());

const Eventos = () => {
  const [search, setSearch] = useState('');
  const [fechaInicio, setFechaInicio] = useState(today);
  const [fechaFin,    setFechaFin]    = useState(today);
  const [modoTodos,  setModoTodos]   = useState(false);
  const [eventos, setEventos] = useState<Exceso[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Exceso | null>(null);
  const [form, setForm] = useState({
    velocidad: 0, placa: '', fecha: '', ruta: '', latitud: 4.6597, longitud: -74.0833
  });

  const fetchEventos = useCallback(async (todos: boolean, inicio: string, fin: string) => {
    setLoading(true);
    setError(null);
    try {
      const params = todos ? '' : `?fecha_inicio=${inicio}&fecha_fin=${fin}`;
      const response = await api.get(`/eventos${params}`);
      setEventos(response.data);
    } catch (err) {
      console.error(err);
      setError('No se pudieron cargar los eventos del servidor.');
    } finally {
      setLoading(false);
    }
  }, []);

  // Carga inicial: solo el día actual
  useEffect(() => {
    fetchEventos(false, today, today);
  }, [fetchEventos]);

  const handleAplicarRango = () => {
    if (fechaInicio > fechaFin) {
      toast.error('La fecha inicial no puede ser mayor que la final');
      return;
    }
    setModoTodos(false);
    fetchEventos(false, fechaInicio, fechaFin);
  };

  const handleVerTodos = () => {
    setModoTodos(true);
    fetchEventos(true, fechaInicio, fechaFin);
  };

  const handleVolverHoy = () => {
    setFechaInicio(today);
    setFechaFin(today);
    setModoTodos(false);
    fetchEventos(false, today, today);
  };

  const filtered = useMemo(() => eventos.filter((e) => {
    return e.placa.toLowerCase().includes(search.toLowerCase()) ||
           e.ruta.toLowerCase().includes(search.toLowerCase());
  }), [eventos, search]);

  const handleSave = async () => {
    if (!form.placa || !form.velocidad || !form.ruta) return toast.error('Complete los campos requeridos');
    
    try {
      if (editing) {
        const { data: updated } = await api.put(`/eventos/${editing.id}`, form);
        setEventos(eventos.map(e => e.id === editing.id ? updated : e));
        toast.success('Exceso actualizado');
      } else {
        const { data: created } = await api.post('/eventos', form);
        setEventos([...eventos, created]);
        toast.success('Exceso registrado');
      }
      setDialogOpen(false);
      setEditing(null);
      setForm({ velocidad: 0, placa: '', fecha: '', ruta: '', latitud: 4.6597, longitud: -74.0833 });
    } catch (e) { toast.error('Error al guardar'); }
  };

  const handleEdit = (e: Exceso) => {
    setEditing(e);
    setForm({ velocidad: e.velocidad, placa: e.placa, fecha: e.fecha || '', ruta: e.ruta, latitud: e.latitud || 4.6597, longitud: e.longitud || -74.0833 });
    setDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    try {
      await api.delete(`/eventos/${id}`);
      setEventos(eventos.filter(e => e.id !== id));
      toast.success('Evento eliminado');
    } catch (e) { toast.error('Error al eliminar evento'); }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Excesos de Velocidad</h1>
          <div className="flex items-center gap-2 mt-1">
            <p className="text-muted-foreground text-sm">{filtered.length} registros</p>
            {modoTodos ? (
              <span className="inline-flex items-center gap-1 text-[10px] bg-amber-100 text-amber-700 border border-amber-300 px-2 py-0.5 rounded-full font-medium">
                <Database className="w-3 h-3" /> Todos los registros
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-[10px] bg-blue-100 text-blue-700 border border-blue-300 px-2 py-0.5 rounded-full font-medium">
                <Calendar className="w-3 h-3" />
                {fechaInicio === fechaFin ? fechaInicio : `${fechaInicio} → ${fechaFin}`}
              </span>
            )}
          </div>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) { setEditing(null); setForm({ velocidad: 0, placa: '', fecha: '', ruta: '', latitud: 4.6597, longitud: -74.0833 }); } }}>
          <DialogTrigger asChild>
            <Button className="gradient-primary text-primary-foreground"><Plus className="w-4 h-4 mr-2" />Nuevo registro</Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>{editing ? 'Editar' : 'Nuevo'} exceso de velocidad</DialogTitle></DialogHeader>
            <div className="space-y-4 mt-2 max-h-[70vh] overflow-y-auto pr-2">
              <div><Label>Placa del Vehículo</Label><Input value={form.placa} onChange={(e) => setForm({ ...form, placa: e.target.value })} placeholder="Ej: ABC-123" /></div>
              <div><Label>Velocidad (km/h)</Label><Input type="number" value={form.velocidad} onChange={(e) => setForm({ ...form, velocidad: Number(e.target.value) })} /></div>
              <div><Label>Ruta</Label><Input value={form.ruta} onChange={(e) => setForm({ ...form, ruta: e.target.value })} placeholder="Ej: Vía principal" /></div>
              <div><Label>Fecha y Hora</Label><Input type="datetime-local" value={form.fecha ? form.fecha.replace(' ', 'T') : ''} onChange={(e) => setForm({ ...form, fecha: e.target.value.replace('T', ' ') })} /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label>Latitud</Label><Input type="number" step="any" value={form.latitud} onChange={(e) => setForm({ ...form, latitud: parseFloat(e.target.value) })} /></div>
                <div><Label>Longitud</Label><Input type="number" step="any" value={form.longitud} onChange={(e) => setForm({ ...form, longitud: parseFloat(e.target.value) })} /></div>
              </div>
              <Button onClick={handleSave} className="w-full gradient-primary text-primary-foreground">{editing ? 'Guardar cambios' : 'Registrar exceso'}</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {loading && (
        <div className="flex justify-center items-center py-10">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2 text-muted-foreground">Cargando eventos...</span>
        </div>
      )}

      {error && (
        <div className="bg-destructive/15 text-destructive p-4 rounded-md">
          {error}
        </div>
      )}

      {!loading && !error && (
        <>

      <div className="flex flex-wrap gap-3 items-end">
        {/* Búsqueda */}
        <div className="relative flex-1 min-w-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar por placa o ruta..." className="pl-9 w-full sm:w-64" />
        </div>

        {/* Rango de fechas */}
        <div className="flex items-center gap-1.5 bg-card border border-border px-3 py-1.5 rounded-lg shadow-sm">
          <Calendar className="w-4 h-4 text-muted-foreground shrink-0" />
          <Input type="date" value={fechaInicio} onChange={e => setFechaInicio(e.target.value)}
            className="h-7 border-none focus-visible:ring-0 px-0 w-32 bg-transparent text-sm" />
          <span className="text-muted-foreground text-xs">—</span>
          <Input type="date" value={fechaFin} min={fechaInicio} onChange={e => setFechaFin(e.target.value)}
            className="h-7 border-none focus-visible:ring-0 px-0 w-32 bg-transparent text-sm" />
        </div>
        <Button size="sm" onClick={handleAplicarRango} disabled={loading} className="text-xs">
          Aplicar
        </Button>
        <Button size="sm" variant="outline" onClick={handleVolverHoy} disabled={loading} className="text-xs">
          Hoy
        </Button>

        {/* Ver todos */}
        {!modoTodos ? (
          <Button size="sm" variant="ghost" onClick={handleVerTodos} disabled={loading}
            className="text-xs text-amber-700 hover:text-amber-800 hover:bg-amber-50 gap-1.5">
            <Database className="w-3.5 h-3.5" /> Ver todos los registros
          </Button>
        ) : (
          <Button size="sm" variant="ghost" onClick={handleVolverHoy} disabled={loading}
            className="text-xs text-blue-700 hover:text-blue-800 hover:bg-blue-50 gap-1.5">
            <Calendar className="w-3.5 h-3.5" /> Volver a hoy
          </Button>
        )}
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                {['Placa', 'Velocidad', 'Ruta', 'Fecha', 'Creado', 'Acciones'].map((h) => (
                  <th key={h} className="text-left py-3 px-4 text-muted-foreground font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((e) => (
                <tr key={e.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="py-3 px-4 font-medium text-foreground">{e.placa}</td>
                  <td className="py-3 px-4 text-destructive font-bold">{e.velocidad} km/h</td>
                  <td className="py-3 px-4 text-foreground">{e.ruta}</td>
                  <td className="py-3 px-4 text-muted-foreground">{e.fecha}</td>
                  <td className="py-3 px-4 text-muted-foreground text-xs">{e.created_at ? new Date(e.created_at).toLocaleDateString() : '-'}</td>
                  <td className="py-3 px-4">
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(e)}><Pencil className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDelete(e.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      </>
      )}
    </div>
  );
};

export default Eventos;
