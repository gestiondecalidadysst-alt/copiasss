import { useState, useEffect } from 'react';
import api from '@/services/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  BookOpen, Plus, Pencil, Trash2, Users, Search,
  Video, FileText, Star, UsersRound, Clock, Link2,
  ChevronDown, ChevronUp, Loader2, CheckCircle2, RefreshCw, Download
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { QuizEditor } from '@/components/QuizEditor';
import { ModulosEditor, Modulo } from '@/components/ModulosEditor';
import { useAppStore } from '@/stores/appStore';

// ── Tipos ──────────────────────────────────────────────────────────────────
interface Capacitacion {
  id: string;
  titulo: string;
  descripcion: string;
  contenido_url: string;
  tipo: 'video' | 'documento' | 'quiz' | 'presencial';
  duracion_minutos: number;
  activo: boolean;
  created_at: string;
  modulos?: Modulo[];
}

interface Conductor {
  id: string;
  nombre: string;
  cedula: string;
  vehiculo: string;
  estado: string;
}

interface Asignacion {
  id: string;
  capacitacion_id: string;
  conductor_id: string;
  estado: 'pendiente' | 'en_progreso' | 'completado';
  etapa?: string;
  progreso_video?: number;
  quiz_puntaje?: number;
  quiz_completado?: boolean;
  fecha_asignacion: string;
  fecha_completado?: string;
  conductor: { nombre: string; cedula: string; vehiculo: string };
}

// ── Helpers ────────────────────────────────────────────────────────────────
const TIPOS = [
  { value: 'documento', label: 'Documento', icon: FileText },
  { value: 'video', label: 'Video', icon: Video },
  { value: 'quiz', label: 'Quiz / Evaluación', icon: Star },
  { value: 'presencial', label: 'Presencial', icon: UsersRound },
] as const;

const TipoIcon = ({ tipo }: { tipo: string }) => {
  const t = TIPOS.find((x) => x.value === tipo);
  const Icon = t?.icon ?? FileText;
  return <Icon className="w-4 h-4" />;
};

const estadoColor: Record<string, string> = {
  pendiente: 'bg-gray-100 text-gray-700',
  en_progreso: 'bg-blue-100 text-blue-700',
  completado: 'bg-green-100 text-green-700',
};

const emptyForm = { titulo: '', descripcion: '', contenido_url: '', tipo: 'documento', duracion_minutos: 0 };

// ── Componente ─────────────────────────────────────────────────────────────
const Capacitaciones = () => {
  const [caps, setCaps] = useState<Capacitacion[]>([]);
  const [conductores, setConductores] = useState<Conductor[]>([]);
  const [asignaciones, setAsignaciones] = useState<Record<string, Asignacion[]>>({});
  const [progresos, setProgresos] = useState<Record<string, Asignacion[]>>({});
  const [loadingProgreso, setLoadingProgreso] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [asignarOpen, setAsignarOpen] = useState<string | null>(null);
  const [detailOpen, setDetailOpen] = useState<string | null>(null);
  const [editing, setEditing] = useState<Capacitacion | null>(null);
  const [form, setForm] = useState({ ...emptyForm });
  const [createWithModulos, setCreateWithModulos] = useState(false);
  const [newModulos, setNewModulos] = useState<Modulo[]>([]);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [downloading, setDownloading] = useState<string | null>(null);
  const [selectedConductores, setSelectedConductores] = useState<string[]>([]);
  const [asignandoSearch, setAsignandoSearch] = useState('');
  const [downloadFilter, setDownloadFilter] = useState<'todos' | 'aprobados' | 'no_aprobados'>('todos');

  const fetchCaps = async () => {
    try {
      const res = await api.get('/capacitaciones');
      setCaps(Array.isArray(res.data) ? res.data : []);
    } catch { toast.error('Error al cargar capacitaciones'); }
    finally { setLoading(false); }
  };

  const fetchConductores = async () => {
    try {
      const res = await api.get('/conductores');
      setConductores(Array.isArray(res.data) ? res.data : []);
    } catch (error) {
      console.error('Error al cargar conductores', error);
    }
  };

  const fetchProgreso = async (capId: string) => {
    setLoadingProgreso(capId);
    try {
      const res = await api.get(`/capacitaciones/${capId}/progreso`);
      setProgresos((prev) => ({ ...prev, [capId]: Array.isArray(res.data) ? res.data : [] }));
    } catch { toast.error('Error al cargar el progreso'); }
    finally { setLoadingProgreso(null); }
  };

  const fetchAsignaciones = async (capId: string) => {
    try {
      const res = await api.get(`/capacitaciones/asignaciones?capacitacion_id=${capId}`);
      setAsignaciones((prev) => ({ ...prev, [capId]: Array.isArray(res.data) ? res.data : [] }));
    } catch (error) {
      console.error('Error al cargar asignaciones', error);
    }
  };

  useEffect(() => { fetchCaps(); fetchConductores(); }, []);

  const openDetail = async (capId: string) => {
    setDetailOpen(capId);
    if (!asignaciones[capId]) await fetchAsignaciones(capId);
  };

  const handleSubmit = async () => {
    if (!form.titulo.trim()) { toast.error('El título es requerido'); return; }
    setSaving(true);
    try {
      if (editing) {
        await api.put(`/capacitaciones/${editing.id}`, form);
        toast.success('Capacitación actualizada');
      } else {
        // Si se crea por módulos, no enviar `tipo`, `duracion_minutos` ni `contenido_url` en el payload
        const payload = createWithModulos
          ? { titulo: form.titulo, descripcion: form.descripcion, modulos: newModulos }
          : form;
        await api.post('/capacitaciones', payload);
        toast.success('Capacitación creada');
      }
      setDialogOpen(false);
      setEditing(null);
      setForm({ ...emptyForm });
      setCreateWithModulos(false);
      setNewModulos([]);
      await fetchCaps();
    } catch { toast.error('Error al guardar capacitación'); }
    finally { setSaving(false); }
  };

  const handleEdit = async (cap: Capacitacion) => {
    try {
      // Obtener datos completos desde la API (incluye módulos, quiz, etc.)
      const res = await api.get(`/capacitaciones/${cap.id}`);
      const data = res.data || cap;
      setEditing(data);
      setForm({
        titulo: data.titulo || '',
        descripcion: data.descripcion || '',
        contenido_url: data.contenido_url || '',
        tipo: data.tipo || 'documento',
        duracion_minutos: data.duracion_minutos || 0,
      });
      if (data.modulos && Array.isArray(data.modulos) && data.modulos.length > 0) {
        setCreateWithModulos(true);
        setNewModulos(data.modulos as Modulo[]);
      } else {
        setCreateWithModulos(false);
        setNewModulos([]);
      }
      setDialogOpen(true);
    } catch (error) {
      console.error('Error al obtener detalles de la capacitación', error);
      toast.error('No se pudieron cargar los datos completos de la capacitación');
      // Caer back a la información mínima para no bloquear al usuario
      setEditing(cap);
      setForm({
        titulo: cap.titulo,
        descripcion: cap.descripcion || '',
        contenido_url: cap.contenido_url || '',
        tipo: cap.tipo,
        duracion_minutos: cap.duracion_minutos || 0,
      });
      setCreateWithModulos(false);
      setNewModulos([]);
      setDialogOpen(true);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await api.delete(`/capacitaciones/${deleteId}`);
      toast.success('Capacitación eliminada');
      setCaps((prev) => prev.filter((c) => c.id !== deleteId));
    } catch { toast.error('Error al eliminar'); }
    finally { setDeleteId(null); }
  };

  const handleAsignar = async (capId: string) => {
    if (selectedConductores.length === 0) { toast.error('Selecciona al menos un conductor'); return; }
    try {
      await api.post('/capacitaciones/asignaciones', { capacitacion_id: capId, conductor_ids: selectedConductores });
      toast.success(`Capacitación asignada a ${selectedConductores.length} conductor(es)`);
      setAsignarOpen(null);
      setSelectedConductores([]);
      await fetchAsignaciones(capId);
    } catch { toast.error('Error al asignar capacitación'); }
  };

  const handleDesasignar = async (asignacionId: string, capId: string) => {
    try {
      await api.delete(`/capacitaciones/asignaciones/${asignacionId}`);
      setAsignaciones((prev) => ({
        ...prev,
        [capId]: (prev[capId] || []).filter((a) => a.id !== asignacionId)
      }));
      toast.success('Asignación eliminada');
    } catch { toast.error('Error al eliminar asignación'); }
  };

  const downloadBlob = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const handleDownloadIndividual = async (capId: string, asignacionId: string, format: 'pdf' | 'xlsx') => {
    const key = `${asignacionId}_${format}`;
    setDownloading(key);
    const token = localStorage.getItem('token');
    console.debug('DEBUG download individual token:', !!token);
    if (!token) {
      toast.error('Sesión no iniciada. Por favor inicia sesión para descargar resultados.');
      setDownloading(null);
      return;
    }
    try {
      const res = await api.get(`/capacitaciones/${capId}/asignaciones/${asignacionId}/resultado?format=${format}`, { responseType: 'blob' });
      const ext = format === 'pdf' ? 'pdf' : 'xlsx';
      const filename = `resultado_${asignacionId}.${ext}`;
      downloadBlob(res.data, filename);
      toast.success('Descarga iniciada');
    } catch (error) {
      console.error('Error al descargar resultado individual', error);
      toast.error('No se pudo descargar el resultado');
    } finally {
      setDownloading(null);
    }
  };

  const { reportHeader, reportFooter } = useAppStore();

  const handleDownloadBulk = async (capId: string, format: 'pdf' | 'xlsx') => {
    const key = `bulk_${capId}_${format}`;
    setDownloading(key);
    const token = localStorage.getItem('token');
    console.debug('DEBUG download bulk token:', !!token);
    if (!token) {
      toast.error('Sesión no iniciada. Por favor inicia sesión para descargar resultados.');
      setDownloading(null);
      return;
    }
    try {
      const params = new URLSearchParams();
      params.append('format', format);
      params.append('filtro', downloadFilter);
      if (reportHeader) params.append('report_header', reportHeader);
      if (reportFooter) params.append('report_footer', reportFooter);

      const res = await api.get(`/capacitaciones/${capId}/resultados?${params.toString()}`, { responseType: 'blob' });
      const ext = format === 'pdf' ? 'pdf' : 'xlsx';
      const filename = `resultados_capacitacion_${capId}_${downloadFilter}.${ext}`;
      downloadBlob(res.data, filename);
      toast.success('Descarga iniciada');
    } catch (error) {
      console.error('Error al descargar resultados masivos', error);
      toast.error('No se pudieron descargar los resultados');
    } finally {
      setDownloading(null);
    }
  };

  const conductoresNoAsignados = (capId: string) => {
    const asigs = asignaciones[capId] || [];
    const asigIds = new Set(asigs.map((a) => a.conductor_id));
    return conductores.filter((c) => c.estado === 'activo' && !asigIds.has(c.id));
  };

  const filtered = caps.filter((c) =>
    c.titulo.toLowerCase().includes(search.toLowerCase()) ||
    c.tipo.includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-primary" />
            Capacitaciones
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Gestiona y asigna capacitaciones de seguridad vial a los conductores
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => {
            if (!open) {
              setEditing(null);
              setForm({ ...emptyForm });
              setCreateWithModulos(false);
              setNewModulos([]);
            }
            setDialogOpen(open);
          }}>
          <DialogTrigger asChild>
            <Button className="gap-2 w-full sm:w-auto">
              <Plus className="w-4 h-4" />
              Nueva capacitación
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editing ? 'Editar capacitación' : 'Nueva capacitación'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div className="space-y-1.5">
                <Label>Título *</Label>
                <Input value={form.titulo} onChange={(e) => setForm((f) => ({ ...f, titulo: e.target.value }))} placeholder="Ej: Manejo defensivo en ciudad" />
              </div>
              <div className="space-y-1.5">
                <Label>Descripción</Label>
                <Textarea value={form.descripcion} onChange={(e) => setForm((f) => ({ ...f, descripcion: e.target.value }))} placeholder="Descripción del contenido y objetivos..." rows={3} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                {!createWithModulos && (
                  <>
                    <div className="space-y-1.5">
                      <Label>Tipo</Label>
                      <Select value={form.tipo} onValueChange={(v) => setForm((f) => ({ ...f, tipo: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {TIPOS.map((t) => (
                            <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5">
                      <Label>Duración (min)</Label>
                      <Input type="number" min={0} value={form.duracion_minutos}
                        onChange={(e) => setForm((f) => ({ ...f, duracion_minutos: Number(e.target.value) }))} />
                    </div>
                  </>
                )}
              </div>
              <div className="space-y-1.5">
                {!createWithModulos && (
                  <>
                    <Label className="flex items-center gap-2"><Link2 className="w-3 h-3" />URL del contenido</Label>
                    <Input value={form.contenido_url} onChange={(e) => setForm((f) => ({ ...f, contenido_url: e.target.value }))} placeholder="https://..." />
                  </>
                )}
              </div>
              <div className="space-y-1.5 flex items-center gap-3">
                <Checkbox
                  checked={createWithModulos}
                  onCheckedChange={(v) => {
                    const val = !!v;
                    setCreateWithModulos(val);
                    if (val) {
                      // Limpiar campos que no deben enviarse cuando se crea por módulos
                      setForm((f) => ({
                        ...f,
                        tipo: emptyForm.tipo,
                        duracion_minutos: emptyForm.duracion_minutos,
                        contenido_url: emptyForm.contenido_url,
                      }));
                    }
                  }}
                />
                <Label className="text-sm">Crear por módulos</Label>
              </div>
              {createWithModulos && (
                <div className="pt-2">
                  <ModulosEditor onChange={(m) => setNewModulos(m)} />
                </div>
              )}
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => { setDialogOpen(false); setEditing(null); setForm({ ...emptyForm }); }}>Cancelar</Button>
              <Button onClick={handleSubmit} disabled={saving} className="gap-2">
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                {editing ? 'Guardar cambios' : 'Crear capacitación'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input className="pl-9" placeholder="Buscar por título o tipo..." value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'Total', value: caps.length, icon: BookOpen, color: 'text-primary' },
          { label: 'Asignadas', value: Object.values(asignaciones).flat().length, icon: Users, color: 'text-blue-500' },
          { label: 'Completadas', value: Object.values(asignaciones).flat().filter((a) => a.estado === 'completado').length, icon: CheckCircle2, color: 'text-green-500' },
          { label: 'Pendientes', value: Object.values(asignaciones).flat().filter((a) => a.estado === 'pendiente').length, icon: Clock, color: 'text-orange-500' },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="pt-4 pb-4 flex items-center gap-3">
              <stat.icon className={cn('w-8 h-8', stat.color)} />
              <div>
                <p className="text-xl font-bold text-foreground">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Lista */}
      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <BookOpen className="w-10 h-10 mx-auto mb-3 opacity-40" />
            {search ? 'No hay resultados para tu búsqueda.' : 'Aún no hay capacitaciones. Crea la primera.'}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((cap) => {
            const asigs = asignaciones[cap.id] || [];
            const completadas = asigs.filter((a) => a.estado === 'completado').length;
            const isOpen = detailOpen === cap.id;

            return (
              <Card key={cap.id} className="overflow-hidden">
                <CardContent className="pt-4 pb-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 space-y-1.5 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <TipoIcon tipo={cap.tipo} />
                        <h3 className="font-semibold text-foreground">{cap.titulo}</h3>
                        <Badge variant="secondary" className="text-xs capitalize">{cap.tipo}</Badge>
                        {cap.duracion_minutos > 0 && (
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="w-3 h-3" />{cap.duracion_minutos} min
                          </span>
                        )}
                      </div>
                      {cap.descripcion && <p className="text-sm text-muted-foreground truncate">{cap.descripcion}</p>}
                      {isOpen && asigs.length > 0 && (
                        <div className="mt-1 text-xs text-muted-foreground flex items-center gap-1">
                          <span>{completadas}/{asigs.length} conductores completaron</span>
                          <Progress value={asigs.length > 0 ? (completadas / asigs.length) * 100 : 0} className="h-1.5 w-24" />
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0">
                      {/* Asignar conductores */}
                      <Dialog open={asignarOpen === cap.id} onOpenChange={(open) => {
                        setAsignarOpen(open ? cap.id : null);
                        if (open) { setSelectedConductores([]); setAsignandoSearch(''); fetchAsignaciones(cap.id); }
                      }}>
                        <DialogTrigger asChild>
                          <Button size="sm" variant="outline" className="gap-1 text-xs">
                            <Users className="w-3.5 h-3.5" />
                            Asignar
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-md">
                          <DialogHeader>
                            <DialogTitle>Asignar conductores</DialogTitle>
                          </DialogHeader>
                          <p className="text-sm text-muted-foreground">
                            <span className="font-medium">{cap.titulo}</span>
                          </p>
                          <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input className="pl-9" placeholder="Buscar conductor..." value={asignandoSearch} onChange={(e) => setAsignandoSearch(e.target.value)} />
                          </div>
                          <div className="max-h-60 overflow-y-auto space-y-1 border rounded-md p-2">
                            {conductoresNoAsignados(cap.id)
                              .filter((c) => c.nombre.toLowerCase().includes(asignandoSearch.toLowerCase()) || c.cedula.includes(asignandoSearch))
                              .map((c) => (
                                <label key={c.id} className="flex items-center gap-3 px-2 py-1.5 rounded hover:bg-muted cursor-pointer">
                                  <Checkbox
                                    checked={selectedConductores.includes(c.id)}
                                    onCheckedChange={(checked) => {
                                      setSelectedConductores((prev) =>
                                        checked ? [...prev, c.id] : prev.filter((id) => id !== c.id)
                                      );
                                    }}
                                  />
                                  <div className="flex-1">
                                    <p className="text-sm font-medium">{c.nombre}</p>
                                    <p className="text-xs text-muted-foreground">{c.cedula} · {c.vehiculo}</p>
                                  </div>
                                </label>
                              ))}
                            {conductoresNoAsignados(cap.id).length === 0 && (
                              <p className="text-sm text-muted-foreground text-center py-4">Todos los conductores activos ya están asignados</p>
                            )}
                          </div>
                          <div className="flex justify-between items-center pt-1">
                            <span className="text-sm text-muted-foreground">{selectedConductores.length} seleccionado(s)</span>
                            <Button size="sm" onClick={() => handleAsignar(cap.id)} disabled={selectedConductores.length === 0} className="gap-1">
                              <Users className="w-3.5 h-3.5" />
                              Asignar
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>

                      <Button size="sm" variant="ghost" onClick={() => handleEdit(cap)}>
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive"
                        onClick={() => setDeleteId(cap.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => openDetail(isOpen ? '__none__' : cap.id)}>
                        {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>

                  {/* Detalle expandible con tabs */}
                  {isOpen && (
                    <div className="mt-4 border-t pt-4">
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
                        <div className="w-full sm:w-auto">
                          <Label htmlFor={`filter-${cap.id}`} className="text-xs font-medium mb-1 block">Filtrar resultados:</Label>
                          <Select value={downloadFilter} onValueChange={(val: any) => setDownloadFilter(val)}>
                            <SelectTrigger id={`filter-${cap.id}`} className="w-full sm:w-auto h-8 text-xs">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="todos">Todos</SelectItem>
                              <SelectItem value="aprobados">Solo Aprobados (≥70%)</SelectItem>
                              <SelectItem value="no_aprobados">No Aprobados (&lt;70%)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="flex items-center gap-2 w-full sm:w-auto">
                          <Button size="sm" variant="outline" onClick={() => handleDownloadBulk(cap.id, 'xlsx')} disabled={!!downloading} className="flex-1 sm:flex-none">
                            {downloading === `bulk_${cap.id}_xlsx` ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5 mr-2" />}
                            Exportar XLSX
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => handleDownloadBulk(cap.id, 'pdf')} disabled={!!downloading} className="flex-1 sm:flex-none">
                            {downloading === `bulk_${cap.id}_pdf` ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileText className="w-3.5 h-3.5 mr-2" />}
                            Exportar PDF (Lista)
                          </Button>
                        </div>
                      </div>
                      <Tabs defaultValue="conductores">
                        <TabsList className="h-8 text-xs">
                          <TabsTrigger value="conductores" className="text-xs px-3 h-7">
                            <Users className="w-3 h-3 mr-1" />Conductores ({asigs.length})
                          </TabsTrigger>
                          <TabsTrigger value="quiz" className="text-xs px-3 h-7">
                            <Star className="w-3 h-3 mr-1" />Quiz
                          </TabsTrigger>
                          <TabsTrigger
                            value="progreso"
                            className="text-xs px-3 h-7"
                            onClick={() => { if (!progresos[cap.id]) fetchProgreso(cap.id); }}
                          >
                            <CheckCircle2 className="w-3 h-3 mr-1" />Progreso
                          </TabsTrigger>
                        </TabsList>

                        {/* Tab: Conductores asignados */}
                        <TabsContent value="conductores" className="mt-3">
                          {asigs.length === 0 ? (
                            <p className="text-sm text-muted-foreground">Ningún conductor asignado aún.</p>
                          ) : (
                            <div className="space-y-2">
                              {asigs.map((asig) => (
                                <div key={asig.id} className="flex items-center justify-between gap-2 text-sm">
                                  <div className="flex items-center gap-2">
                                    <span className={cn('px-2 py-0.5 rounded-full text-xs font-medium', estadoColor[asig.estado])}>
                                      {asig.estado.replace('_', ' ')}
                                    </span>
                                    <span className="font-medium">{asig.conductor?.nombre}</span>
                                    <span className="text-muted-foreground text-xs">{asig.conductor?.vehiculo}</span>
                                  </div>
                                      <div className="flex items-center gap-2">
                                        {asig.quiz_puntaje != null ? (
                                          <Badge variant={asig.quiz_puntaje >= 70 ? 'default' : 'destructive'} className="text-xs h-5">
                                            {asig.quiz_puntaje}%
                                          </Badge>
                                        ) : null}
                                            <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive"
                                              onClick={() => handleDesasignar(asig.id, cap.id)}>
                                              <Trash2 className="w-3.5 h-3.5" />
                                            </Button>
                                            <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
                                              onClick={() => handleDownloadIndividual(cap.id, asig.id, 'xlsx')}
                                              disabled={!!downloading}>
                                              {downloading === `${asig.id}_xlsx` ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                                            </Button>
                                            <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
                                              onClick={() => handleDownloadIndividual(cap.id, asig.id, 'pdf')}
                                              disabled={!!downloading}>
                                              {downloading === `${asig.id}_pdf` ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileText className="w-3.5 h-3.5" />}
                                            </Button>
                                      </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </TabsContent>

                        {/* Tab: Editor de Quiz */}
                        <TabsContent value="quiz" className="mt-3">
                          <QuizEditor capacitacionId={cap.id} />
                        </TabsContent>

                        {/* Tab: Progreso en tiempo real */}
                        <TabsContent value="progreso" className="mt-3">
                          <div className="flex items-center justify-between mb-3">
                            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                              Avance de cada conductor
                            </p>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-7 gap-1 text-xs"
                              onClick={() => fetchProgreso(cap.id)}
                              disabled={loadingProgreso === cap.id}
                            >
                              <RefreshCw className={cn('w-3 h-3', loadingProgreso === cap.id && 'animate-spin')} />
                              Actualizar
                            </Button>
                          </div>
                          {loadingProgreso === cap.id ? (
                            <div className="flex items-center justify-center py-6 text-muted-foreground gap-2 text-sm">
                              <Loader2 className="w-4 h-4 animate-spin" /> Cargando...
                            </div>
                          ) : (progresos[cap.id] || []).length === 0 ? (
                            <p className="text-sm text-muted-foreground">
                              {progresos[cap.id] ? 'Sin conductores asignados.' : 'Haz clic en "Actualizar" para ver el progreso.'}
                            </p>
                          ) : (
                            <div className="space-y-3">
                              {(progresos[cap.id] || []).map((prog) => (
                                <div key={prog.id} className="space-y-1.5 p-3 bg-muted/30 rounded-lg">
                                  <div className="flex items-center justify-between gap-2">
                                    <div className="flex items-center gap-2 min-w-0">
                                      <span className="font-medium text-sm truncate">{prog.conductor?.nombre}</span>
                                      <span className="text-xs text-muted-foreground flex-shrink-0">{prog.conductor?.vehiculo}</span>
                                    </div>
                                    <div className="flex items-center gap-2 flex-shrink-0">
                                      <span className={cn('px-2 py-0.5 rounded-full text-xs font-medium', estadoColor[prog.estado])}>
                                        {(prog.etapa || prog.estado).replace('_', ' ')}
                                      </span>
                                      {prog.quiz_completado && prog.quiz_puntaje != null && (
                                        <Badge variant={prog.quiz_puntaje >= 70 ? 'default' : 'destructive'} className="text-xs h-5">
                                          {prog.quiz_puntaje}%
                                        </Badge>
                                      )}
                                    </div>
                                  </div>
                                  {(prog.progreso_video ?? 0) > 0 && (
                                    <div className="space-y-0.5">
                                      <div className="flex justify-between text-xs text-muted-foreground">
                                        <span>Video</span>
                                        <span>{prog.progreso_video}%</span>
                                      </div>
                                      <Progress value={prog.progreso_video ?? 0} className="h-1.5" />
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </TabsContent>
                      </Tabs>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Confirm delete */}
      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar capacitación?</AlertDialogTitle>
            <AlertDialogDescription>Esta acción desactivará la capacitación. Las asignaciones existentes no se borrarán.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Capacitaciones;
