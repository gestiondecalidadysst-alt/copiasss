import { useState, useEffect } from 'react';
import api from '@/services/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Search, Pencil, Trash2, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface Vehiculo {
  id: string;
  placa: string;
  estado: string;
  riesgo: string;
  velocidad_ulti: number;
  ultima_ruta: string;
  created_at: string;
}

const ESTADOS_VEHICULO = ['S1', 'S2', 'S3', 'inactivo', 'mantenimiento'] as const;

const Vehiculos = () => {
  const [vehiculos, setVehiculos] = useState<Vehiculo[]>([]);
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Vehiculo | null>(null);
  const [form, setForm] = useState({ placa: '', estado: 'S1', riesgo: '', velocidad_ulti: 0, ultima_ruta: '' });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const fetchVehiculos = async () => {
    try {
      const res = await api.get('/vehiculos');
      setVehiculos(res.data);
    } catch (e) { toast.error('Error al cargar vehículos'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchVehiculos(); }, []);

  const filtered = vehiculos.filter((v) =>
    v.placa.toLowerCase().includes(search.toLowerCase()) ||
    (v.ultima_ruta ?? '').toLowerCase().includes(search.toLowerCase())
  );

  const handleSave = async () => {
    if (!form.placa.trim()) return toast.error('La placa es requerida');
    setSaving(true);
    try {
      const payload = {
        placa: form.placa.trim(),
        estado: form.estado,
        riesgo: form.riesgo,
        velocidad_ulti: Number(form.velocidad_ulti),
        ultima_ruta: form.ultima_ruta,
      };
      if (editing) {
        const { data: updated } = await api.put(`/vehiculos/${editing.id}`, payload);
        setVehiculos(vehiculos.map(v => v.id === editing.id ? updated : v));
        toast.success('Vehículo actualizado');
      } else {
        const { data: created } = await api.post('/vehiculos', payload);
        setVehiculos(prev => [...prev, created]);
        toast.success('Vehículo creado');
      }
      setDialogOpen(false);
      setEditing(null);
      setForm({ placa: '', estado: 'S1', riesgo: '', velocidad_ulti: 0, ultima_ruta: '' });
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Error al guardar vehículo'); }
    finally { setSaving(false); }
  };

  const handleEdit = (v: Vehiculo) => {
    setEditing(v);
    setForm({ placa: v.placa, estado: v.estado ?? 'S1', riesgo: v.riesgo ?? '', velocidad_ulti: v.velocidad_ulti ?? 0, ultima_ruta: v.ultima_ruta ?? '' });
    setDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await api.delete(`/vehiculos/${deleteId}`);
      setVehiculos(vehiculos.filter(v => v.id !== deleteId));
      toast.success('Vehículo eliminado');
    } catch { toast.error('Error al eliminar vehículo'); }
    finally { setDeleteId(null); }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Encabezado */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Vehículos</h1>
          <p className="text-muted-foreground text-sm">{vehiculos.length} vehículos registrados</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(o) => {
          setDialogOpen(o);
          if (!o) { setEditing(null); setForm({ placa: '', estado: 'S1', riesgo: '', velocidad_ulti: 0, ultima_ruta: '' }); }
        }}>
          <DialogTrigger asChild>
            <Button className="gradient-primary text-primary-foreground">
              <Plus className="w-4 h-4 mr-2" />Nuevo vehículo
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editing ? 'Editar vehículo' : 'Nuevo vehículo'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-2">
              <div>
                <Label>Placa <span className="text-destructive">*</span></Label>
                <Input
                  value={form.placa}
                  onChange={(e) => setForm({ ...form, placa: e.target.value.toUpperCase() })}
                  placeholder="ABC123"
                />
              </div>
              <div>
                <Label>Estado</Label>
                <Select value={form.estado} onValueChange={(v) => setForm({ ...form, estado: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {ESTADOS_VEHICULO.map(e => (
                      <SelectItem key={e} value={e}>{e}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Riesgo</Label>
                <Input
                  value={form.riesgo}
                  onChange={(e) => setForm({ ...form, riesgo: e.target.value })}
                  placeholder="Ej: 50"
                />
              </div>
              <div>
                <Label>Velocidad última (km/h)</Label>
                <Input
                  type="number"
                  value={form.velocidad_ulti}
                  onChange={(e) => setForm({ ...form, velocidad_ulti: Number(e.target.value) })}
                  placeholder="0"
                />
              </div>
              <div>
                <Label>Última ruta</Label>
                <Input
                  value={form.ultima_ruta}
                  onChange={(e) => setForm({ ...form, ultima_ruta: e.target.value })}
                  placeholder="Descripción de la ruta"
                />
              </div>
              <Button
                onClick={handleSave}
                disabled={saving}
                className="w-full gradient-primary text-primary-foreground"
              >
                {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                {editing ? 'Guardar cambios' : 'Crear vehículo'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Buscador */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar por placa o tipo..." className="pl-9" />
      </div>

      {/* Tabla */}
      {loading ? (
        <div className="flex justify-center items-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2 text-muted-foreground">Cargando vehículos...</span>
        </div>
      ) : (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  {['Placa', 'Estado', 'Riesgo', 'Vel. última', 'Última ruta', 'Acciones'].map((h) => (
                    <th key={h} className="text-left py-3 px-4 text-muted-foreground font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-muted-foreground">
                      {search ? 'Sin resultados para la búsqueda.' : 'No hay vehículos registrados.'}
                    </td>
                  </tr>
                ) : (
                  filtered.map((v) => (
                    <tr key={v.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                      <td className="py-3 px-4 font-medium text-foreground">{v.placa}</td>
                      <td className="py-3 px-4">
                        <span className={cn(
                          'px-2 py-1 rounded-full text-xs font-medium',
                          v.estado === 'S1' ? 'bg-success/15 text-success'
                          : v.estado === 'S2' ? 'bg-warning/15 text-warning'
                          : v.estado === 'S3' ? 'bg-destructive/15 text-destructive'
                          : 'bg-muted text-muted-foreground'
                        )}>{v.estado}</span>
                      </td>
                      <td className="py-3 px-4 text-foreground">{v.riesgo || '-'}</td>
                      <td className="py-3 px-4 text-foreground">{v.velocidad_ulti != null ? `${v.velocidad_ulti} km/h` : '-'}</td>
                      <td className="py-3 px-4 text-muted-foreground text-xs max-w-[200px] truncate">{v.ultima_ruta || '-'}</td>
                      <td className="py-3 px-4">
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" onClick={() => handleEdit(v)}>
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => setDeleteId(v.id)}>
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Confirmación de borrado */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => { if (!o) setDeleteId(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar vehículo?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. El vehículo será eliminado permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Vehiculos;
