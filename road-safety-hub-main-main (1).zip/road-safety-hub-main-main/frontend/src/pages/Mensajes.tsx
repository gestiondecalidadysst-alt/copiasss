
import { useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import {
  Bold, Italic, Underline, List, Quote, Smile, Send, Copy, Trash2,
  AlertTriangle, CheckCircle2, Info, Shield, Truck, MessageSquare,
  Zap, FileText, Pencil, Loader2, Save, RotateCcw, Image, Music, Video, Paperclip, X,
  CalendarCheck,
} from 'lucide-react';

const API = `${import.meta.env.VITE_API_URL}/mensajes`;

const getAuthHeaders = (): Record<string, string> => {
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}` } : {};
};

const EMOJIS_CATEGORIES = {
  '😀 Caras':        ['😀','😁','😂','🤣','😃','😄','😅','😆','😉','😊','😋','😎','🥳','🤩','😏','😒','😢','😭','😡','🤬','😤','🥺','🤔','🧐','😬','🫠','🥹','😳','😱','😨'],
  '👍 Gestos':       ['👍','👎','👏','🙌','🤝','🫶','👋','🤚','✋','🫵','☝️','✌️','🤞','🫰','🤟','🤘','💪','🦾','🙏','💅','👌','🤌'],
  '❤️ Símbolos':     ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','💔','❤️‍🔥','💯','✅','❌','⚠️','🚨','🔴','🟠','🟡','🟢','🔵','🟣','⭕','🔰','🆘','📵','🚫','⛔','🔞'],
  '🎂 Cumpleaños':   ['🎂','🍰','🥳','🎉','🎊','🎈','🎁','🎀','🪅','🎆','🎇','✨','🌟','💝','🥂','🍾','🫧','🍭','🍬','🍫','🍩','🍪','🎵','🎶','🎤','🎸','🎺','🥇','👑','💐','🌹','🌷','💌'],
  '💼 Trabajo':      ['💼','🗂️','📁','📂','📋','📊','📈','📉','📝','✏️','🖊️','🖋️','📌','📍','📎','🖇️','✂️','🗃️','🗄️','🖥️','💻','⌨️','🖱️','📱','☎️','📞','📠','🖨️','⏰','📅','📆','🗓️','🏢','👔','👩‍💼','👨‍💼','🤝','🏆','🥇','💡','🔑','🔐','💰','💳','🏦'],
  '⚖️ Leyes':        ['⚖️','🏛️','📜','🔏','🔒','🗝️','👮','👩‍⚖️','👨‍⚖️','🚔','🚨','🛡️','⛓️','🪪','📋','✍️','🖊️','📄','📃','🗺️','🏠','🚫','⛔','🔞','🆘','🚧','🚦','⚠️','❌','✅','🤝','🏅','🎗️','🪙','💰','🏦'],
  '🚗 Transporte':   ['🚗','🚕','🚙','🚌','🚎','🚐','🚑','🚒','🚓','🚔','🚖','🚘','🏎️','🚛','🚚','🚜','🛻','🚧','🛣️','🛤️','⛽','🚦','🚥','🛞','⚡','🏍️','🛵','🚲'],
  '📢 Comunicación': ['📣','📢','📡','💬','💭','🗣️','📲','📱','📞','📠','📮','📬','📭','📨','📧','✉️','📩','📝','📋','📊','📈','📉','🗂️','📎','📌','📍'],
  '🛡️ Seguridad':    ['🛡️','🔒','🔓','🔑','🗝️','🔐','⚙️','🔧','🔨','🪛','⛑️','🦺','👮','🚔','🚨','🆘','⚠️','🚧','🏥','🩺','💊','🩹','🩻'],
  '🌟 Varios':       ['⭐','🌟','✨','💫','🎯','🏆','🥇','🎖️','🏅','🎗️','🎉','🎊','🎈','🎁','🪄','🔮','💡','🔦','🕯️','💎','🪙','💰','🎶','🎵','🎸','🥁','🎺','🎻'],
  '🌤️ Clima':        ['☀️','🌤️','⛅','🌦️','🌧️','⛈️','🌩️','🌨️','❄️','🌪️','🌫️','🌈','⚡','💧','🌊','🔥','💨','🌡️','🌙','🌚','🌝'],
  '🏙️ Lugares':      ['🏙️','🌆','🌇','🌉','🌃','🌁','🏞️','🏔️','⛰️','🗻','🏠','🏢','🏦','🏨','🏪','🏫','⛪','🕌','🗼','🗽','🗺️','🧭','📍'],
};
const EMOJIS = Object.values(EMOJIS_CATEGORIES).flat();

const PRIORIDADES = [
  { value: 'alta', label: '🔴 Alta', color: 'bg-red-500/15 text-red-600' },
  { value: 'normal', label: '🟡 Normal', color: 'bg-yellow-500/15 text-yellow-600' },
  { value: 'baja', label: '🟢 Baja', color: 'bg-green-500/15 text-green-600' },
];

const ESTADOS = [
  { value: 'draft', label: '📝 Borrador', color: 'bg-slate-500/15 text-slate-600' },
  { value: 'enviado', label: '✅ Enviado', color: 'bg-green-500/15 text-green-600' },
  { value: 'programado', label: '⏰ Programado', color: 'bg-blue-500/15 text-blue-600' },
];

const TIPOS: { value: string; label: string; color: string }[] = [
  { value: 'preventiva',  label: '🚨 Alerta Preventiva',   color: 'bg-amber-500/15 text-amber-400 border-amber-500/30' },
  { value: 'segunda',     label: '⚠️ Segunda Advertencia', color: 'bg-orange-500/15 text-orange-400 border-orange-500/30' },
  { value: 'tercera',     label: '🔴 Tercer Llamado',      color: 'bg-red-500/15 text-red-400 border-red-500/30' },
  { value: 'informativa', label: '📋 Informativo',          color: 'bg-blue-500/15 text-blue-400 border-blue-500/30' },
  { value: 'broadcast',   label: '📢 Difusión Masiva',     color: 'bg-purple-500/15 text-purple-400 border-purple-500/30' },
];

const MEDIA_TYPES = [
  { value: 'texto', label: '📝 Texto', icon: FileText },
  { value: 'imagen', label: '🖼️ Imagen', icon: Image },
  { value: 'video', label: '🎬 Video', icon: Video },
  { value: 'audio', label: '🎵 Audio', icon: Music },
];

const DIAS_CORTO = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

/** Genera los próximos 7 días a partir de hoy como objetos { iso, label, weekday } */
const getProximos7Dias = () => {
  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(hoy);
    d.setDate(hoy.getDate() + i);
    const iso = d.toISOString().slice(0, 10);
    const wd = d.getDay();
    const esHoy = i === 0;
    return {
      iso,
      dia: DIAS_CORTO[wd],
      num: d.getDate(),
      esFinDeSemana: wd === 0 || wd === 6,
      esHoy,
    };
  });
};

/** Convierte "HH:mm" (24 h) a "h:mm AM/PM" (12 h) */
const to12h = (hora: string): string => {
  const [hStr, mStr] = hora.split(':');
  const h = parseInt(hStr, 10);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  return `${h12}:${mStr} ${ampm}`;
};



const QUICK_TEMPLATES: { label: string; tipo: string; titulo: string; contenido: string }[] = [
  {
    label: '🚨 Preventiva',
    tipo: 'preventiva',
    titulo: 'ALERTA PREVENTIVA – EXCESO DE VELOCIDAD',
    contenido:
`🚨 *ALERTA PREVENTIVA – EXCESO DE VELOCIDAD*

Se detectó un evento de velocidad superior al límite permitido.

🚐 Vehículo: 
⚡ Velocidad registrada: 
🛣️ Ruta: 

⚠️ Primer llamado de atención.

Se solicita al conductor reducir la velocidad y cumplir las normas de tránsito para prevenir incidentes.

📡 Sistema de Monitoreo Vehicular – GEOTRACK`,
  },
  {
    label: '⚠️ Segunda',
    tipo: 'segunda',
    titulo: 'SEGUNDA ADVERTENCIA – EXCESO DE VELOCIDAD',
    contenido:
`⚠️ *SEGUNDA ADVERTENCIA – EXCESO DE VELOCIDAD*

Se registra reincidencia en exceso de velocidad.

🚐 Vehículo: 
⚡ Velocidad registrada: 
🛣️ Ruta: 

🔔 Este es el segundo llamado de atención.

Se requiere acción inmediata. El incumplimiento reiterado generará un reporte formal.

📡 Sistema de Monitoreo Vehicular – GEOTRACK`,
  },
  {
    label: '🔴 Tercer llamado',
    tipo: 'tercera',
    titulo: 'TERCER LLAMADO – REPORTE FORMAL',
    contenido:
`🔴 *TERCER LLAMADO – REPORTE FORMAL*

Se documenta tercera infracción de velocidad.

🚐 Vehículo: 
⚡ Velocidad registrada: 
🛣️ Ruta: 
👤 Conductor: 

❌ Se genera reporte formal ante el área de seguridad vial.

📡 Sistema de Monitoreo Vehicular – GEOTRACK`,
  },
];

interface Mensaje {
  id: string;
  titulo: string;
  tipo: string;
  contenido: string;
  destinatario?: string;
  asunto?: string;
  prioridad?: string;
  emoji?: string;
  estado?: string;
  media_type?: string;
  media_url?: string;
  file_name?: string;
  fecha_programada?: string;
  hora_programada?: string;
  created_at: string;
  updated_at?: string;
}

interface MediaData {
  url: string;
  path: string;
  fileName: string;
  size: number;
  mimetype: string;
}

interface MensajeProgramado {
  id: string;
  mensaje_id: string;
  fecha: string;
  hora: string | null;
  estado: 'programado' | 'enviado';
  created_at: string;
  updated_at: string;
}

const insertAtCursor = (el: HTMLTextAreaElement, text: string) => {
  const s = el.selectionStart ?? 0;
  const e = el.selectionEnd ?? s;
  const v = el.value;
  return { next: v.slice(0, s) + text + v.slice(e), cursor: s + text.length };
};

const wrapSelection = (el: HTMLTextAreaElement, before: string, after: string) => {
  const s = el.selectionStart ?? 0;
  const e = el.selectionEnd ?? s;
  const v = el.value;
  const sel = v.slice(s, e) || 'texto';
  const next = v.slice(0, s) + before + sel + after + v.slice(e);
  return { next, selStart: s + before.length, selEnd: s + before.length + sel.length };
};

const tipoMeta = (tipo: string) => TIPOS.find(t => t.value === tipo) ?? TIPOS[0];

export default function Mensajes() {
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Editor state
  const [titulo, setTitulo] = useState('');
  const [tipo, setTipo] = useState('preventiva');
  const [contenido, setContenido] = useState('');
  const [destinatario, setDestinatario] = useState('');
  const [asunto, setAsunto] = useState('');
  const [prioridad, setPrioridad] = useState('normal');
  const [emoji, setEmoji] = useState('📬');
  const [estado, setEstado] = useState('draft');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showEmojis, setShowEmojis] = useState(false);
  const [showTitleEmojis, setShowTitleEmojis] = useState(false);
  // Programación de envío (para informativos y difusión masiva)
  const [fechaProgramada, setFechaProgramada] = useState('');
  const [horaProgramada, setHoraProgramada] = useState('');

  // Media state
  const [mediaType, setMediaType] = useState<string>('texto');
  const [mediaData, setMediaData] = useState<MediaData | null>(null);
  const [uploadingMedia, setUploadingMedia] = useState(false);

  // List state
  const [mensajes, setMensajes] = useState<Mensaje[]>([]);
  const [loadingList, setLoadingList] = useState(true);
  const [saving, setSaving] = useState(false);

  // Programados del mensaje abierto en el editor
  const [programado, setProgramado] = useState<MensajeProgramado | null>(null);
  const [sendingEnvio, setSendingEnvio] = useState(false);

  // Filtro de la tabla por estado (persiste en localStorage)
  const FILTRO_KEY = 'mensajes_filtro_estado';
  const [filtroEstado, setFiltroEstado] = useState<string>(
    () => localStorage.getItem(FILTRO_KEY) ?? 'programado'
  );
  const [filtroGuardado, setFiltroGuardado] = useState<string>(
    () => localStorage.getItem(FILTRO_KEY) ?? 'programado'
  );
  const handleGuardarFiltro = () => {
    localStorage.setItem(FILTRO_KEY, filtroEstado);
    setFiltroGuardado(filtroEstado);
    toast.success('Filtro guardado como predeterminado');
  };

  // Modal de estado de envíos
  const [estadoModal, setEstadoModal] = useState<Mensaje | null>(null);
  const [programadoModal, setProgramadoModal] = useState<MensajeProgramado | null>(null);
  const [loadingEnviosModal, setLoadingEnviosModal] = useState(false);

  // ─── ver estado desde la tabla (modal) ─────────────────────────────
  const handleVerEstados = async (m: Mensaje) => {
    setEstadoModal(m);
    setLoadingEnviosModal(true);
    try {
      const res = await fetch(`${API}/${m.id}/programados`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error();
      const rows: MensajeProgramado[] = await res.json();
      setProgramadoModal(rows[0] ?? null);
    } catch {
      setProgramadoModal(null);
    } finally {
      setLoadingEnviosModal(false);
    }
  };

  // Cambia el estado desde el modal
  const handleCambiarEstadoModal = async (nuevoEstado: 'enviado' | 'programado') => {
    if (!estadoModal) return;
    try {
      const res = await fetch(`${API}/${estadoModal.id}/programados`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ estado: nuevoEstado }),
      });
      if (!res.ok) throw new Error();
      const actualizado: MensajeProgramado = await res.json();
      setProgramadoModal(actualizado);
      toast.success(nuevoEstado === 'enviado' ? '✅ Marcado como enviado' : 'Revertido a programado');
    } catch {
      toast.error('Error al cambiar estado');
    }
  };

  // ─── fetch programado del mensaje cargado ────────────────────────────────────
  const fetchEnvios = async (mensajeId: string) => {
    try {
      const res = await fetch(`${API}/${mensajeId}/programados`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error();
      const rows: MensajeProgramado[] = await res.json();
      setProgramado(rows[0] ?? null);
    } catch {
      setProgramado(null);
    }
  };

  /** Cambia estado a 'enviado' */
  const handleMarcarEnviado = async () => {
    if (!editingId) return;
    setSendingEnvio(true);
    try {
      const res = await fetch(`${API}/${editingId}/programados`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ estado: 'enviado' }),
      });
      if (!res.ok) throw new Error();
      await fetchEnvios(editingId);
      toast.success('✅ Envío registrado');
    } catch {
      toast.error('Error al registrar el envío');
    } finally {
      setSendingEnvio(false);
    }
  };

  /** Revierte a 'programado' */
  const handleDesmarcarEnviado = async () => {
    if (!editingId) return;
    setSendingEnvio(true);
    try {
      const res = await fetch(`${API}/${editingId}/programados`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ estado: 'programado' }),
      });
      if (!res.ok) throw new Error();
      await fetchEnvios(editingId);
      toast.success('Revertido a programado');
    } catch {
      toast.error('Error al revertir estado');
    } finally {
      setSendingEnvio(false);
    }
  };

  // ─── fetch list ──────────────────────────────────────────────────────────
  const fetchMensajes = async () => {
    setLoadingList(true);
    try {
      const res = await fetch(API, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error();
      setMensajes(await res.json());
    } catch {
      toast.error('No se pudieron cargar los mensajes');
    } finally {
      setLoadingList(false);
    }
  };

  useEffect(() => {
    fetchMensajes();
    const interval = setInterval(fetchMensajes, 30_000); // refresca el estado cada 30 s
    return () => clearInterval(interval);
  }, []);

  // ─── live preview ─────────────────────────────────────────────────────────
  const preview = contenido;

  // ─── toolbar helpers ──────────────────────────────────────────────────────
  const insert = (text: string) => {
    const el = textareaRef.current;
    if (!el) return;
    const { next, cursor } = insertAtCursor(el, text);
    setContenido(next);
    requestAnimationFrame(() => { el.focus(); el.setSelectionRange(cursor, cursor); });
  };

  const wrap = (before: string, after: string) => {
    const el = textareaRef.current;
    if (!el) return;
    const { next, selStart, selEnd } = wrapSelection(el, before, after);
    setContenido(next);
    requestAnimationFrame(() => { el.focus(); el.setSelectionRange(selStart, selEnd); });
  };

  // ─── quick template ───────────────────────────────────────────────────────
  const loadQuick = (tpl: typeof QUICK_TEMPLATES[0]) => {
    setTitulo(tpl.titulo);
    setTipo(tpl.tipo);
    setContenido(tpl.contenido);
    setEditingId(null);
    toast.success('Plantilla cargada en el editor');
  };

  // ─── media upload ─────────────────────────────────────────────────────────
  const handleMediaUpload = async (file: File) => {
    if (!file) return;

    // Validate file size (50MB max)
    if (file.size > 50 * 1024 * 1024) {
      toast.error('El archivo no debe superar 50MB');
      return;
    }

    setUploadingMedia(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('tipo', tipo);

      const res = await fetch(`${API}/media/upload`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: formData,
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Error al subir archivo');
      }

      const data: MediaData = await res.json();
      setMediaData(data);
      
      // Update media type based on file type — must match DB CHECK constraint values
      const mimeBase = data.mimetype.split('/')[0]; // 'image', 'video', 'audio'
      const mimeToMediaType: Record<string, string> = {
        image: 'imagen',
        video: 'video',
        audio: 'audio',
      };
      setMediaType(mimeToMediaType[mimeBase] ?? 'texto');
      
      toast.success(`${file.name} subido correctamente`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Error al subir archivo');
    } finally {
      setUploadingMedia(false);
    }
  };

  // handleFileSelect kept for backward-compat; actual input uses handleFileSelectOrReplace
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFileSelectOrReplace(e);
  };

  // ─── delete media ─────────────────────────────────────────────────────────
  const handleDeleteMedia = async () => {
    if (!mediaData) return;

    // If path is empty the media belongs to an existing message but wasn't
    // uploaded in this session — just clear local state, nothing to delete.
    if (!mediaData.path) {
      setMediaData(null);
      setMediaType('texto');
      return;
    }

    try {
      const res = await fetch(`${API}/media/delete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ filePath: mediaData.path }),
      });

      if (!res.ok) throw new Error();
      setMediaData(null);
      setMediaType('texto');
      toast.success('Archivo eliminado');
    } catch {
      toast.error('Error al eliminar archivo');
    }
  };

  // ─── replace media ────────────────────────────────────────────────────────
  const handleReplaceMedia = async (file: File) => {
    // Delete existing file from storage only if it was uploaded in this session
    if (mediaData?.path) {
      await fetch(`${API}/media/delete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ filePath: mediaData.path }),
      }).catch(() => { /* ignore delete errors on replace */ });
    }
    setMediaData(null);
    await handleMediaUpload(file);
  };

  const handleFileSelectOrReplace = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = ''; // reset so same file can be re-selected
    if (mediaData) {
      handleReplaceMedia(file);
    } else {
      handleMediaUpload(file);
    }
  };

  // ─── save ─────────────────────────────────────────────────────────────────
  const handleSave = async () => {
    if (!titulo.trim() || !contenido.trim()) {
      toast.error('El título y el contenido son requeridos');
      return;
    }
    setSaving(true);
    try {
      const esConProgramacion = tipo === 'informativa' || tipo === 'broadcast';      const body = JSON.stringify({ 
        titulo, 
        tipo, 
        contenido,
        destinatario: destinatario || null,
        asunto: asunto || null,
        prioridad,
        emoji,
        estado,
        media_type: mediaData ? mediaType : null,
        media_url: mediaData?.url || null,
        file_name: mediaData?.fileName || null,
        fecha_programada: (tipo === 'informativa' || tipo === 'broadcast') ? (fechaProgramada || null) : null,
        hora_programada: (tipo === 'informativa' || tipo === 'broadcast') ? (horaProgramada || null) : null,
      });
      const headers = { 'Content-Type': 'application/json', ...getAuthHeaders() };
      let res: Response;
      if (editingId) {
        res = await fetch(`${API}/${editingId}`, { method: 'PUT', headers, body });
      } else {
        res = await fetch(API, { method: 'POST', headers, body });
      }
      if (!res.ok) throw new Error();
      toast.success(editingId ? 'Mensaje actualizado' : 'Mensaje guardado en Supabase');
      handleClear();
      await fetchMensajes();
    } catch {
      toast.error('Error al guardar mensaje');
    } finally {
      setSaving(false);
    }
  };

  // ─── delete ───────────────────────────────────────────────────────────────
  const handleDelete = async (id: string) => {
    try {
      const res = await fetch(`${API}/${id}`, { method: 'DELETE', headers: getAuthHeaders() });
      if (!res.ok) throw new Error();
      setMensajes(prev => prev.filter(m => m.id !== id));
      if (editingId === id) handleClear();
      toast.success('Mensaje eliminado');
    } catch {
      toast.error('Error al eliminar');
    }
  };

  // ─── load into editor ─────────────────────────────────────────────────────
  const handleLoad = (m: Mensaje) => {
    setTitulo(m.titulo);
    setTipo(m.tipo);
    setContenido(m.contenido);
    setDestinatario(m.destinatario || '');
    setAsunto(m.asunto || '');
    setPrioridad(m.prioridad || 'normal');
    setEmoji(m.emoji || '📬');
    setEstado(m.estado || 'draft');
    
    // Load media if exists
    if (m.media_url) {
      setMediaData({
        url: m.media_url,
        path: '',
        fileName: m.file_name || 'archivo',
        size: 0,
        mimetype: m.media_type || 'text',
      });
      setMediaType(m.media_type || 'texto');
    } else {
      setMediaData(null);
      setMediaType('texto');
    }
    
    // Programación
    setFechaProgramada(m.fecha_programada || '');
    setHoraProgramada(m.hora_programada || '');
    setEditingId(m.id);
    fetchEnvios(m.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    toast.success('Mensaje cargado para editar');
  };

  // ─── copy ─────────────────────────────────────────────────────────────────
  const handleCopy = async (text?: string) => {
    try {
      await navigator.clipboard.writeText(text ?? contenido);
      toast.success('Copiado al portapapeles');
    } catch {
      toast.error('No se pudo copiar');
    }
  };

  const handleClear = () => {
    setTitulo(''); 
    setTipo('preventiva'); 
    setContenido(''); 
    setDestinatario('');
    setAsunto('');
    setPrioridad('normal');
    setEmoji('📬');
    setEstado('draft');
    setMediaData(null);
    setMediaType('texto');
    setFechaProgramada('');
    setHoraProgramada('');
    setEditingId(null);
    setProgramado(null);
  };

  const meta = tipoMeta(tipo);

  return (
    <div className="space-y-8 animate-fade-in">

      {/* ── Header ── */}
      <div>
        <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
          <MessageSquare className="w-6 h-6 text-primary" />
          Constructor de Mensajes
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Crea plantillas de alerta con variables dinámicas y guárdalas en Supabase
        </p>
      </div>

      {/* ── Quick templates ── */}
      <div className="flex flex-wrap gap-2">
        <span className="text-xs text-muted-foreground self-center mr-1 font-medium">Plantillas rápidas:</span>
        {QUICK_TEMPLATES.map(tpl => (
          <Button key={tpl.tipo} variant="outline" size="sm" onClick={() => loadQuick(tpl)}
            className="h-8 text-xs gap-1">
            <Zap className="w-3 h-3" />{tpl.label}
          </Button>
        ))}
      </div>

      {/* ── Main grid ── */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">

        {/* LEFT – Editor */}
        <div className="space-y-4">
          <div className="bg-card border border-border rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-2 mb-1">
              <FileText className="w-4 h-4 text-primary" />
              <span className="font-semibold text-foreground text-sm">
                {editingId ? 'Editando plantilla' : 'Nueva plantilla'}
              </span>
              {editingId && (
                <Badge variant="outline" className="text-xs ml-auto">Modo edición</Badge>
              )}
            </div>

            {/* Título */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Título de la plantilla</Label>
              <div className="flex gap-1.5 relative">
                <Input value={titulo} onChange={e => setTitulo(e.target.value)}
                  placeholder="Ej: ALERTA PREVENTIVA – EXCESO DE VELOCIDAD"
                  className="flex-1" />
                <button
                  type="button"
                  onClick={() => setShowTitleEmojis(s => !s)}
                  className="h-9 w-9 shrink-0 border border-input rounded-md flex items-center justify-center text-lg hover:bg-muted transition-colors"
                  title="Insertar emoji en el título"
                >
                  <Smile className="w-4 h-4 text-muted-foreground" />
                </button>
                {showTitleEmojis && (
                  <div className="absolute top-10 right-0 z-50 bg-popover border border-border rounded-xl shadow-xl p-2 w-72 max-h-72 overflow-y-auto">
                    {Object.entries(EMOJIS_CATEGORIES).map(([cat, items]) => (
                      <div key={cat} className="mb-2">
                        <p className="text-[10px] font-semibold text-muted-foreground px-1 mb-1">{cat}</p>
                        <div className="flex flex-wrap gap-0.5">
                          {items.map(em => (
                            <button key={em} type="button"
                              onClick={() => { setTitulo(t => t + em); setShowTitleEmojis(false); }}
                              className="h-7 w-7 flex items-center justify-center text-base hover:bg-muted rounded">
                              {em}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Tipo */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Tipo de mensaje</Label>
              <Select value={tipo} onValueChange={setTipo}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TIPOS.map(t => (
                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Media Type */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">📎 Tipo de contenido</Label>
              <div className="grid grid-cols-4 gap-1.5">
                {MEDIA_TYPES.map(mt => {
                  const Icon = mt.icon;
                  const isAudio = mt.value === 'audio';
                  return (
                    <button
                      key={mt.value}
                      onClick={() => !isAudio && setMediaType(mt.value)}
                      disabled={isAudio}
                      title={isAudio ? 'Opción no disponible' : undefined}
                      className={`p-2 rounded-lg border-2 text-xs font-medium transition-all flex items-center justify-center gap-1 ${
                        isAudio
                          ? 'border-border opacity-40 cursor-not-allowed'
                          : mediaType === mt.value
                            ? 'border-primary bg-primary/10 text-primary'
                            : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      {mt.label.split(' ')[0]}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Media Upload */}
            {mediaType !== 'texto' && mediaType !== 'audio' && (
              <div className="space-y-1.5 p-3 bg-muted/40 rounded-lg border border-border">
                <div className="flex items-center justify-between">
                  <Label className="text-xs font-medium">Subir archivo</Label>
                  {uploadingMedia && <Loader2 className="w-3.5 h-3.5 animate-spin text-primary" />}
                </div>
                
                {!mediaData ? (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploadingMedia}
                    className="w-full p-3 border-2 border-dashed border-border rounded-lg hover:border-primary/50 hover:bg-primary/5 transition-all text-xs text-muted-foreground hover:text-primary cursor-pointer disabled:opacity-50"
                  >
                    <div className="flex flex-col items-center gap-1">
                      <Paperclip className="w-4 h-4" />
                      <span>Haz clic o arrastra un archivo ({mediaType})</span>
                      <span className="text-[10px]">Max 50MB</span>
                    </div>
                  </button>
                ) : (
                  <div className="p-2 bg-white rounded-lg border border-border flex items-center justify-between gap-2">
                    <div className="text-xs min-w-0">
                      <p className="font-medium text-foreground truncate">{mediaData.fileName}</p>
                      {mediaData.size > 0 && (
                        <p className="text-muted-foreground">{(mediaData.size / 1024 / 1024).toFixed(2)}MB</p>
                      )}
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        disabled={uploadingMedia}
                        title="Cambiar archivo"
                        className="p-1.5 hover:bg-primary/10 rounded-lg text-primary transition-colors disabled:opacity-50 text-[10px] font-medium"
                      >
                        Cambiar
                      </button>
                      <button
                        onClick={handleDeleteMedia}
                        disabled={uploadingMedia}
                        title="Eliminar archivo"
                        className="p-1.5 hover:bg-red-100 rounded-lg text-red-600 transition-colors disabled:opacity-50"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  onChange={handleFileSelect}
                  className="hidden"
                  accept={
                    mediaType === 'imagen' ? 'image/*' :
                    mediaType === 'video' ? 'video/*' :
                    mediaType === 'audio' ? 'audio/*' : ''
                  }
                />
              </div>
            )}

            {/* Destinatario */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">👤 Destinatario (opcional)</Label>
              <Input value={destinatario} onChange={e => setDestinatario(e.target.value)}
                placeholder="Ej: Todos los conductores, Admin, Operador" />
            </div>

            {/* Asunto */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">📨 Asunto (opcional)</Label>
              <Input value={asunto} onChange={e => setAsunto(e.target.value)}
                placeholder="Ej: Notificación importante" />
            </div>

            {/* Grid: Prioridad, Emoji, Estado */}
            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">Prioridad</Label>
                <Select value={prioridad} onValueChange={setPrioridad}>
                  <SelectTrigger className="text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PRIORIDADES.map(p => (
                      <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">Emoji</Label>
                <div className="relative">
                  <button onClick={() => setShowEmojis(!showEmojis)} 
                    className="w-full h-9 border border-input rounded-md flex items-center justify-center text-lg hover:bg-muted transition-colors">
                    {emoji}
                  </button>
                  {showEmojis && (
                    <div className="absolute top-10 left-0 z-50 bg-popover border border-border rounded-xl shadow-xl p-2 w-72 max-h-72 overflow-y-auto">
                      {Object.entries(EMOJIS_CATEGORIES).map(([cat, items]) => (
                        <div key={cat} className="mb-2">
                          <p className="text-[10px] font-semibold text-muted-foreground px-1 mb-1">{cat}</p>
                          <div className="flex flex-wrap gap-0.5">
                            {items.map(em => (
                              <button key={em} onClick={() => { setEmoji(em); setShowEmojis(false); }}
                                className="h-7 w-7 flex items-center justify-center text-base hover:bg-muted rounded">
                                {em}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">Estado</Label>
                <Select value={estado} onValueChange={setEstado}>
                  <SelectTrigger className="text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ESTADOS.map(es => (
                      <SelectItem key={es.value} value={es.value}>{es.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Programación de envío – solo para informativos y difusión masiva */}
            {(tipo === 'informativa' || tipo === 'broadcast') && (
              <div className="space-y-3 p-3.5 bg-blue-500/5 rounded-lg border border-blue-500/20">
                <div className="flex items-center gap-2">
                  <CalendarCheck className="w-4 h-4 text-blue-500" />
                  <Label className="text-xs font-semibold text-blue-600 dark:text-blue-400">
                    Programación de envío
                  </Label>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {/* Fecha */}
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">📅 Fecha de envío</Label>
                    <Input
                      type="date"
                      value={fechaProgramada}
                      min={(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; })()}
                      onChange={e => setFechaProgramada(e.target.value)}
                      className="text-xs"
                    />
                  </div>

                  {/* Hora */}
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">🕐 Hora de envío</Label>
                    <Input
                      type="time"
                      value={horaProgramada}
                      onChange={e => setHoraProgramada(e.target.value)}
                      className="text-xs"
                    />
                  </div>
                </div>

                {/* Botón marcar enviado – solo si el mensaje está guardado */}
                {editingId && programado && (
                  <div className="flex items-center justify-between p-2.5 rounded-lg border border-border bg-card">
                    <div className="text-xs">
                      <span className={programado.estado === 'enviado' ? 'text-green-600 font-semibold' : 'text-amber-500 font-medium'}>
                        {programado.estado === 'enviado' ? '✅ Enviado' : '⏳ Programado'}
                      </span>
                    </div>
                    <button
                      type="button"
                      disabled={sendingEnvio}
                      onClick={() => programado.estado === 'enviado' ? handleDesmarcarEnviado() : handleMarcarEnviado()}
                      className={`text-xs px-3 py-1 rounded font-semibold transition-all disabled:opacity-40 ${
                        programado.estado === 'enviado'
                          ? 'bg-amber-500/10 text-amber-600 hover:bg-amber-500/20'
                          : 'bg-green-500/10 text-green-600 hover:bg-green-500/20'
                      }`}
                    >
                      {sendingEnvio ? '…' : programado.estado === 'enviado' ? 'Revertir' : 'Marcar como enviado'}
                    </button>
                  </div>
                )}
                {editingId && !programado && (
                  <p className="text-[10px] text-amber-500 italic">
                    💡 Guarda el mensaje con fecha para habilitar el seguimiento de envío
                  </p>
                )}
                {!editingId && fechaProgramada && (
                  <p className="text-[10px] text-amber-500 italic">
                    💡 Guarda el mensaje para activar el seguimiento de envío
                  </p>
                )}
              </div>
            )}

            {/* Toolbar */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Contenido</Label>
              <div className="flex flex-wrap items-center gap-1 rounded-lg border border-border bg-muted/10 p-1.5">
                <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={() => wrap('*', '*')} title="Negrita"><Bold className="w-3.5 h-3.5" /></Button>
                <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={() => wrap('_', '_')} title="Cursiva"><Italic className="w-3.5 h-3.5" /></Button>
                <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={() => wrap('~', '~')} title="Tachado"><Underline className="w-3.5 h-3.5" /></Button>
                <div className="w-px h-5 bg-border mx-0.5" />
                <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={() => insert('- ')} title="Lista"><List className="w-3.5 h-3.5" /></Button>
                <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={() => insert('> ')} title="Cita"><Quote className="w-3.5 h-3.5" /></Button>
                <div className="w-px h-5 bg-border mx-0.5" />
                <div className="relative">
                  <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={() => setShowEmojis(s => !s)} title="Emojis">
                    <Smile className="w-3.5 h-3.5" />
                  </Button>
                  {showEmojis && (
                    <div className="absolute top-8 left-0 z-50 bg-popover border border-border rounded-xl shadow-xl p-2 w-72 max-h-72 overflow-y-auto">
                      {Object.entries(EMOJIS_CATEGORIES).map(([cat, items]) => (
                        <div key={cat} className="mb-2">
                          <p className="text-[10px] font-semibold text-muted-foreground px-1 mb-1">{cat}</p>
                          <div className="flex flex-wrap gap-0.5">
                            {items.map(e => (
                              <button key={e} onClick={() => { insert(e); setShowEmojis(false); }}
                                className="h-7 w-7 flex items-center justify-center text-base hover:bg-muted rounded">
                                {e}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <Textarea ref={textareaRef} value={contenido} onChange={e => setContenido(e.target.value)}
                placeholder="Escribe el cuerpo del mensaje aquí..." className="min-h-52 font-mono text-sm resize-y" />
            </div>

            {/* Actions */}
            <div className="flex gap-2 flex-wrap pt-1">
              <Button onClick={handleSave} disabled={saving} className="gradient-primary text-primary-foreground flex-1 sm:flex-none">
                {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                {editingId ? 'Actualizar' : 'Guardar en Supabase'}
              </Button>
              <Button variant="outline" onClick={() => handleCopy()} disabled={!contenido}>
                <Copy className="w-4 h-4 mr-2" />Copiar
              </Button>
              <Button variant="ghost" onClick={handleClear}>
                <RotateCcw className="w-4 h-4 mr-2" />Limpiar
              </Button>
            </div>
          </div>
        </div>

        {/* RIGHT – Preview */}
        <div className="space-y-4">
          <div className="bg-card border border-border rounded-xl p-5 h-full flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Vista previa</span>
              <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${meta.color}`}>{meta.label}</span>
            </div>

            {titulo && (
              <div className="text-sm font-bold text-foreground border-b border-border pb-2">{titulo}</div>
            )}

            <div className="flex-1 min-h-48 bg-muted/20 rounded-lg p-4 text-sm text-foreground whitespace-pre-wrap break-words font-mono leading-relaxed">
              {preview || <span className="text-muted-foreground italic">El contenido aparecerá aquí...</span>}
            </div>

            {(tipo === 'informativa' || tipo === 'broadcast') && (fechaProgramada || horaProgramada) && (
              <div className="border-t border-border pt-3">
                <p className="text-xs text-foreground font-mono">
                  {fechaProgramada && `📆 ${new Date(fechaProgramada + 'T00:00:00').toLocaleDateString('es', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}`}
                  {horaProgramada && `  🕐 ${to12h(horaProgramada)}`}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── Saved templates table ── */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-primary" />
            <span className="font-semibold text-foreground text-sm">Plantillas guardadas</span>
            <Badge variant="secondary" className="text-xs">
              {mensajes.filter(m => filtroEstado === 'todos' || (m.estado ?? 'draft') === filtroEstado).length}
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            <Select value={filtroEstado} onValueChange={setFiltroEstado}>
              <SelectTrigger className="h-8 text-xs w-40">
                <SelectValue placeholder="Filtrar por estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">🔎 Todos los estados</SelectItem>
                {ESTADOS.map(e => (
                  <SelectItem key={e.value} value={e.value}>{e.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="ghost"
              size="sm"
              title="Guardar como filtro predeterminado"
              onClick={handleGuardarFiltro}
              disabled={filtroEstado === filtroGuardado}
              className="h-8 px-2 text-xs gap-1"
            >
              <Save className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Guardar</span>
            </Button>
            <Button variant="ghost" size="sm" onClick={fetchMensajes} disabled={loadingList}>
              {loadingList ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RotateCcw className="w-3.5 h-3.5" />}
            </Button>
          </div>
        </div>

        {loadingList ? (
          <div className="flex justify-center items-center py-12 gap-2 text-muted-foreground">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span className="text-sm">Cargando plantillas...</span>
          </div>
        ) : mensajes.length === 0 ? (
          <div className="py-12 text-center text-muted-foreground">
            <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No hay plantillas guardadas aún.</p>
            <p className="text-xs mt-1">Crea y guarda tu primera plantilla arriba.</p>
          </div>
        ) : (() => {
          const mensajesFiltrados = mensajes.filter(m =>
            filtroEstado === 'todos' || (m.estado ?? 'draft') === filtroEstado
          );
          return (
          <div className="overflow-x-auto">
            {mensajesFiltrados.length === 0 ? (
              <div className="py-10 text-center text-muted-foreground">
                <MessageSquare className="w-7 h-7 mx-auto mb-2 opacity-30" />
                <p className="text-sm">No hay mensajes con ese estado.</p>
              </div>
            ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  {['Emoji', 'Título', 'Tipo', 'Destinatario', 'Prioridad', 'Estado', 'Fecha', 'Acciones'].map(h => (
                    <th key={h} className="text-left py-3 px-4 text-muted-foreground font-medium text-xs uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {mensajesFiltrados.map(m => {
                  const mt = tipoMeta(m.tipo);
                  const pr = PRIORIDADES.find(p => p.value === m.prioridad) || PRIORIDADES[1];
                  const es = ESTADOS.find(s => s.value === m.estado) || ESTADOS[0];
                  return (
                    <tr key={m.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                      <td className="py-3 px-4 text-lg">{m.emoji || '📬'}</td>
                      <td className="py-3 px-4 font-medium text-foreground max-w-xs truncate">{m.titulo}</td>
                      <td className="py-3 px-4">
                        <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${mt.color}`}>{mt.label}</span>
                      </td>
                      <td className="py-3 px-4 text-muted-foreground text-xs">{m.destinatario || '—'}</td>
                      <td className="py-3 px-4">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${pr.color}`}>{pr.label}</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${es.color}`}>{es.label}</span>
                      </td>
                      <td className="py-3 px-4 text-xs">
                        {m.updated_at && m.updated_at !== m.created_at ? (
                          <div>
                            <p className="text-foreground">
                              {new Date(m.updated_at).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' })}
                            </p>
                            <p className="text-[10px] text-muted-foreground">Actualizado</p>
                          </div>
                        ) : (
                          <div>
                            <p className="text-muted-foreground">
                              {new Date(m.created_at).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' })}
                            </p>
                            <p className="text-[10px] text-muted-foreground">Creado</p>
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7" title="Cargar en editor" onClick={() => handleLoad(m)}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7" title="Copiar contenido" onClick={() => handleCopy(m.contenido)}>
                            <Copy className="w-3.5 h-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" title="Eliminar" onClick={() => handleDelete(m.id)}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                          {(m.tipo === 'informativa' || m.tipo === 'broadcast') && (
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-blue-500 hover:text-blue-600" title="Ver estado de envíos" onClick={() => handleVerEstados(m)}>
                              <CalendarCheck className="w-3.5 h-3.5" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            )}
          </div>
          );
        })()}
      </div>

      {/* ── Modal historial de envíos ── */}
      {estadoModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
          onClick={() => setEstadoModal(null)}
        >
          <div
            className="bg-card border border-border rounded-xl shadow-2xl w-full max-w-lg max-h-[80vh] overflow-hidden flex flex-col"
            onClick={e => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <div className="flex items-center gap-2">
                <CalendarCheck className="w-4 h-4 text-primary" />
                <span className="font-semibold text-sm">Estado de envíos</span>
              </div>
              <button onClick={() => setEstadoModal(null)} className="p-1 hover:bg-muted rounded transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Mensaje info */}
            <div className="px-5 py-3 border-b border-border bg-muted/20">
              <p className="text-xs text-muted-foreground mb-0.5">Plantilla</p>
              <p className="font-medium text-sm truncate">{estadoModal.emoji} {estadoModal.titulo}</p>
            </div>

            {/* Contenido */}
            <div className="overflow-y-auto flex-1 p-5">
              {loadingEnviosModal ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                </div>
              ) : !programadoModal ? (
                <p className="text-sm text-muted-foreground text-center py-8">
                  Sin programación guardada. Edita el mensaje y selecciona fecha de envío.
                </p>
              ) : (
                <div className={`flex items-center justify-between p-3 rounded-lg border text-sm transition-all ${
                  programadoModal.estado === 'enviado'
                    ? 'border-green-500/40 bg-green-500/5'
                    : 'border-border bg-muted/20'
                }`}>
                  <div className="flex items-center gap-2">
                    {programadoModal.estado === 'enviado' ? (
                      <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border-2 border-muted-foreground/40 flex-shrink-0" />
                    )}
                    <div>
                      <p className="font-medium text-foreground">
                        {`📆 ${new Date(programadoModal.fecha + 'T00:00:00').toLocaleDateString('es', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}`}
                      </p>
                      {programadoModal.hora && (
                        <p className="text-xs text-muted-foreground">🕐 {to12h(programadoModal.hora)}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={programadoModal.estado === 'enviado' ? 'text-green-600 font-semibold text-xs' : 'text-amber-500 font-medium text-xs'}>
                      {programadoModal.estado === 'enviado' ? '✅ Enviado' : '⏳ Programado'}
                    </span>
                    <button
                      onClick={() => handleCambiarEstadoModal(programadoModal.estado === 'enviado' ? 'programado' : 'enviado')}
                      className={`text-[10px] px-2 py-1 rounded font-semibold transition-all ${
                        programadoModal.estado === 'enviado'
                          ? 'bg-amber-500/10 text-amber-600 hover:bg-amber-500/20'
                          : 'bg-green-500/10 text-green-600 hover:bg-green-500/20'
                      }`}
                    >
                      {programadoModal.estado === 'enviado' ? 'Revertir' : 'Marcar enviado'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
