# 🚀 Optimizaciones de Memoria del Backend

## Descripción General

El backend ahora incluye **optimizaciones agresivas de memoria** para mantener el uso de heap bajo y evitar memory leaks en producción.

## ⚙️ Características de Optimización

### 1. **Garbage Collection Manual Habilitado**
- Se ejecuta `node --expose-gc` para permitir control manual de GC
- El middleware detecta cuando el heap supera 90% y fuerza GC manual
- Alerta crítica cuando se alcanza 95%

### 2. **Caché Inteligente**
- **queryCache** (eventos): TTL de 1 segundo, máximo 50 items
- **reportesCache**: TTL de 2 minutos, máximo 50 items
- Evicción FIFO cuando se alcanza el límite

### 3. **Limpieza Automática**
- Limpieza de caché expirado cada 2 minutos
- Limpieza completa de caché a 95% de uso

## 🏃 Ejecución

### **Opción 1: Con npm (Recomendado)**
```bash
cd backend
npm install
npm start
```

### **Opción 2: Directo con Node**
```bash
cd backend
node --expose-gc server.js
```

## 📊 Monitoreo de Memoria

### Health Check Endpoint
```bash
curl http://localhost:3000/api/health
```

**Respuesta de ejemplo:**
```json
{
  "status": "ok",
  "uptime": 1234.56,
  "memory": {
    "heapUsed": "45.32MB",
    "heapTotal": "52.48MB",
    "rss": "89.23MB",
    "heapPercentage": "86.3%",
    "status": "NORMAL"
  },
  "cache": {
    "queryCache": 12,
    "reportesCache": 8
  },
  "timestamp": "2024-01-15T10:30:45.123Z"
}
```

**Estados posibles:**
- ✅ `NORMAL`: < 90% heap
- ⚠️ `HIGH`: 90-95% heap (GC forzado)
- 🚨 `CRITICAL`: > 95% heap (caché limpiado)

## 📈 Logs de Monitoreo

Observarás estos mensajes en la consola:

```
✅ Cache hit: /api/eventos (Respuesta rápida)
🔍 GET /api/eventos?limit=500 (Query a BD)
⚠️  Memoria alta: 47.23MB / 52.48MB (90%+) (Detectada, GC forzado)
🗑️  Activando garbage collection... (GC manual ejecutado)
🚨 ALERTA CRÍTICA: Memoria casi llena! (Caché limpiado completamente)
🗑️  Caché limpiado completamente
```

## 🔧 Configuración

Para ajustar los parámetros de caché, edita `backend/server.js`:

```javascript
// Cambiar TTL y límite máximo
const queryCache = new SimpleCache(1000, 100);  // 1s TTL, 100 items max
const reportesCache = new SimpleCache(120000, 100);  // 2min TTL, 100 items max
```

## ✅ Checklist de Producción

- [ ] Iniciar con `npm start` (incluye `--expose-gc`)
- [ ] Verificar `/api/health` regularmente
- [ ] Revisar logs para alertas de memoria
- [ ] Si heap > 95% frecuentemente, aumentar cache TTL o reducir maxSize
- [ ] Si heap < 50%, puede aumentar cache size para mejor performance

## 📌 Notas Importantes

1. **GC Manual**: Solo funciona con `--expose-gc`. Sin esta bandera, se usa GC automático de Node.js
2. **Production**: Monitorear con herramientas como PM2, New Relic o DataDog
3. **Database**: Las queries son cacheadas 1s. Para data más fresca, reduce el TTL
4. **Memory Limits**: Node.js por defecto usa ~1.5GB. Para aumentar:
   ```bash
   node --max-old-space-size=4096 --expose-gc server.js
   ```

