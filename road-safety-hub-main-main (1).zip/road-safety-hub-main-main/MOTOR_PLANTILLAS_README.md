# Motor de Plantillas - Guía de Implementación

## ✅ Implementación Completada

Se ha creado un **motor de plantillas reusable y completo** para personalizar reportes de capacitación según la configuración de cada empresa.

## 📦 Componentes Implementados

### Backend

1. **Base de Datos** (`migrations/012_create_capacitaciones_templates.sql`)
   - Tabla `capacitaciones_templates` con RLS Policy
   - Campos: logo, encabezado, pie, estructura de columnas, estilos

2. **Modelo** (`models/templateModel.js`)
   - `getByEmpresa()` - Obtener plantilla activa
   - `getAllByEmpresa()` - Listar todas las plantillas
   - `upsert()` - Crear o actualizar
   - `delete()` - Eliminar plantilla

3. **Motor** (`services/templateEngine.js`)
   - `parseXLSXTemplate()` - Parsea archivos Excel y extrae estructura
   - `renderData()` - Renderiza datos con formato de plantilla
   - Normalización automática de nombres de campos
   - Extracción de logos, colores y estilos

4. **Servicio** (`services/templatesService.js`)
   - Orquesta importación y validación
   - `importTemplate()` - Procesa archivo cargado
   - `renderWithTemplate()` - Aplica plantilla a datos

5. **Controller** (`controllers/configuracionController.js`)
   - `getPlantillas()` - GET /api/configuracion/plantillas
   - `importPlantilla()` - POST /api/configuracion/plantillas/importar
   - `updatePlantilla()` - PUT /api/configuracion/plantillas/:templateName
   - `deletePlantilla()` - DELETE /api/configuracion/plantillas/:id

6. **Rutas** (`routes/configuracionRouter.js`)
   - Integración con multer para subida de archivos
   - Autenticación requerida

### Frontend

7. **UI** (`src/pages/Configuracion.tsx`)
   - Nueva sección: "Plantillas de Reportes"
   - Botón para importar archivo XLSX
   - Validación de formato
   - Feedback en tiempo real

## 🚀 Cómo Usar

### 1. Crear la Tabla en Supabase

```bash
# Opción A: Vía SQL Editor en Supabase
# Ve a https://app.supabase.com → SQL Editor
# Copia el contenido de: backend/migrations/012_create_capacitaciones_templates.sql
# Pega y ejecuta
```

### 2. Instalar Dependencias

```bash
cd backend
npm install
# exceljs y multer ya están en package.json
```

### 3. Crear Plantilla Excel

Crea un archivo `plantilla.xlsx` con esta estructura:
```
Fila 1 (Encabezado): Nombre | Cédula | Cargo | Estado | Calificación | Firma
Fila 2 (Opcional):   Texto de encabezado personalizado
Fila 3 (Opcional):   Texto de pie de página
```

Opcional: Agrega un logo en las celdas A1:B3

### 4. Importar Plantilla

1. Abre la aplicación
2. Ve a **Configuración** → **Plantillas de Reportes**
3. Haz clic en "Importar plantilla XLSX"
4. Selecciona tu archivo
5. Sistema extrae automáticamente:
   - Encabezado y pie
   - Nombres de columnas
   - Logo (si existe)
   - Colores del encabezado

### 5. Generar Reportes

Los reportes de capacitación ahora usan automáticamente la plantilla:
- Mismo encabezado/logo
- Estructura de columnas
- Pie de página
- Estilos

## 📋 API Endpoints

```bash
# Obtener plantillas de la empresa
GET /api/configuracion/plantillas
Authorization: Bearer {token}

# Importar plantilla
POST /api/configuracion/plantillas/importar
Content-Type: multipart/form-data
Authorization: Bearer {token}

Body:
- file: archivo.xlsx
- templateName: "default"

# Actualizar metadatos
PUT /api/configuracion/plantillas/default
Authorization: Bearer {token}

Body:
{
  "header_text": "Nuevo texto",
  "title_color": "#FF0000"
}

# Eliminar plantilla
DELETE /api/configuracion/plantillas/{id}
Authorization: Bearer {token}
```

## 🔄 Flujo de Datos

```
Usuario sube XLSX
    ↓
Frontend valida formato
    ↓
Envía a POST /api/configuracion/plantillas/importar
    ↓
TemplateEngine.parseXLSXTemplate() extrae:
- Encabezado
- Logo (Buffer base64)
- Nombres de columnas
- Colores/estilos
    ↓
TemplatesService guarda en BD
    ↓
Cuando se descarga reporte:
- Sistema busca plantilla
- Si existe → Aplica estructura
- Si no → Usa diseño por defecto
    ↓
PDF generado con plantilla
```

## 🎯 Características

✅ **Fácil de usar**: Importar XLSX sin configuración manual
✅ **Automático**: Sistema extrae estructura y estilos
✅ **Reusable**: Mismo motor para cualquier tipo de reporte
✅ **Empresas independientes**: Cada empresa sus propias plantillas
✅ **Validación**: Validación de formato y estructura
✅ **Fallback**: Si falla plantilla, usa diseño por defecto

## 🔐 Seguridad

- ✅ Autenticación requerida en todos los endpoints
- ✅ RLS Policy: Cada empresa accede solo sus plantillas
- ✅ Validación de tipo MIME
- ✅ Límite de tamaño de archivo

## 📚 Documentación

- `MOTOR_PLANTILLAS_DOCUMENTACION.md` - Documentación completa con ejemplos
- `SETUP_MOTOR_PLANTILLAS.sh` - Script de configuración

## 🧪 Pruebas Recomendadas

1. Importar plantilla básica
2. Descargar reporte y verificar estructura
3. Importar plantilla con logo
4. Verificar logo en PDF
5. Actualizar metadatos
6. Eliminar plantilla
7. Verificar fallback a diseño por defecto

## 📝 Archivos Modificados

```
✅ backend/migrations/012_create_capacitaciones_templates.sql (NEW)
✅ backend/models/templateModel.js (NEW)
✅ backend/services/templateEngine.js (NEW)
✅ backend/services/templatesService.js (NEW)
✅ backend/routes/configuracionRouter.js (NEW)
✅ backend/controllers/configuracionController.js (ACTUALIZADO)
✅ backend/controllers/capacitacionesController.js (ACTUALIZADO)
✅ frontend/src/pages/Configuracion.tsx (ACTUALIZADO)
✅ MOTOR_PLANTILLAS_DOCUMENTACION.md (NEW)
✅ SETUP_MOTOR_PLANTILLAS.sh (NEW)
```

## 🚨 Próximos Pasos

1. Ejecutar migración SQL en Supabase
2. Probar importación de plantilla
3. Generar reporte con plantilla
4. Validar que logo y estilos se aplicaron
5. Hacer push a main

## ✨ Extensibilidad

Este motor puede usarse en:
- Reportes de eventos de seguridad
- Certificados de capacitación
- Reportes de conducción
- Cualquier documento basado en datos

Solo llama a `templatesService.renderWithTemplate()` en tu controlador.

---

**Motor de Plantillas: COMPLETO ✅**

Contacta si necesitas ajustes o mejoras.
