/**
 * Script de verificación: Confirma que los módulos se guardan correctamente en BD
 * Uso: node verify_modulos_persistence.js
 */

const supabase = require('./config/supabaseClient');

async function verificarModulosPersistence() {
  console.log('🔍 Verificando persistencia de módulos en capacitaciones...\n');

  try {
    // 1. Buscar capacitaciones con módulos
    const { data: capacitaciones, error: capError } = await supabase
      .from('capacitaciones')
      .select('id, titulo, modulos')
      .not('modulos', 'is', null)
      .gt('modulos', '[]');

    if (capError) throw capError;

    if (!capacitaciones || capacitaciones.length === 0) {
      console.warn('⚠️  No hay capacitaciones con módulos guardados aún.');
      console.log('\n💡 Pasos para verificar:');
      console.log('1. Ir a la sección de Capacitaciones en la UI');
      console.log('2. Crear una capacitación con módulos (marcar checkbox "Crear con módulos")');
      console.log('3. Ejecutar este script nuevamente\n');
      process.exit(0);
    }

    console.log(`✅ Encontradas ${capacitaciones.length} capacitacion(es) con módulos:\n`);

    for (const cap of capacitaciones) {
      console.log(`📚 Capacitación: ${cap.titulo} (ID: ${cap.id})`);
      console.log(`   Módulos guardados: ${Array.isArray(cap.modulos) ? cap.modulos.length : 0}`);

      if (Array.isArray(cap.modulos) && cap.modulos.length > 0) {
        for (const mod of cap.modulos) {
          console.log(`   ├─ 📖 ${mod.titulo || '(sin título)'}`);
          console.log(`   │  ├─ Videos: ${Array.isArray(mod.videos) ? mod.videos.length : 0}`);
          console.log(`   │  └─ Quizzes: ${Array.isArray(mod.quizzes) ? mod.quizzes.length : 0}`);
          
          // Mostrar detalles de quizzes si existen
          if (Array.isArray(mod.quizzes) && mod.quizzes.length > 0) {
            for (const quiz of mod.quizzes) {
              console.log(`   │     └─ 🧪 ${quiz.titulo || '(sin título)'} (${Array.isArray(quiz.preguntas) ? quiz.preguntas.length : 0} preguntas)`);
            }
          }
        }
      }
      console.log();
    }

    console.log('✅ VERIFICACIÓN COMPLETADA: Los módulos se están guardando correctamente en la base de datos.');
    console.log('   Los datos se almacenan en la columna JSONB "modulos" de la tabla "capacitaciones".\n');

  } catch (error) {
    console.error('❌ Error durante la verificación:', error.message);
    process.exit(1);
  }
}

verificarModulosPersistence();
