/**
 * Verificación de integridad del sistema de reportes
 * ✅ Asegurar que NO se crean reportes automáticamente
 * ✅ Solo se crean reportes cuando el usuario lo requiere
 */

const supabase = require('./config/supabaseClient');
const EventoModel = require('./models/eventoModel');
const ReporteModel = require('./models/reporteModel');

async function verificarIntegridad() {
  try {
    console.log('\n🔍 VERIFICACIÓN DE INTEGRIDAD DEL SISTEMA DE REPORTES\n');

    // 1. Contar reportes en la BD
    const { data: reportes, count: totalReportes, error: reportesError } = await supabase
      .from('reportes')
      .select('*', { count: 'exact' });

    if (reportesError) throw reportesError;

    console.log(`📊 Reportes en BD: ${totalReportes}`);
    if (reportes && reportes.length > 0) {
      console.log('Reportes actuales:');
      reportes.forEach(r => {
        console.log(`  - ID ${r.id}: "${r.nombre}" (Placa: ${r.placa})`);
      });
    }

    // 2. Obtener placas únicas de eventos
    const eventos = await EventoModel.getAll(100);
    const placasUnicas = Array.from(new Set(eventos.map(e => e.placa).filter(Boolean)));
    
    console.log(`\n🚗 Placas únicas en eventos: ${placasUnicas.length}`);
    placasUnicas.forEach(p => console.log(`  - ${p}`));

    // 3. Verificar que no hay un reporte por cada placa
    if (totalReportes !== placasUnicas.length) {
      console.log(`\n✅ ESTADO CORRECTO: ${totalReportes} reportes, ${placasUnicas.length} placas distintas`);
      console.log('   El sistema NO crea reportes automáticos por cada placa');
    } else if (totalReportes === placasUnicas.length && totalReportes > 1) {
      console.log(`\n⚠️  ALERTA: ${totalReportes} reportes y ${placasUnicas.length} placas - Verificar si son automáticos`);
      
      // Mostrar detalles
      reportes?.forEach(r => {
        const eventosDePlaca = eventos.filter(e => e.placa === r.placa).length;
        console.log(`   Reporte "${r.nombre}": placa="${r.placa}", eventos=${eventosDePlaca}`);
      });
    } else {
      console.log(`\n✅ ESTADO CORRECTO: Sistema funcionando correctamente`);
    }

    // 4. Mostrar últimos reportes creados
    console.log(`\n📋 Últimos reportes creados:\n`);
    const { data: ultimos, error: ultimosError } = await supabase
      .from('reportes')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(5);

    if (ultimosError) throw ultimosError;

    if (ultimos && ultimos.length > 0) {
      ultimos.forEach(r => {
        console.log(`  ID ${r.id}: "${r.nombre}"`);
        console.log(`    Fecha: ${new Date(r.created_at).toLocaleString('es-ES')}`);
        console.log(`    Usuario: ${r.usuario}`);
        console.log(`    Placa: ${r.placa}`);
      });
    } else {
      console.log('  ✅ No hay reportes en la BD');
    }

    console.log('\n' + '='.repeat(60) + '\n');
    process.exit(0);
  } catch (err) {
    console.error('❌ Error en verificación:', err.message);
    process.exit(1);
  }
}

verificarIntegridad();
