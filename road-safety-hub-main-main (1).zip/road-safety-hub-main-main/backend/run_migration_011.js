require('dotenv').config();
const url = process.env.SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
const projectRef = url.match(/https:\/\/([^.]+)\.supabase\.co/)[1];

const sqls = [
  `ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS conductor_id UUID REFERENCES conductores(id) ON DELETE SET NULL`,
  `CREATE INDEX IF NOT EXISTS idx_usuarios_conductor_id ON usuarios(conductor_id)`,
  `INSERT INTO roles (nombre, descripcion) VALUES ('conductor', 'Conductor con acceso al portal') ON CONFLICT (nombre) DO NOTHING`,
  `CREATE TABLE IF NOT EXISTS capacitaciones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    titulo VARCHAR(255) NOT NULL,
    descripcion TEXT,
    contenido_url TEXT,
    tipo VARCHAR(50) DEFAULT 'documento' CHECK (tipo IN ('video','documento','quiz','presencial')),
    duracion_minutos INTEGER DEFAULT 0,
    empresa VARCHAR(255),
    activo BOOLEAN DEFAULT true,
    created_by UUID,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
  )`,
  `CREATE INDEX IF NOT EXISTS idx_capacitaciones_empresa ON capacitaciones(empresa)`,
  `CREATE INDEX IF NOT EXISTS idx_capacitaciones_activo ON capacitaciones(activo)`,
  `CREATE TABLE IF NOT EXISTS asignaciones_capacitacion (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    capacitacion_id UUID NOT NULL REFERENCES capacitaciones(id) ON DELETE CASCADE,
    conductor_id UUID NOT NULL REFERENCES conductores(id) ON DELETE CASCADE,
    estado VARCHAR(50) DEFAULT 'pendiente' CHECK (estado IN ('pendiente','en_progreso','completado')),
    fecha_asignacion TIMESTAMP DEFAULT NOW(),
    fecha_completado TIMESTAMP,
    observaciones TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(capacitacion_id, conductor_id)
  )`,
  `CREATE INDEX IF NOT EXISTS idx_asignaciones_conductor_id ON asignaciones_capacitacion(conductor_id)`,
  `CREATE INDEX IF NOT EXISTS idx_asignaciones_capacitacion_id ON asignaciones_capacitacion(capacitacion_id)`,
  `CREATE INDEX IF NOT EXISTS idx_asignaciones_estado ON asignaciones_capacitacion(estado)`,
];

async function run() {
  console.log(`\nProyecto: ${projectRef}\n`);
  for (const sql of sqls) {
    const desc = sql.trim().substring(0, 65) + '...';
    try {
      // Intentar primero via Management API
      const r = await fetch(`https://api.supabase.com/v1/projects/${projectRef}/database/query`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${key}`
        },
        body: JSON.stringify({ query: sql })
      });
      const body = await r.json().catch(() => ({}));
      if (r.ok) {
        console.log('✅', desc);
      } else {
        console.log('⚠️ ', desc);
        console.log('   ->', body?.message || body?.error || JSON.stringify(body).substring(0, 120));
      }
    } catch (e) {
      console.log('❌', desc, '->', e.message);
    }
  }
  console.log('\nListo.\n');
}

run();
