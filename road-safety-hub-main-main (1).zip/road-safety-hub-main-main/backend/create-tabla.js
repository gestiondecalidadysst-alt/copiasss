#!/usr/bin/env node

/**
 * Script para crear la tabla mensajes directamente en Supabase
 * Usa PostgreSQL cliente (pg) para conectar directamente
 */

const { Client } = require('pg');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

// Extraer credenciales
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl) {
  console.error('❌ Error: SUPABASE_URL no encontrada en .env');
  process.exit(1);
}

// Construir URL de conexión PostgreSQL desde Supabase URL
// Formato: https://project.supabase.co -> postgresql://...@project.supabase.co
const urlMatch = supabaseUrl.match(/https:\/\/([^.]+)\.supabase\.co/);
if (!urlMatch) {
  console.error('❌ Error: Formato de SUPABASE_URL inválido');
  process.exit(1);
}

const projectRef = urlMatch[1];
console.log(`\n📍 Proyecto Supabase: ${projectRef}\n`);

// Nota: Esta forma de conexión requiere credenciales de base de datos
// que normalmente no vienen con las claves anon
console.log('⚠️  IMPORTANTE:\n');
console.log('Para conectar directamente a PostgreSQL necesitamos usar una URL de conexión');
console.log('con credenciales de base de datos.\n');

console.log('📋 OPCIÓN 1: Si tienes Supabase CLI instalado (RECOMENDADO):\n');
console.log('   npm install -g supabase');
console.log('   supabase projects list  (para obtener tu proyecto)');
console.log('   supabase db push\n');

console.log('📋 OPCIÓN 2: Obtener credenciales de Base de Datos:\n');
console.log('   1. Ve a: https://supabase.com/dashboard');
console.log('   2. Selecciona tu proyecto');
console.log('   3. Ve a Settings > Database > Connection String');
console.log('   4. Copia la connection string en formato "Session pooler"');
console.log('   5. Agregala a .env como: DATABASE_URL=<connection_string>\n');

console.log('📋 OPCIÓN 3: Ejecutar SQL manualmente (MÁS RÁPIDO):\n');

// Leer y mostrar el SQL
const sqlFile = path.join(__dirname, 'migrations', '002_create_mensajes_table.sql');
const sqlContent = fs.readFileSync(sqlFile, 'utf-8');

console.log('Copia todo esto:\n');
console.log('═'.repeat(70));
console.log(sqlContent);
console.log('═'.repeat(70) + '\n');

console.log('Y ejecutalo en: https://supabase.com/dashboard -> SQL Editor\n');

// Verificar si existe DATABASE_URL
const databaseUrl = process.env.DATABASE_URL;

if (databaseUrl) {
  console.log('✅ DATABASE_URL encontrada en .env\n');
  console.log('🔄 Intentando conectar...\n');
  
  createTableViaSQL(databaseUrl, sqlContent);
} else {
  console.log('⚠️  DATABASE_URL no encontrada en .env');
  console.log('Por favor, agrega una de las opciones arriba y vuelve a intentar.\n');
}

async function createTableViaSQL(connectionString, sql) {
  const client = new Client({
    connectionString: connectionString,
    ssl: { rejectUnauthorized: false }
  });

  try {
    console.log('🔗 Conectando a base de datos...');
    await client.connect();
    console.log('✅ Conexión exitosa\n');

    // Separar statements
    const statements = sql
      .split(';')
      .map(stmt => {
        const trimmed = stmt
          .split('\n')
          .filter(line => !line.trim().startsWith('--'))
          .join('\n')
          .trim();
        return trimmed;
      })
      .filter(stmt => stmt.length > 0);

    console.log(`📝 Ejecutando ${statements.length} comandos...\n`);

    let successCount = 0;
    
    for (let i = 0; i < statements.length; i++) {
      const stmt = statements[i];
      const shortStmt = stmt.substring(0, 60).replace(/\s+/g, ' ');
      
      try {
        console.log(`[${i + 1}/${statements.length}] ${shortStmt}...`);
        await client.query(stmt);
        console.log('   ✅ OK\n');
        successCount++;
      } catch (error) {
        console.error(`   ❌ Error: ${error.message}\n`);
      }
    }

    console.log('╔════════════════════════════════════════════════════════╗');
    console.log('║         ✨ ¡TABLA CREADA EXITOSAMENTE! ✨            ║');
    console.log('╚════════════════════════════════════════════════════════╝\n');
    
    console.log(`✅ ${successCount}/${statements.length} comandos ejecutados\n`);

    console.log('📊 Tabla "mensajes" creada con campos para:\n');
    console.log('  • Contenido: titulo, tipo, contenido, asunto');
    console.log('  • Prioridad: prioridad, estado, emoji');
    console.log('  • Media: media_type, media_url, media_size, file_name ← NUEVO');
    console.log('  • Scheduling: fecha_programada');
    console.log('  • Tracking: enviados, visualizados');
    console.log('  • Metadata: created_at, updated_at, conductor_id\n');

    console.log('📈 Índices creados: tipo, estado, created_at, conductor_id');
    console.log('🔐 RLS habilitado con políticas de seguridad\n');

    console.log('⏭️  Próximos pasos:\n');
    console.log('  1. Crea el bucket "mensaje-media" en Storage (Supabase UI)');
    console.log('  2. npm start (iniciar servidor)');
    console.log('  3. Abre http://localhost:5173/mensajes\n');

  } catch (error) {
    console.error('❌ Error de conexión:', error.message);
    console.log('\n💡 Asegúrate de que DATABASE_URL es correcta y que Supabase está disponible\n');
  } finally {
    await client.end();
  }
}
