/**
 * Script para crear tablas de usuarios y roles usando Supabase Client
 * Este método es más compatible que ejecutar SQL raw
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Error: Faltan credenciales de Supabase en .env');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function crearTablasDirectamente() {
  console.log('🔄 Creando tablas de usuarios y roles...\n');
  console.log('⚠️  IMPORTANTE: Este script requiere que ejecutes el SQL manualmente\n');
  console.log('Las tablas de usuarios requieren permisos especiales que solo se pueden');
  console.log('configurar desde el SQL Editor de Supabase.\n');
  
  console.log('═══════════════════════════════════════════════════════════════\n');
  console.log('Por favor, ve a: https://app.supabase.com\n');
  console.log('1. Abre tu proyecto');
  console.log('2. Ve a "SQL Editor"');
  console.log('3. Crea una nueva query');
  console.log('4. Copia el contenido del archivo:');
  console.log('   backend/migrations/004_create_users_and_roles.sql\n');
  console.log('5. Pégalo y ejecuta con "Run"\n');
  console.log('═══════════════════════════════════════════════════════════════\n');

  // Intentar verificar si ya existen las tablas
  console.log('🧪 Verificando si las tablas ya existen...\n');

  const tablesToCheck = [
    { name: 'roles', description: 'Tabla de roles del sistema' },
    { name: 'usuarios', description: 'Tabla de usuarios' },
    { name: 'usuario_roles', description: 'Relación usuario-rol' }
  ];

  let allTablesExist = true;

  for (const table of tablesToCheck) {
    try {
      const { data, error } = await supabase
        .from(table.name)
        .select('*')
        .limit(1);

      if (error && error.code === 'PGRST204') {
        // La tabla existe pero está vacía
        console.log(`✅ ${table.name}: Tabla existe (vacía)`);
      } else if (error && (error.code === '42P01' || error.message.includes('does not exist'))) {
        console.log(`❌ ${table.name}: Tabla NO existe - ${table.description}`);
        allTablesExist = false;
      } else if (error) {
        console.log(`⚠️  ${table.name}: ${error.message.substring(0, 60)}...`);
        allTablesExist = false;
      } else {
        console.log(`✅ ${table.name}: Tabla existe (${data ? data.length : 0} registros)`);
      }
    } catch (err) {
      console.log(`❌ ${table.name}: Error al verificar - ${err.message.substring(0, 60)}`);
      allTablesExist = false;
    }
  }

  console.log('\n═══════════════════════════════════════════════════════════════\n');

  if (allTablesExist) {
    console.log('✅ ¡Las tablas ya existen!\n');
    console.log('Puedes ejecutar ahora:');
    console.log('  node crear_admin_inicial.js\n');
    return true;
  } else {
    console.log('❌ Faltan tablas por crear\n');
    console.log('Ejecuta el SQL manualmente en Supabase SQL Editor');
    console.log('Archivo: backend/migrations/004_create_users_and_roles.sql\n');
    console.log('O si prefieres, copia el siguiente SQL:\n');
    console.log('═══════════════════════════════════════════════════════════════\n');
    
    const fs = require('fs');
    const path = require('path');
    const sqlFile = path.join(__dirname, 'migrations', '004_create_users_and_roles.sql');
    const sqlContent = fs.readFileSync(sqlFile, 'utf-8');
    console.log(sqlContent);
    console.log('\n═══════════════════════════════════════════════════════════════\n');
    
    return false;
  }
}

crearTablasDirectamente()
  .then((success) => {
    if (success) {
      process.exit(0);
    } else {
      console.log('\n⏳ Ejecuta el SQL en Supabase y luego continúa\n');
      process.exit(1);
    }
  })
  .catch((error) => {
    console.error('❌ Error:', error.message);
    process.exit(1);
  });
