const supabase = require('../config/supabaseClient');

class PortalConductorController {
  /** Perfil completo del conductor autenticado */
  static async getPerfil(req, res) {
    try {
      const conductorId = req.usuario.conductor_id;
      if (!conductorId) return res.status(404).json({ error: 'Perfil de conductor no vinculado' });

      const { data, error } = await supabase
        .from('conductores')
        .select('*')
        .eq('id', conductorId)
        .single();
      if (error) throw error;
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Eventos de velocidad del vehículo asignado al conductor */
  static async getEventos(req, res) {
    try {
      const conductorId = req.usuario.conductor_id;
      if (!conductorId) return res.json([]);

      const { data: conductor, error: cError } = await supabase
        .from('conductores')
        .select('vehiculo')
        .eq('id', conductorId)
        .single();
      if (cError) throw cError;
      if (!conductor?.vehiculo) return res.json([]);

      const { data, error } = await supabase
        .from('EXCESOS DE VELOCIDAD')
        .select('*')
        .ilike('placa', `%${conductor.vehiculo.trim()}%`)
        .order('created_at', { ascending: false })
        .limit(200);
      if (error) throw error;
      res.json(data || []);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Mensajes recibidos por el conductor */
  static async getMensajes(req, res) {
    try {
      const conductorId = req.usuario.conductor_id;
      if (!conductorId) return res.json([]);

      const { data, error } = await supabase
        .from('mensajes')
        .select('id, titulo, contenido, tipo, prioridad, estado, created_at')
        .eq('conductor_id', conductorId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      res.json(data || []);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Capacitaciones asignadas al conductor */
  static async getCapacitaciones(req, res) {
    try {
      const conductorId = req.usuario.conductor_id;
      if (!conductorId) return res.json([]);

      const { data, error } = await supabase
        .from('asignaciones_capacitacion')
        .select('*, capacitacion:capacitaciones(id, titulo, descripcion, contenido_url, tipo, duracion_minutos, modulos)')
        .eq('conductor_id', conductorId)
        .order('fecha_asignacion', { ascending: false });
      if (error) throw error;
      res.json(data || []);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** El conductor actualiza su propio estado de capacitación */
  static async actualizarEstadoCapacitacion(req, res) {
    try {
      const conductorId = req.usuario.conductor_id;
      if (!conductorId) return res.status(403).json({ error: 'No autorizado' });

      const { estado } = req.body;
      const estadosValidos = ['en_progreso', 'completado'];
      if (!estadosValidos.includes(estado)) {
        return res.status(400).json({ error: 'Estado inválido' });
      }

      const updates = { estado, updated_at: new Date() };
      if (estado === 'completado') updates.fecha_completado = new Date();

      // conductor_id en el filtro garantiza que solo puede editar sus propias asignaciones
      const { data, error } = await supabase
        .from('asignaciones_capacitacion')
        .update(updates)
        .eq('id', req.params.id)
        .eq('conductor_id', conductorId)
        .select()
        .single();
      if (error) throw error;
      if (!data) return res.status(404).json({ error: 'Asignación no encontrada' });
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Resumen / KPIs del conductor para su dashboard */
  static async getResumen(req, res) {
    try {
      const conductorId = req.usuario.conductor_id;
      if (!conductorId) return res.json({ score: 0, eventos: 0, mensajes: 0, capacitaciones: { pendientes: 0, completadas: 0 } });

      const { data: conductor } = await supabase
        .from('conductores')
        .select('score, vehiculo')
        .eq('id', conductorId)
        .single();

      // Contar eventos del mes actual
      const inicioMes = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString();
      let eventosCount = 0;
      if (conductor?.vehiculo) {
        const { count } = await supabase
          .from('EXCESOS DE VELOCIDAD')
          .select('*', { count: 'exact', head: true })
          .ilike('placa', `%${conductor.vehiculo.trim()}%`)
          .gte('created_at', inicioMes);
        eventosCount = count || 0;
      }

      // Contar mensajes no leídos (asumimos enviados = no leídos sin campo leido)
      const { count: mensajesCount } = await supabase
        .from('mensajes')
        .select('*', { count: 'exact', head: true })
        .eq('conductor_id', conductorId);

      // Capacitaciones por estado
      const { data: caps } = await supabase
        .from('asignaciones_capacitacion')
        .select('estado')
        .eq('conductor_id', conductorId);
      const pendientes = (caps || []).filter((c) => c.estado === 'pendiente').length;
      const completadas = (caps || []).filter((c) => c.estado === 'completado').length;

      res.json({
        score: conductor?.score || 0,
        eventos: eventosCount,
        mensajes: mensajesCount || 0,
        capacitaciones: { pendientes, completadas }
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Quiz de una asignación específica (sin revelar respuestas correctas) */
  static async getQuizConductor(req, res) {
    try {
      const conductorId = req.usuario.conductor_id;
      if (!conductorId) return res.status(403).json({ error: 'No autorizado' });

      const { data: asig, error: aErr } = await supabase
        .from('asignaciones_capacitacion')
        .select('id, capacitacion_id, etapa, quiz_completado, quiz_intentos')
        .eq('id', req.params.id)
        .eq('conductor_id', conductorId)
        .single();
      if (aErr || !asig) return res.status(404).json({ error: 'Asignación no encontrada' });

      // Preguntas SIN es_correcta (ocultar respuestas)
      const { data, error } = await supabase
        .from('preguntas_capacitacion')
        .select('id, pregunta, tipo, orden, opciones:opciones_pregunta(id, texto, orden)')
        .eq('capacitacion_id', asig.capacitacion_id)
        .order('orden');
      if (error) throw error;

      const { data: cap } = await supabase
        .from('capacitaciones')
        .select('porcentaje_aprobacion')
        .eq('id', asig.capacitacion_id)
        .single();

      const intentosUsados = asig.quiz_intentos || 0;
      res.json({
        preguntas: data || [],
        etapa: asig.etapa,
        quiz_completado: asig.quiz_completado,
        quiz_intentos: intentosUsados,
        intentos_restantes: Math.max(0, 2 - intentosUsados),
        porcentaje_aprobacion: cap?.porcentaje_aprobacion ?? 70
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Actualizar progreso del video. Avanza etapa automáticamente al llegar al 80% */
  static async actualizarProgresoVideo(req, res) {
    try {
      const conductorId = req.usuario.conductor_id;
      if (!conductorId) return res.status(403).json({ error: 'No autorizado' });

      const progresoNum = Math.min(100, Math.max(0, Number(req.body.progreso) || 0));

      const { data: asig, error: aErr } = await supabase
        .from('asignaciones_capacitacion')
        .select('id, etapa, capacitacion_id')
        .eq('id', req.params.id)
        .eq('conductor_id', conductorId)
        .single();
      if (aErr || !asig) return res.status(404).json({ error: 'Asignación no encontrada' });

      const updates = { progreso_video: progresoNum, estado: 'en_progreso' };

      // Avanzar etapa solo si todavía está en 'contenido' y alcanzó el 80%
      if (progresoNum >= 80 && asig.etapa === 'contenido') {
        const { count } = await supabase
          .from('preguntas_capacitacion')
          .select('*', { count: 'exact', head: true })
          .eq('capacitacion_id', asig.capacitacion_id);

        if (count && count > 0) {
          updates.etapa = 'quiz';
        } else {
          updates.etapa = 'completado';
          updates.estado = 'completado';
          updates.fecha_completado = new Date();
        }
      }

      const { data, error } = await supabase
        .from('asignaciones_capacitacion')
        .update(updates)
        .eq('id', req.params.id)
        .eq('conductor_id', conductorId)
        .select()
        .single();
      if (error) throw error;
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Enviar respuestas del quiz, calcular puntaje y marcar completado */
  static async responderQuiz(req, res) {
    try {
      const conductorId = req.usuario.conductor_id;
      if (!conductorId) return res.status(403).json({ error: 'No autorizado' });

      const { respuestas } = req.body;
      if (!Array.isArray(respuestas) || respuestas.length === 0) {
        return res.status(400).json({ error: 'respuestas es requerido' });
      }

      const { data: asig, error: aErr } = await supabase
        .from('asignaciones_capacitacion')
        .select('id, capacitacion_id, quiz_intentos')
        .eq('id', req.params.id)
        .eq('conductor_id', conductorId)
        .single();
      if (aErr || !asig) return res.status(403).json({ error: 'No autorizado' });

      // Verificar límite de 2 intentos
      const intentosUsados = asig.quiz_intentos || 0;
      if (intentosUsados >= 2) {
        return res.status(403).json({ error: 'Has alcanzado el máximo de 2 intentos para este quiz' });
      }

      // Obtener preguntas con puntos y respuestas correctas
      const { data: preguntas, error: pErr } = await supabase
        .from('preguntas_capacitacion')
        .select('id, puntos, opciones:opciones_pregunta(id, es_correcta)')
        .eq('capacitacion_id', asig.capacitacion_id);
      if (pErr) throw pErr;

      let puntosObtenidos = 0;
      const totalPuntos = (preguntas || []).reduce((acc, p) => acc + (p.puntos || 1), 0);

      const filas = respuestas.map((r) => {
        const pregunta = (preguntas || []).find((p) => p.id === r.pregunta_id);
        const opcion = pregunta?.opciones?.find((o) => o.id === r.opcion_id);
        const esCorrecta = opcion?.es_correcta || false;
        if (esCorrecta) puntosObtenidos += (pregunta?.puntos || 1);
        return {
          asignacion_id: asig.id,
          pregunta_id: r.pregunta_id,
          opcion_id: r.opcion_id,
          es_correcta: esCorrecta
        };
      });

      await supabase
        .from('respuestas_conductor')
        .upsert(filas, { onConflict: 'asignacion_id,pregunta_id' });

      // Puntaje ponderado por puntos de cada pregunta
      const puntaje = totalPuntos > 0
        ? Math.round((puntosObtenidos / totalPuntos) * 100)
        : 0;

      // Obtener porcentaje mínimo de aprobación
      const { data: cap } = await supabase
        .from('capacitaciones')
        .select('porcentaje_aprobacion')
        .eq('id', asig.capacitacion_id)
        .single();
      const porcentajeAprobacion = cap?.porcentaje_aprobacion ?? 70;

      const nuevoIntentos = intentosUsados + 1;
      const aprobado = puntaje >= porcentajeAprobacion;
      const agotadoIntentos = nuevoIntentos >= 2;

      const updates = {
        quiz_intentos: nuevoIntentos,
        quiz_puntaje: puntaje,
      };

      // Marcar completado si aprobó o agotó los intentos
      if (aprobado || agotadoIntentos) {
        updates.quiz_completado = true;
        updates.estado = 'completado';
        updates.etapa = 'completado';
        updates.fecha_completado = new Date();
      }

      await supabase
        .from('asignaciones_capacitacion')
        .update(updates)
        .eq('id', asig.id);

      res.json({
        puntaje,
        puntosObtenidos,
        totalPuntos,
        total: respuestas.length,
        aprobado,
        porcentaje_aprobacion: porcentajeAprobacion,
        intentos_usados: nuevoIntentos,
        intentos_restantes: Math.max(0, 2 - nuevoIntentos)
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  // ── MÓDULOS (ESTRUCTURA NUEVA CON MÚLTIPLES ACTIVIDADES) ─────────────────

  /** Obtener todos los módulos de una capacitación con videos y quizzes */
  static async getModulosCapacitacion(req, res) {
    try {
      const conductorId = req.usuario.conductor_id;
      if (!conductorId) return res.status(403).json({ error: 'No autorizado' });

      // Verificar acceso a la asignación
      const { data: asig, error: aErr } = await supabase
        .from('asignaciones_capacitacion')
        .select('id, capacitacion_id, estado, progreso_modulos')
        .eq('id', req.params.id)
        .eq('conductor_id', conductorId)
        .single();
      if (aErr || !asig) return res.status(403).json({ error: 'No autorizado' });

      // Obtener módulos desde la capacitación almacenados en JSONB
      const { data: capacitacion, error: capErr } = await supabase
        .from('capacitaciones')
        .select('modulos')
        .eq('id', asig.capacitacion_id)
        .single();
      if (capErr || !capacitacion) throw capErr || new Error('Capacitación no encontrada');

      const modulosList = Array.isArray(capacitacion.modulos) ? capacitacion.modulos : [];

      // Agregar cálculo de progreso parcial por módulo (videos y quizzes)
      // Recolectar ids para consultas
      const allVideoIds = [];
      const allQuizIds = [];
      for (const m of modulosList) {
        if (Array.isArray(m.videos)) for (const v of m.videos) allVideoIds.push(v.id);
        if (Array.isArray(m.quizzes)) for (const q of m.quizzes) allQuizIds.push(q.id);
      }

      // Consultar progreso de videos
      let progresoVideos = [];
      if (allVideoIds.length > 0) {
        const { data: pvData, error: pvErr } = await supabase
          .from('progreso_videos')
          .select('video_id, progreso')
          .eq('asignacion_id', asig.id)
          .in('video_id', allVideoIds);
        if (pvErr) throw pvErr;
        progresoVideos = pvData || [];
      }

      // Consultar intentos por quiz
      let intentosQuiz = [];
      if (allQuizIds.length > 0) {
        const { data: iqData, error: iqErr } = await supabase
          .from('intentos_quiz_modulo')
          .select('quiz_id, puntaje, aprobado, intento')
          .eq('asignacion_id', asig.id)
          .in('quiz_id', allQuizIds);
        if (iqErr) throw iqErr;
        intentosQuiz = iqData || [];
      }

      // Construir progreso por módulo
      const progreso_modulos = { modulos: [] };
      for (const m of modulosList) {
        const moduloVideos = Array.isArray(m.videos) ? m.videos : [];
        const moduloQuizzes = Array.isArray(m.quizzes) ? m.quizzes : [];

        // Videos completos?
        const videosCompletos = moduloVideos.length === 0 || moduloVideos.every((v) => {
          const pv = progresoVideos.find((p) => p.video_id === v.id);
          return pv && Number(pv.progreso) >= 100;
        });

        // Evaluar quizzes: obtener mejor puntaje por quiz y si aprobó o agotó intentos
        const quizzesRes = [];
        let quizzesPasados = true;
        for (const q of moduloQuizzes) {
          const registros = intentosQuiz.filter((it) => it.quiz_id === q.id);
          const mejor = registros.length > 0 ? Math.max(...registros.map((r) => r.puntaje || 0)) : null;
          const aprobado = registros.some((r) => r.aprobado === true);
          const intentosUsados = registros.length;
          const finalizado = aprobado || intentosUsados >= 2;
          if (!finalizado) quizzesPasados = false;
          quizzesRes.push({ quiz_id: q.id, puntaje: mejor, aprobado: aprobado, intentos: intentosUsados });
        }

        const moduloCompletado = videosCompletos && quizzesPasados;

        // Calcular nota del módulo (promedio de quizzes si existen, sino 10 si completado)
        let nota = undefined;
        if (moduloCompletado) {
          if (quizzesRes.length > 0) {
            const sum = quizzesRes.reduce((acc, r) => acc + (r.puntaje || 0), 0);
            nota = Math.round((sum / quizzesRes.length) * 10) / 10;
          } else {
            nota = 10;
          }
        }

        progreso_modulos.modulos.push({ modulo_id: m.id, nota, quizzes: quizzesRes, completado: moduloCompletado });
      }

      // Si ya existe progreso final en la asignación, preservarlo
      if (asig.progreso_modulos && asig.progreso_modulos.nota_final) {
        progreso_modulos.nota_final = asig.progreso_modulos.nota_final;
      }

      res.json({
        modulos: modulosList,
        progreso_modulos
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Actualizar progreso de video en módulo */
  static async actualizarProgresoVideoModulo(req, res) {
    try {
      const conductorId = req.usuario.conductor_id;
      if (!conductorId) return res.status(403).json({ error: 'No autorizado' });

      const { modulo_id, video_id, progreso } = req.body;
      if (!modulo_id || !video_id || progreso === undefined) {
        return res.status(400).json({ error: 'modulo_id, video_id, progreso son requeridos' });
      }

      // Verificar acceso
      const { data: asig, error: aErr } = await supabase
        .from('asignaciones_capacitacion')
        .select('id, conductor_id')
        .eq('id', req.params.id)
        .eq('conductor_id', conductorId)
        .single();
      if (aErr || !asig) return res.status(403).json({ error: 'No autorizado' });

      const progresoNum = Math.min(100, Math.max(0, Number(progreso) || 0));

      // Upsert de progreso del video
      const { error: uErr } = await supabase
        .from('progreso_videos')
        .upsert({
          asignacion_id: asig.id,
          video_id,
          progreso: progresoNum,
          completado: progresoNum >= 100
        }, {
          onConflict: 'asignacion_id,video_id'
        });
      if (uErr) throw uErr;

      res.json({ progreso: progresoNum, completado: progresoNum >= 100 });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Responder quiz de un módulo */
  static async responderQuizModulo(req, res) {
    try {
      const conductorId = req.usuario.conductor_id;
      if (!conductorId) return res.status(403).json({ error: 'No autorizado' });

      const { modulo_id, quiz_id, respuestas } = req.body;
      if (!modulo_id || !quiz_id || !Array.isArray(respuestas)) {
        return res.status(400).json({ error: 'modulo_id, quiz_id, respuestas son requeridos' });
      }

      // Verificar acceso
      const { data: asig, error: aErr } = await supabase
        .from('asignaciones_capacitacion')
        .select('id, conductor_id, capacitacion_id')
        .eq('id', req.params.id)
        .eq('conductor_id', conductorId)
        .single();
      if (aErr || !asig) return res.status(403).json({ error: 'No autorizado' });
      if (!asig.capacitacion_id) return res.status(404).json({ error: 'Capacitación no encontrada' });

      // Obtener capacitación con módulos embebidos
      const { data: capacitacion, error: capErr } = await supabase
        .from('capacitaciones')
        .select('modulos')
        .eq('id', asig.capacitacion_id)
        .single();
        if (capErr || !capacitacion) return res.status(404).json({ error: 'Capacitación no encontrada' });

        // Buscar el módulo y el quiz dentro de los módulos embebidos
        const modulos = Array.isArray(capacitacion.modulos) ? capacitacion.modulos : [];
        const modulo = modulos.find((m) => m.id === modulo_id);
        if (!modulo) return res.status(404).json({ error: 'Módulo no encontrado' });

        const quiz = (Array.isArray(modulo.quizzes) ? modulo.quizzes : []).find((q) => q.id === quiz_id);
        if (!quiz) return res.status(404).json({ error: 'Quiz no encontrado' });

        // Validar que el quiz exista en tablas relacionales. Si falta, regenerarlo desde el JSONB.
        const { data: quizRow, error: quizRowErr } = await supabase
          .from('quizzes_modulo')
          .select('id, modulo_id, porcentaje_aprobacion')
          .eq('id', quiz_id)
          .eq('modulo_id', modulo_id)
          .maybeSingle();
        if (quizRowErr) throw quizRowErr;

        if (!quizRow) {
          const moduloUpsert = {
            id: modulo.id,
            capacitacion_id: asig.capacitacion_id,
            titulo: modulo.titulo,
            descripcion: modulo.descripcion || null,
            orden: modulo.orden || 0,
          };
          const { error: mUpsertErr } = await supabase.from('modulos').upsert(moduloUpsert, { onConflict: 'id' });
          if (mUpsertErr) throw mUpsertErr;

          const quizUpsert = {
            id: quiz.id,
            modulo_id,
            titulo: quiz.titulo,
            porcentaje_aprobacion: quiz.porcentaje_aprobacion || 70,
            orden: quiz.orden || 0,
          };
          const { error: qUpsertErr } = await supabase.from('quizzes_modulo').upsert(quizUpsert, { onConflict: 'id' });
          if (qUpsertErr) throw qUpsertErr;

          const preguntasRows = Array.isArray(quiz.preguntas) ? quiz.preguntas.map((p, pi) => ({
            id: p.id,
            quiz_id: quiz.id,
            pregunta: p.pregunta,
            puntos: p.puntos || 1,
            orden: p.orden ?? pi,
          })) : [];
          if (preguntasRows.length > 0) {
            const { error: pUpsertErr } = await supabase.from('preguntas_modulo').upsert(preguntasRows, { onConflict: 'id' });
            if (pUpsertErr) throw pUpsertErr;
          }

          const opcionesRows = [];
          if (Array.isArray(quiz.preguntas)) {
            for (const pregunta of quiz.preguntas) {
              if (!Array.isArray(pregunta.opciones)) continue;
              for (const opcion of pregunta.opciones) {
                opcionesRows.push({
                  id: opcion.id,
                  pregunta_id: pregunta.id,
                  texto: opcion.texto,
                  es_correcta: opcion.es_correcta || false,
                  orden: opcion.orden || 0,
                });
              }
            }
          }
          if (opcionesRows.length > 0) {
            const { error: oUpsertErr } = await supabase.from('opciones_modulo').upsert(opcionesRows, { onConflict: 'id' });
            if (oUpsertErr) throw oUpsertErr;
          }
        }

        const preguntaIds = respuestas.map((r) => r.pregunta_id);
        const opcionIds = respuestas.map((r) => r.opcion_id);

        const { data: preguntasPersistidas, error: preguntasErr } = await supabase
          .from('preguntas_modulo')
          .select('id, quiz_id, puntos')
          .in('id', preguntaIds);
        if (preguntasErr) throw preguntasErr;
        if (!Array.isArray(preguntasPersistidas) || preguntasPersistidas.length !== preguntaIds.length) {
          return res.status(400).json({ error: 'Preguntas de quiz inválidas' });
        }

        const { data: opcionesPersistidas, error: opcionesErr } = await supabase
          .from('opciones_modulo')
          .select('id, pregunta_id, es_correcta')
          .in('id', opcionIds);
        if (opcionesErr) throw opcionesErr;
        if (!Array.isArray(opcionesPersistidas) || opcionesPersistidas.length !== opcionIds.length) {
          return res.status(400).json({ error: 'Opciones de quiz inválidas' });
        }

        const preguntaMap = new Map(preguntasPersistidas.map((p) => [p.id, p]));
        const opcionMap = new Map(opcionesPersistidas.map((o) => [o.id, o]));

        for (const respuesta of respuestas) {
          const preguntaPersistida = preguntaMap.get(respuesta.pregunta_id);
          const opcionPersistida = opcionMap.get(respuesta.opcion_id);
          if (!preguntaPersistida || !opcionPersistida || opcionPersistida.pregunta_id !== respuesta.pregunta_id) {
            return res.status(400).json({ error: 'Respuesta inválida para el quiz' });
          }
          if (preguntaPersistida.quiz_id !== quiz_id) {
            return res.status(400).json({ error: 'Pregunta no pertenece al quiz' });
          }
        }

      // Verificar intentos
      const { count: intentosCount } = await supabase
        .from('intentos_quiz_modulo')
        .select('*', { count: 'exact', head: true })
        .eq('asignacion_id', asig.id)
        .eq('quiz_id', quiz_id);
      const intentosUsados = intentosCount || 0;
      if (intentosUsados >= 2) {
        return res.status(403).json({ error: 'Has alcanzado el máximo de 2 intentos para este quiz' });
      }

      // Calcular puntaje
      let puntosObtenidos = 0;
      const totalPuntos = preguntasPersistidas.reduce((acc, p) => acc + (p.puntos || 1), 0);

      const filas = respuestas.map((r) => {
        const preguntaPersistida = preguntaMap.get(r.pregunta_id);
        const opcionPersistida = opcionMap.get(r.opcion_id);
        const esCorrecta = opcionPersistida?.es_correcta || false;
        if (esCorrecta) puntosObtenidos += (preguntaPersistida?.puntos || 1);
        return {
          asignacion_id: asig.id,
          pregunta_id: r.pregunta_id,
          opcion_id: r.opcion_id,
          es_correcta: esCorrecta
        };
      });

      // Guardar respuestas
      const { error: rErr } = await supabase
        .from('respuestas_modulo')
        .upsert(filas, { onConflict: 'asignacion_id,pregunta_id' });
      if (rErr) throw rErr;

      // Calcular puntaje porcentual
      const puntaje = totalPuntos > 0
        ? Math.round((puntosObtenidos / totalPuntos) * 100)
        : 0;

      const aprobado = puntaje >= (quiz.porcentaje_aprobacion || 70);
      const nuevoIntento = intentosUsados + 1;

      // Registrar intento
      const { error: iErr } = await supabase
        .from('intentos_quiz_modulo')
        .insert({
          asignacion_id: asig.id,
          quiz_id,
          intento: nuevoIntento,
          puntaje,
          aprobado
        });
      if (iErr) throw iErr;

      // Determinar si este quiz es el último dentro del módulo
      const { data: quizzesModulo, error: qListErr } = await supabase
        .from('quizzes_modulo')
        .select('id, orden')
        .eq('modulo_id', modulo_id)
        .order('orden', { ascending: true });
      if (qListErr) throw qListErr;
      const currentQuizOrden = quizzesModulo?.find((q) => q.id === quiz_id)?.orden;
      const isLastQuiz = Array.isArray(quizzesModulo) && quizzesModulo.length > 0
        ? currentQuizOrden === Math.max(...quizzesModulo.map((q) => q.orden || 0))
        : true;

      const moduloCompletado = isLastQuiz && (aprobado || nuevoIntento >= 2);

      res.json({
        puntaje,
        puntosObtenidos,
        totalPuntos,
        aprobado,
        porcentaje_aprobacion: quiz.porcentaje_aprobacion || 70,
        intentos_usados: nuevoIntento,
        intentos_restantes: Math.max(0, 2 - nuevoIntento),
        modulo_completado: moduloCompletado,
        nota_modulo: moduloCompletado ? puntaje : undefined
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Completar capacitación y calcular nota final */
  static async completarCapacitacionModulos(req, res) {
    try {
      const conductorId = req.usuario.conductor_id;
      if (!conductorId) return res.status(403).json({ error: 'No autorizado' });

      const { modulos_resultados } = req.body;
      if (!Array.isArray(modulos_resultados)) {
        return res.status(400).json({ error: 'modulos_resultados debe ser un array' });
      }

      // Verificar acceso
      const { data: asig, error: aErr } = await supabase
        .from('asignaciones_capacitacion')
        .select('id, conductor_id')
        .eq('id', req.params.id)
        .eq('conductor_id', conductorId)
        .single();
      if (aErr || !asig) return res.status(403).json({ error: 'No autorizado' });

      // Calcular nota final (promedio de módulos)
      const notas = modulos_resultados.map((m) => m.nota || 0);
      const notaFinal = notas.length > 0
        ? Math.round((notas.reduce((a, b) => a + b, 0) / notas.length) * 10) / 10
        : 0;

      // Guardar progreso de módulos
      const progreso_modulos = {
        nota_final: notaFinal,
        modulos: modulos_resultados,
        fecha_completado: new Date().toISOString()
      };

      const { error: uErr } = await supabase
        .from('asignaciones_capacitacion')
        .update({
          estado: 'completado',
          progreso_modulos,
          fecha_completado: new Date(),
          quiz_puntaje: Math.round(notaFinal * 10), // Guardar como 0-100 (nota 8.5 = 85)
          quiz_completado: true
        })
        .eq('id', asig.id);
      if (uErr) throw uErr;

      res.json({
        nota_final: notaFinal,
        aprobado: notaFinal >= 8.0,
        modulos_completados: modulos_resultados.length
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = PortalConductorController;
