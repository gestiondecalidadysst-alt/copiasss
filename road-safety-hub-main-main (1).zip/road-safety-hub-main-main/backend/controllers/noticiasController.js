const supabase = require('../config/supabaseClient');

class NoticiasController {
  /** Obtener todas las noticias con conteos de interacciones */
  static async getNoticias(req, res) {
    try {
      const [{ data: noticias, error: noticiasError }, { data: reacciones, error: reaccionesError }, { data: comentarios, error: comentariosError }, { data: certificaciones, error: certificacionesError }, { data: vistas, error: vistasError }] =
        await Promise.all([
          supabase.from('noticias').select('*').order('created_at', { ascending: false }),
          supabase.from('noticias_reacciones').select('noticia_id, tipo'),
          supabase.from('noticias_comentarios').select('noticia_id'),
          supabase.from('noticias_certificaciones').select('noticia_id'),
          supabase.from('noticias_vistas').select('noticia_id'),
        ]);
      if (noticiasError || reaccionesError || comentariosError || certificacionesError || vistasError) {
        throw noticiasError || reaccionesError || comentariosError || certificacionesError || vistasError;
      }

      const enriched = (noticias || []).map((n) => ({
        ...n,
        me_gusta_count: (reacciones || []).filter((r) => r.noticia_id === n.id && r.tipo === 'me_gusta').length,
        no_me_gusta_count: (reacciones || []).filter((r) => r.noticia_id === n.id && r.tipo === 'no_me_gusta').length,
        comentarios_count: (comentarios || []).filter((c) => c.noticia_id === n.id).length,
        certificaciones_count: (certificaciones || []).filter((c) => c.noticia_id === n.id).length,
        vistas_count: (vistas || []).filter((v) => v.noticia_id === n.id).length,
      }));

      res.json(enriched);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Reacciones y certificaciones del usuario autenticado (todas a la vez) */
  static async getMisInteracciones(req, res) {
    try {
      const userId = req.usuario.id;
      const [{ data: reacciones }, { data: certificaciones }] = await Promise.all([
        supabase.from('noticias_reacciones').select('noticia_id, tipo').eq('user_id', userId),
        supabase.from('noticias_certificaciones').select('noticia_id').eq('user_id', userId),
      ]);
      res.json({
        reacciones: reacciones || [],
        certificaciones: (certificaciones || []).map((c) => c.noticia_id),
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Comentarios de una noticia */
  static async getComentarios(req, res) {
    try {
      const { data, error } = await supabase
        .from('noticias_comentarios')
        .select('*')
        .eq('noticia_id', req.params.id)
        .order('created_at', { ascending: true });
      if (error) throw error;
      res.json(data || []);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Crear una noticia */
  static async createNoticia(req, res) {
    try {
      const { titulo, contenido, imagen_url, video_youtube, publicado, permite_certificar } = req.body;
      if (!titulo || !contenido) return res.status(400).json({ error: 'titulo y contenido son requeridos' });
      const autor = req.usuario?.nombre || req.usuario?.email || 'Administrador';
      const { data, error } = await supabase
        .from('noticias')
        .insert([{
          titulo,
          contenido,
          imagen_url: imagen_url || null,
          video_youtube: video_youtube || null,
          publicado: publicado !== undefined ? publicado : true,
          permite_certificar: permite_certificar ?? false,
          autor,
        }])
        .select()
        .single();
      if (error) throw error;
      res.status(201).json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Actualizar una noticia */
  static async updateNoticia(req, res) {
    try {
      const { titulo, contenido, imagen_url, video_youtube, publicado, permite_certificar } = req.body;
      const { data, error } = await supabase
        .from('noticias')
        .update({
          titulo,
          contenido,
          imagen_url: imagen_url || null,
          video_youtube: video_youtube || null,
          publicado,
          permite_certificar: permite_certificar ?? false,
          updated_at: new Date().toISOString(),
        })
        .eq('id', req.params.id)
        .select()
        .single();
      if (error) throw error;
      if (!data) return res.status(404).json({ error: 'Noticia no encontrada' });
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Eliminar una noticia */
  static async deleteNoticia(req, res) {
    try {
      const { error } = await supabase.from('noticias').delete().eq('id', req.params.id);
      if (error) throw error;
      res.json({ message: 'Noticia eliminada correctamente' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Toggle reacción me_gusta / no_me_gusta */
  static async reaccionar(req, res) {
    try {
      const userId = req.usuario.id;
      const noticiaId = req.params.id;
      const { tipo } = req.body;
      if (!['me_gusta', 'no_me_gusta'].includes(tipo)) return res.status(400).json({ error: 'tipo inválido' });

      const { data: existing } = await supabase
        .from('noticias_reacciones')
        .select('id, tipo')
        .eq('noticia_id', noticiaId)
        .eq('user_id', userId)
        .maybeSingle();

      if (existing) {
        if (existing.tipo === tipo) {
          await supabase.from('noticias_reacciones').delete().eq('id', existing.id);
          return res.json({ accion: 'removido' });
        }
        await supabase.from('noticias_reacciones').update({ tipo }).eq('id', existing.id);
        return res.json({ accion: 'cambiado', tipo });
      }

      await supabase.from('noticias_reacciones').insert([{ noticia_id: noticiaId, user_id: userId, tipo }]);
      res.status(201).json({ accion: 'creado', tipo });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Agregar comentario */
  static async comentar(req, res) {
    try {
      const { contenido } = req.body;
      if (!contenido?.trim()) return res.status(400).json({ error: 'contenido es requerido' });
      const autor = req.usuario?.nombre || req.usuario?.email || 'Usuario';
      const { data, error } = await supabase
        .from('noticias_comentarios')
        .insert([{ noticia_id: req.params.id, user_id: req.usuario.id, autor, contenido: contenido.trim() }])
        .select()
        .single();
      if (error) throw error;
      res.status(201).json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Eliminar comentario (admin o propio) */
  static async eliminarComentario(req, res) {
    try {
      const userId = req.usuario.id;
      const isAdmin = req.usuario.rol === 'admin';
      const { data: comentario } = await supabase
        .from('noticias_comentarios').select('user_id').eq('id', req.params.cid).maybeSingle();
      if (!comentario) return res.status(404).json({ error: 'Comentario no encontrado' });
      if (!isAdmin && comentario.user_id !== userId) return res.status(403).json({ error: 'No autorizado' });
      await supabase.from('noticias_comentarios').delete().eq('id', req.params.cid);
      res.json({ message: 'Comentario eliminado' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Toggle certificación de visualización */
  static async certificar(req, res) {
    try {
      const userId = req.usuario.id;
      const noticiaId = req.params.id;
      const autor = req.usuario?.nombre || req.usuario?.email || 'Usuario';
      const { data: existing } = await supabase
        .from('noticias_certificaciones').select('id')
        .eq('noticia_id', noticiaId).eq('user_id', userId).maybeSingle();
      if (existing) {
        await supabase.from('noticias_certificaciones').delete().eq('id', existing.id);
        return res.json({ accion: 'removido' });
      }
      await supabase.from('noticias_certificaciones').insert([{ noticia_id: noticiaId, user_id: userId, autor }]);
      res.status(201).json({ accion: 'certificado' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Registrar vista de noticia por el conductor */
  static async marcarComoVisto(req, res) {
    try {
      if (!req.usuario || !req.usuario.id) return res.status(401).json({ error: 'No autenticado' });
      const userId = req.usuario.id;
      const noticiaId = req.params.id;
      const autor = req.usuario?.nombre || req.usuario?.email || 'Usuario';

      const { data: existing, error: fetchError } = await supabase
        .from('noticias_vistas')
        .select('id')
        .eq('noticia_id', noticiaId)
        .eq('user_id', userId)
        .maybeSingle();
      if (fetchError) throw fetchError;
      if (existing) return res.json({ accion: 'ya_visto' });

      const { error: insertError } = await supabase
        .from('noticias_vistas')
        .insert([{ noticia_id: noticiaId, user_id: userId, autor }]);
      if (insertError) throw insertError;

      res.status(201).json({ accion: 'visto' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Obtener estadísticas de una noticia */
  static async getEstadisticas(req, res) {
    try {
      const noticiaId = req.params.id;
      const [
        { data: reacciones, error: reaccionesError },
        { data: comentarios, error: comentariosError },
        { data: certificaciones, error: certificacionesError },
        { data: vistas, error: vistasError },
      ] = await Promise.all([
        supabase.from('noticias_reacciones').select('tipo').eq('noticia_id', noticiaId),
        supabase.from('noticias_comentarios').select('id').eq('noticia_id', noticiaId),
        supabase.from('noticias_certificaciones').select('user_id, autor, created_at').eq('noticia_id', noticiaId).order('created_at', { ascending: false }),
        supabase.from('noticias_vistas').select('user_id, autor, created_at').eq('noticia_id', noticiaId).order('created_at', { ascending: false }),
      ]);

      if (reaccionesError || comentariosError || certificacionesError || vistasError) {
        throw reaccionesError || comentariosError || certificacionesError || vistasError;
      }

      res.json({
        vista_count: (vistas || []).length,
        certificacion_count: (certificaciones || []).length,
        comentarios_count: (comentarios || []).length,
        me_gusta_count: (reacciones || []).filter((r) => r.tipo === 'me_gusta').length,
        no_me_gusta_count: (reacciones || []).filter((r) => r.tipo === 'no_me_gusta').length,
        vistas: vistas || [],
        certificaciones: certificaciones || [],
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Subir imagen al bucket de Supabase Storage */
  static async uploadImagen(req, res) {
    try {
      if (!req.file) return res.status(400).json({ error: 'No se recibió ninguna imagen' });
      const sanitizedName = req.file.originalname
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9._-]/g, '_');
      const fileName = `${Date.now()}-${sanitizedName}`;
      const filePath = `noticias/${fileName}`;
      const { error: uploadError } = await supabase.storage
        .from('mensaje-media').upload(filePath, req.file.buffer, {
          contentType: req.file.mimetype, cacheControl: '3600', upsert: false,
        });
      if (uploadError) throw uploadError;
      const { data: { publicUrl } } = supabase.storage.from('mensaje-media').getPublicUrl(filePath);
      res.json({ url: publicUrl });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Descargar estadísticas de una noticia como CSV */
  static async descargarEstadisticasNoticia(req, res) {
    try {
      const noticiaId = req.params.id;
      
      // Obtener la noticia
      const { data: noticia, error: noticiaError } = await supabase
        .from('noticias')
        .select('*')
        .eq('id', noticiaId)
        .single();
      
      if (noticiaError || !noticia) {
        return res.status(404).json({ error: 'Noticia no encontrada' });
      }

      // Obtener estadísticas
      const [
        { data: reacciones },
        { data: comentarios },
        { data: certificaciones },
        { data: vistas },
      ] = await Promise.all([
        supabase.from('noticias_reacciones').select('tipo').eq('noticia_id', noticiaId),
        supabase.from('noticias_comentarios').select('id').eq('noticia_id', noticiaId),
        supabase.from('noticias_certificaciones').select('user_id, autor, created_at').eq('noticia_id', noticiaId).order('created_at', { ascending: false }),
        supabase.from('noticias_vistas').select('user_id, autor, created_at').eq('noticia_id', noticiaId).order('created_at', { ascending: false }),
      ]);

      // Construir CSV
      let csv = 'ESTADÍSTICAS DE NOTICIA\n';
      csv += '=======================\n\n';
      csv += `Título,${noticia.titulo}\n`;
      csv += `Autor,${noticia.autor}\n`;
      csv += `Fecha de publicación,${new Date(noticia.created_at).toLocaleDateString('es-CO')}\n\n`;

      csv += 'RESUMEN DE INTERACCIONES\n';
      csv += 'Métrica,Cantidad\n';
      csv += `Vistas,${(vistas || []).length}\n`;
      csv += `Me gusta,${(reacciones || []).filter(r => r.tipo === 'me_gusta').length}\n`;
      csv += `No me gusta,${(reacciones || []).filter(r => r.tipo === 'no_me_gusta').length}\n`;
      csv += `Comentarios,${(comentarios || []).length}\n`;
      csv += `Certificaciones,${(certificaciones || []).length}\n\n`;

      if ((vistas || []).length > 0) {
        csv += 'DETALLE DE VISTAS\n';
        csv += 'Conductor,Fecha y Hora\n';
        (vistas || []).forEach(vista => {
          const fecha = new Date(vista.created_at).toLocaleString('es-CO');
          csv += `"${vista.autor.replace(/"/g, '""')}","${fecha}"\n`;
        });
        csv += '\n';
      }

      if ((certificaciones || []).length > 0) {
        csv += 'DETALLE DE CERTIFICACIONES\n';
        csv += 'Conductor,Fecha y Hora\n';
        (certificaciones || []).forEach(cert => {
          const fecha = new Date(cert.created_at).toLocaleString('es-CO');
          csv += `"${cert.autor.replace(/"/g, '""')}","${fecha}"\n`;
        });
      }

      // Enviar archivo
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="estadisticas_noticia_${noticiaId.slice(0, 8)}_${Date.now()}.csv"`);
      res.send(csv);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Descargar todas las estadísticas de noticias como Excel/CSV */
  static async descargarTodasEstadisticas(req, res) {
    try {
      // Obtener todas las noticias
      const { data: noticias, error: noticiasError } = await supabase
        .from('noticias')
        .select('*')
        .order('created_at', { ascending: false });

      if (noticiasError || !noticias) {
        return res.status(500).json({ error: 'Error al obtener noticias' });
      }

      // Construir CSV con resumen de todas las noticias
      let csv = 'REPORTE COMPLETO DE ESTADÍSTICAS DE NOTICIAS\n';
      csv += '='.repeat(50) + '\n';
      csv += `Generado: ${new Date().toLocaleString('es-CO')}\n\n`;

      csv += 'RESUMEN POR NOTICIA\n';
      csv += 'Título,Autor,Fecha Publicación,Vistas,Me Gusta,No Me Gusta,Comentarios,Certificaciones\n';

      // Obtener todas las interacciones en paralelo
      const [
        { data: reacciones },
        { data: comentarios },
        { data: certificaciones },
        { data: vistas },
      ] = await Promise.all([
        supabase.from('noticias_reacciones').select('noticia_id, tipo'),
        supabase.from('noticias_comentarios').select('noticia_id'),
        supabase.from('noticias_certificaciones').select('noticia_id'),
        supabase.from('noticias_vistas').select('noticia_id'),
      ]);

      noticias.forEach(noticia => {
        const vistasCount = (vistas || []).filter(v => v.noticia_id === noticia.id).length;
        const meGusta = (reacciones || []).filter(r => r.noticia_id === noticia.id && r.tipo === 'me_gusta').length;
        const noMeGusta = (reacciones || []).filter(r => r.noticia_id === noticia.id && r.tipo === 'no_me_gusta').length;
        const comentariosCount = (comentarios || []).filter(c => c.noticia_id === noticia.id).length;
        const certificacionesCount = (certificaciones || []).filter(c => c.noticia_id === noticia.id).length;

        const fecha = new Date(noticia.created_at).toLocaleDateString('es-CO');
        csv += `"${noticia.titulo.replace(/"/g, '""')}","${noticia.autor.replace(/"/g, '""')}","${fecha}",${vistasCount},${meGusta},${noMeGusta},${comentariosCount},${certificacionesCount}\n`;
      });

      csv += '\n\nTOTAL DE NOTICIAS,,' + noticias.length + '\n';
      csv += 'TOTAL DE VISTAS,,' + ((vistas || []).length) + '\n';
      csv += 'TOTAL DE ME GUSTA,,' + ((reacciones || []).filter(r => r.tipo === 'me_gusta').length) + '\n';
      csv += 'TOTAL DE NO ME GUSTA,,' + ((reacciones || []).filter(r => r.tipo === 'no_me_gusta').length) + '\n';
      csv += 'TOTAL DE COMENTARIOS,,' + ((comentarios || []).length) + '\n';
      csv += 'TOTAL DE CERTIFICACIONES,,' + ((certificaciones || []).length) + '\n';

      // Enviar archivo
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="estadisticas_noticias_completo_${Date.now()}.csv"`);
      res.send(csv);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = NoticiasController;
