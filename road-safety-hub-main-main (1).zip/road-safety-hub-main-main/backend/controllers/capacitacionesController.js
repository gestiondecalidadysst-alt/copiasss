const crypto = require('crypto');
const supabase = require('../config/supabaseClient');
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');

const validateModulosPayload = (modulos) => {
  if (!Array.isArray(modulos)) return false;
  for (const mod of modulos) {
    if (!mod || typeof mod !== 'object') return false;
    if (!mod.titulo || typeof mod.titulo !== 'string') return false;
    if (mod.videos && !Array.isArray(mod.videos)) return false;
    if (mod.quizzes && !Array.isArray(mod.quizzes)) return false;

    if (Array.isArray(mod.videos)) {
      for (const video of mod.videos) {
        if (!video || typeof video !== 'object') return false;
        if (!video.titulo || typeof video.titulo !== 'string') return false;
        if (!video.url || typeof video.url !== 'string') return false;
      }
    }

    if (Array.isArray(mod.quizzes)) {
      for (const quiz of mod.quizzes) {
        if (!quiz || typeof quiz !== 'object') return false;
        if (!quiz.titulo || typeof quiz.titulo !== 'string') return false;
        if (quiz.preguntas && !Array.isArray(quiz.preguntas)) return false;
        if (Array.isArray(quiz.preguntas)) {
          for (const pregunta of quiz.preguntas) {
            if (!pregunta || typeof pregunta !== 'object') return false;
            if (!pregunta.pregunta || typeof pregunta.pregunta !== 'string') return false;
            if (!Array.isArray(pregunta.opciones)) return false;
            if (pregunta.opciones.length === 0) return false;
            if (!pregunta.opciones.some((o) => o?.es_correcta === true)) return false;
            for (const opcion of pregunta.opciones) {
              if (!opcion || typeof opcion !== 'object') return false;
              if (!opcion.texto || typeof opcion.texto !== 'string') return false;
            }
          }
        }
      }
    }
  }
  return true;
};

class CapacitacionesController {
  // ── Capacitaciones CRUD ────────────────────────────────────────────────

  static async getCapacitaciones(req, res) {
    try {
      const { data, error } = await supabase
        .from('capacitaciones')
        .select('*')
        .eq('activo', true)
        .order('created_at', { ascending: false });
      if (error) throw error;
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async getCapacitacion(req, res) {
    try {
      const { data, error } = await supabase
        .from('capacitaciones')
        .select('*')
        .eq('id', req.params.id)
        .single();
      
      if (error) throw error;
      if (!data) return res.status(404).json({ error: 'No encontrado' });

      // Si la capacitación tiene módulos en JSONB, usarlos
      // Si no, intentar recuperar desde la tabla relacional
      if (!data.modulos || !Array.isArray(data.modulos) || data.modulos.length === 0) {
        try {
          const { data: modulos } = await supabase
            .from('modulos')
            .select(`
              id,
              titulo,
              descripcion,
              orden,
              videos:videos_modulo(id, titulo, url, duracion_minutos, orden),
              quizzes:quizzes_modulo(
                id,
                titulo,
                porcentaje_aprobacion,
                orden,
                preguntas:preguntas_modulo(
                  id,
                  pregunta,
                  puntos,
                  orden,
                  opciones:opciones_modulo(id, texto, es_correcta, orden)
                )
              )
            `)
            .eq('capacitacion_id', req.params.id)
            .order('orden');
          
          if (modulos && modulos.length > 0) {
            data.modulos = modulos;
          }
        } catch (e) {
          // Si falla, dejar modulos como viene
          console.error('Error al obtener módulos relacionales:', e);
        }
      }

      res.json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async createCapacitacion(req, res) {
    try {
      const { titulo, descripcion, contenido_url, tipo, duracion_minutos, empresa, modulos } = req.body;
      if (!titulo) return res.status(400).json({ error: 'El título es requerido' });
      if (modulos !== undefined && !validateModulosPayload(modulos)) {
        return res.status(400).json({ error: 'Estructura de módulos inválida' });
      }

      // Preparar datos de módulos con IDs únicos
      const modulosConId = Array.isArray(modulos) && modulos.length > 0 
        ? modulos.map((mod) => ({
            ...mod,
            id: mod.id || crypto.randomUUID?.() || `mod-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            videos: Array.isArray(mod.videos) ? mod.videos.map((v) => ({
              ...v,
              id: v.id || crypto.randomUUID?.() || `vid-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
            })) : [],
            quizzes: Array.isArray(mod.quizzes) ? mod.quizzes.map((q) => ({
              ...q,
              id: q.id || crypto.randomUUID?.() || `quiz-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
              preguntas: Array.isArray(q.preguntas) ? q.preguntas.map((p) => ({
                ...p,
                id: p.id || crypto.randomUUID?.() || `preg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                opciones: Array.isArray(p.opciones) ? p.opciones.map((o) => ({
                  ...o,
                  id: o.id || crypto.randomUUID?.() || `opc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
                })) : []
              })) : []
            })) : []
          }))
        : [];

      const { data, error } = await supabase
        .from('capacitaciones')
        .insert([{
          titulo,
          descripcion,
          contenido_url,
          tipo: tipo || 'documento',
          duracion_minutos: duracion_minutos || 0,
          empresa: empresa || req.usuario.empresa,
          created_by: req.usuario.id,
          modulos: modulosConId
        }])
        .select()
        .single();
      if (error) throw error;

      res.status(201).json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async updateCapacitacion(req, res) {
    try {
      const { titulo, descripcion, contenido_url, tipo, duracion_minutos, activo } = req.body;
      const { data, error } = await supabase
        .from('capacitaciones')
        .update({ titulo, descripcion, contenido_url, tipo, duracion_minutos, activo, updated_at: new Date() })
        .eq('id', req.params.id)
        .select()
        .single();
      if (error) throw error;
      if (!data) return res.status(404).json({ error: 'No encontrado' });
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async deleteCapacitacion(req, res) {
    try {
      const { error } = await supabase
        .from('capacitaciones')
        .update({ activo: false, updated_at: new Date() })
        .eq('id', req.params.id);
      if (error) throw error;
      res.json({ message: 'Capacitación desactivada correctamente' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  // ── Asignaciones ───────────────────────────────────────────────────────

  static async getAsignaciones(req, res) {
    try {
      const { capacitacion_id, conductor_id } = req.query;
      let query = supabase
        .from('asignaciones_capacitacion')
        .select('*, capacitacion:capacitaciones(titulo, tipo, duracion_minutos), conductor:conductores(nombre, cedula, vehiculo)')
        .order('fecha_asignacion', { ascending: false });

      if (capacitacion_id) query = query.eq('capacitacion_id', capacitacion_id);
      if (conductor_id) query = query.eq('conductor_id', conductor_id);

      const { data, error } = await query;
      if (error) throw error;
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async asignarConductores(req, res) {
    try {
      const { capacitacion_id, conductor_ids } = req.body;
      if (!capacitacion_id || !Array.isArray(conductor_ids) || conductor_ids.length === 0) {
        return res.status(400).json({ error: 'capacitacion_id y conductor_ids son requeridos' });
      }

      const filas = conductor_ids.map((conductor_id) => ({
        capacitacion_id,
        conductor_id,
        estado: 'pendiente',
        fecha_asignacion: new Date()
      }));

      const { data, error } = await supabase
        .from('asignaciones_capacitacion')
        .upsert(filas, { onConflict: 'capacitacion_id,conductor_id', ignoreDuplicates: true })
        .select();
      if (error) throw error;
      res.status(201).json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async desasignarConductor(req, res) {
    try {
      const { error } = await supabase
        .from('asignaciones_capacitacion')
        .delete()
        .eq('id', req.params.id);
      if (error) throw error;
      res.json({ message: 'Asignación eliminada' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async updateEstadoAsignacion(req, res) {
    try {
      const { estado, observaciones } = req.body;
      const updates = { estado, updated_at: new Date() };
      if (observaciones !== undefined) updates.observaciones = observaciones;
      if (estado === 'completado') updates.fecha_completado = new Date();

      const { data, error } = await supabase
        .from('asignaciones_capacitacion')
        .update(updates)
        .eq('id', req.params.id)
        .select()
        .single();
      if (error) throw error;
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
  // ── Quiz CRUD ───────────────────────────────────────────────────────────

  /** Obtener preguntas + opciones (admin, incluye es_correcta) */
  static async getQuiz(req, res) {
    try {
      const { data, error } = await supabase
        .from('preguntas_capacitacion')
        .select('*, opciones:opciones_pregunta(id, texto, es_correcta, orden)')
        .eq('capacitacion_id', req.params.id)
        .order('orden');
      if (error) throw error;

      const { data: cap } = await supabase
        .from('capacitaciones')
        .select('porcentaje_aprobacion')
        .eq('id', req.params.id)
        .single();

      res.json({
        preguntas: data || [],
        porcentaje_aprobacion: cap?.porcentaje_aprobacion ?? 70
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Guardar quiz completo (reemplaza preguntas existentes) */
  static async saveQuiz(req, res) {
    try {
      const { preguntas, porcentaje_aprobacion } = req.body;
      if (!Array.isArray(preguntas)) {
        return res.status(400).json({ error: 'preguntas debe ser un array' });
      }

      // Actualizar porcentaje de aprobación si se envió
      if (porcentaje_aprobacion !== undefined) {
        const pct = Math.min(100, Math.max(1, Number(porcentaje_aprobacion) || 70));
        await supabase
          .from('capacitaciones')
          .update({ porcentaje_aprobacion: pct })
          .eq('id', req.params.id);
      }

      // Borrar preguntas previas (cascade elimina opciones)
      const { error: delErr } = await supabase
        .from('preguntas_capacitacion')
        .delete()
        .eq('capacitacion_id', req.params.id);
      if (delErr) throw delErr;

      // Insertar nuevas preguntas + opciones
      for (const p of preguntas) {
        const { data: pData, error: pErr } = await supabase
          .from('preguntas_capacitacion')
          .insert({
            capacitacion_id: req.params.id,
            pregunta: p.pregunta,
            tipo: 'multiple_choice',
            puntos: p.puntos || 1,
            orden: p.orden || 0
          })
          .select()
          .single();
        if (pErr) throw pErr;

        if (Array.isArray(p.opciones) && p.opciones.length > 0) {
          const { error: oErr } = await supabase
            .from('opciones_pregunta')
            .insert(p.opciones.map((o, i) => ({
              pregunta_id: pData.id,
              texto: o.texto,
              es_correcta: o.es_correcta || false,
              orden: o.orden !== undefined ? o.orden : i
            })));
          if (oErr) throw oErr;
        }
      }

      res.json({ message: 'Quiz guardado correctamente', total: preguntas.length });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Progreso de todos los conductores en una capacitación (para admin) */
  static async getProgreso(req, res) {
    try {
      const { data, error } = await supabase
        .from('asignaciones_capacitacion')
        .select('id, conductor_id, estado, etapa, progreso_video, quiz_puntaje, quiz_completado, fecha_asignacion, fecha_completado, conductor:conductores(nombre, cedula, vehiculo)')
        .eq('capacitacion_id', req.params.id)
        .order('fecha_asignacion', { ascending: false });
      if (error) throw error;
      res.json(data || []);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  // ── MÓDULOS CRUD ───────────────────────────────────────────────────────

  /** Obtener todos los módulos de una capacitación */
  static async getModulos(req, res) {
    try {
      const { data, error } = await supabase
        .from('modulos')
        .select(`
          id,
          titulo,
          descripcion,
          orden,
          videos:videos_modulo(id, titulo, url, duracion_minutos, orden),
          quizzes:quizzes_modulo(
            id,
            titulo,
            porcentaje_aprobacion,
            orden,
            preguntas:preguntas_modulo(
              id,
              pregunta,
              puntos,
              orden,
              opciones:opciones_modulo(id, texto, es_correcta, orden)
            )
          )
        `)
        .eq('capacitacion_id', req.params.id)
        .order('orden');
      if (error) throw error;
      res.json(data || []);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  /** Guardar módulos completos (reemplaza estructura existente) */
  static async saveModulos(req, res) {
    try {
      const { modulos } = req.body;
      if (!Array.isArray(modulos)) {
        return res.status(400).json({ error: 'modulos debe ser un array' });
      }
      if (!validateModulosPayload(modulos)) {
        return res.status(400).json({ error: 'Estructura de módulos inválida' });
      }

      const capId = req.params.id;

      // Preparar datos de módulos con IDs únicos
      const modulosConId = modulos.map((mod) => ({
        ...mod,
        id: mod.id || crypto.randomUUID?.() || `mod-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        videos: Array.isArray(mod.videos) ? mod.videos.map((v) => ({
          ...v,
          id: v.id || crypto.randomUUID?.() || `vid-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
        })) : [],
        quizzes: Array.isArray(mod.quizzes) ? mod.quizzes.map((q) => ({
          ...q,
          id: q.id || crypto.randomUUID?.() || `quiz-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          preguntas: Array.isArray(q.preguntas) ? q.preguntas.map((p) => ({
            ...p,
            id: p.id || crypto.randomUUID?.() || `preg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            opciones: Array.isArray(p.opciones) ? p.opciones.map((o) => ({
              ...o,
              id: o.id || crypto.randomUUID?.() || `opc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
            })) : []
          })) : []
        })) : []
      }));

      // Actualizar la capacitación con los módulos en JSONB
      const { data, error } = await supabase
        .from('capacitaciones')
        .update({ modulos: modulosConId })
        .eq('id', capId)
        .select()
        .single();
      
      if (error) throw error;
      if (!data) return res.status(404).json({ error: 'Capacitación no encontrada' });

      // Además de persistir el JSONB, asegurar que existan las filas relacionales
      try {
        for (let mi = 0; mi < modulosConId.length; mi++) {
          const m = modulosConId[mi];
          // Upsert módulo
          const { error: mErr } = await supabase
            .from('modulos')
            .upsert({ id: m.id, capacitacion_id: capId, titulo: m.titulo, descripcion: m.descripcion || null, orden: m.orden ?? mi }, { onConflict: 'id' });
          if (mErr) throw mErr;

          // Videos del módulo
          if (Array.isArray(m.videos) && m.videos.length > 0) {
            const videosRows = m.videos.map((v, vi) => ({
              id: v.id,
              modulo_id: m.id,
              titulo: v.titulo,
              url: v.url,
              duracion_minutos: v.duracion_minutos || null,
              orden: v.orden ?? vi
            }));
            const { error: vErr } = await supabase.from('videos_modulo').upsert(videosRows, { onConflict: 'id' });
            if (vErr) throw vErr;
          }

          // Quizzes + preguntas + opciones
          if (Array.isArray(m.quizzes) && m.quizzes.length > 0) {
            for (let qi = 0; qi < m.quizzes.length; qi++) {
              const q = m.quizzes[qi];
              const { error: qErr } = await supabase.from('quizzes_modulo').upsert({
                id: q.id,
                modulo_id: m.id,
                titulo: q.titulo,
                porcentaje_aprobacion: q.porcentaje_aprobacion ?? 70,
                orden: q.orden ?? qi
              }, { onConflict: 'id' });
              if (qErr) throw qErr;

              // Preguntas
              if (Array.isArray(q.preguntas) && q.preguntas.length > 0) {
                for (let pi = 0; pi < q.preguntas.length; pi++) {
                  const p = q.preguntas[pi];
                  const { error: pErr } = await supabase.from('preguntas_modulo').upsert({
                    id: p.id,
                    quiz_id: q.id,
                    pregunta: p.pregunta,
                    puntos: p.puntos ?? 1,
                    orden: p.orden ?? pi
                  }, { onConflict: 'id' });
                  if (pErr) throw pErr;

                  // Opciones
                  if (Array.isArray(p.opciones) && p.opciones.length > 0) {
                    const opcionesRows = p.opciones.map((o, oi) => ({
                      id: o.id,
                      pregunta_id: p.id,
                      texto: o.texto,
                      es_correcta: !!o.es_correcta,
                      orden: o.orden ?? oi
                    }));
                    const { error: oErr } = await supabase.from('opciones_modulo').upsert(opcionesRows, { onConflict: 'id' });
                    if (oErr) throw oErr;
                  }
                }
              }
            }
          }
        }
      } catch (relError) {
        // Si falla la persistencia relacional, registrar y devolver 500
        console.error('Error guardando filas relacionales de módulos:', relError);
        return res.status(500).json({ error: 'Error al persistir estructura relacional de módulos', detail: relError.message || relError });
      }

      res.json({ message: 'Módulos guardados correctamente', total: modulos.length, data });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  // ── EXPORTACIÓN DE RESULTADOS ─────────────────────────────────────────

  /**
   * Descargar resultado individual de un conductor en una capacitación
   * Formato: PDF o XLSX
   */
  static async downloadResultadoIndividual(req, res) {
    try {
      const { capId, asignacionId } = req.params;
      const { format = 'pdf' } = req.query;

      // Validar formato
      if (!['pdf', 'xlsx'].includes(format)) {
        return res.status(400).json({ error: 'Formato debe ser pdf o xlsx' });
      }

      // Obtener datos de la asignación con conductor y capacitación
      const { data: asignacion, error: asigErr } = await supabase
        .from('asignaciones_capacitacion')
        .select('id, estado, quiz_puntaje, fecha_completado, conductor:conductores(id, nombre, cedula), capacitacion:capacitaciones(id, titulo, descripcion)')
        .eq('id', asignacionId)
        .eq('capacitacion_id', capId)
        .single();

      if (asigErr || !asignacion) {
        return res.status(404).json({ error: 'Asignación no encontrada' });
      }

      if (format === 'xlsx') {
        await CapacitacionesController._generateXLSXResultado(res, asignacion);
      } else {
        await CapacitacionesController._generatePDFResultado(res, asignacion);
      }
    } catch (error) {
      console.error('Error descargando resultado individual:', error);
      res.status(500).json({ error: error.message });
    }
  }

  /**
   * Descargar resultados masivos de una capacitación
   * Formato: PDF o XLSX
   * Filtro: todos, aprobados, no_aprobados
   */
  static async downloadResultadosMasivo(req, res) {
    try {
      const { capId } = req.params;
      const {
        format = 'pdf',
        filtro = 'todos',
        report_header = '',
        report_footer = ''
      } = req.query;
      const empresa = req.usuario?.empresa || req.usuario?.email;
      const reportHeader = Array.isArray(report_header) ? report_header.join(' ') : report_header || '';
      const reportFooter = Array.isArray(report_footer) ? report_footer.join(' ') : report_footer || '';

      // Validar formato
      if (!['pdf', 'xlsx'].includes(format)) {
        return res.status(400).json({ error: 'Formato debe ser pdf o xlsx' });
      }

      // Validar filtro
      if (!['todos', 'aprobados', 'no_aprobados'].includes(filtro)) {
        return res.status(400).json({ error: 'Filtro debe ser todos, aprobados o no_aprobados' });
      }

      // Obtener datos de la capacitación
      const { data: capacitacion, error: capErr } = await supabase
        .from('capacitaciones')
        .select('id, titulo, descripcion')
        .eq('id', capId)
        .single();

      if (capErr || !capacitacion) {
        return res.status(404).json({ error: 'Capacitación no encontrada' });
      }

      // Obtener configuración de certificado y branding de la empresa
      const { data: certificadoConfig, error: certErr } = await supabase
        .from('certificado_config')
        .select('footer_text, show_logo_sistema, logo_height, footer_logo_height')
        .eq('empresa', empresa)
        .maybeSingle();

      if (certErr) {
        console.error('Error al obtener configuración del certificado:', certErr);
      }

      const { data: brandingConfig, error: brandErr } = await supabase
        .from('branding_config')
        .select('company_logo')
        .eq('empresa', empresa)
        .maybeSingle();

      if (brandErr) {
        console.error('Error al obtener branding:', brandErr);
      }

      // Obtener todas las asignaciones
      const { data: asignaciones, error: asigErr } = await supabase
        .from('asignaciones_capacitacion')
        .select('id, estado, quiz_puntaje, fecha_completado, conductor:conductores(id, nombre, cedula)')
        .eq('capacitacion_id', capId)
        .order('conductor_id');

      if (asigErr) {
        console.error('Error Supabase al obtener asignaciones:', asigErr);
        return res.status(500).json({ error: 'Error al obtener asignaciones', detail: asigErr.message });
      }

      let asignacionesFiltradas = asignaciones || [];
      if (filtro === 'aprobados') {
        asignacionesFiltradas = asignacionesFiltradas.filter((a) => a.quiz_puntaje >= 70);
      } else if (filtro === 'no_aprobados') {
        asignacionesFiltradas = asignacionesFiltradas.filter((a) => a.quiz_puntaje == null || a.quiz_puntaje < 70);
      }

      if (format === 'xlsx') {
        await CapacitacionesController._generateXLSXResultadosMasivo(res, capacitacion, asignacionesFiltradas, filtro);
      } else {
        await CapacitacionesController._generatePDFResultadosMasivo(
          res,
          capacitacion,
          asignacionesFiltradas,
          filtro,
          certificadoConfig,
          brandingConfig,
          reportHeader,
          reportFooter
        );
      }
    } catch (error) {
      console.error('Error descargando resultados masivos:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Métodos auxiliares para generar XLSX
  static _parseBase64Image(base64String) {
    if (!base64String || typeof base64String !== 'string') return null;
    const match = base64String.match(/^data:(image\/[a-zA-Z0-9+\-\.]+);base64,(.+)$/);
    const data = match ? match[2] : base64String;
    try {
      return Buffer.from(data, 'base64');
    } catch (error) {
      console.error('Error decodificando imagen base64:', error);
      return null;
    }
  }

  static async _generateXLSXResultado(res, asignacion) {
    try {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Resultado');

      worksheet.columns = [
        { header: 'Campo', key: 'campo', width: 25 },
        { header: 'Valor', key: 'valor', width: 40 }
      ];

      worksheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
      worksheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4472C4' } };

      const conductor = asignacion.conductor || {};
      const capacitacion = asignacion.capacitacion || {};

      worksheet.addRow({ campo: 'Capacitación', valor: capacitacion.titulo });
      worksheet.addRow({ campo: 'Nombre Conductor', valor: conductor.nombre });
      worksheet.addRow({ campo: 'Número de Documento', valor: conductor.cedula });
      worksheet.addRow({ campo: 'Cargo', valor: conductor.cargo || 'N/A' });
      worksheet.addRow({ campo: 'Estado', valor: asignacion.estado });
      worksheet.addRow({ campo: 'Calificación', valor: asignacion.quiz_puntaje ? `${asignacion.quiz_puntaje}%` : 'Pendiente' });
      worksheet.addRow({ campo: 'Fecha Completado', valor: asignacion.fecha_completado ? new Date(asignacion.fecha_completado).toLocaleDateString() : 'N/A' });
      worksheet.addRow({ campo: 'Firma', valor: '___________________________' });

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="resultado_${asignacion.id}.xlsx"`);
      
      return new Promise((resolve, reject) => {
        workbook.xlsx.write(res)
          .then(() => { res.end(); resolve(); })
          .catch(reject);
      });
    } catch (error) {
      console.error('Error generando XLSX individual:', error);
      throw error;
    }
  }

  static async _generateXLSXResultadosMasivo(res, capacitacion, asignaciones, filtro = 'todos') {
    try {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Resultados');

      worksheet.columns = [
        { header: 'Nombre', key: 'nombre', width: 20 },
        { header: 'Documento', key: 'cedula', width: 15 },
        { header: 'Cargo', key: 'cargo', width: 15 },
        { header: 'Estado', key: 'estado', width: 12 },
        { header: 'Calificación', key: 'calificacion', width: 12 },
        { header: 'Firma', key: 'firma', width: 20 }
      ];

      worksheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
      worksheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4472C4' } };

      if (Array.isArray(asignaciones)) {
        asignaciones.forEach((asig) => {
          const conductor = asig.conductor || {};
          worksheet.addRow({
            nombre: conductor.nombre || 'N/A',
            cedula: conductor.cedula || 'N/A',
            cargo: conductor.cargo || 'N/A',
            estado: asig.estado || 'N/A',
            calificacion: asig.quiz_puntaje ? `${asig.quiz_puntaje}%` : 'Pendiente',
            firma: '___________________________'
          });
        });
      }

      const filtroLabel = filtro === 'aprobados' ? '_aprobados' : filtro === 'no_aprobados' ? '_no_aprobados' : '';
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="resultados_${capacitacion.id}${filtroLabel}.xlsx"`);
      
      return new Promise((resolve, reject) => {
        workbook.xlsx.write(res)
          .then(() => { res.end(); resolve(); })
          .catch(reject);
      });
    } catch (error) {
      console.error('Error generando XLSX masivo:', error);
      throw error;
    }
  }

  // Métodos auxiliares para generar PDF
  static async _generatePDFResultado(res, asignacion) {
    try {
      const doc = new PDFDocument();

      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="resultado_${asignacion.id}.pdf"`);

      doc.pipe(res);

      const conductor = asignacion.conductor || {};
      const capacitacion = asignacion.capacitacion || {};

      doc.fontSize(18).font('Helvetica-Bold').text('RESULTADO DE CAPACITACIÓN', { align: 'center' });
      doc.moveDown();
      doc.fontSize(12).font('Helvetica-Bold').text(`Capacitación: ${capacitacion.titulo || 'N/A'}`);
      doc.moveDown();

      doc.fontSize(11).font('Helvetica-Bold').text('DATOS DEL CONDUCTOR:');
      doc.fontSize(10).font('Helvetica');
      doc.text(`Nombre: ${conductor.nombre || 'N/A'}`);
      doc.text(`Número de Documento: ${conductor.cedula || 'N/A'}`);
      doc.text(`Cargo: ${conductor.cargo || 'N/A'}`);
      doc.moveDown();

      doc.fontSize(11).font('Helvetica-Bold').text('RESULTADOS:');
      doc.fontSize(10).font('Helvetica');
      doc.text(`Estado: ${asignacion.estado || 'N/A'}`);
      doc.text(`Calificación: ${asignacion.quiz_puntaje ? `${asignacion.quiz_puntaje}%` : 'Pendiente'}`);
      doc.text(`Fecha Completado: ${asignacion.fecha_completado ? new Date(asignacion.fecha_completado).toLocaleDateString() : 'N/A'}`);
      doc.moveDown(2);

      doc.fontSize(11).font('Helvetica-Bold').text('FIRMA:');
      doc.moveDown();
      doc.fontSize(9).font('Helvetica').text('_____________________________');
      doc.text('Fecha: ' + new Date().toLocaleDateString());

      doc.end();
    } catch (error) {
      console.error('Error generando PDF individual:', error);
      throw error;
    }
  }

  static async _generatePDFResultadosMasivo(res, capacitacion, asignaciones, filtro = 'todos', certificadoConfig = {}, brandingConfig = {}, reportHeader = '', reportFooter = '') {
    try {
      const doc = new PDFDocument({ size: 'A4', margin: 40 });

      res.setHeader('Content-Type', 'application/pdf');
      const filtroLabel = filtro === 'aprobados' ? '_aprobados' : filtro === 'no_aprobados' ? '_no_aprobados' : '';
      res.setHeader('Content-Disposition', `attachment; filename="resultados_${capacitacion.id}${filtroLabel}.pdf"`);

      const headerText = reportHeader || '';
      const footerText = reportFooter || certificadoConfig.footer_text || '';
      const headerLogoBuffer = (certificadoConfig.show_logo_sistema !== false && brandingConfig.company_logo)
        ? CapacitacionesController._parseBase64Image(brandingConfig.company_logo)
        : null;
      const headerLogoHeight = certificadoConfig.logo_height || 60;

      const drawFooter = () => {
        if (!footerText) return;
        const bottomY = doc.page.height - 80;

        doc.fontSize(9).font('Helvetica').text(footerText, 40, bottomY, {
          width: doc.page.width - 80,
          align: 'center',
          lineGap: 2,
        });
      };

      doc.on('pageAdded', drawFooter);
      doc.pipe(res);

      if (headerLogoBuffer) {
        try {
          doc.image(headerLogoBuffer, 40, 40, { height: headerLogoHeight });
        } catch (err) {
          console.error('Error al dibujar logo en encabezado:', err);
        }
      }

      const headerLeft = headerLogoBuffer ? 40 + 20 + 140 : 40;
      const headerWidth = doc.page.width - headerLeft - 40;
      const headerTop = 40;

      doc.fontSize(18).font('Helvetica-Bold').text('LISTA DE ASISTENCIA Y RESULTADOS', headerLeft, headerTop, {
        width: headerWidth,
        align: 'center',
      });
      doc.fontSize(12).font('Helvetica').text(`Capacitación: ${capacitacion.titulo || 'N/A'}`, headerLeft, doc.y + 6, {
        width: headerWidth,
        align: 'center',
      });

      if (headerText) {
        doc.fontSize(11).font('Helvetica').text(headerText, headerLeft, doc.y + 6, {
          width: headerWidth,
          align: 'center',
        });
        doc.moveDown();
      }

      const filtroTexto = filtro === 'aprobados'
        ? 'Solo Aprobados'
        : filtro === 'no_aprobados'
          ? 'Solo No Aprobados'
          : 'Todos los resultados';

      doc.fontSize(11).font('Helvetica').text(`Filtro: ${filtroTexto}`, headerLeft, doc.y + 4, {
        width: headerWidth,
        align: 'center',
      });
      doc.fontSize(10).font('Helvetica').text(
        `Fecha de generación: ${new Date().toLocaleDateString('es-ES', { year: 'numeric', month: '2-digit', day: '2-digit' })} ${new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}`,
        headerLeft,
        doc.y + 4,
        {
          width: headerWidth,
          align: 'center',
        }
      );
      doc.moveDown(2);

      if (doc.y < 40 + headerLogoHeight + 20) {
        doc.y = 40 + headerLogoHeight + 20;
      }

      const tableTop = doc.y;
      const colPositions = { num: 30, nombre: 60, documento: 190, cargo: 270, estado: 340, calificacion: 410, firma: 480 };

      doc.fontSize(9).font('Helvetica-Bold');
      doc.text('#', colPositions.num, tableTop);
      doc.text('Nombre', colPositions.nombre, tableTop);
      doc.text('Documento', colPositions.documento, tableTop);
      doc.text('Cargo', colPositions.cargo, tableTop);
      doc.text('Estado', colPositions.estado, tableTop);
      doc.text('Calificación', colPositions.calificacion, tableTop);
      doc.text('Firma', colPositions.firma, tableTop);
      doc.moveTo(30, tableTop + 15).lineTo(565, tableTop + 15).stroke();

      let yPosition = tableTop + 25;
      doc.fontSize(8).font('Helvetica');

      if (Array.isArray(asignaciones)) {
        asignaciones.forEach((asig, index) => {
          const conductor = asig.conductor || {};
          const rowNum = index + 1;

          doc.text(rowNum.toString(), colPositions.num, yPosition);
          const nombre = (conductor.nombre || 'N/A').substring(0, 30);
          doc.text(nombre, colPositions.nombre, yPosition, { width: 115 });
          doc.text(conductor.cedula || 'N/A', colPositions.documento, yPosition);
          doc.text(conductor.cargo || 'N/A', colPositions.cargo, yPosition);
          const estadoText = asig.estado ? asig.estado.charAt(0).toUpperCase() + asig.estado.slice(1) : 'N/A';
          doc.text(estadoText, colPositions.estado, yPosition);
          const calificacion = asig.quiz_puntaje ? `${asig.quiz_puntaje}%` : 'Pendiente';
          doc.text(calificacion, colPositions.calificacion, yPosition);
          doc.text('___________', colPositions.firma, yPosition);

          yPosition += 20;

          if (yPosition > 700) {
            drawFooter();
            doc.addPage();
            doc.fontSize(9).font('Helvetica-Bold');
            doc.text('#', colPositions.num, 40);
            doc.text('Nombre', colPositions.nombre, 40);
            doc.text('Documento', colPositions.documento, 40);
            doc.text('Cargo', colPositions.cargo, 40);
            doc.text('Estado', colPositions.estado, 40);
            doc.text('Calificación', colPositions.calificacion, 40);
            doc.text('Firma', colPositions.firma, 40);
            doc.moveTo(30, 55).lineTo(565, 55).stroke();
            doc.fontSize(8).font('Helvetica');
            yPosition = 70;
          }
        });
      }

      doc.moveTo(30, yPosition).lineTo(565, yPosition).stroke();
      doc.moveDown(2);
      doc.fontSize(10).font('Helvetica-Bold').text('AUTORIZADO POR:');
      doc.moveDown(3);
      doc.fontSize(9).font('Helvetica');
      doc.text('Nombre: _____________________________');
      doc.text('Firma: _____________________________');
      doc.text('Fecha: ' + new Date().toLocaleDateString('es-ES'));

      drawFooter();
      doc.end();
    } catch (error) {
      console.error('Error generando PDF masivo:', error);
      throw error;
    }
  }

  /**
   * Genera PDF usando plantilla si está disponible
   */
  static async _generatePDFWithTemplate(res, capacitacion, asignaciones, filtro = 'todos', empresa = '', certificadoConfig = {}, brandingConfig = {}, reportHeader = '', reportFooter = '') {
    try {
      const templatesService = require('../services/templatesService');
      
      // Intentar cargar plantilla
      let template = null;
      try {
        template = await templatesService.getTemplate(empresa, 'default');
      } catch (err) {
        console.log('No template found, using default PDF generation');
      }

      // Si no hay plantilla, usar generación estándar
      if (!template) {
        return CapacitacionesController._generatePDFResultadosMasivo(
          res, capacitacion, asignaciones, filtro, certificadoConfig, brandingConfig, reportHeader, reportFooter
        );
      }

      // Usar plantilla para renderizar
      const renderedAsignaciones = await templatesService.renderWithTemplate(
        empresa,
        asignaciones,
        'default'
      );

      // Generar PDF con estructura de plantilla
      const doc = new PDFDocument({ size: 'A4', margin: 40 });
      res.setHeader('Content-Type', 'application/pdf');
      const filtroLabel = filtro === 'aprobados' ? '_aprobados' : filtro === 'no_aprobados' ? '_no_aprobados' : '';
      res.setHeader('Content-Disposition', `attachment; filename="resultados_${capacitacion.id}${filtroLabel}.pdf"`);

      doc.pipe(res);

      // Encabezado con logo de plantilla
      if (template.header_logo) {
        try {
          const logoBuffer = Buffer.isBuffer(template.header_logo)
            ? template.header_logo
            : Buffer.from(template.header_logo, 'base64');
          doc.image(logoBuffer, 40, 40, { height: template.header_logo_height || 60 });
        } catch (err) {
          console.error('Error dibujando logo de plantilla:', err);
        }
      }

      // Título y encabezado de plantilla
      const titleColor = template.title_color || '#1A1A2E';
      const headerBgColor = template.header_bg_color || '#0D6EFD';

      doc.fontSize(18).fillColor(titleColor).font('Helvetica-Bold')
        .text('LISTA DE ASISTENCIA Y RESULTADOS', 40, 120);
      
      if (template.header_text) {
        doc.fontSize(11).fillColor('#000000').font('Helvetica')
          .text(template.header_text, 40, doc.y + 6);
      }

      // Tabla con estructura de plantilla
      const headerColumns = template.columns_config || [
        { header: '#', width: 30 },
        { header: 'Nombre', width: 115 },
        { header: 'Documento', width: 80 },
        { header: 'Estado', width: 70 },
        { header: 'Calificación', width: 80 },
        { header: 'Firma', width: 85 }
      ];

      // Dibujar encabezados
      let xPos = 40;
      doc.fontSize(9).fillColor(headerBgColor).font('Helvetica-Bold');
      headerColumns.forEach(col => {
        doc.text(col.header, xPos, doc.y);
        xPos += col.width;
      });

      // Línea separadora
      doc.moveTo(40, doc.y + 5).lineTo(565, doc.y + 5).stroke();
      doc.moveDown(1);

      // Filas de datos
      doc.fontSize(8).fillColor('#000000').font('Helvetica');
      if (Array.isArray(renderedAsignaciones)) {
        renderedAsignaciones.forEach((asig, index) => {
          xPos = 40;
          doc.text((index + 1).toString(), xPos, doc.y, { width: 30 });
          xPos += 30;
          
          const nombre = (asig.conductor?.nombre || 'N/A').substring(0, 30);
          doc.text(nombre, xPos, doc.y, { width: 115 });
          xPos += 115;
          
          doc.text(asig.conductor?.cedula || 'N/A', xPos, doc.y, { width: 80 });
          xPos += 80;
          
          const estado = asig.estado ? asig.estado.charAt(0).toUpperCase() + asig.estado.slice(1) : 'N/A';
          doc.text(estado, xPos, doc.y, { width: 70 });
          xPos += 70;
          
          const calificacion = asig.quiz_puntaje ? `${asig.quiz_puntaje}%` : 'Pendiente';
          doc.text(calificacion, xPos, doc.y, { width: 80 });
          xPos += 80;
          
          doc.text('___________', xPos, doc.y, { width: 85 });

          if (doc.y > 700) {
            doc.addPage();
          }
        });
      }

      // Pie de página
      if (template.footer_text) {
        doc.fontSize(9).fillColor('#000000').font('Helvetica')
          .text(template.footer_text, 40, doc.page.height - 80, {
            width: doc.page.width - 80,
            align: 'center'
          });
      }

      doc.end();
    } catch (error) {
      console.error('Error generando PDF con plantilla:', error);
      // Fallback a generación estándar
      CapacitacionesController._generatePDFResultadosMasivo(
        res, capacitacion, asignaciones, filtro, certificadoConfig, brandingConfig, reportHeader, reportFooter
      );
    }
  }
}

module.exports = CapacitacionesController;
