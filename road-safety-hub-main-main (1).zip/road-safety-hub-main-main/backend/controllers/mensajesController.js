const mensajesService = require('../services/mensajesService');
const MensajesProgramadoModel = require('../models/mensajesProgramadoModel');

const getMensajes = async (req, res) => {
  try {
    const mensajes = await mensajesService.getAllMensajes();
    res.json(mensajes);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener mensajes', error: error.message });
  }
};

const getMensaje = async (req, res) => {
  try {
    const mensaje = await mensajesService.getMensajeById(req.params.id);
    if (!mensaje) return res.status(404).json({ message: 'Mensaje no encontrado' });
    res.json(mensaje);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener mensaje', error: error.message });
  }
};

const getMensajesByTipo = async (req, res) => {
  try {
    const { tipo } = req.params;
    const mensajes = await mensajesService.getMensajesByTipo(tipo);
    res.json(mensajes);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener mensajes por tipo', error: error.message });
  }
};

const getMensajesByEstado = async (req, res) => {
  try {
    const { estado } = req.params;
    const mensajes = await mensajesService.getMensajesByEstado(estado);
    res.json(mensajes);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener mensajes por estado', error: error.message });
  }
};

const createMensaje = async (req, res) => {
  try {
    const { 
      titulo, 
      tipo, 
      contenido, 
      destinatario, 
      asunto, 
      prioridad, 
      emoji, 
      estado,
      media_type,
      media_url,
      media_size,
      file_name,
      fecha_programada,
      hora_programada,
      conductor_id,
    } = req.body;

    if (!titulo || !contenido) {
      return res.status(400).json({ message: 'titulo y contenido son requeridos' });
    }

    const nuevoMensaje = await mensajesService.createMensaje({ 
      titulo, 
      tipo, 
      contenido,
      destinatario,
      asunto,
      prioridad,
      emoji,
      estado,
      media_type,
      media_url,
      media_size,
      file_name,
      fecha_programada,
      hora_programada,
      conductor_id,
    });

    // Crea o actualiza la fila en mensajes_programados
    if ((tipo === 'informativa' || tipo === 'broadcast') && fecha_programada) {
      try {
        await MensajesProgramadoModel.upsert(nuevoMensaje.id, fecha_programada, hora_programada ?? null);
      } catch (syncErr) {
        console.error('⚠️  upsert programado (create):', syncErr.message);
      }
    }

    res.status(201).json(nuevoMensaje);
  } catch (error) {
    console.error('Error creating mensaje:', error);
    res.status(500).json({ 
      message: 'Error al crear mensaje', 
      error: error.message,
    });
  }
};

const updateMensaje = async (req, res) => {
  try {
    const mensajeActualizado = await mensajesService.updateMensaje(req.params.id, req.body);
    if (!mensajeActualizado) return res.status(404).json({ message: 'Mensaje no encontrado' });

    const { tipo, fecha_programada, hora_programada } = req.body;
    if ((tipo === 'informativa' || tipo === 'broadcast') && fecha_programada) {
      try {
        await MensajesProgramadoModel.upsert(req.params.id, fecha_programada, hora_programada ?? null);
      } catch (syncErr) {
        console.error('⚠️  upsert programado (update):', syncErr.message);
      }
    }

    res.json(mensajeActualizado);
  } catch (error) {
    res.status(500).json({ message: 'Error al actualizar mensaje', error: error.message });
  }
};

const deleteMensaje = async (req, res) => {
  try {
    const mensajeEliminado = await mensajesService.deleteMensaje(req.params.id);
    if (!mensajeEliminado) return res.status(404).json({ message: 'Mensaje no encontrado' });
    res.json({ message: 'Mensaje eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ message: 'Error al eliminar mensaje', error: error.message });
  }
};

const uploadMedia = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file provided' });
    }

    const { tipo } = req.body;
    if (!tipo) {
      return res.status(400).json({ message: 'tipo is required' });
    }

    const mediaData = await mensajesService.uploadMedia(req.file, tipo);
    res.status(201).json(mediaData);
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ message: 'Error al subir archivo', error: error.message });
  }
};

const deleteMedia = async (req, res) => {
  try {
    const { filePath } = req.body;
    if (!filePath) {
      return res.status(400).json({ message: 'filePath is required' });
    }

    await mensajesService.deleteMedia(filePath);
    res.json({ message: 'Archivo eliminado correctamente' });
  } catch (error) {
    console.error('Delete error:', error);
    res.status(500).json({ message: 'Error al eliminar archivo', error: error.message });
  }
};

module.exports = {
  getMensajes,
  getMensaje,
  getMensajesByTipo,
  getMensajesByEstado,
  createMensaje,
  updateMensaje,
  deleteMensaje,
  uploadMedia,
  deleteMedia,
};
