const UsuarioModel = require('../models/usuarioModel.js');
const jwt = require('jsonwebtoken');
const tokenBlacklist = require('../utils/tokenBlacklist.js');

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET no está definido en las variables de entorno.');
  process.exit(1);
}

class AuthController {
  /**
   * Login - Validar credenciales y retornar token
   */
  static async login(req, res) {
    try {
      const { email, password } = req.body;

      // Validar entrada
      if (!email || !password) {
        return res.status(400).json({
          error: 'Email y contraseña son requeridos'
        });
      }

      // Verificar contraseña
      const resultado = await UsuarioModel.verificarPassword(email, password);
      
      if (!resultado.valido) {
        return res.status(401).json({
          error: 'Email o contraseña incorrectos'
        });
      }

      const usuario = resultado.usuario;

      // Obtener roles del usuario
      const roles = await UsuarioModel.getRoles(usuario.id);
      const rolNombre = roles[0]?.nombre || 'usuario';

      // Crear JWT con datos del usuario y rol
      const token = jwt.sign(
        {
          id: usuario.id,
          email: usuario.email,
          nombre: usuario.nombre,
          rol: rolNombre,
          empresa: usuario.empresa,
          conductor_id: usuario.conductor_id || null
        },
        JWT_SECRET,
        { expiresIn: '24h' }
      );

      // Retornar token y datos del usuario
      res.json({
        token,
        usuario: {
          id: usuario.id,
          email: usuario.email,
          nombre: usuario.nombre,
          empresa: usuario.empresa,
          rol: rolNombre,
          roles: roles.map(r => r.nombre),
          conductor_id: usuario.conductor_id || null
        }
      });
    } catch (error) {
      console.error('Error en AuthController.login():', error);
      res.status(500).json({
        error: 'Error al iniciar sesión'
      });
    }
  }

  /**
   * Logout - Invalidar sesión (en cliente se elimina el token)
   */
  static async logout(req, res) {
    try {
      // Revocar el token actual añadiéndolo a la lista negra
      const authHeader = req.headers.authorization;
      if (authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.substring(7);
        // exp está en segundos, convertir a ms
        const expMs = (req.usuario?.exp || 0) * 1000;
        tokenBlacklist.addToken(token, expMs || Date.now() + 24 * 60 * 60 * 1000);
      }
      res.json({ message: 'Sesión cerrada correctamente' });
    } catch (error) {
      console.error('Error en AuthController.logout():', error);
      res.status(500).json({
        error: 'Error al cerrar sesión'
      });
    }
  }

  /**
   * Obtener perfil del usuario autenticado
   */
  static async me(req, res) {
    try {
      const usuarioId = req.usuario.id;

      // Obtener usuario completo
      const usuario = await UsuarioModel.getById(usuarioId);
      
      if (!usuario) {
        return res.status(404).json({
          error: 'Usuario no encontrado'
        });
      }

      // Obtener roles
      const roles = await UsuarioModel.getRoles(usuarioId);

      res.json({
        id: usuario.id,
        email: usuario.email,
        nombre: usuario.nombre,
        empresa: usuario.empresa,
        activo: usuario.activo,
        roles: roles.map(r => r.nombre),
        created_at: usuario.created_at
      });
    } catch (error) {
      console.error('Error en AuthController.me():', error);
      res.status(500).json({
        error: 'Error al obtener perfil'
      });
    }
  }

  /**
   * Registrar nuevo usuario (solo admin puede hacer esto mediante usuariosController)
   * Este endpoint es para auto-registro opcional
   */
  static async registrar(req, res) {
    try {
      const { email, nombre, empresa, password } = req.body;

      // Validar entrada
      if (!email || !nombre || !password) {
        return res.status(400).json({
          error: 'Email, nombre y contraseña son requeridos'
        });
      }

      // Crear usuario con rol 'usuario' por defecto
      const usuario = await UsuarioModel.create({
        email,
        nombre,
        empresa,
        password,
        rolNombre: 'usuario'
      });

      res.status(201).json({
        message: 'Usuario registrado correctamente',
        usuario
      });
    } catch (error) {
      console.error('Error en AuthController.registrar():', error);
      res.status(500).json({
        error: 'Error al registrar usuario'
      });
    }
  }

  /**
   * Cambiar contraseña del usuario autenticado
   */
  static async cambiarPassword(req, res) {
    try {
      const usuarioId = req.usuario.id;
      const { passwordAntigua, passwordNueva } = req.body;

      if (!passwordAntigua || !passwordNueva) {
        return res.status(400).json({
          error: 'Contraseña antigua y nueva son requeridas'
        });
      }

      await UsuarioModel.cambiarPassword(usuarioId, passwordAntigua, passwordNueva);

      res.json({
        message: 'Contraseña actualizada correctamente'
      });
    } catch (error) {
      console.error('Error en AuthController.cambiarPassword():', error);
      res.status(400).json({
        error: error.message || 'Error al cambiar contraseña'
      });
    }
  }

  /**
   * Actualizar perfil del usuario autenticado
   */
  static async actualizarPerfil(req, res) {
    try {
      const usuarioId = req.usuario.id;
      const { nombre, empresa } = req.body;

      if (!nombre || !nombre.trim()) {
        return res.status(400).json({ error: 'El nombre es requerido' });
      }

      const usuarioActualizado = await UsuarioModel.update(usuarioId, {
        nombre: nombre.trim(),
        empresa: empresa?.trim() || null,
        activo: true
      });

      res.json({
        message: 'Perfil actualizado correctamente',
        usuario: {
          id: usuarioActualizado.id,
          email: usuarioActualizado.email,
          nombre: usuarioActualizado.nombre,
          empresa: usuarioActualizado.empresa
        }
      });
    } catch (error) {
      console.error('Error en AuthController.actualizarPerfil():', error);
      res.status(500).json({ error: 'Error al actualizar perfil' });
    }
  }

  /**
   * Verificar si el token es válido
   */
  static async verificarToken(req, res) {
    try {
      res.json({
        valido: true,
        usuario: req.usuario
      });
    } catch (error) {
      console.error('Error en AuthController.verificarToken():', error);
      res.status(401).json({
        valido: false,
        error: 'Token inválido'
      });
    }
  }
}

module.exports = AuthController;
