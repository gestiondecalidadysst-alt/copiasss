const reportesService = require('../services/reportesService');

const getReportes = async (req, res) => {
  try {
    // Extraer parámetros de paginación de query params
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 100;
    const noPagination = req.query.all === 'true'; // ?all=true para obtener todos

    // Validar límites razonables
    if (limit > 5000) {
      return res.status(400).json({ 
        message: 'Límite muy alto. Máximo permitido: 5000 registros por página',
        maxLimit: 5000
      });
    }

    const options = {
      page,
      limit,
      includePagination: !noPagination
    };

    const result = await reportesService.getAllReportes(options);
    
    // Si hay paginación, enviar headers adicionales
    if (result.pagination) {
      res.set({
        'X-Total-Count': result.pagination.total,
        'X-Page': result.pagination.page,
        'X-Per-Page': result.pagination.limit,
        'X-Total-Pages': result.pagination.totalPages
      });
    }

    res.json(result);
  } catch (error) {
    console.error('Error al obtener reportes:', error);
    res.status(500).json({ message: 'Error al obtener reportes', error: error.message });
  }
};

const getReporte = async (req, res) => {
  try {
    const reporte = await reportesService.getReporteById(req.params.id);
    if (!reporte) return res.status(404).json({ message: 'Reporte no encontrado' });
    res.json(reporte);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener reporte', error: error.message });
  }
};

const createReporte = async (req, res) => {
  try {
    const nuevoReporte = await reportesService.createReporte(req.body);
    res.status(201).json(nuevoReporte);
  } catch (error) {
    res.status(500).json({ message: 'Error al crear reporte', error: error.message });
  }
};

const updateReporte = async (req, res) => {
  try {
    const reporteActualizado = await reportesService.updateReporte(req.params.id, req.body);
    if (!reporteActualizado) return res.status(404).json({ message: 'Reporte no encontrado' });
    res.json(reporteActualizado);
  } catch (error) {
    res.status(500).json({ message: 'Error al actualizar reporte', error: error.message });
  }
};

const deleteReporte = async (req, res) => {
  try {
    const reporteEliminado = await reportesService.deleteReporte(req.params.id);
    if (!reporteEliminado) {
      return res.status(404).json({ message: 'Reporte no encontrado' });
    }
    console.log(`✅ Reporte ${req.params.id} eliminado correctamente`);
    res.json({ message: 'Reporte eliminado correctamente', id: reporteEliminado.id });
  } catch (error) {
    console.error(`❌ Error al eliminar reporte ${req.params.id}:`, error);
    res.status(500).json({ message: 'Error al eliminar reporte', error: error.message });
  }
};

module.exports = {
  getReportes,
  getReporte,
  createReporte,
  updateReporte,
  deleteReporte
};
