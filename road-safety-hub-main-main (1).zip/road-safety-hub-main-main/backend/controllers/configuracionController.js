const supabase = require('../config/supabaseClient');

class ConfiguracionController {
  /**
   * GET /api/configuracion/certificado
   * Devuelve la configuración del diploma de la empresa del usuario autenticado.
   */
  static async getCertificadoConfig(req, res) {
    try {
      const empresa = req.usuario?.empresa || req.usuario?.email;
      if (!empresa) return res.status(400).json({ error: 'Empresa no identificada' });

      const { data, error } = await supabase
        .from('certificado_config')
        .select('*')
        .eq('empresa', empresa)
        .maybeSingle();

      if (error) throw error;
      res.json(data ?? null);
    } catch (error) {
      console.error('Error en getCertificadoConfig:', error);
      res.status(500).json({ error: 'Error al obtener configuración del diploma' });
    }
  }

  /**
   * PUT /api/configuracion/certificado
   * Crea o actualiza la configuración del diploma de la empresa (upsert).
   * Body: { titulo, certify_text, course_intro, firma_nombre, firma_titulo,
   *         footer_text, numero_prefix, show_numero,
   *         color_fondo, color_borde, color_titulo, color_nombre,
   *         color_texto, color_acento, show_logo_sistema,
   *         campos_activos, etiquetas_campos,
   *         // Nuevos campos de tipografía y tamaños
   *         font_family, title_font_size, name_font_size,
   *         body_font_size, course_font_size, logo_height, footer_logo_height }
   */
  static async upsertCertificadoConfig(req, res) {
    try {
      const empresa = req.usuario?.empresa || req.usuario?.email;
      if (!empresa) return res.status(400).json({ error: 'Empresa no identificada' });

      const {
        titulo, certify_text, course_intro, firma_nombre, firma_titulo,
        footer_text, numero_prefix, show_numero,
        color_fondo, color_borde, color_titulo, color_nombre,
        color_texto, color_acento, show_logo_sistema,
        campos_activos, etiquetas_campos,
        font_family, title_font_size, name_font_size,
        body_font_size, course_font_size, logo_height, footer_logo_height,
      } = req.body;

      const payload = {
        empresa,
        updated_at: new Date().toISOString(),
        ...(titulo           !== undefined && { titulo }),
        ...(certify_text     !== undefined && { certify_text }),
        ...(course_intro     !== undefined && { course_intro }),
        ...(firma_nombre     !== undefined && { firma_nombre }),
        ...(firma_titulo     !== undefined && { firma_titulo }),
        ...(footer_text      !== undefined && { footer_text }),
        ...(numero_prefix    !== undefined && { numero_prefix }),
        ...(show_numero      !== undefined && { show_numero }),
        ...(color_fondo      !== undefined && { color_fondo }),
        ...(color_borde      !== undefined && { color_borde }),
        ...(color_titulo     !== undefined && { color_titulo }),
        ...(color_nombre     !== undefined && { color_nombre }),
        ...(color_texto      !== undefined && { color_texto }),
        ...(color_acento     !== undefined && { color_acento }),
        ...(show_logo_sistema !== undefined && { show_logo_sistema }),
        ...(campos_activos   !== undefined && { campos_activos }),
        ...(etiquetas_campos !== undefined && { etiquetas_campos }),
        ...(font_family      !== undefined && { font_family }),
        ...(title_font_size  !== undefined && { title_font_size }),
        ...(name_font_size   !== undefined && { name_font_size }),
        ...(body_font_size   !== undefined && { body_font_size }),
        ...(course_font_size !== undefined && { course_font_size }),
        ...(logo_height      !== undefined && { logo_height }),
        ...(footer_logo_height !== undefined && { footer_logo_height }),
      };

      const { data, error } = await supabase
        .from('certificado_config')
        .upsert(payload, { onConflict: 'empresa' })
        .select()
        .single();

      if (error) throw error;
      res.json(data);
    } catch (error) {
      console.error('Error en upsertCertificadoConfig:', error);
      res.status(500).json({ error: 'Error al guardar configuración del diploma' });
    }
  }

  /**
   * GET /api/configuracion/branding
   * Devuelve el branding (nombre y logo) de la empresa del usuario autenticado.
   */
  static async getBranding(req, res) {
    try {
      const empresa = req.usuario?.empresa || req.usuario?.email;
      if (!empresa) return res.status(400).json({ error: 'Empresa no identificada' });

      const { data, error } = await supabase
        .from('branding_config')
        .select('*')
        .eq('empresa', empresa)
        .maybeSingle();

      if (error) throw error;
      res.json(data ?? null);
    } catch (error) {
      console.error('Error en getBranding:', error);
      res.status(500).json({ error: 'Error al obtener branding' });
    }
  }

  /**
   * PUT /api/configuracion/branding
   * Crea o actualiza el branding de la empresa (upsert).
   * Body: { company_name, company_logo }
   */
  static async upsertBranding(req, res) {
    try {
      const empresa = req.usuario?.empresa || req.usuario?.email;
      if (!empresa) return res.status(400).json({ error: 'Empresa no identificada' });

      const { company_name, company_logo } = req.body;

      const payload = {
        empresa,
        updated_at: new Date().toISOString(),
        ...(company_name !== undefined && { company_name }),
        ...(company_logo !== undefined && { company_logo }),
      };

      const { data, error } = await supabase
        .from('branding_config')
        .upsert(payload, { onConflict: 'empresa' })
        .select()
        .single();

      if (error) throw error;
      res.json(data);
    } catch (error) {
      console.error('Error en upsertBranding:', error);
      res.status(500).json({ error: 'Error al guardar branding' });
    }
  }

  /**
   * GET /api/configuracion/plantillas
   * Obtener todas las plantillas de la empresa
   */
  static async getPlantillas(req, res) {
    try {
      const templatesService = require('../services/templatesService');
      const empresa = req.usuario?.empresa || req.usuario?.email;
      if (!empresa) return res.status(400).json({ error: 'Empresa no identificada' });

      const templates = await templatesService.getAll(empresa);
      res.json(templates);
    } catch (error) {
      console.error('Error en getPlantillas:', error);
      res.status(500).json({ error: 'Error al obtener plantillas' });
    }
  }

  /**
   * POST /api/configuracion/plantillas/importar
   * Importar plantilla desde archivo XLSX
   * Body: multipart/form-data con campo 'file'
   */
  static async importPlantilla(req, res) {
    try {
      const templatesService = require('../services/templatesService');
      const empresa = req.usuario?.empresa || req.usuario?.email;
      if (!empresa) return res.status(400).json({ error: 'Empresa no identificada' });

      if (!req.file) {
        return res.status(400).json({ error: 'No se proporcionó archivo' });
      }

      const templateName = req.body.templateName || 'default';
      const result = await templatesService.importTemplate(
        empresa,
        req.file.buffer,
        templateName
      );

      res.json(result);
    } catch (error) {
      console.error('Error en importPlantilla:', error);
      res.status(500).json({ error: error.message || 'Error importando plantilla' });
    }
  }

  /**
   * PUT /api/configuracion/plantillas/:templateName
   * Actualizar metadatos de plantilla
   */
  static async updatePlantilla(req, res) {
    try {
      const templatesService = require('../services/templatesService');
      const empresa = req.usuario?.empresa || req.usuario?.email;
      if (!empresa) return res.status(400).json({ error: 'Empresa no identificada' });

      const { templateName } = req.params;
      const updates = req.body;

      const updated = await templatesService.updateTemplate(empresa, templateName, updates);
      res.json(updated);
    } catch (error) {
      console.error('Error en updatePlantilla:', error);
      res.status(500).json({ error: 'Error actualizando plantilla' });
    }
  }

  /**
   * DELETE /api/configuracion/plantillas/:id
   * Eliminar plantilla
   */
  static async deletePlantilla(req, res) {
    try {
      const templatesService = require('../services/templatesService');
      const { id } = req.params;

      await templatesService.deleteTemplate(id);
      res.json({ message: 'Plantilla eliminada' });
    } catch (error) {
      console.error('Error en deletePlantilla:', error);
      res.status(500).json({ error: 'Error eliminando plantilla' });
    }
  }
}

module.exports = ConfiguracionController;
