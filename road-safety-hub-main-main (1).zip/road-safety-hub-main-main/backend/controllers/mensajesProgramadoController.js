const MensajesProgramadoModel = require('../models/mensajesProgramadoModel');

/**
 * GET /api/mensajes/:id/programados
 * Devuelve array con la fila de programación (o [] si no existe).
 */
const getProgramados = async (req, res) => {
  try {
    const fila = await MensajesProgramadoModel.getByMensajeId(req.params.id);
    res.json(fila ? [fila] : []);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener programados', error: error.message });
  }
};

/**
 * PATCH /api/mensajes/:id/programados
 * Cambia el estado del mensaje programado.
 *
 * Body: { estado: "enviado"|"programado" }
 */
const updateEstado = async (req, res) => {
  const { estado } = req.body;

  if (!estado) {
    return res.status(400).json({ message: '"estado" es requerido' });
  }
  if (!['enviado', 'programado'].includes(estado)) {
    return res.status(400).json({ message: 'estado debe ser "enviado" o "programado"' });
  }

  try {
    const actualizado = await MensajesProgramadoModel.updateEstado(req.params.id, estado);
    res.json(actualizado);
  } catch (error) {
    res.status(500).json({ message: 'Error al actualizar estado', error: error.message });
  }
};

module.exports = { getProgramados, updateEstado };

