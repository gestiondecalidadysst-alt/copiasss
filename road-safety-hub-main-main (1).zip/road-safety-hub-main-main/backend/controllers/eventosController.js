const eventosService = require('../services/eventosService');

const getEventos = async (req, res) => {
  try {
    const { fecha_inicio, fecha_fin } = req.query;
    let eventos;
    if (fecha_inicio && fecha_fin) {
      eventos = await eventosService.getEventosByDateRange(fecha_inicio, fecha_fin);
    } else {
      eventos = await eventosService.getAllEventos();
    }
    res.json(eventos);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener eventos', error: error.message });
  }
};

const getEvento = async (req, res) => {
  try {
    const evento = await eventosService.getEventoById(req.params.id);
    if (!evento) return res.status(404).json({ message: 'Evento no encontrado' });
    res.json(evento);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener evento', error: error.message });
  }
};

const createEvento = async (req, res) => {
  try {
    const nuevoEvento = await eventosService.createEvento(req.body);
    res.status(201).json(nuevoEvento);
  } catch (error) {
    res.status(500).json({ message: 'Error al crear evento', error: error.message });
  }
};

const updateEvento = async (req, res) => {
  try {
    const eventoActualizado = await eventosService.updateEvento(req.params.id, req.body);
    if (!eventoActualizado) return res.status(404).json({ message: 'Evento no encontrado' });
    res.json(eventoActualizado);
  } catch (error) {
    res.status(500).json({ message: 'Error al actualizar evento', error: error.message });
  }
};

const deleteEvento = async (req, res) => {
  try {
    const eventoEliminado = await eventosService.deleteEvento(req.params.id);
    if (!eventoEliminado) return res.status(404).json({ message: 'Evento no encontrado' });
    res.json({ message: 'Evento eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ message: 'Error al eliminar evento', error: error.message });
  }
};

module.exports = {
  getEventos,
  getEvento,
  createEvento,
  updateEvento,
  deleteEvento
};
