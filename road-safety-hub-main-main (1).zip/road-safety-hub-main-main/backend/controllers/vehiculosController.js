const vehiculosService = require('../services/vehiculosService');

const getVehiculos = async (req, res) => {
  try { res.json(await vehiculosService.getAll()); }
  catch (error) { res.status(500).json({ message: 'Error', error: error.message }); }
};

const getVehiculo = async (req, res) => {
  try { 
    const v = await vehiculosService.getById(req.params.id);
    v ? res.json(v) : res.status(404).json({ message: 'No encontrado' });
  } catch (error) { res.status(500).json({ message: 'Error', error: error.message }); }
};

const createVehiculo = async (req, res) => {
  try { res.status(201).json(await vehiculosService.create(req.body)); }
  catch (error) { res.status(500).json({ message: 'Error', error: error.message }); }
};

const updateVehiculo = async (req, res) => {
  try {
    const v = await vehiculosService.update(req.params.id, req.body);
    v ? res.json(v) : res.status(404).json({ message: 'No encontrado' });
  } catch (error) { res.status(500).json({ message: 'Error', error: error.message }); }
};

const deleteVehiculo = async (req, res) => {
  try {
    const v = await vehiculosService.delete(req.params.id);
    v ? res.json({ message: 'Eliminado' }) : res.status(404).json({ message: 'No encontrado' });
  } catch (error) { res.status(500).json({ message: 'Error', error: error.message }); }
};

module.exports = { getVehiculos, getVehiculo, createVehiculo, updateVehiculo, deleteVehiculo };
