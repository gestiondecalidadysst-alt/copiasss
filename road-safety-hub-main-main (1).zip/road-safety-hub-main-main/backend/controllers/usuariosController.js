const UsuarioModel = require('../models/usuarioModel.js');

class UsuariosController {
  /**
   * Obtener todos los usuarios (solo admin)
   */
  static async getAll(req, res) {
    try {
      const usuarios = await UsuarioModel.getAll();

      res.json({
        total: usuarios.length,
        usuarios: usuarios.map(u => ({
          id: u.id,
          email: u.email,
          nombre: u.nombre,
          empresa: u.empresa,
          activo: u.activo,
          roles: u.usuario_roles?.map(ur => ur.roles?.nombre) || [],
          created_at: u.created_at
        }))
      });
    } catch (error) {
      console.error('Error en UsuariosController.getAll():', error);
      res.status(500).json({
        error: 'Error al obtener usuarios'
      });
    }
  }

  /**
   * Obtener usuario por ID
   */
  static async getById(req, res) {
    try {
      const { id } = req.params;

      const usuario = await UsuarioModel.getById(id);

      if (!usuario) {
        return res.status(404).json({
          error: 'Usuario no encontrado'
        });
      }

      res.json({
        id: usuario.id,
        email: usuario.email,
        nombre: usuario.nombre,
        empresa: usuario.empresa,
        activo: usuario.activo,
        roles: usuario.usuario_roles?.map(ur => ur.roles?.nombre) || [],
        created_at: usuario.created_at
      });
    } catch (error) {
      console.error('Error en UsuariosController.getById():', error);
      res.status(500).json({
        error: 'Error al obtener usuario'
      });
    }
  }

  /**
   * Crear nuevo usuario (solo admin)
   */
  static async crear(req, res) {
    try {
      const { email, nombre, empresa, password, rol = 'usuario' } = req.body;

      // Validar entrada
      if (!email || !nombre || !password) {
        return res.status(400).json({
          error: 'Email, nombre y contraseña son requeridos'
        });
      }

      // Validar rol válido
      const rolesValidos = ['admin', 'usuario', 'conductor'];
      if (!rolesValidos.includes(rol)) {
        return res.status(400).json({
          error: 'Rol inválido. Roles válidos: admin, usuario, conductor'
        });
      }

      // Crear usuario
      const usuarioCreado = await UsuarioModel.create({
        email,
        nombre,
        empresa,
        password,
        rolNombre: rol,
        conductor_id: req.body.conductor_id || null
      });

      res.status(201).json({
        message: 'Usuario creado correctamente',
        usuario: usuarioCreado
      });
    } catch (error) {
      console.error('Error en UsuariosController.crear():', error);
      res.status(400).json({
        error: error.message || 'Error al crear usuario'
      });
    }
  }

  /**
   * Actualizar usuario (solo admin)
   */
  static async actualizar(req, res) {
    try {
      const { id } = req.params;
      const { nombre, empresa, activo } = req.body;

      // Validar que el usuario existe
      const usuario = await UsuarioModel.getById(id);
      if (!usuario) {
        return res.status(404).json({
          error: 'Usuario no encontrado'
        });
      }

      // Actualizar usuario
      const usuarioActualizado = await UsuarioModel.update(id, {
        nombre: nombre || usuario.nombre,
        empresa: empresa !== undefined ? empresa : usuario.empresa,
        activo: activo !== undefined ? activo : usuario.activo
      });

      res.json({
        message: 'Usuario actualizado correctamente',
        usuario: usuarioActualizado
      });
    } catch (error) {
      console.error('Error en UsuariosController.actualizar():', error);
      res.status(500).json({
        error: 'Error al actualizar usuario'
      });
    }
  }

  /**
   * Eliminar usuario (solo admin)
   */
  static async eliminar(req, res) {
    try {
      const { id } = req.params;

      // Validar que el usuario existe
      const usuario = await UsuarioModel.getById(id);
      if (!usuario) {
        return res.status(404).json({
          error: 'Usuario no encontrado'
        });
      }

      // No permitir eliminar al único admin
      const roles = await UsuarioModel.getRoles(id);
      if (roles.some(r => r.nombre === 'admin')) {
        const adminCount = await this._contarAdmins();
        if (adminCount <= 1) {
          return res.status(400).json({
            error: 'No se puede eliminar el único administrador del sistema'
          });
        }
      }

      await UsuarioModel.delete(id);

      res.json({
        message: 'Usuario eliminado correctamente'
      });
    } catch (error) {
      console.error('Error en UsuariosController.eliminar():', error);
      res.status(500).json({
        error: 'Error al eliminar usuario'
      });
    }
  }

  /**
   * Asignar rol a usuario (solo admin)
   */
  static async asignarRol(req, res) {
    try {
      const { id } = req.params;
      const { rol } = req.body;

      if (!rol) {
        return res.status(400).json({
          error: 'Rol es requerido'
        });
      }

      // Validar rol válido
      const rolesValidos = ['admin', 'usuario'];
      if (!rolesValidos.includes(rol)) {
        return res.status(400).json({
          error: 'Rol inválido. Roles válidos: admin, usuario'
        });
      }

      // Validar que el usuario existe
      const usuario = await UsuarioModel.getById(id);
      if (!usuario) {
        return res.status(404).json({
          error: 'Usuario no encontrado'
        });
      }

      await UsuarioModel.asignarRol(id, rol);

      res.json({
        message: `Rol ${rol} asignado correctamente`
      });
    } catch (error) {
      console.error('Error en UsuariosController.asignarRol():', error);
      res.status(500).json({
        error: 'Error al asignar rol'
      });
    }
  }

  /**
   * Remover rol de usuario (solo admin)
   */
  static async removerRol(req, res) {
    try {
      const { id } = req.params;
      const { rol } = req.body;

      if (!rol) {
        return res.status(400).json({
          error: 'Rol es requerido'
        });
      }

      // Validar que el usuario existe
      const usuario = await UsuarioModel.getById(id);
      if (!usuario) {
        return res.status(404).json({
          error: 'Usuario no encontrado'
        });
      }

      // Validar que el usuario tiene al menos un rol
      const roles = await UsuarioModel.getRoles(id);
      if (roles.length <= 1) {
        return res.status(400).json({
          error: 'El usuario debe tener al menos un rol'
        });
      }

      await UsuarioModel.removerRol(id, rol);

      res.json({
        message: `Rol ${rol} removido correctamente`
      });
    } catch (error) {
      console.error('Error en UsuariosController.removerRol():', error);
      res.status(500).json({
        error: 'Error al remover rol'
      });
    }
  }

  /**
   * Activar/Desactivar usuario
   */
  static async toggleActivo(req, res) {
    try {
      const { id } = req.params;

      const usuario = await UsuarioModel.toggleActivo(id);

      res.json({
        message: `Usuario ${usuario.activo ? 'activado' : 'desactivado'} correctamente`,
        usuario
      });
    } catch (error) {
      console.error('Error en UsuariosController.toggleActivo():', error);
      res.status(500).json({
        error: 'Error al cambiar estado del usuario'
      });
    }
  }

  /**
   * Helper: Contar administradores en el sistema
   */
  static async _contarAdmins() {
    try {
      const usuarios = await UsuarioModel.getAll();
      return usuarios.filter(u =>
        u.usuario_roles?.some(ur => ur.roles?.nombre === 'admin')
      ).length;
    } catch (error) {
      console.error('Error en UsuariosController._contarAdmins():', error);
      return 0;
    }
  }
}

module.exports = UsuariosController;
