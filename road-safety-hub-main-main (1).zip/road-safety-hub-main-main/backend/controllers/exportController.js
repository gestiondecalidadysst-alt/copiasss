const EventosService = require('../services/eventosService');
const { streamJsonResponse, processBatches } = require('../utils/streamHelpers');

/**
 * Controlador optimizado para exportar eventos grandes
 * Usa streaming para evitar colapso de memoria
 */

/**
 * Exportar eventos en formato JSON con streaming
 * Para datasets muy grandes que no caben en memoria
 */
const exportEventosStream = async (req, res) => {
  try {
    console.log('📤 Iniciando exportación en streaming...');
    
    const { 
      placa, 
      fecha_desde, 
      fecha_hasta, 
      tipo_evento,
      format = 'json' 
    } = req.query;

    // Obtener eventos en batches
    const eventos = await EventosService.getAllEventos();
    
    // Aplicar filtros
    let filtered = eventos;
    
    if (placa && placa !== 'todas') {
      filtered = filtered.filter(e => e.placa?.trim() === placa);
    }
    
    if (fecha_desde) {
      const desde = new Date(fecha_desde);
      filtered = filtered.filter(e => new Date(e.created_at) >= desde);
    }
    
    if (fecha_hasta) {
      const hasta = new Date(fecha_hasta);
      hasta.setHours(23, 59, 59, 999);
      filtered = filtered.filter(e => new Date(e.created_at) <= hasta);
    }
    
    if (tipo_evento && tipo_evento !== 'todos') {
      if (tipo_evento === 'alta') {
        filtered = filtered.filter(e => e.velocidad > 100);
      } else if (tipo_evento === 'media') {
        filtered = filtered.filter(e => e.velocidad > 80 && e.velocidad <= 100);
      } else if (tipo_evento === 'baja') {
        filtered = filtered.filter(e => e.velocidad <= 80);
      }
    }

    console.log(`📊 Eventos a exportar: ${filtered.length}`);

    // Metadata del reporte
    const metadata = {
      total_eventos: filtered.length,
      fecha_generacion: new Date().toISOString(),
      filtros: { placa, fecha_desde, fecha_hasta, tipo_evento }
    };

    // Calcular velocidad promedio
    if (filtered.length > 0) {
      metadata.velocidad_promedio = (
        filtered.reduce((sum, e) => sum + e.velocidad, 0) / filtered.length
      ).toFixed(2);
    }

    // Stream de respuesta
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename=eventos_${Date.now()}.json`);
    
    // Enviar metadata
    res.write('{"metadata":' + JSON.stringify(metadata) + ',"eventos":[');
    
    // Enviar eventos en batches para no sobrecargar memoria
    const batchSize = 5000;
    for (let i = 0; i < filtered.length; i += batchSize) {
      const batch = filtered.slice(i, i + batchSize);
      
      batch.forEach((evento, index) => {
        if (i > 0 || index > 0) res.write(',');
        res.write(JSON.stringify(evento));
      });
      
      // Pequeña pausa para liberar CPU
      await new Promise(resolve => setImmediate(resolve));
    }
    
    res.write(']}');
    res.end();
    
    console.log('✅ Exportación completada');
    
  } catch (error) {
    console.error('❌ Error en exportación:', error);
    
    if (!res.headersSent) {
      res.status(500).json({ 
        message: 'Error al exportar eventos', 
        error: error.message 
      });
    }
  }
};

/**
 * Obtener estadísticas de eventos sin cargar todos los datos
 */
const getEventosStats = async (req, res) => {
  try {
    const eventos = await EventosService.getAllEventos();
    
    const stats = {
      total: eventos.length,
      por_placa: {},
      velocidad_promedio: 0,
      velocidad_maxima: 0,
      fecha_primer_evento: null,
      fecha_ultimo_evento: null,
      distribucion_velocidades: {
        baja: 0,      // <= 80 km/h
        media: 0,     // 80-100 km/h
        alta: 0       // > 100 km/h
      }
    };

    if (eventos.length > 0) {
      // Estadísticas agregadas sin copiar todos los datos
      let sumVelocidad = 0;
      let maxVelocidad = 0;
      let minFecha = new Date(eventos[0].created_at);
      let maxFecha = new Date(eventos[0].created_at);

      eventos.forEach(e => {
        // Velocidades
        sumVelocidad += e.velocidad;
        if (e.velocidad > maxVelocidad) maxVelocidad = e.velocidad;
        
        // Distribución
        if (e.velocidad <= 80) stats.distribucion_velocidades.baja++;
        else if (e.velocidad <= 100) stats.distribucion_velocidades.media++;
        else stats.distribucion_velocidades.alta++;
        
        // Por placa
        const placa = e.placa?.trim() || 'Sin placa';
        stats.por_placa[placa] = (stats.por_placa[placa] || 0) + 1;
        
        // Fechas
        const fecha = new Date(e.created_at);
        if (fecha < minFecha) minFecha = fecha;
        if (fecha > maxFecha) maxFecha = fecha;
      });

      stats.velocidad_promedio = (sumVelocidad / eventos.length).toFixed(2);
      stats.velocidad_maxima = maxVelocidad;
      stats.fecha_primer_evento = minFecha.toISOString();
      stats.fecha_ultimo_evento = maxFecha.toISOString();
    }

    res.json(stats);
    
  } catch (error) {
    console.error('Error al obtener estadísticas:', error);
    res.status(500).json({ 
      message: 'Error al obtener estadísticas', 
      error: error.message 
    });
  }
};

module.exports = {
  exportEventosStream,
  getEventosStats
};
