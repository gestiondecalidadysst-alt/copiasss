const MensajesEnvioModel = require('../models/mensajesEnvioModel');

/**
 * GET /api/mensajes/:id/envios
 * Devuelve todos los envíos registrados de un mensaje.
 */
const getEnviosByMensaje = async (req, res) => {
  try {
    const envios = await MensajesEnvioModel.getByMensajeId(req.params.id);
    res.json(envios);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener envíos', error: error.message });
  }
};

/**
 * POST /api/mensajes/:id/envios
 * Registra que el mensaje fue enviado en una fecha/franja concreta.
 *
 * Body esperado:
 *   { programacion_idx: 0 | 1, fecha: "YYYY-MM-DD", hora_envio?: "HH:MM" }
 *
 * Respuestas:
 *   201 – envío registrado correctamente
 *   409 – el mensaje ya fue enviado en esa fecha/franja
 *   400 – faltan campos requeridos
 */
const registrarEnvio = async (req, res) => {
  const { programacion_idx, fecha, hora_envio } = req.body;

  if (fecha === undefined || fecha === null) {
    return res.status(400).json({ message: 'El campo "fecha" es requerido (YYYY-MM-DD)' });
  }

  // Validar formato de fecha YYYY-MM-DD
  if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha)) {
    return res.status(400).json({ message: 'Formato de fecha inválido. Use YYYY-MM-DD' });
  }

  try {
    const registro = await MensajesEnvioModel.registrarEnvio({
      mensajeId:       req.params.id,
      programacionIdx: programacion_idx ?? 0,
      fecha,
      horaEnvio:       hora_envio ?? null,
    });

    if (!registro) {
      // null → unique_violation → ya fue enviado en esta fecha/franja
      return res.status(409).json({
        message: 'Este mensaje ya fue enviado en esa fecha y franja de programación',
        already_sent: true,
      });
    }

    res.status(201).json(registro);
  } catch (error) {
    res.status(500).json({ message: 'Error al registrar envío', error: error.message });
  }
};

/**
 * DELETE /api/mensajes/:id/envios
 * Elimina el registro de envío de una fecha/franja (deshace el marcado).
 *
 * Body esperado:
 *   { programacion_idx: 0 | 1, fecha: "YYYY-MM-DD" }
 */
const eliminarEnvio = async (req, res) => {
  const { programacion_idx, fecha } = req.body;

  if (!fecha) {
    return res.status(400).json({ message: 'El campo "fecha" es requerido' });
  }

  try {
    const eliminado = await MensajesEnvioModel.eliminarEnvio({
      mensajeId:       req.params.id,
      programacionIdx: programacion_idx ?? 0,
      fecha,
    });
    res.json(eliminado);
  } catch (error) {
    res.status(500).json({ message: 'Error al eliminar envío', error: error.message });
  }
};

module.exports = { getEnviosByMensaje, registrarEnvio, eliminarEnvio };
