const conductoresService = require('../services/conductoresService');

const getConductores = async (req, res) => {
  try { res.json(await conductoresService.getAll()); }
  catch (error) { res.status(500).json({ message: 'Error', error: error.message }); }
};

const getConductor = async (req, res) => {
  try { 
    const c = await conductoresService.getById(req.params.id);
    c ? res.json(c) : res.status(404).json({ message: 'No encontrado' });
  } catch (error) { res.status(500).json({ message: 'Error', error: error.message }); }
};

const createConductor = async (req, res) => {
  try {
    res.status(201).json(await conductoresService.create(req.body));
  } catch (error) {
    if (error.code === 'DUPLICATE_CONDUCTOR') {
      return res.status(400).json({ message: error.message });
    }
    if (error.code === 'VALIDATION_ERROR') {
      return res.status(400).json({ message: error.message });
    }
    res.status(500).json({ message: 'Error', error: error.message });
  }
};

const updateConductor = async (req, res) => {
  try {
    const c = await conductoresService.update(req.params.id, req.body);
    c ? res.json(c) : res.status(404).json({ message: 'No encontrado' });
  } catch (error) {
    if (error.code === 'DUPLICATE_CONDUCTOR') {
      return res.status(400).json({ message: error.message });
    }
    res.status(500).json({ message: 'Error', error: error.message });
  }
};

const deleteConductor = async (req, res) => {
  try {
    const c = await conductoresService.delete(req.params.id);
    c ? res.json({ message: 'Eliminado' }) : res.status(404).json({ message: 'No encontrado' });
  } catch (error) { res.status(500).json({ message: 'Error', error: error.message }); }
};

module.exports = { getConductores, getConductor, createConductor, updateConductor, deleteConductor };
