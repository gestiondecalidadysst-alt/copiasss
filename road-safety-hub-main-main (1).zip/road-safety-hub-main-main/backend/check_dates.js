async function checkDates() {
  try {
    const res = await fetch('http://localhost:5000/api/eventos');
    const data = await res.json();
    console.log("Fechas de los eventos:", data.map(e => e.fecha));
  } catch(e) {
    console.log("Error", e);
  }
}
checkDates();
