/**
 * Lista negra de tokens JWT revocados.
 *
 * - Se almacena en memoria: al reiniciar el servidor la lista se vacía,
 *   lo cual es aceptable porque los tokens firmados seguirán siendo
 *   válidos sólo hasta su expiración natural (24 h).
 * - Para producción con múltiples instancias, se debería usar Redis.
 */

/** @type {Map<string, number>} token → timestamp de expiración (ms) */
const blacklist = new Map();

/**
 * Añade un token a la lista negra hasta su fecha de expiración.
 * @param {string} token  – JWT sin el prefijo "Bearer "
 * @param {number} expMs  – Marca de expiración en milisegundos (Date.now() + ttl)
 */
function addToken(token, expMs) {
  blacklist.set(token, expMs);
  // Programar limpieza automática para no acumular tokens caducados
  const ttl = expMs - Date.now();
  if (ttl > 0) {
    setTimeout(() => blacklist.delete(token), ttl);
  }
}

/**
 * Comprueba si un token está en la lista negra.
 * @param {string} token
 * @returns {boolean}
 */
function hasToken(token) {
  return blacklist.has(token);
}

module.exports = { addToken, hasToken };
