/**
 * Utilidades para streaming de datos grandes
 * Previene colapso de memoria al procesar reportes masivos
 */

const { Readable } = require('stream');

/**
 * Convierte un array grande en un stream para procesamiento eficiente
 * @param {Array} data - Array de datos a convertir en stream
 * @param {Object} options - Opciones de configuración
 * @returns {Readable} - Stream de datos
 */
function arrayToStream(data, options = {}) {
  const { chunkSize = 100 } = options;
  let index = 0;

  return new Readable({
    objectMode: true,
    read() {
      if (index >= data.length) {
        this.push(null); // Fin del stream
        return;
      }

      // Enviar datos en chunks para no sobrecargar memoria
      const chunk = data.slice(index, index + chunkSize);
      index += chunkSize;
      this.push(chunk);
    }
  });
}

/**
 * Procesa datos en batches para evitar sobrecarga de memoria
 * @param {Array} data - Datos a procesar
 * @param {Function} processFn - Función de procesamiento
 * @param {Number} batchSize - Tamaño del batch
 * @returns {Promise<Array>} - Datos procesados
 */
async function processBatches(data, processFn, batchSize = 1000) {
  const results = [];
  
  for (let i = 0; i < data.length; i += batchSize) {
    const batch = data.slice(i, i + batchSize);
    const processed = await processFn(batch);
    results.push(...processed);
    
    // Liberar memoria entre batches
    if (global.gc) {
      global.gc();
    }
  }
  
  return results;
}

/**
 * Genera JSON en streaming para datasets grandes
 * @param {Response} res - Objeto de respuesta Express
 * @param {Array} data - Datos a enviar
 * @param {Object} metadata - Metadatos adicionales
 */
function streamJsonResponse(res, data, metadata = {}) {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Transfer-Encoding', 'chunked');
  
  // Inicio del JSON
  res.write('{"metadata":' + JSON.stringify(metadata) + ',"data":[');
  
  // Stream de datos
  data.forEach((item, index) => {
    if (index > 0) res.write(',');
    res.write(JSON.stringify(item));
  });
  
  // Fin del JSON
  res.write(']}');
  res.end();
}

/**
 * Limita la memoria usada por una operación
 * @param {Function} operation - Operación a ejecutar
 * @param {Number} maxMemoryMB - Límite de memoria en MB
 * @returns {Promise} - Resultado de la operación
 */
async function withMemoryLimit(operation, maxMemoryMB = 100) {
  const startMemory = process.memoryUsage().heapUsed / 1024 / 1024;
  
  try {
    const result = await operation();
    
    const endMemory = process.memoryUsage().heapUsed / 1024 / 1024;
    const memoryUsed = endMemory - startMemory;
    
    if (memoryUsed > maxMemoryMB) {
      console.warn(`⚠️  Operación usó ${memoryUsed.toFixed(2)}MB de memoria (límite: ${maxMemoryMB}MB)`);
    }
    
    return result;
  } catch (error) {
    console.error('Error en operación con límite de memoria:', error);
    throw error;
  }
}

/**
 * Caché simple en memoria para evitar consultas repetidas
 */
class SimpleCache {
  constructor(ttl = 5 * 60 * 1000, maxSize = 50) { // 5 minutos y máximo 50 items
    this.cache = new Map();
    this.ttl = ttl;
    this.maxSize = maxSize; // Límite máximo de items en caché
  }

  set(key, value) {
    // Si ya hemos alcanzado el límite, limpiar el item más antiguo
    if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }

    this.cache.set(key, {
      value,
      timestamp: Date.now()
    });
  }

  get(key) {
    const item = this.cache.get(key);
    if (!item) return null;

    // Verificar si expiró
    if (Date.now() - item.timestamp > this.ttl) {
      this.cache.delete(key);
      return null;
    }

    return item.value;
  }

  clear() {
    this.cache.clear();
  }

  size() {
    return this.cache.size;
  }

  // Limpieza automática de items expirados
  cleanup() {
    const now = Date.now();
    let deleted = 0;
    for (const [key, item] of this.cache.entries()) {
      if (now - item.timestamp > this.ttl) {
        this.cache.delete(key);
        deleted++;
      }
    }
    if (deleted > 0) {
      console.log(`🗑️  ${deleted} items expirados eliminados del caché`);
    }
  }
}

module.exports = {
  arrayToStream,
  processBatches,
  streamJsonResponse,
  withMemoryLimit,
  SimpleCache
};
