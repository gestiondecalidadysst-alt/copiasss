require('dotenv').config({ path: __dirname + '/.env' });
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function main() {
  // Verificar si ya existe
  const { error: checkError } = await supabase.from('conductores').select('id').limit(1);
  if (!checkError) {
    console.log('La tabla conductores ya existe.');
    return;
  }

  console.log('Tabla no existe, creando...');

  // Usar SQL directo via postgrest rpc si está disponible, sino intentar insertar para que falle con info útil
  const { data, error } = await supabase.rpc('exec_sql', {
    sql: `
      CREATE TABLE IF NOT EXISTS conductores (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        nombre VARCHAR(150) NOT NULL,
        cedula VARCHAR(20) UNIQUE NOT NULL,
        licencia VARCHAR(50),
        telefono VARCHAR(20),
        vehiculo VARCHAR(20),
        score INT DEFAULT 100,
        estado VARCHAR(20) DEFAULT 'activo',
        created_at TIMESTAMPTZ DEFAULT NOW(),
        updated_at TIMESTAMPTZ DEFAULT NOW()
      );
    `
  });

  if (error) {
    console.log('RPC exec_sql no disponible:', error.message);
    console.log('');
    console.log('Ejecuta este SQL manualmente en el editor SQL de Supabase:');
    console.log('');
    console.log(`
CREATE TABLE IF NOT EXISTS conductores (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  cedula VARCHAR(20) UNIQUE NOT NULL,
  licencia VARCHAR(50),
  telefono VARCHAR(20),
  vehiculo VARCHAR(20),
  score INT DEFAULT 100,
  estado VARCHAR(20) DEFAULT 'activo',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
    `);
  } else {
    console.log('Tabla creada exitosamente:', data);
  }
}

main().catch(console.error);
