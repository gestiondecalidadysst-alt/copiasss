const supabase = require('./config/supabaseClient');

async function limpiarReportes() {
  try {
    // Obtener todos los reportes
    const { data: reportes, error: getError } = await supabase
      .from('reportes')
      .select('id')
      .order('created_at', { ascending: false });

    if (getError) throw getError;

    if (reportes && reportes.length > 0) {
      console.log(`🗑️  Encontrados ${reportes.length} reportes. Eliminando...\n`);
      
      for (const reporte of reportes) {
        const { error: deleteError } = await supabase
          .from('reportes')
          .delete()
          .eq('id', reporte.id);
        
        if (deleteError) {
          console.error(`❌ Error al eliminar reporte ${reporte.id}:`, deleteError.message);
        } else {
          console.log(`✅ Reporte ${reporte.id} eliminado`);
        }
      }

      console.log('\n✅ Base de datos limpiada. Todos los reportes han sido eliminados.');
    } else {
      console.log('✅ No hay reportes para eliminar.');
    }

    process.exit(0);
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
}

limpiarReportes();
