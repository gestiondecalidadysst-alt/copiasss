/**
 * Script para aplicar la migración 007 en Supabase
 * Abre el SQL Editor del dashboard y muestra el SQL listo para pegar.
 * Uso: node ejecutar_migracion_007_browser.js
 */

const open = require('open');
const path = require('path');
const { execSync } = require('child_process');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL || '';
const urlMatch = supabaseUrl.match(/https:\/\/([^.]+)\.supabase\.co/);
const PROJECT_REF = urlMatch ? urlMatch[1] : 'tcmoypkoyozgxhsioqwz';

// SQL de la migración (inline para garantizar UTF-8 correcto)
const SQL = `-- MIGRACIÓN 007: Programación de mensajes
-- Fecha: 2026-04-28

-- 1. Eliminar columna obsoleta fecha_hora
ALTER TABLE mensajes
  DROP COLUMN IF EXISTS fecha_hora;

-- 2. Agregar columna num_repeticiones (1 o 2 envíos por día)
ALTER TABLE mensajes
  ADD COLUMN IF NOT EXISTS num_repeticiones SMALLINT DEFAULT 1;

ALTER TABLE mensajes
  ADD CONSTRAINT IF NOT EXISTS valid_num_repeticiones
  CHECK (num_repeticiones BETWEEN 1 AND 2);

-- 3. Agregar columna programaciones (JSONB)
--    Estructura: [{ "hora": "08:00", "dias": ["2026-04-28", "2026-04-29"] }]
ALTER TABLE mensajes
  ADD COLUMN IF NOT EXISTS programaciones JSONB DEFAULT '[]'::jsonb;

-- 4. Índice GIN para consultas por fecha de programación
CREATE INDEX IF NOT EXISTS idx_mensajes_programaciones
  ON mensajes USING GIN (programaciones);`;

const SQL_EDITOR_URL = `https://supabase.com/dashboard/project/${PROJECT_REF}/sql/new`;

function copiarAlPortapapeles(texto) {
  try {
    // Windows
    const ps = `Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Clipboard]::SetText(@'
${texto}
'@)`;
    execSync(`powershell -Command "${ps.replace(/"/g, '\\"')}"`, { stdio: 'ignore' });
    return true;
  } catch {
    try {
      // Fallback: clip.exe
      const tmp = require('os').tmpdir() + '/migration_007.sql';
      require('fs').writeFileSync(tmp, texto, 'utf8');
      execSync(`clip < "${tmp}"`, { stdio: 'ignore', shell: true });
      return true;
    } catch {
      return false;
    }
  }
}

async function main() {
  console.log('\n╔══════════════════════════════════════════════════════════════╗');
  console.log('║  MIGRACIÓN 007 – Programación de mensajes en Supabase        ║');
  console.log('╚══════════════════════════════════════════════════════════════╝\n');

  // Mostrar SQL en consola
  console.log('━━━ SQL A EJECUTAR ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  console.log(SQL);
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  // Intentar copiar al portapapeles
  const copiado = copiarAlPortapapeles(SQL);
  if (copiado) {
    console.log('📋 SQL copiado al portapapeles ✅\n');
  } else {
    console.log('⚠️  No se pudo copiar automáticamente. Copia el SQL de arriba.\n');
  }

  console.log('📌 Pasos a seguir:\n');
  console.log('  1. Se abrirá el SQL Editor de tu proyecto Supabase en el navegador');
  console.log('  2. Pega el SQL (Ctrl+V) en el editor');
  console.log('  3. Haz clic en "Run" (o presiona Ctrl+Enter)');
  console.log('  4. Verifica que aparezca "Success. No rows returned"\n');
  console.log(`  🔗 URL: ${SQL_EDITOR_URL}\n`);

  try {
    await open(SQL_EDITOR_URL);
    console.log('✅ Navegador abierto — pega el SQL y haz clic en Run\n');
  } catch {
    console.log('⚠️  No se pudo abrir el navegador automáticamente.');
    console.log(`   Abre manualmente: ${SQL_EDITOR_URL}\n`);
  }
}

main();
