#!/usr/bin/env node

/**
 * Verificar si tabla "conductores" existe en Supabase
 * Si no existe, mostrar SQL para crearla
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Error: Faltan credenciales en .env');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function verificar() {
  console.log('\n╔════════════════════════════════════════════════╗');
  console.log('║  VERIFICANDO DEPENDENCIAS DE TABLA "mensajes"  ║');
  console.log('╚════════════════════════════════════════════════╝\n');

  try {
    // Verificar tabla conductores
    console.log('🔍 Verificando tabla "conductores"...');
    const { data: conductoresData, error: conductoresError } = await supabase
      .from('conductores')
      .select('*')
      .limit(1);

    if (conductoresError) {
      console.log('❌ Tabla "conductores" NO existe\n');
      mostrarSoluciones();
      return;
    }

    console.log('✅ Tabla "conductores" existe\n');

    // Si conductores existe, intentar crear mensajes con FK
    console.log('🔍 Ahora intenta crear la tabla "mensajes" de nuevo...\n');
    mostrarSQL_ConFK();

  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

function mostrarSoluciones() {
  console.log('📖 SOLUCIONES:\n');

  console.log('═'.repeat(70));
  console.log('OPCIÓN 1: Crear tabla "conductores" PRIMERO\n');
  console.log('En SQL Editor, pega PRIMERO esto:\n');
  
  const conductoreSQL = `CREATE TABLE IF NOT EXISTS conductores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre VARCHAR(255) NOT NULL,
  apellido VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  telefono VARCHAR(20),
  numero_licencia VARCHAR(50),
  tipo_licencia VARCHAR(10),
  estado VARCHAR(20) DEFAULT 'activo',
  fecha_vencimiento_licencia DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);`;

  console.log(conductoreSQL);
  console.log('\nLuego, DESPUÉS pega el SQL de "mensajes"\n');
  console.log('═'.repeat(70) + '\n');

  console.log('═'.repeat(70));
  console.log('OPCIÓN 2: Crear "mensajes" SIN referencia a conductores\n');
  console.log('En SQL Editor, pega esto (sin la FK a conductores):\n');

  const mensajesSQL = `CREATE TABLE IF NOT EXISTS mensajes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  titulo VARCHAR(255) NOT NULL,
  tipo VARCHAR(50) NOT NULL,
  contenido TEXT,
  asunto VARCHAR(255),
  
  prioridad VARCHAR(20) DEFAULT 'normal',
  estado VARCHAR(20) DEFAULT 'draft',
  emoji VARCHAR(10) DEFAULT '📬',
  
  destinatario VARCHAR(255),
  
  media_type VARCHAR(20),
  media_url TEXT,
  media_size INT,
  file_name VARCHAR(255),
  
  fecha_programada TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  created_by UUID,
  conductor_id UUID,
  
  enviados INT DEFAULT 0,
  visualizados INT DEFAULT 0,
  
  CONSTRAINT valid_tipo CHECK (tipo IN ('preventiva', 'segunda', 'tercera', 'informativa', 'broadcast')),
  CONSTRAINT valid_prioridad CHECK (prioridad IN ('alta', 'normal', 'baja')),
  CONSTRAINT valid_estado CHECK (estado IN ('draft', 'enviado', 'programado')),
  CONSTRAINT valid_media_type CHECK (media_type IN ('texto', 'imagen', 'video', 'audio', 'multimedia'))
);

CREATE INDEX idx_mensajes_tipo ON mensajes(tipo);
CREATE INDEX idx_mensajes_estado ON mensajes(estado);
CREATE INDEX idx_mensajes_created_at ON mensajes(created_at DESC);
CREATE INDEX idx_mensajes_conductor_id ON mensajes(conductor_id);

ALTER TABLE mensajes ENABLE ROW LEVEL SECURITY;

CREATE POLICY mensajes_read ON mensajes FOR SELECT USING (true);
CREATE POLICY mensajes_insert ON mensajes FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY mensajes_update ON mensajes FOR UPDATE USING (auth.role() = 'authenticated');
CREATE POLICY mensajes_delete ON mensajes FOR DELETE USING (auth.role() = 'authenticated');`;

  console.log(mensajesSQL);
  console.log('\n═'.repeat(70) + '\n');

  console.log('💡 RECOMENDACIÓN: Usa OPCIÓN 2 (sin FK) primero');
  console.log('   Así puedes crear mensajes sin depender de conductores\n');
}

function mostrarSQL_ConFK() {
  const sql = `-- Como "conductores" ya existe, usa este SQL con FK:
  
CREATE TABLE IF NOT EXISTS mensajes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  titulo VARCHAR(255) NOT NULL,
  tipo VARCHAR(50) NOT NULL,
  contenido TEXT,
  asunto VARCHAR(255),
  
  prioridad VARCHAR(20) DEFAULT 'normal',
  estado VARCHAR(20) DEFAULT 'draft',
  emoji VARCHAR(10) DEFAULT '📬',
  
  destinatario VARCHAR(255),
  
  media_type VARCHAR(20),
  media_url TEXT,
  media_size INT,
  file_name VARCHAR(255),
  
  fecha_programada TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  created_by UUID,
  
  conductor_id UUID REFERENCES conductores(id) ON DELETE SET NULL,
  
  enviados INT DEFAULT 0,
  visualizados INT DEFAULT 0,
  
  CONSTRAINT valid_tipo CHECK (tipo IN ('preventiva', 'segunda', 'tercera', 'informativa', 'broadcast')),
  CONSTRAINT valid_prioridad CHECK (prioridad IN ('alta', 'normal', 'baja')),
  CONSTRAINT valid_estado CHECK (estado IN ('draft', 'enviado', 'programado')),
  CONSTRAINT valid_media_type CHECK (media_type IN ('texto', 'imagen', 'video', 'audio', 'multimedia'))
);

CREATE INDEX idx_mensajes_tipo ON mensajes(tipo);
CREATE INDEX idx_mensajes_estado ON mensajes(estado);
CREATE INDEX idx_mensajes_created_at ON mensajes(created_at DESC);
CREATE INDEX idx_mensajes_conductor_id ON mensajes(conductor_id);

ALTER TABLE mensajes ENABLE ROW LEVEL SECURITY;

CREATE POLICY mensajes_read ON mensajes FOR SELECT USING (true);
CREATE POLICY mensajes_insert ON mensajes FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY mensajes_update ON mensajes FOR UPDATE USING (auth.role() = 'authenticated');
CREATE POLICY mensajes_delete ON mensajes FOR DELETE USING (auth.role() = 'authenticated');`;

  console.log(sql);
}

verificar();
