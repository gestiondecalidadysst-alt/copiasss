const axios = require('axios');

async function probarAPIReportes() {
  console.log('🧪 Probando API de Reportes...\n');

  try {
    // 1. Verificar endpoint GET /api/reportes
    console.log('1️⃣ Probando GET /api/reportes (listar reportes)...');
    const getResponse = await axios.get('http://localhost:5000/api/reportes');
    console.log(`✅ Status: ${getResponse.status}`);
    console.log(`📊 Reportes encontrados: ${getResponse.data.length}`);
    console.log('');

    // 2. Crear un reporte de prueba
    console.log('2️⃣ Probando POST /api/reportes (crear reporte)...');
    const reportePrueba = {
      nombre: 'Reporte de Prueba - ' + new Date().toLocaleString('es-ES'),
      placa: 'ABC123',
      fecha_desde: '2026-04-01',
      fecha_hasta: '2026-04-21',
      tipo_evento: 'alta',
      total_eventos: 150,
      velocidad_promedio: 105.5,
      filtros_aplicados: {
        placa: 'ABC123',
        fecha_desde: '2026-04-01',
        fecha_hasta: '2026-04-21',
        tipo_evento: 'alta'
      },
      usuario: 'Usuario de Prueba',
      empresa: 'Road Safety Hub'
    };

    const postResponse = await axios.post('http://localhost:5000/api/reportes', reportePrueba);
    console.log(`✅ Status: ${postResponse.status}`);
    console.log(`📝 Reporte creado con ID: ${postResponse.data.id}`);
    console.log(`📅 Fecha de creación: ${postResponse.data.created_at}`);
    console.log('');

    const reporteId = postResponse.data.id;

    // 3. Obtener el reporte por ID
    console.log(`3️⃣ Probando GET /api/reportes/${reporteId} (obtener por ID)...`);
    const getByIdResponse = await axios.get(`http://localhost:5000/api/reportes/${reporteId}`);
    console.log(`✅ Status: ${getByIdResponse.status}`);
    console.log(`📋 Reporte obtenido: ${getByIdResponse.data.nombre}`);
    console.log('');

    // 4. Listar todos los reportes de nuevo
    console.log('4️⃣ Verificando que el reporte aparece en la lista...');
    const getAllResponse = await axios.get('http://localhost:5000/api/reportes');
    console.log(`✅ Status: ${getAllResponse.status}`);
    console.log(`📊 Total de reportes: ${getAllResponse.data.length}`);
    console.log('');

    // 5. Eliminar el reporte de prueba
    console.log(`5️⃣ Probando DELETE /api/reportes/${reporteId} (eliminar reporte)...`);
    const deleteResponse = await axios.delete(`http://localhost:5000/api/reportes/${reporteId}`);
    console.log(`✅ Status: ${deleteResponse.status}`);
    console.log(`🗑️  Reporte eliminado correctamente`);
    console.log('');

    // 6. Verificar que fue eliminado
    console.log('6️⃣ Verificando que el reporte fue eliminado...');
    const finalGetResponse = await axios.get('http://localhost:5000/api/reportes');
    console.log(`✅ Status: ${finalGetResponse.status}`);
    console.log(`📊 Reportes restantes: ${finalGetResponse.data.length}`);
    console.log('');

    console.log('═══════════════════════════════════════════════════════════');
    console.log('✅ ¡TODAS LAS PRUEBAS PASARON EXITOSAMENTE!');
    console.log('═══════════════════════════════════════════════════════════');
    console.log('');
    console.log('🎉 El sistema de reportes está funcionando correctamente:');
    console.log('   ✓ Crear reportes');
    console.log('   ✓ Listar reportes');
    console.log('   ✓ Obtener reporte por ID');
    console.log('   ✓ Eliminar reportes');
    console.log('');
    console.log('🚀 Ya puedes usar la aplicación para crear y gestionar reportes!');

  } catch (error) {
    console.error('');
    console.error('❌ ERROR EN LAS PRUEBAS:');
    console.error('═══════════════════════════════════════════════════════════');
    
    if (error.response) {
      console.error(`Status HTTP: ${error.response.status}`);
      console.error(`Mensaje: ${error.response.data.message || error.response.data.error || 'Sin mensaje'}`);
      console.error('Respuesta completa:', error.response.data);
    } else if (error.request) {
      console.error('No se pudo conectar al servidor.');
      console.error('Verifica que el backend esté corriendo en http://localhost:5000');
      console.error('');
      console.error('Para iniciar el backend:');
      console.error('  cd backend');
      console.error('  node server.js');
    } else {
      console.error('Error:', error.message);
    }
    
    console.error('═══════════════════════════════════════════════════════════');
    process.exit(1);
  }
}

probarAPIReportes();
