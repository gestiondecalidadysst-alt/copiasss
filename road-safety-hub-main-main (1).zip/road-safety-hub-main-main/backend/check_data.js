async function check() {
  const res = await fetch('http://localhost:5000/api/eventos');
  const data = await res.json();
  const conCoords = data.filter(e => e.latitud !== null || e.longitud !== null);
  console.log(`Total eventos: ${data.length}`);
  console.log(`Eventos con coordenadas: ${conCoords.length}`);
  if (conCoords.length > 0) {
    console.log("Muestra de eventos con coordenadas:");
    console.log(conCoords.slice(0, 5));
  } else {
    console.log("No se encontraron eventos con latitud o longitud.");
    console.log("Columnas presentes en el primer objeto:", Object.keys(data[0] || {}));
  }
}
check();
