import supabaseClient from '../config/supabaseClient.js';
import bcrypt from 'bcryptjs';

/**
 * Script para crear el primer usuario administrador
 */
async function crearAdminInicial() {
  console.log('🔧 Creando usuario administrador inicial...');

  try {
    // Verificar si ya existe un admin
    const { data: adminExistente, error: errorCheck } = await supabaseClient
      .from('usuarios')
      .select('id')
      .eq('email', 'admin@translogistica.com')
      .single();

    if (adminExistente) {
      console.log('✅ Ya existe un usuario administrador');
      return;
    }

    // Obtener el rol de admin
    const { data: rolAdmin, error: errorRol } = await supabaseClient
      .from('roles')
      .select('id')
      .eq('nombre', 'admin')
      .single();

    if (errorRol) {
      console.error('❌ Error al obtener rol admin:', errorRol);
      return;
    }

    // Hash de la contraseña
    const passwordHash = await bcrypt.hash('admin123', 10);

    // Crear usuario administrador
    const { data: usuario, error: errorUsuario } = await supabaseClient
      .from('usuarios')
      .insert({
        email: 'admin@translogistica.com',
        nombre: 'Administrador',
        empresa: 'TransLogística S.A.',
        password_hash: passwordHash,
        activo: true
      })
      .select()
      .single();

    if (errorUsuario) {
      console.error('❌ Error al crear usuario:', errorUsuario);
      return;
    }

    // Asignar rol de admin
    const { error: errorAsignar } = await supabaseClient
      .from('usuario_roles')
      .insert({
        usuario_id: usuario.id,
        rol_id: rolAdmin.id
      });

    if (errorAsignar) {
      console.error('❌ Error al asignar rol:', errorAsignar);
      return;
    }

    console.log('✅ Usuario administrador creado correctamente');
    console.log('📧 Email: admin@translogistica.com');
    console.log('🔑 Contraseña: admin123');
    console.log('⚠️  IMPORTANTE: Cambia la contraseña después del primer login');

  } catch (error) {
    console.error('❌ Error:', error);
  }
}

// Ejecutar script
crearAdminInicial()
  .then(() => {
    console.log('✨ Script completado');
    process.exit(0);
  })
  .catch((error) => {
    console.error('💥 Error fatal:', error);
    process.exit(1);
  });
