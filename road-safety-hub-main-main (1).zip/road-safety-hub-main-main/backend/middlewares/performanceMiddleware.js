const { SimpleCache } = require('../utils/streamHelpers');

/**
 * Middleware para optimizar rendimiento del backend
 * Maneja caché, compresión y límites de datos
 */

// Caché global para consultas frecuentes
const queryCache = new SimpleCache(1 * 60 * 1000); // 1 minuto en lugar de 5

// Limpiar caché cada 2 minutos (más agresivo)
setInterval(() => {
  queryCache.cleanup();
  const size = queryCache.size();
  if (size > 0) {
    console.log(`🧹 Limpieza de caché: ${size} items en caché`);
  }
  
  // Forzar garbage collection cada 2 minutos (solo loguear si memoria es alta)
  if (global.gc) {
    const mem = process.memoryUsage();
    const heapUsedMB = mem.heapUsed / 1024 / 1024;
    global.gc();
    if (heapUsedMB > 50) {
      console.log('🗑️  Garbage collection ejecutado');
    }
  }
}, 2 * 60 * 1000);

/**
 * Middleware de caché para GET requests
 */
const cacheMiddleware = (ttl = 5 * 60 * 1000) => {
  return (req, res, next) => {
    // Solo cachear GET requests
    if (req.method !== 'GET') {
      return next();
    }

    const key = `${req.path}?${JSON.stringify(req.query)}`;
    const cached = queryCache.get(key);

    if (cached) {
      console.log(`✅ Cache hit: ${req.path}`);
      res.setHeader('X-Cache', 'HIT');
      return res.json(cached);
    }

    // Interceptar res.json para guardar en caché
    const originalJson = res.json.bind(res);
    res.json = (data) => {
      queryCache.set(key, data);
      res.setHeader('X-Cache', 'MISS');
      return originalJson(data);
    };

    next();
  };
};

/**
 * Middleware para validar tamaño de respuestas
 */
const responseSizeLimit = (maxSizeMB = 50) => {
  return (req, res, next) => {
    const originalJson = res.json.bind(res);
    
    res.json = (data) => {
      const size = Buffer.byteLength(JSON.stringify(data)) / 1024 / 1024;
      
      if (size > maxSizeMB) {
        console.warn(`⚠️  Respuesta muy grande: ${size.toFixed(2)}MB (límite: ${maxSizeMB}MB)`);
        console.warn(`   Ruta: ${req.path}`);
        
        return res.status(413).json({
          error: 'Payload demasiado grande',
          message: `La respuesta (${size.toFixed(2)}MB) excede el límite de ${maxSizeMB}MB`,
          suggestion: 'Usa paginación o filtros para reducir el tamaño de los datos',
          params: {
            page: '?page=1&limit=100',
            filters: 'Aplica filtros específicos'
          }
        });
      }

      res.setHeader('Content-Length', Buffer.byteLength(JSON.stringify(data)));
      res.setHeader('X-Response-Size', `${size.toFixed(2)}MB`);
      
      return originalJson(data);
    };

    next();
  };
};

/**
 * Middleware para monitorear uso de memoria
 */
const memoryMonitor = (req, res, next) => {
  const memUsage = process.memoryUsage();
  const heapUsedMBNum = memUsage.heapUsed / 1024 / 1024;
  const heapUsedMB = heapUsedMBNum.toFixed(2);
  const heapTotalMB = (memUsage.heapTotal / 1024 / 1024).toFixed(2);
  const heapRatio = memUsage.heapUsed / memUsage.heapTotal;

  // Solo advertir si el heap es grande (>50MB) Y el ratio es alto.
  // Evita falsos positivos con el heap inicial pequeño de Node.js (~14MB).
  if (heapRatio > 0.9 && heapUsedMBNum > 50) {
    console.warn(`⚠️  Memoria alta: ${heapUsedMB}MB / ${heapTotalMB}MB (90%+)`);
    
    // Intentar garbage collection manual
    if (global.gc) {
      console.log('🗑️  Activando garbage collection...');
      global.gc();
    }
  }
  
  // Alerta crítica si excede 95% con más de 50MB usados
  if (heapRatio > 0.95 && heapUsedMBNum > 50) {
    console.error('🚨 ALERTA CRÍTICA: Memoria casi llena!');
    queryCache.clear();
    console.log('🗑️  Caché limpiado completamente');
  }

  res.setHeader('X-Memory-Usage', `${heapUsedMB}MB`);
  next();
};

/**
 * Middleware para agregar headers de rendimiento
 */
const performanceHeaders = (req, res, next) => {
  const start = Date.now();

  // Interceptar el método res.end para calcular duración antes de enviar
  const originalEnd = res.end.bind(res);
  res.end = function(...args) {
    const duration = Date.now() - start;
    
    // Solo establecer header si aún no se enviaron los headers
    if (!res.headersSent) {
      res.setHeader('X-Response-Time', `${duration}ms`);
    }
    
    if (duration > 5000) {
      console.warn(`⚠️  Request muy lenta: ${req.method} ${req.path} - ${duration}ms`);
    }
    
    return originalEnd(...args);
  };

  next();
};

/**
 * Limpiar caché manualmente
 */
const clearCache = () => {
  queryCache.clear();
  console.log('🧹 Caché limpiado completamente');
};

module.exports = {
  cacheMiddleware,
  responseSizeLimit,
  memoryMonitor,
  performanceHeaders,
  clearCache,
  queryCache
};
