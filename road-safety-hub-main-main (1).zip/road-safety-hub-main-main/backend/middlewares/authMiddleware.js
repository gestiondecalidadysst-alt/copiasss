const jwt = require('jsonwebtoken');
const tokenBlacklist = require('../utils/tokenBlacklist');

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET no está definido en las variables de entorno.');
  process.exit(1);
}

/**
 * Middleware de autenticación
 * Valida que el usuario tenga un token JWT válido
 */
const authMiddleware = (req, res, next) => {
  try {
    // Obtener token del header Authorization
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        error: 'Token no proporcionado'
      });
    }

    const token = authHeader.substring(7); // Remover "Bearer "

    // Rechazar tokens revocados (logout previo)
    if (tokenBlacklist.hasToken(token)) {
      return res.status(401).json({ error: 'Token revocado. Inicia sesión nuevamente.' });
    }

    // Verificar y decodificar el token
    const usuario = jwt.verify(token, JWT_SECRET);

    // Guardar usuario en el request para usar en controladores
    req.usuario = usuario;

    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        error: 'Token expirado'
      });
    }

    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        error: 'Token inválido'
      });
    }

    res.status(401).json({
      error: 'No autorizado'
    });
  }
};

/**
 * Middleware de autorización por rol
 * Verifica que el usuario tenga el rol requerido
 */
const roleMiddleware = (rolesRequeridos) => {
  return (req, res, next) => {
    try {
      // El middleware de autenticación debe ejecutarse primero
      if (!req.usuario) {
        return res.status(401).json({
          error: 'Usuario no autenticado'
        });
      }

      // Convertir a array si es necesario
      const rolesArray = Array.isArray(rolesRequeridos) ? rolesRequeridos : [rolesRequeridos];

      // Verificar si el usuario tiene uno de los roles requeridos
      if (!rolesArray.includes(req.usuario.rol)) {
        return res.status(403).json({
          error: 'No tienes permiso para acceder a este recurso'
        });
      }

      next();
    } catch (error) {
      console.error('Error en roleMiddleware:', error);
      res.status(500).json({
        error: 'Error al verificar rol'
      });
    }
  };
};

/**
 * Middleware para verificar que solo admin puede acceder
 */
const adminMiddleware = (req, res, next) => {
  try {
    if (!req.usuario) {
      return res.status(401).json({
        error: 'Usuario no autenticado'
      });
    }

    if (req.usuario.rol !== 'admin') {
      return res.status(403).json({
        error: 'Solo administradores pueden acceder a este recurso'
      });
    }

    next();
  } catch (error) {
    console.error('Error en adminMiddleware:', error);
    res.status(500).json({
      error: 'Error al verificar permisos'
    });
  }
};

/**
 * Middleware de auditoría (opcional)
 * Registra acciones de administrador
 */
const auditMiddleware = (req, res, next) => {
  // Guardar información de la solicitud para auditoría
  req.auditInfo = {
    usuario_id: req.usuario?.id,
    metodo: req.method,
    ruta: req.originalUrl,
    ip_address: req.ip,
    user_agent: req.headers['user-agent'],
    timestamp: new Date()
  };

  // Interceptar la respuesta para registrar el resultado
  const originalSend = res.send;
  res.send = function(data) {
    req.auditInfo.status = res.statusCode;

    // Aquí podrías guardar la auditoría en la BD
    if (req.usuario?.rol === 'admin' && 
        (req.method === 'POST' || req.method === 'PUT' || req.method === 'DELETE')) {
      console.log('[AUDITORÍA]', req.auditInfo);
      // Ejemplo: AuditoriaModel.save(req.auditInfo);
    }

    return originalSend.call(this, data);
  };

  next();
};

/**
 * Middleware opcional: Permitir múltiples roles
 */
const multiRoleMiddleware = (rolesRequeridos) => {
  return (req, res, next) => {
    try {
      if (!req.usuario) {
        return res.status(401).json({
          error: 'Usuario no autenticado'
        });
      }

      // Convertir a array si es necesario
      const rolesArray = Array.isArray(rolesRequeridos) ? rolesRequeridos : [rolesRequeridos];

      // Verificar si el usuario tiene uno de los roles requeridos
      const tienePermiso = rolesArray.some(rol => {
        if (Array.isArray(req.usuario.roles)) {
          return req.usuario.roles.includes(rol);
        }
        return req.usuario.rol === rol;
      });

      if (!tienePermiso) {
        return res.status(403).json({
          error: 'No tienes permiso para acceder a este recurso'
        });
      }

      next();
    } catch (error) {
      console.error('Error en multiRoleMiddleware:', error);
      res.status(500).json({
        error: 'Error al verificar roles'
      });
    }
  };
};

module.exports = { authMiddleware, roleMiddleware, adminMiddleware, auditMiddleware, multiRoleMiddleware };
