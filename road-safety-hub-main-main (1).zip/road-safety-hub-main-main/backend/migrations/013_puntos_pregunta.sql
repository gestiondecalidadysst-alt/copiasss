-- ============================================================
-- Migración 013: Agregar puntos por pregunta al quiz
-- Ejecutar en el SQL Editor de Supabase
-- ============================================================

ALTER TABLE preguntas_capacitacion ADD COLUMN puntos INT NOT NULL DEFAULT 1;
