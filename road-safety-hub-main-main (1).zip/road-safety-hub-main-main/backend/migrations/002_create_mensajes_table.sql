-- Create mensajes table with support for multiple message types
CREATE TABLE IF NOT EXISTS mensajes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Message content
  titulo VARCHAR(255) NOT NULL,
  tipo VARCHAR(50) NOT NULL, -- preventiva, segunda, tercera, informativa, broadcast
  contenido TEXT,
  asunto VARCHAR(255),
  
  -- Priority and state
  prioridad VARCHAR(20) DEFAULT 'normal', -- alta, normal, baja
  estado VARCHAR(20) DEFAULT 'draft', -- draft, enviado, programado
  emoji VARCHAR(10) DEFAULT '📬',
  
  -- Recipients
  destinatario VARCHAR(255),
  
  -- Media support
  media_type VARCHAR(20), -- texto, imagen, video, audio, multimedia
  media_url TEXT, -- URL to stored file in Supabase Storage
  media_size INT, -- File size in bytes
  file_name VARCHAR(255), -- Original file name
  
  -- Scheduling
  fecha_programada TIMESTAMP WITH TIME ZONE,
  
  -- Metadata
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  created_by UUID,
  
  -- Relationships
  conductor_id UUID REFERENCES conductores(id) ON DELETE SET NULL,
  
  -- Tracking
  enviados INT DEFAULT 0,
  visualizados INT DEFAULT 0,
  
  CONSTRAINT valid_tipo CHECK (tipo IN ('preventiva', 'segunda', 'tercera', 'informativa', 'broadcast')),
  CONSTRAINT valid_prioridad CHECK (prioridad IN ('alta', 'normal', 'baja')),
  CONSTRAINT valid_estado CHECK (estado IN ('draft', 'enviado', 'programado')),
  CONSTRAINT valid_media_type CHECK (media_type IN ('texto', 'imagen', 'video', 'audio', 'multimedia'))
);

-- Create index for better query performance
CREATE INDEX idx_mensajes_tipo ON mensajes(tipo);
CREATE INDEX idx_mensajes_estado ON mensajes(estado);
CREATE INDEX idx_mensajes_created_at ON mensajes(created_at DESC);
CREATE INDEX idx_mensajes_conductor_id ON mensajes(conductor_id);

-- Add RLS policies
ALTER TABLE mensajes ENABLE ROW LEVEL SECURITY;

-- Create policy: anyone can read mensajes
CREATE POLICY mensajes_read ON mensajes
  FOR SELECT
  USING (true);

-- Create policy: authenticated users can insert
CREATE POLICY mensajes_insert ON mensajes
  FOR INSERT
  WITH CHECK (auth.role() = 'authenticated');

-- Create policy: authenticated users can update their own mensajes
CREATE POLICY mensajes_update ON mensajes
  FOR UPDATE
  USING (auth.role() = 'authenticated');

-- Create policy: authenticated users can delete their own mensajes
CREATE POLICY mensajes_delete ON mensajes
  FOR DELETE
  USING (auth.role() = 'authenticated');

-- Create a bucket for message media if it doesn't exist
-- This should be handled via Supabase UI or a separate setup script
-- INSERT INTO storage.buckets (id, name) VALUES ('mensaje-media', 'mensaje-media')
-- ON CONFLICT DO NOTHING;
