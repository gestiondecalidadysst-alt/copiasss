-- ============================================================================
-- SCHEMA PARA SISTEMA DE MÓDULOS EN CAPACITACIONES
-- ============================================================================

-- Tabla: modulos (estructura de módulos dentro de capacitaciones)
CREATE TABLE IF NOT EXISTS modulos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  capacitacion_id UUID NOT NULL REFERENCES capacitaciones(id) ON DELETE CASCADE,
  titulo VARCHAR(255) NOT NULL,
  descripcion TEXT,
  orden INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(capacitacion_id, orden)
);

-- Tabla: videos_modulo (videos dentro de cada módulo)
CREATE TABLE IF NOT EXISTS videos_modulo (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  modulo_id UUID NOT NULL REFERENCES modulos(id) ON DELETE CASCADE,
  titulo VARCHAR(255) NOT NULL,
  url TEXT NOT NULL,
  duracion_minutos INTEGER DEFAULT 0,
  orden INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(modulo_id, orden)
);

-- Tabla: quizzes_modulo (quizzes dentro de cada módulo)
CREATE TABLE IF NOT EXISTS quizzes_modulo (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  modulo_id UUID NOT NULL REFERENCES modulos(id) ON DELETE CASCADE,
  titulo VARCHAR(255) NOT NULL,
  porcentaje_aprobacion INTEGER DEFAULT 70,
  orden INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(modulo_id, orden)
);

-- Tabla: preguntas_modulo (preguntas de quizzes en módulos)
CREATE TABLE IF NOT EXISTS preguntas_modulo (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  quiz_id UUID NOT NULL REFERENCES quizzes_modulo(id) ON DELETE CASCADE,
  pregunta VARCHAR(500) NOT NULL,
  puntos INTEGER DEFAULT 1,
  orden INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(quiz_id, orden)
);

-- Tabla: opciones_modulo (opciones de respuesta para preguntas de módulos)
CREATE TABLE IF NOT EXISTS opciones_modulo (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pregunta_id UUID NOT NULL REFERENCES preguntas_modulo(id) ON DELETE CASCADE,
  texto VARCHAR(255) NOT NULL,
  es_correcta BOOLEAN DEFAULT FALSE,
  orden INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(pregunta_id, orden)
);

-- Tabla: progreso_modulos (seguimiento del progreso por conductor y módulo)
CREATE TABLE IF NOT EXISTS progreso_modulos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asignacion_id UUID NOT NULL REFERENCES asignaciones_capacitacion(id) ON DELETE CASCADE,
  modulo_id UUID NOT NULL REFERENCES modulos(id) ON DELETE CASCADE,
  estado VARCHAR(50) DEFAULT 'pendiente', -- pendiente, en_progreso, completado
  nota NUMERIC(3, 1),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(asignacion_id, modulo_id)
);

-- Tabla: progreso_videos (seguimiento de videos por conductor)
CREATE TABLE IF NOT EXISTS progreso_videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asignacion_id UUID NOT NULL REFERENCES asignaciones_capacitacion(id) ON DELETE CASCADE,
  video_id UUID NOT NULL REFERENCES videos_modulo(id) ON DELETE CASCADE,
  progreso NUMERIC(5, 2) DEFAULT 0, -- porcentaje 0-100
  completado BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(asignacion_id, video_id)
);

-- Tabla: respuestas_modulo (respuestas de conductores a quizzes de módulos)
CREATE TABLE IF NOT EXISTS respuestas_modulo (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asignacion_id UUID NOT NULL REFERENCES asignaciones_capacitacion(id) ON DELETE CASCADE,
  pregunta_id UUID NOT NULL REFERENCES preguntas_modulo(id) ON DELETE CASCADE,
  opcion_id UUID NOT NULL REFERENCES opciones_modulo(id),
  es_correcta BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(asignacion_id, pregunta_id)
);

-- Tabla: intentos_quiz_modulo (control de intentos por quiz)
CREATE TABLE IF NOT EXISTS intentos_quiz_modulo (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asignacion_id UUID NOT NULL REFERENCES asignaciones_capacitacion(id) ON DELETE CASCADE,
  quiz_id UUID NOT NULL REFERENCES quizzes_modulo(id) ON DELETE CASCADE,
  intento INTEGER DEFAULT 1,
  puntaje INTEGER,
  aprobado BOOLEAN DEFAULT FALSE,
  fecha_intento TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(asignacion_id, quiz_id, intento)
);

-- Índices para mejor performance
CREATE INDEX idx_modulos_capacitacion_id ON modulos(capacitacion_id);
CREATE INDEX idx_videos_modulo_id ON videos_modulo(modulo_id);
CREATE INDEX idx_quizzes_modulo_id ON quizzes_modulo(modulo_id);
CREATE INDEX idx_preguntas_quiz_id ON preguntas_modulo(quiz_id);
CREATE INDEX idx_progreso_modulos_asignacion ON progreso_modulos(asignacion_id);
CREATE INDEX idx_progreso_videos_asignacion ON progreso_videos(asignacion_id);
CREATE INDEX idx_respuestas_modulo_asignacion ON respuestas_modulo(asignacion_id);
CREATE INDEX idx_intentos_quiz_asignacion ON intentos_quiz_modulo(asignacion_id);

-- RLS (Row Level Security)
ALTER TABLE modulos ENABLE ROW LEVEL SECURITY;
ALTER TABLE videos_modulo ENABLE ROW LEVEL SECURITY;
ALTER TABLE quizzes_modulo ENABLE ROW LEVEL SECURITY;
ALTER TABLE preguntas_modulo ENABLE ROW LEVEL SECURITY;
ALTER TABLE opciones_modulo ENABLE ROW LEVEL SECURITY;
ALTER TABLE progreso_modulos ENABLE ROW LEVEL SECURITY;
ALTER TABLE progreso_videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE respuestas_modulo ENABLE ROW LEVEL SECURITY;
ALTER TABLE intentos_quiz_modulo ENABLE ROW LEVEL SECURITY;
