-- 004_create_users_and_roles.sql
-- Crear tablas de usuarios y roles

-- Tabla de roles
CREATE TABLE IF NOT EXISTS roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre VARCHAR(50) UNIQUE NOT NULL,
  descripcion TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  nombre VARCHAR(255) NOT NULL,
  empresa VARCHAR(255),
  password_hash VARCHAR(255) NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Tabla de relación usuario-rol
CREATE TABLE IF NOT EXISTS usuario_roles (
  usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  rol_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT NOW(),
  PRIMARY KEY (usuario_id, rol_id)
);

-- Insertar roles predefinidos
INSERT INTO roles (nombre, descripcion) VALUES
  ('admin', 'Administrador del sistema'),
  ('usuario', 'Usuario cliente de la aplicación')
ON CONFLICT (nombre) DO NOTHING;

-- Índices para mejor rendimiento
CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios(email);
CREATE INDEX IF NOT EXISTS idx_usuarios_activo ON usuarios(activo);
CREATE INDEX IF NOT EXISTS idx_usuario_roles_usuario_id ON usuario_roles(usuario_id);
CREATE INDEX IF NOT EXISTS idx_usuario_roles_rol_id ON usuario_roles(rol_id);

-- Row Level Security para usuarios
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;

-- Política: Usuarios pueden ver su propio perfil
CREATE POLICY "usuarios_ver_propio_perfil" ON usuarios
  FOR SELECT USING (auth.uid() = id);

-- Política: Admin puede ver todos los usuarios
CREATE POLICY "admin_ver_todos_usuarios" ON usuarios
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM usuario_roles ur
      JOIN roles r ON ur.rol_id = r.id
      WHERE ur.usuario_id = auth.uid() AND r.nombre = 'admin'
    )
  );

-- Política: Admin puede crear usuarios
CREATE POLICY "admin_crear_usuarios" ON usuarios
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM usuario_roles ur
      JOIN roles r ON ur.rol_id = r.id
      WHERE ur.usuario_id = auth.uid() AND r.nombre = 'admin'
    )
  );

-- Política: Admin puede actualizar usuarios
CREATE POLICY "admin_actualizar_usuarios" ON usuarios
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM usuario_roles ur
      JOIN roles r ON ur.rol_id = r.id
      WHERE ur.usuario_id = auth.uid() AND r.nombre = 'admin'
    )
  );

-- Política: Admin puede eliminar usuarios
CREATE POLICY "admin_eliminar_usuarios" ON usuarios
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM usuario_roles ur
      JOIN roles r ON ur.rol_id = r.id
      WHERE ur.usuario_id = auth.uid() AND r.nombre = 'admin'
    )
  );

-- Row Level Security para usuario_roles
ALTER TABLE usuario_roles ENABLE ROW LEVEL SECURITY;

-- Política: Admin puede ver roles de todos
CREATE POLICY "admin_ver_roles" ON usuario_roles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM usuario_roles ur
      JOIN roles r ON ur.rol_id = r.id
      WHERE ur.usuario_id = auth.uid() AND r.nombre = 'admin'
    )
  );

-- Política: Admin puede asignar roles
CREATE POLICY "admin_asignar_roles" ON usuario_roles
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM usuario_roles ur
      JOIN roles r ON ur.rol_id = r.id
      WHERE ur.usuario_id = auth.uid() AND r.nombre = 'admin'
    )
  );

-- Tabla de auditoría (opcional pero recomendado)
CREATE TABLE IF NOT EXISTS usuario_auditoria (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id UUID REFERENCES usuarios(id) ON DELETE SET NULL,
  accion VARCHAR(50) NOT NULL,
  detalles JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_auditoria_usuario_id ON usuario_auditoria(usuario_id);
CREATE INDEX IF NOT EXISTS idx_auditoria_created_at ON usuario_auditoria(created_at);
