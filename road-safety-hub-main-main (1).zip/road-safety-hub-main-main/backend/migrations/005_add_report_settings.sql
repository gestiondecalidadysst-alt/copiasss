-- 005_add_report_settings.sql
-- Agregar campos de configuración de encabezado y pie de página
-- para los informes/reportes generados por el sistema.

-- Añadir columnas a la tabla usuarios
ALTER TABLE usuarios
  ADD COLUMN IF NOT EXISTS report_header TEXT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS report_footer TEXT DEFAULT NULL;

COMMENT ON COLUMN usuarios.report_header IS 'Texto personalizado para el encabezado de los informes (dirección, teléfono, slogan, etc.)';
COMMENT ON COLUMN usuarios.report_footer IS 'Texto personalizado para el pie de página de los informes (términos, contacto, etc.)';
