CREATE TABLE IF NOT EXISTS noticias_vistas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  noticia_id uuid NOT NULL REFERENCES noticias(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  autor text NOT NULL,
  created_at timestamp with time zone DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS noticias_vistas_unq_noticia_usuario
  ON noticias_vistas(noticia_id, user_id);
