-- ============================================================
-- Migración 012: Quiz para capacitaciones + seguimiento detallado
-- Ejecutar en el SQL Editor de Supabase
-- ============================================================

-- 1. Preguntas del quiz asociadas a una capacitación
CREATE TABLE preguntas_capacitacion (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  capacitacion_id UUID NOT NULL REFERENCES capacitaciones(id) ON DELETE CASCADE,
  pregunta TEXT NOT NULL,
  tipo VARCHAR(20) NOT NULL DEFAULT 'multiple_choice',
  orden INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Opciones de respuesta por pregunta
CREATE TABLE opciones_pregunta (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pregunta_id UUID NOT NULL REFERENCES preguntas_capacitacion(id) ON DELETE CASCADE,
  texto TEXT NOT NULL,
  es_correcta BOOLEAN NOT NULL DEFAULT FALSE,
  orden INT NOT NULL DEFAULT 0
);

-- 3. Respuestas que envía el conductor al tomar el quiz
CREATE TABLE respuestas_conductor (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asignacion_id UUID NOT NULL REFERENCES asignaciones_capacitacion(id) ON DELETE CASCADE,
  pregunta_id UUID NOT NULL REFERENCES preguntas_capacitacion(id) ON DELETE CASCADE,
  opcion_id UUID NOT NULL REFERENCES opciones_pregunta(id) ON DELETE CASCADE,
  es_correcta BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(asignacion_id, pregunta_id)
);

-- 4. Columnas de seguimiento detallado en asignaciones
ALTER TABLE asignaciones_capacitacion ADD COLUMN progreso_video INT DEFAULT 0;
ALTER TABLE asignaciones_capacitacion ADD COLUMN etapa VARCHAR(20) DEFAULT 'contenido';
ALTER TABLE asignaciones_capacitacion ADD COLUMN quiz_puntaje INT;
ALTER TABLE asignaciones_capacitacion ADD COLUMN quiz_completado BOOLEAN DEFAULT FALSE;
