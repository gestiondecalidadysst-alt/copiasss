-- Migración: Agregar columna 'modulos' a la tabla capacitaciones
-- Ejecutar en el SQL Editor de Supabase
-- Cada capacitación puede tener múltiples módulos; cada módulo tiene videos y quizzes.
-- La estructura se almacena como JSONB para flexibilidad.

ALTER TABLE capacitaciones
  ADD COLUMN IF NOT EXISTS modulos JSONB DEFAULT '[]'::jsonb;

-- Estructura esperada de cada elemento en el array 'modulos':
-- {
--   "id": "uuid-string",
--   "titulo": "Módulo 1: Introducción",
--   "descripcion": "Descripción opcional",
--   "orden": 0,
--   "videos": [
--     { "id": "uuid", "titulo": "Video 1", "url": "https://...", "duracion_minutos": 10 }
--   ],
--   "quizzes": [
--     {
--       "id": "uuid",
--       "titulo": "Quiz del módulo",
--       "porcentaje_aprobacion": 70,
--       "preguntas": [
--         {
--           "id": "uuid",
--           "pregunta": "¿Pregunta?",
--           "puntos": 1,
--           "opciones": [
--             { "id": "uuid", "texto": "Opción A", "es_correcta": true },
--             { "id": "uuid", "texto": "Opción B", "es_correcta": false }
--           ]
--         }
--       ]
--     }
--   ]
-- }
