-- ============================================================
-- Migración 016: Añadir columnas de tipografía y tamaños al diploma
-- Ejecutar en Supabase SQL Editor
-- ============================================================

ALTER TABLE certificado_config
  ADD COLUMN IF NOT EXISTS font_family         TEXT NOT NULL DEFAULT 'helvetica',
  ADD COLUMN IF NOT EXISTS title_font_size     INTEGER NOT NULL DEFAULT 22,
  ADD COLUMN IF NOT EXISTS name_font_size      INTEGER NOT NULL DEFAULT 24,
  ADD COLUMN IF NOT EXISTS body_font_size      INTEGER NOT NULL DEFAULT 12,
  ADD COLUMN IF NOT EXISTS course_font_size    INTEGER NOT NULL DEFAULT 14,
  ADD COLUMN IF NOT EXISTS logo_height         INTEGER NOT NULL DEFAULT 62,
  ADD COLUMN IF NOT EXISTS footer_logo_height  INTEGER NOT NULL DEFAULT 32;

COMMENT ON COLUMN certificado_config.font_family        IS 'Familia tipográfica del diploma: helvetica | times | courier';
COMMENT ON COLUMN certificado_config.title_font_size    IS 'Tamaño del título principal en puntos PDF';
COMMENT ON COLUMN certificado_config.name_font_size     IS 'Tamaño del nombre del participante en puntos PDF';
COMMENT ON COLUMN certificado_config.body_font_size     IS 'Tamaño del texto cuerpo en puntos PDF';
COMMENT ON COLUMN certificado_config.course_font_size   IS 'Tamaño del nombre del curso en puntos PDF';
COMMENT ON COLUMN certificado_config.logo_height        IS 'Altura del logo superior en puntos PDF';
COMMENT ON COLUMN certificado_config.footer_logo_height IS 'Altura de logos del pie de página en puntos PDF';
