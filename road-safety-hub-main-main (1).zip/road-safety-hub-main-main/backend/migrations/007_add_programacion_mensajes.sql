-- Migración: Agregar soporte de programación de envíos a mensajes
-- Fecha: 2026-04-28
-- Descripción:
--   - Elimina la columna fecha_hora (ya no se usa; las fechas van en programaciones)
--   - Agrega num_repeticiones: cuántos envíos por día (1 ó 2)
--   - Agrega programaciones: arreglo JSONB con cada bloque { hora, dias[] }

-- 1. Eliminar columna obsoleta fecha_hora
ALTER TABLE mensajes
  DROP COLUMN IF EXISTS fecha_hora;

-- 2. Agregar columna num_repeticiones
ALTER TABLE mensajes
  ADD COLUMN IF NOT EXISTS num_repeticiones SMALLINT DEFAULT 1
    CONSTRAINT valid_num_repeticiones CHECK (num_repeticiones BETWEEN 1 AND 2);

COMMENT ON COLUMN mensajes.num_repeticiones IS
  'Número de envíos programados por día: 1 ó 2. Solo aplica a tipos informativa y broadcast.';

-- 3. Agregar columna programaciones (JSONB)
--    Estructura esperada:
--    [
--      { "hora": "08:00", "dias": ["2026-04-28", "2026-04-29"] },
--      { "hora": "17:00", "dias": ["2026-04-28"] }           <- solo si num_repeticiones = 2
--    ]
ALTER TABLE mensajes
  ADD COLUMN IF NOT EXISTS programaciones JSONB DEFAULT '[]'::jsonb;

COMMENT ON COLUMN mensajes.programaciones IS
  'Arreglo JSON con la configuración de envío. Cada elemento tiene: hora (HH:MM) y dias (array de fechas ISO YYYY-MM-DD).';

-- 4. Índice para consultas de mensajes programados por fecha
CREATE INDEX IF NOT EXISTS idx_mensajes_programaciones
  ON mensajes USING GIN (programaciones);
