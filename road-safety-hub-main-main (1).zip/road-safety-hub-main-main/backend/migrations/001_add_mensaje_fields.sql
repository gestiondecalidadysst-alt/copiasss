-- Migración: Agregar nuevos campos a la tabla mensajes
-- Fecha: 2026-04-18
-- Descripción: Agrega columnas para destinatario, asunto, prioridad, emoji y estado

-- Verificar si la tabla existe y agregar columnas si no existen
ALTER TABLE mensajes
ADD COLUMN IF NOT EXISTS destinatario VARCHAR(255),
ADD COLUMN IF NOT EXISTS asunto VARCHAR(255),
ADD COLUMN IF NOT EXISTS prioridad VARCHAR(50) DEFAULT 'normal',
ADD COLUMN IF NOT EXISTS emoji VARCHAR(50) DEFAULT '📬',
ADD COLUMN IF NOT EXISTS estado VARCHAR(50) DEFAULT 'draft';

-- Comentarios para documentación
COMMENT ON COLUMN mensajes.destinatario IS 'Destinatario del mensaje (Ej: Todos, Admin, Operador)';
COMMENT ON COLUMN mensajes.asunto IS 'Asunto o línea de resumen del mensaje';
COMMENT ON COLUMN mensajes.prioridad IS 'Prioridad del mensaje: alta, normal, baja';
COMMENT ON COLUMN mensajes.emoji IS 'Emoji que representa el mensaje';
COMMENT ON COLUMN mensajes.estado IS 'Estado del mensaje: draft, enviado, programado';

-- Ver estructura actual de la tabla
-- SELECT * FROM information_schema.columns WHERE table_name = 'mensajes';
