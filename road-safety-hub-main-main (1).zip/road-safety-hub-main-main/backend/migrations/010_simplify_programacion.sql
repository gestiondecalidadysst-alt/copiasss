-- Migración 010: Simplificar programación de mensajes
-- Fecha: 2026-04-29
-- Descripción:
--   Reemplaza el campo JSONB `programaciones` y `num_repeticiones` de la tabla mensajes
--   por columnas escalares fecha_programada (DATE) y hora_programada (TIME).
--   Rediseña mensajes_programados como tabla simple de una sola fila por mensaje.

-- ─── 1. Columnas en mensajes ────────────────────────────────────────────────
ALTER TABLE mensajes DROP COLUMN IF EXISTS programaciones;
ALTER TABLE mensajes DROP COLUMN IF EXISTS num_repeticiones;

ALTER TABLE mensajes ADD COLUMN IF NOT EXISTS fecha_programada DATE;
ALTER TABLE mensajes ADD COLUMN IF NOT EXISTS hora_programada  TIME;

COMMENT ON COLUMN mensajes.fecha_programada IS 'Fecha de envío programado (solo para tipos informativa y broadcast)';
COMMENT ON COLUMN mensajes.hora_programada  IS 'Hora de envío programado (solo para tipos informativa y broadcast)';

-- ─── 2. Tabla mensajes_programados simplificada ─────────────────────────────
DROP TABLE IF EXISTS mensajes_programados CASCADE;

CREATE TABLE mensajes_programados (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  mensaje_id UUID        NOT NULL REFERENCES mensajes(id) ON DELETE CASCADE,
  fecha      DATE        NOT NULL,
  hora       TIME,
  estado     VARCHAR(20) NOT NULL DEFAULT 'programado'
               CHECK (estado IN ('programado', 'enviado')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_mprog UNIQUE (mensaje_id)
);

COMMENT ON TABLE mensajes_programados IS
  'Una fila por mensaje con la fecha, hora y estado de envío programado.';

CREATE INDEX idx_mprog_mensaje_id ON mensajes_programados (mensaje_id);
CREATE INDEX idx_mprog_fecha      ON mensajes_programados (fecha);

ALTER TABLE mensajes_programados ENABLE ROW LEVEL SECURITY;
CREATE POLICY mprog_read   ON mensajes_programados FOR SELECT USING (true);
CREATE POLICY mprog_insert ON mensajes_programados FOR INSERT WITH CHECK (true);
CREATE POLICY mprog_update ON mensajes_programados FOR UPDATE USING (true);
CREATE POLICY mprog_delete ON mensajes_programados FOR DELETE USING (true);
