-- ============================================================
-- Migración 014: Intentos de quiz y porcentaje de aprobación
-- Ejecutar en el SQL Editor de Supabase
-- ============================================================

-- 1. Porcentaje mínimo para aprobar el quiz (en capacitaciones)
ALTER TABLE capacitaciones
  ADD COLUMN IF NOT EXISTS porcentaje_aprobacion INT NOT NULL DEFAULT 70;

-- 2. Contador de intentos usados por conductor en cada asignación
ALTER TABLE asignaciones_capacitacion
  ADD COLUMN IF NOT EXISTS quiz_intentos INT NOT NULL DEFAULT 0;
