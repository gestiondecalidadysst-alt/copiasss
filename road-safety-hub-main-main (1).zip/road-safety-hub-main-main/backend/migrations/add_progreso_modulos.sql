-- Migración: Agregar columna progreso_modulos a asignaciones_capacitacion
-- Ejecutar en: Supabase → SQL Editor

ALTER TABLE asignaciones_capacitacion
  ADD COLUMN IF NOT EXISTS progreso_modulos JSONB DEFAULT '{}'::jsonb;

-- La estructura almacenada en progreso_modulos es:
-- {
--   "nota_final": 8.5,          -- nota promedio final (1-10), null hasta completar
--   "<modulo_id>": {
--     "completado": true,
--     "nota": 9.0,              -- nota del módulo (1-10)
--     "videos": {
--       "<video_id>": 85        -- % visualizado del video
--     },
--     "quizzes": {
--       "<quiz_id>": {
--         "intentos": 1,
--         "puntaje": 90,        -- puntaje 0-100
--         "completado": true
--       }
--     }
--   }
-- }
