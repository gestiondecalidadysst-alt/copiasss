-- Migración: Agregar columna fecha_hora a la tabla mensajes
-- Fecha: 2026-04-26
-- Descripción: Agrega columna fecha_hora para mensajes de tipo informativo

ALTER TABLE mensajes
ADD COLUMN IF NOT EXISTS fecha_hora TIMESTAMP WITH TIME ZONE;

COMMENT ON COLUMN mensajes.fecha_hora IS 'Fecha y hora del evento para mensajes de tipo informativo';
