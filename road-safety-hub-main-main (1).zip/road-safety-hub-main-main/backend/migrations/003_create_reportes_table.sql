-- Crear tabla de reportes guardados
CREATE TABLE IF NOT EXISTS reportes (
  id BIGSERIAL PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  nombre VARCHAR(255) NOT NULL,
  placa VARCHAR(50),
  fecha_desde DATE,
  fecha_hasta DATE,
  tipo_evento VARCHAR(50),
  total_eventos INTEGER DEFAULT 0,
  velocidad_promedio DECIMAL(10, 2),
  filtros_aplicados JSONB,
  usuario VARCHAR(255),
  empresa VARCHAR(255)
);

-- Crear índice para búsquedas más rápidas
CREATE INDEX IF NOT EXISTS idx_reportes_created_at ON reportes(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reportes_nombre ON reportes(nombre);

-- Habilitar RLS (Row Level Security) - opcional
ALTER TABLE reportes ENABLE ROW LEVEL SECURITY;

-- Política para permitir todas las operaciones (ajustar según necesidades de seguridad)
CREATE POLICY "Permitir todas las operaciones en reportes" 
  ON reportes 
  FOR ALL 
  USING (true) 
  WITH CHECK (true);
