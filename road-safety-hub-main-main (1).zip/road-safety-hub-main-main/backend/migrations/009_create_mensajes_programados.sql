-- Migración 009: Tabla mensajes_programados (rediseñada)
-- Fecha: 2026-04-29
-- Estructura:
--   UNA FILA por franja de envío del día (máx 2 filas por mensaje).
--   Cada fila tiene:
--     • hora         → hora de envío de esa franja
--     • fecha_X      → fecha ISO del día X de la semana (NULL si no fue seleccionado)
--     • estado_X     → 'programado' | 'enviado' | NULL
--   Así se puede ver y cambiar el estado de cada día directamente.

-- Eliminar versión anterior si existe (seguro porque aún no hay datos)
DROP TABLE IF EXISTS mensajes_programados CASCADE;

CREATE TABLE mensajes_programados (
  id               UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  mensaje_id       UUID        NOT NULL REFERENCES mensajes(id) ON DELETE CASCADE,
  programacion_idx SMALLINT    NOT NULL DEFAULT 0,  -- 0 = primer envío del día, 1 = segundo
  hora             TIME,                             -- Hora configurada para esta franja

  -- Domingo
  fecha_dom  DATE,
  estado_dom VARCHAR(20) DEFAULT NULL CHECK (estado_dom IN ('programado','enviado') OR estado_dom IS NULL),

  -- Lunes
  fecha_lun  DATE,
  estado_lun VARCHAR(20) DEFAULT NULL CHECK (estado_lun IN ('programado','enviado') OR estado_lun IS NULL),

  -- Martes
  fecha_mar  DATE,
  estado_mar VARCHAR(20) DEFAULT NULL CHECK (estado_mar IN ('programado','enviado') OR estado_mar IS NULL),

  -- Miércoles
  fecha_mie  DATE,
  estado_mie VARCHAR(20) DEFAULT NULL CHECK (estado_mie IN ('programado','enviado') OR estado_mie IS NULL),

  -- Jueves
  fecha_jue  DATE,
  estado_jue VARCHAR(20) DEFAULT NULL CHECK (estado_jue IN ('programado','enviado') OR estado_jue IS NULL),

  -- Viernes
  fecha_vie  DATE,
  estado_vie VARCHAR(20) DEFAULT NULL CHECK (estado_vie IN ('programado','enviado') OR estado_vie IS NULL),

  -- Sábado
  fecha_sab  DATE,
  estado_sab VARCHAR(20) DEFAULT NULL CHECK (estado_sab IN ('programado','enviado') OR estado_sab IS NULL),

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Máximo 2 filas por mensaje (una por franja)
  CONSTRAINT uq_mprog        UNIQUE (mensaje_id, programacion_idx),
  CONSTRAINT valid_prog_idx  CHECK  (programacion_idx IN (0, 1))
);

COMMENT ON TABLE mensajes_programados IS
  'Una fila por franja de envío (máx 2 por mensaje). Cada columna fecha_X/estado_X
   representa un día de la semana: dom, lun, mar, mie, jue, vie, sab.
   NULL = día no seleccionado. programado = pendiente. enviado = ya enviado.';

-- Índices
CREATE INDEX idx_mprog_mensaje_id ON mensajes_programados (mensaje_id);
CREATE INDEX idx_mprog_updated_at ON mensajes_programados (updated_at);

-- RLS
ALTER TABLE mensajes_programados ENABLE ROW LEVEL SECURITY;
CREATE POLICY mprog_read   ON mensajes_programados FOR SELECT USING (true);
CREATE POLICY mprog_insert ON mensajes_programados FOR INSERT WITH CHECK (true);
CREATE POLICY mprog_update ON mensajes_programados FOR UPDATE USING (true);
CREATE POLICY mprog_delete ON mensajes_programados FOR DELETE USING (true);
