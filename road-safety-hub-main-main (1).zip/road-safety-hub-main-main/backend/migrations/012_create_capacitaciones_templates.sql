-- Crear tabla para plantillas de capacitaciones por empresa
CREATE TABLE IF NOT EXISTS capacitaciones_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa VARCHAR(255) NOT NULL,
  template_name VARCHAR(255) NOT NULL DEFAULT 'default',
  
  -- Encabezado
  header_text VARCHAR(500),
  header_logo BYTEA,
  header_logo_height SMALLINT DEFAULT 60,
  
  -- Pie de página
  footer_text VARCHAR(500),
  footer_logo BYTEA,
  footer_logo_height SMALLINT DEFAULT 40,
  
  -- Estructura de columnas
  columns_config JSONB DEFAULT '{}'::jsonb,
  
  -- Estilos
  title_color VARCHAR(10),
  header_bg_color VARCHAR(10),
  border_color VARCHAR(10),
  font_family VARCHAR(50),
  
  -- Metadata
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(empresa, template_name)
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_templates_empresa ON capacitaciones_templates(empresa);
CREATE INDEX IF NOT EXISTS idx_templates_created_at ON capacitaciones_templates(created_at DESC);

-- RLS Policy
ALTER TABLE capacitaciones_templates ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Permitir acceso a templates propias" ON capacitaciones_templates;
CREATE POLICY "Permitir acceso a templates propias"
  ON capacitaciones_templates
  FOR ALL
  USING (
    empresa = current_setting('request.headers')::json->>'X-Company' 
    OR empresa = (SELECT email FROM auth.users WHERE id = auth.uid())
  );
