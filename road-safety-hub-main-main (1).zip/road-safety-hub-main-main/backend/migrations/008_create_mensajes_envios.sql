-- Migración 008: Tabla de registro de envíos por día
-- Fecha: 2026-04-29
-- Descripción:
--   Crea la tabla mensajes_envios para rastrear si un mensaje ya fue enviado
--   en una fecha concreta y en qué franja de programación (0 = primer envío, 1 = segundo envío).
--
--   La restricción UNIQUE(mensaje_id, programacion_idx, fecha) impide duplicados
--   a nivel de base de datos, independientemente de cuántas veces el usuario
--   presione el botón de enviar.

CREATE TABLE IF NOT EXISTS mensajes_envios (
  id               UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  mensaje_id       UUID         NOT NULL REFERENCES mensajes(id) ON DELETE CASCADE,
  programacion_idx SMALLINT     NOT NULL DEFAULT 0,   -- 0 = primer envío del día, 1 = segundo envío
  fecha            DATE         NOT NULL,              -- Fecha ISO en que se marcó como enviado (YYYY-MM-DD)
  hora_envio       TIME,                               -- Hora real del envío (HH:MM)
  enviado_at       TIMESTAMPTZ  NOT NULL DEFAULT now(), -- Timestamp exacto del registro

  -- Restricción clave: evita registrar el mismo envío dos veces en el mismo día
  CONSTRAINT uq_envio_dia UNIQUE (mensaje_id, programacion_idx, fecha),

  CONSTRAINT valid_programacion_idx CHECK (programacion_idx IN (0, 1))
);

COMMENT ON TABLE mensajes_envios IS
  'Registro de envíos reales de cada mensaje por día y franja de programación.
   La clave única (mensaje_id, programacion_idx, fecha) garantiza que no se pueda
   insertar un envío duplicado para el mismo mensaje, franja y fecha.';

COMMENT ON COLUMN mensajes_envios.programacion_idx IS
  '0 = primer envío del día, 1 = segundo envío del día (cuando num_repeticiones = 2).';

COMMENT ON COLUMN mensajes_envios.fecha IS
  'Fecha en formato DATE (YYYY-MM-DD) en que se registró el envío.';

-- Índices para consultas frecuentes
CREATE INDEX IF NOT EXISTS idx_mensajes_envios_mensaje_id
  ON mensajes_envios (mensaje_id);

CREATE INDEX IF NOT EXISTS idx_mensajes_envios_fecha
  ON mensajes_envios (fecha);

-- RLS: las mismas políticas que la tabla mensajes
ALTER TABLE mensajes_envios ENABLE ROW LEVEL SECURITY;

CREATE POLICY mensajes_envios_read ON mensajes_envios
  FOR SELECT USING (true);

CREATE POLICY mensajes_envios_insert ON mensajes_envios
  FOR INSERT WITH CHECK (true);

CREATE POLICY mensajes_envios_delete ON mensajes_envios
  FOR DELETE USING (true);
