-- ============================================================
-- Migración 015: Tablas para Certificados de Capacitación
-- Ejecutar en Supabase SQL Editor
-- ============================================================

-- ── 1. Configuración del diploma por empresa ─────────────────
CREATE TABLE IF NOT EXISTS certificado_config (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa       TEXT NOT NULL UNIQUE,
  titulo        TEXT NOT NULL DEFAULT 'CERTIFICADO DE CAPACITACIÓN',
  certify_text  TEXT NOT NULL DEFAULT 'Se certifica que:',
  course_intro  TEXT NOT NULL DEFAULT 'Ha completado satisfactoriamente la capacitación:',
  firma_nombre  TEXT NOT NULL DEFAULT 'Director de Seguridad Vial',
  firma_titulo  TEXT,
  footer_text   TEXT,
  numero_prefix TEXT NOT NULL DEFAULT 'CERT-',
  show_numero   BOOLEAN NOT NULL DEFAULT TRUE,
  -- Colores (hex)
  color_fondo   TEXT NOT NULL DEFAULT '#FDFAF0',
  color_borde   TEXT NOT NULL DEFAULT '#B8941E',
  color_titulo  TEXT NOT NULL DEFAULT '#1A1A2E',
  color_nombre  TEXT NOT NULL DEFAULT '#1A3D8A',
  color_texto   TEXT NOT NULL DEFAULT '#444444',
  color_acento  TEXT NOT NULL DEFAULT '#B8941E',
  -- Logos
  show_logo_sistema BOOLEAN NOT NULL DEFAULT TRUE,
  -- Campos activos (array de keys)
  campos_activos  TEXT[] NOT NULL DEFAULT ARRAY['nombre','apellido','documento','fecha','calificacion'],
  -- Etiquetas personalizadas (jsonb key→label)
  etiquetas_campos JSONB NOT NULL DEFAULT '{}',
  -- Tipografía y tamaños
  font_family         TEXT NOT NULL DEFAULT 'serif',
  title_font_size     INT  NOT NULL DEFAULT 28,
  name_font_size      INT  NOT NULL DEFAULT 22,
  body_font_size      INT  NOT NULL DEFAULT 13,
  course_font_size    INT  NOT NULL DEFAULT 14,
  logo_height         INT  NOT NULL DEFAULT 60,
  footer_logo_height  INT  NOT NULL DEFAULT 40,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE certificado_config IS
  'Almacena el diseño y texto del diploma de capacitación por empresa.';

-- ── 2. Registro de certificados emitidos ─────────────────────
CREATE TABLE IF NOT EXISTS certificados_emitidos (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  numero_certificado  TEXT UNIQUE,          -- ej: CERT-000042
  conductor_id        UUID NOT NULL REFERENCES conductores(id) ON DELETE CASCADE,
  capacitacion_id     UUID NOT NULL REFERENCES capacitaciones(id) ON DELETE CASCADE,
  asignacion_id       UUID REFERENCES asignaciones_capacitacion(id) ON DELETE SET NULL,
  calificacion        NUMERIC(5,2),         -- puntaje del quiz
  fecha_emision       TIMESTAMPTZ NOT NULL DEFAULT now(),
  empresa             TEXT NOT NULL,
  emitido_por         UUID REFERENCES usuarios(id) ON DELETE SET NULL,
  -- Snapshot de datos al momento de emitir (inmutable)
  datos_conductor     JSONB NOT NULL DEFAULT '{}',
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE certificados_emitidos IS
  'Registro histórico e inmutable de cada certificado emitido.';

CREATE INDEX IF NOT EXISTS idx_cert_conductor    ON certificados_emitidos(conductor_id);
CREATE INDEX IF NOT EXISTS idx_cert_capacitacion ON certificados_emitidos(capacitacion_id);
CREATE INDEX IF NOT EXISTS idx_cert_empresa      ON certificados_emitidos(empresa);

-- ── 3. Función para auto-generar número de certificado ────────
CREATE OR REPLACE FUNCTION generar_numero_certificado()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  prefijo TEXT;
  secuencia INT;
BEGIN
  -- Obtener prefijo de la config de la empresa (default 'CERT-')
  SELECT COALESCE(numero_prefix, 'CERT-') INTO prefijo
  FROM certificado_config
  WHERE empresa = NEW.empresa
  LIMIT 1;

  -- Calcular siguiente número de la empresa
  SELECT COALESCE(MAX(
    NULLIF(regexp_replace(numero_certificado, '^[^0-9]*', ''), '')::INT
  ), 0) + 1
  INTO secuencia
  FROM certificados_emitidos
  WHERE empresa = NEW.empresa;

  NEW.numero_certificado := prefijo || LPAD(secuencia::TEXT, 6, '0');
  RETURN NEW;
END;
$$;

CREATE OR REPLACE TRIGGER trg_numero_certificado
BEFORE INSERT ON certificados_emitidos
FOR EACH ROW
WHEN (NEW.numero_certificado IS NULL)
EXECUTE FUNCTION generar_numero_certificado();

-- ── 4. RLS (Row Level Security) ───────────────────────────────
ALTER TABLE certificado_config    ENABLE ROW LEVEL SECURITY;
ALTER TABLE certificados_emitidos ENABLE ROW LEVEL SECURITY;

-- Cada empresa solo ve su propia configuración
DROP POLICY IF EXISTS "empresa_propia_config" ON certificado_config;
CREATE POLICY "empresa_propia_config" ON certificado_config
  FOR ALL USING (empresa = (current_setting('app.empresa', true)));

-- Cada empresa solo ve sus certificados emitidos
DROP POLICY IF EXISTS "empresa_propia_certs" ON certificados_emitidos;
CREATE POLICY "empresa_propia_certs" ON certificados_emitidos
  FOR ALL USING (empresa = (current_setting('app.empresa', true)));
