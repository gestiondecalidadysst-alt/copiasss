async function check() {
  const res = await fetch('http://localhost:5000/api/eventos');
  const data = await res.json();
  const today = new Date().toLocaleDateString('en-CA');
  
  const eventosHoy = data.filter(e => {
    const dStr = e.created_at ? new Date(e.created_at).toLocaleDateString('en-CA') : '';
    return dStr === today;
  });

  console.log(`Fecha de hoy detectada: ${today}`);
  console.log(`Total eventos hoy: ${eventosHoy.length}`);
  
  eventosHoy.forEach(e => {
    console.log(`ID: ${e.id}, Placa: ${e.placa}, Lat: ${e.latitud}, Lng: ${e.longitud}, Velocidad: ${e.velocidad}`);
  });
}
check();
