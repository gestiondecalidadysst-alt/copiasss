# Backend de Módulos - Implementación Completa ✅

## 📋 Resumen de Cambios

Se ha implementado completamente el backend para soportar **capacitaciones con múltiples módulos** donde cada módulo contiene diferentes actividades (videos + quizzes).

## 🗂️ Archivos Modificados/Creados

### 1. **Nueva Migración SQL** 
- **Archivo**: `backend/migrations/MODULOS_SCHEMA.sql`
- **Descripción**: Crea todas las tablas necesarias para módulos

**Tablas creadas:**
- `modulos` - Estructura de módulos dentro de capacitaciones
- `videos_modulo` - Videos dentro de cada módulo
- `quizzes_modulo` - Quizzes dentro de cada módulo
- `preguntas_modulo` - Preguntas de quizzes
- `opciones_modulo` - Opciones de respuesta
- `progreso_modulos` - Seguimiento de progreso por módulo
- `progreso_videos` - Seguimiento de progreso de videos
- `respuestas_modulo` - Respuestas de conductores
- `intentos_quiz_modulo` - Control de intentos por quiz

### 2. **Backend Controller - Capacitaciones**
- **Archivo**: `backend/controllers/capacitacionesController.js`
- **Nuevos Métodos**:
  - `getModulos(req, res)` - Obtener módulos completos de una capacitación
  - `saveModulos(req, res)` - Guardar/actualizar estructura de módulos

### 3. **Backend Controller - Portal Conductor**
- **Archivo**: `backend/controllers/portalConductorController.js`
- **Nuevos Métodos**:
  - `getModulosCapacitacion(req, res)` - Conductor obtiene módulos asignados
  - `actualizarProgresoVideoModulo(req, res)` - Guardar progreso de video
  - `responderQuizModulo(req, res)` - Enviar respuestas de quiz de módulo
  - `completarCapacitacionModulos(req, res)` - Completar toda la capacitación

### 4. **Rutas Portal Conductor**
- **Archivo**: `backend/routes/portalConductorRoutes.js`
- **Nuevas Rutas**:
  ```
  GET  /capacitaciones/:id/modulos
  PUT  /capacitaciones/:id/modulos/video-progreso
  POST /capacitaciones/:id/modulos/quiz/responder
  POST /capacitaciones/:id/modulos/completar
  ```

### 5. **Rutas Capacitaciones**
- **Archivo**: `backend/routes/capacitacionesRoutes.js`
- **Nuevas Rutas**:
  ```
  GET  /capacitaciones/:id/modulos      (admin/usuario)
  POST /capacitaciones/:id/modulos      (admin/usuario) - guardar módulos
  ```

## 🚀 Pasos para Implementar

### Paso 1: Ejecutar la Migración SQL
Abrir Supabase SQL Editor y ejecutar el contenido de:
```
backend/migrations/MODULOS_SCHEMA.sql
```

### Paso 2: Validar las Tablas
En Supabase, verificar que existan:
- modulos
- videos_modulo
- quizzes_modulo
- preguntas_modulo
- opciones_modulo
- progreso_modulos
- progreso_videos
- respuestas_modulo
- intentos_quiz_modulo

## 📡 Endpoints Nuevos

### Para Administradores (crear/editar módulos)

**Obtener módulos de una capacitación:**
```bash
GET /api/capacitaciones/:capacitacion_id/modulos
Authorization: Bearer <token_admin>
```

**Guardar/actualizar módulos:**
```bash
POST /api/capacitaciones/:capacitacion_id/modulos
Authorization: Bearer <token_admin>
Content-Type: application/json

{
  "modulos": [
    {
      "titulo": "Módulo 1: Seguridad Vial",
      "descripcion": "Conceptos básicos",
      "orden": 0,
      "videos": [
        {
          "titulo": "Video 1",
          "url": "https://youtube.com/...",
          "duracion_minutos": 10,
          "orden": 0
        }
      ],
      "quizzes": [
        {
          "titulo": "Quiz 1",
          "porcentaje_aprobacion": 70,
          "orden": 0,
          "preguntas": [
            {
              "pregunta": "¿Qué es un semáforo?",
              "puntos": 1,
              "orden": 0,
              "opciones": [
                {
                  "texto": "Un aparato de señalización",
                  "es_correcta": true,
                  "orden": 0
                },
                {
                  "texto": "Una calle",
                  "es_correcta": false,
                  "orden": 1
                }
              ]
            }
          ]
        }
      ]
    }
  ]
}
```

### Para Conductores (ejecutar capacitación)

**Obtener módulos de una asignación:**
```bash
GET /api/portal/conductor/capacitaciones/:asignacion_id/modulos
Authorization: Bearer <token_conductor>
```

**Actualizar progreso de video:**
```bash
PUT /api/portal/conductor/capacitaciones/:asignacion_id/modulos/video-progreso
Authorization: Bearer <token_conductor>
Content-Type: application/json

{
  "modulo_id": "uuid",
  "video_id": "uuid",
  "progreso": 85
}
```

**Responder quiz de módulo:**
```bash
POST /api/portal/conductor/capacitaciones/:asignacion_id/modulos/quiz/responder
Authorization: Bearer <token_conductor>
Content-Type: application/json

{
  "modulo_id": "uuid",
  "quiz_id": "uuid",
  "respuestas": [
    {
      "pregunta_id": "uuid",
      "opcion_id": "uuid"
    }
  ]
}
```

**Completar capacitación:**
```bash
POST /api/portal/conductor/capacitaciones/:asignacion_id/modulos/completar
Authorization: Bearer <token_conductor>
Content-Type: application/json

{
  "modulos_resultados": [
    {
      "modulo_id": "uuid",
      "nota": 8.5,
      "quizzes": [
        {
          "quiz_id": "uuid",
          "titulo": "Quiz 1",
          "puntaje": 85,
          "aprobado": true
        }
      ]
    }
  ]
}
```

## 📊 Flujo Completo de Módulos

```
1. Admin crea capacitación
   ↓
2. Admin obtiene módulos vacíos
   ↓
3. Admin crea estructura: Módulo 1 → [Video 1, Video 2] → [Quiz 1]
                         Módulo 2 → [Video 3] → [Quiz 2]
   ↓
4. Admin guarda módulos (POST /capacitaciones/:id/modulos)
   ↓
5. Conductor es asignado a capacitación
   ↓
6. Conductor obtiene módulos (GET /capacitaciones/:id/modulos)
   ↓
7. Conductor ve Módulo 1:
   - Ve Video 1 (progreso 0%)
   - Ve Video 2 (bloqueado hasta completar Video 1)
   - Ve Quiz (bloqueado hasta ver todos los videos)
   ↓
8. Conductor ve Video 1, progresa al 80% → desbloquea botón
   ↓
9. Conductor avanza a Video 2 (mismo proceso)
   ↓
10. Conductor completa todos los videos → desbloquea Quiz
   ↓
11. Conductor responde Quiz (máx 2 intentos)
   ↓
12. Si Quiz aprobado → Módulo 1 completado (nota: 8.5)
   ↓
13. Repetir pasos 7-12 para Módulo 2
   ↓
14. Cuando Módulo 2 completado → calcular nota final
   ↓
15. Nota final = promedio de notas de módulos
   ↓
16. Si Nota final >= 8.0 → Capacitación aprobada ✅
```

## 🔐 Seguridad

- ✅ Los conductores solo pueden ver/editar sus propias asignaciones
- ✅ Los conductores no pueden ver respuestas correctas
- ✅ Máximo 2 intentos por quiz
- ✅ Límite de progreso: 80% video para desbloquear siguiente
- ✅ RLS (Row Level Security) habilitado en todas las tablas

## 🔄 Compatibilidad

- ✅ Sistema antiguo (SIN módulos) sigue funcionando
- ✅ Las nuevas rutas de módulos NO interfieren con las antiguas
- ✅ Transición suave: los admins pueden usar ambas arquitecturas

## 📝 Notas Importantes

1. **VideoThreshold**: 80% es el porcentaje requerido para desbloquear siguiente video/quiz
2. **Nota Final**: Se calcula como promedio de todas las notas de módulos
3. **Aprobación**: Nota final >= 8.0
4. **Intentos**: 2 intentos máximo por quiz dentro de cada módulo
