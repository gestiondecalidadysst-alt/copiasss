const supabase = require('../config/supabaseClient');

const MensajesProgramadoModel = {
  /** Devuelve la fila de programación de un mensaje, o null si no existe */
  getByMensajeId: async (mensajeId) => {
    const { data, error } = await supabase
      .from('mensajes_programados')
      .select('*')
      .eq('mensaje_id', mensajeId)
      .maybeSingle();
    if (error) throw error;
    return data ?? null;
  },

  /**
   * Crea o actualiza la programación de un mensaje.
   * Si ya existe la fila y la fecha cambió, resetea el estado a 'programado'.
   */
  upsert: async (mensajeId, fecha, hora) => {
    // Verificar si ya existe
    const { data: existing, error: selErr } = await supabase
      .from('mensajes_programados')
      .select('*')
      .eq('mensaje_id', mensajeId)
      .maybeSingle();
    if (selErr) throw selErr;

    if (!existing) {
      const { data, error } = await supabase
        .from('mensajes_programados')
        .insert([{ mensaje_id: mensajeId, fecha, hora: hora || null, estado: 'programado' }])
        .select()
        .single();
      if (error) throw error;
      return data;
    } else {
      const nuevoEstado = existing.fecha !== fecha ? 'programado' : existing.estado;
      const { data, error } = await supabase
        .from('mensajes_programados')
        .update({ fecha, hora: hora || null, estado: nuevoEstado, updated_at: new Date().toISOString() })
        .eq('mensaje_id', mensajeId)
        .select()
        .single();
      if (error) throw error;
      return data;
    }
  },

  /** Cambia el estado a 'enviado' o 'programado' */
  updateEstado: async (mensajeId, nuevoEstado) => {
    const { data, error } = await supabase
      .from('mensajes_programados')
      .update({ estado: nuevoEstado, updated_at: new Date().toISOString() })
      .eq('mensaje_id', mensajeId)
      .select()
      .single();
    if (error) throw error;
    return data;
  },
};

module.exports = MensajesProgramadoModel;
