const supabase = require('../config/supabaseClient');

const ConductorModel = {
  getAll: async () => {
    const { data, error } = await supabase.from('conductores').select('*');
    if (error) throw error;
    return data;
  },
  getById: async (id) => {
    const { data, error } = await supabase.from('conductores').select('*').eq('id', id).single();
    if (error) throw error;
    return data;
  },
  create: async (dataToInsert) => {
    const cedula = (dataToInsert.cedula || '').trim();
    if (!cedula) {
      const error = new Error('Cédula es requerida');
      error.code = 'VALIDATION_ERROR';
      throw error;
    }

    const { data: existing, error: existingError } = await supabase
      .from('conductores')
      .select('id')
      .eq('cedula', cedula)
      .maybeSingle();

    if (existingError) throw existingError;
    if (existing) {
      const error = new Error('Ya existe un conductor con esa cédula');
      error.code = 'DUPLICATE_CONDUCTOR';
      throw error;
    }

    const newConductor = { score: 100, ...dataToInsert, cedula };
    const { data, error } = await supabase.from('conductores').insert([newConductor]).select().single();
    if (error) throw error;
    return data;
  },
  update: async (id, dataToUpdate) => {
    const cedula = typeof dataToUpdate.cedula === 'string' ? dataToUpdate.cedula.trim() : undefined;
    if (cedula) {
      const { data: existing, error: existingError } = await supabase
        .from('conductores')
        .select('id')
        .eq('cedula', cedula)
        .maybeSingle();

      if (existingError) throw existingError;
      if (existing && existing.id !== id) {
        const error = new Error('Ya existe un conductor con esa cédula');
        error.code = 'DUPLICATE_CONDUCTOR';
        throw error;
      }
    }

    const { data, error } = await supabase.from('conductores').update(dataToUpdate).eq('id', id).select().single();
    if (error) throw error;
    return data;
  },
  delete: async (id) => {
    const { data, error } = await supabase.from('conductores').delete().eq('id', id).select().single();
    if (error) throw error;
    return data;
  }
};

module.exports = ConductorModel;
