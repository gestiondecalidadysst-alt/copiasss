const supabase = require('../config/supabaseClient');

const MensajesEnvioModel = {
  /**
   * Devuelve todos los envíos registrados de un mensaje.
   * Retorna [] si no hay ninguno (nunca lanza error por 0 filas).
   */
  getByMensajeId: async (mensajeId) => {
    const { data, error } = await supabase
      .from('mensajes_envios')
      .select('*')
      .eq('mensaje_id', mensajeId)
      .order('fecha', { ascending: true });
    if (error) throw error;
    return data ?? [];
  },

  /**
   * Registra que un mensaje fue enviado en una fecha/franja concretas.
   * Retorna el registro creado.
   * Si ya existe (UNIQUE violation, código 23505) retorna null en vez de lanzar error,
   * para que el controlador pueda responder 409 de forma controlada.
   */
  registrarEnvio: async ({ mensajeId, programacionIdx, fecha, horaEnvio }) => {
    const { data, error } = await supabase
      .from('mensajes_envios')
      .insert([{
        mensaje_id:       mensajeId,
        programacion_idx: programacionIdx ?? 0,
        fecha,
        hora_envio:       horaEnvio ?? null,
      }])
      .select()
      .single();

    // Código 23505 = unique_violation (envío ya registrado para ese día/franja)
    if (error) {
      if (error.code === '23505') return null;
      throw error;
    }
    return data;
  },

  /**
   * Elimina el registro de envío de una fecha/franja (para deshacer el marcado).
   */
  eliminarEnvio: async ({ mensajeId, programacionIdx, fecha }) => {
    const { data, error } = await supabase
      .from('mensajes_envios')
      .delete()
      .eq('mensaje_id', mensajeId)
      .eq('programacion_idx', programacionIdx ?? 0)
      .eq('fecha', fecha)
      .select()
      .single();
    if (error) throw error;
    return data;
  },
};

module.exports = MensajesEnvioModel;
