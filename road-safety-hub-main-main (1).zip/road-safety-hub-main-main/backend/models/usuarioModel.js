const supabaseClient = require('../config/supabaseClient.js');
const bcrypt = require('bcryptjs');

class UsuarioModel {
  /**
   * Obtener todos los usuarios (solo para admin)
   */
  static async getAll() {
    try {
      const { data, error } = await supabaseClient
        .from('usuarios')
        .select(`
          id,
          email,
          nombre,
          empresa,
          activo,
          created_at,
          updated_at,
          usuario_roles!inner(
            rol_id,
            roles!inner(id, nombre, descripcion)
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error en UsuarioModel.getAll():', error);
      throw error;
    }
  }

  /**
   * Obtener usuario por ID
   */
  static async getById(id) {
    try {
      const { data, error } = await supabaseClient
        .from('usuarios')
        .select(`
          id,
          email,
          nombre,
          empresa,
          activo,
          created_at,
          updated_at,
          usuario_roles(
            rol_id,
            roles(id, nombre, descripcion)
          )
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error en UsuarioModel.getById():', error);
      throw error;
    }
  }

  /**
   * Obtener usuario por email
   */
  static async getByEmail(email) {
    try {
      const { data, error } = await supabaseClient
        .from('usuarios')
        .select(`
          id,
          email,
          nombre,
          empresa,
          password_hash,
          conductor_id,
          activo,
          created_at,
          updated_at,
          usuario_roles(
            rol_id,
            roles(id, nombre, descripcion)
          )
        `)
        .eq('email', email.toLowerCase())
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return data || null;
    } catch (error) {
      console.error('Error en UsuarioModel.getByEmail():', error);
      throw error;
    }
  }

  /**
   * Crear nuevo usuario
   */
  static async create(usuarioData) {
    try {
      const { email, nombre, empresa, password, rolNombre = 'usuario', conductor_id = null } = usuarioData;

      // Validar email único
      const usuarioExistente = await this.getByEmail(email);
      if (usuarioExistente) {
        throw new Error('El email ya está registrado');
      }

      // Hash de la contraseña
      const passwordHash = await bcrypt.hash(password, 10);

      // Crear usuario
      const insertData = {
        email: email.toLowerCase(),
        nombre,
        empresa,
        password_hash: passwordHash,
        activo: true
      };
      if (conductor_id) insertData.conductor_id = conductor_id;

      const { data: usuarioCreado, error: errorUsuario } = await supabaseClient
        .from('usuarios')
        .insert(insertData)
        .select()
        .single();

      if (errorUsuario) throw errorUsuario;

      // Obtener el rol
      const { data: rol, error: errorRol } = await supabaseClient
        .from('roles')
        .select('id')
        .eq('nombre', rolNombre)
        .single();

      if (errorRol) throw errorRol;

      // Asignar rol al usuario
      const { error: errorAsignar } = await supabaseClient
        .from('usuario_roles')
        .insert({
          usuario_id: usuarioCreado.id,
          rol_id: rol.id
        });

      if (errorAsignar) throw errorAsignar;

      return {
        id: usuarioCreado.id,
        email: usuarioCreado.email,
        nombre: usuarioCreado.nombre,
        empresa: usuarioCreado.empresa,
        rol: rolNombre
      };
    } catch (error) {
      console.error('Error en UsuarioModel.create():', error);
      throw error;
    }
  }

  /**
   * Actualizar usuario
   */
  static async update(id, usuarioData) {
    try {
      const { nombre, empresa, activo } = usuarioData;

      const { data, error } = await supabaseClient
        .from('usuarios')
        .update({
          nombre,
          empresa,
          activo,
          updated_at: new Date()
        })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error en UsuarioModel.update():', error);
      throw error;
    }
  }

  /**
   * Cambiar contraseña
   */
  static async cambiarPassword(id, passwordAntigua, passwordNueva) {
    try {
      // Obtener usuario actual
      const usuario = await this.getById(id);
      if (!usuario) throw new Error('Usuario no encontrado');

      // Verificar contraseña antigua
      const passwordValida = await bcrypt.compare(passwordAntigua, usuario.password_hash);
      if (!passwordValida) throw new Error('Contraseña actual incorrecta');

      // Hash de nueva contraseña
      const passwordHash = await bcrypt.hash(passwordNueva, 10);

      const { error } = await supabaseClient
        .from('usuarios')
        .update({
          password_hash: passwordHash,
          updated_at: new Date()
        })
        .eq('id', id);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Error en UsuarioModel.cambiarPassword():', error);
      throw error;
    }
  }

  /**
   * Eliminar usuario
   */
  static async delete(id) {
    try {
      // Primero eliminar relaciones de roles
      const { error: errorRoles } = await supabaseClient
        .from('usuario_roles')
        .delete()
        .eq('usuario_id', id);

      if (errorRoles) throw errorRoles;

      // Luego eliminar usuario
      const { error } = await supabaseClient
        .from('usuarios')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Error en UsuarioModel.delete():', error);
      throw error;
    }
  }

  /**
   * Obtener roles de un usuario
   */
  static async getRoles(usuarioId) {
    try {
      const { data, error } = await supabaseClient
        .from('usuario_roles')
        .select('roles(id, nombre, descripcion)')
        .eq('usuario_id', usuarioId);

      if (error) throw error;
      return data.map(ur => ur.roles);
    } catch (error) {
      console.error('Error en UsuarioModel.getRoles():', error);
      throw error;
    }
  }

  /**
   * Asignar rol a usuario
   */
  static async asignarRol(usuarioId, rolNombre) {
    try {
      // Obtener el rol
      const { data: rol, error: errorRol } = await supabaseClient
        .from('roles')
        .select('id')
        .eq('nombre', rolNombre)
        .single();

      if (errorRol) throw errorRol;

      // Asignar rol
      const { error } = await supabaseClient
        .from('usuario_roles')
        .insert({
          usuario_id: usuarioId,
          rol_id: rol.id
        });

      if (error && error.code !== '23505') throw error; // 23505 = violación de unique constraint

      return { success: true, rol: rolNombre };
    } catch (error) {
      console.error('Error en UsuarioModel.asignarRol():', error);
      throw error;
    }
  }

  /**
   * Remover rol de usuario
   */
  static async removerRol(usuarioId, rolNombre) {
    try {
      // Obtener el rol
      const { data: rol, error: errorRol } = await supabaseClient
        .from('roles')
        .select('id')
        .eq('nombre', rolNombre)
        .single();

      if (errorRol) throw errorRol;

      // Remover rol
      const { error } = await supabaseClient
        .from('usuario_roles')
        .delete()
        .eq('usuario_id', usuarioId)
        .eq('rol_id', rol.id);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Error en UsuarioModel.removerRol():', error);
      throw error;
    }
  }

  /**
   * Verificar contraseña
   */
  static async verificarPassword(email, password) {
    try {
      const usuario = await this.getByEmail(email);
      if (!usuario) return { valido: false, usuario: null };

      const valido = await bcrypt.compare(password, usuario.password_hash);
      if (!valido) return { valido: false, usuario: null };

      // No retornar hash de contraseña
      const { password_hash, ...usuarioSeguro } = usuario;
      return { valido: true, usuario: usuarioSeguro };
    } catch (error) {
      console.error('Error en UsuarioModel.verificarPassword():', error);
      throw error;
    }
  }

  /**
   * Activar/Desactivar usuario
   */
  static async toggleActivo(id) {
    try {
      const usuario = await this.getById(id);
      if (!usuario) throw new Error('Usuario no encontrado');

      const { data, error } = await supabaseClient
        .from('usuarios')
        .update({
          activo: !usuario.activo,
          updated_at: new Date()
        })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error en UsuarioModel.toggleActivo():', error);
      throw error;
    }
  }
}

module.exports = UsuarioModel;
