const supabase = require('../config/supabaseClient');

const TemplateModel = {
  // Obtener plantilla activa de una empresa
  getByEmpresa: async (empresa, templateName = 'default') => {
    const { data, error } = await supabase
      .from('capacitaciones_templates')
      .select('*')
      .eq('empresa', empresa)
      .eq('template_name', templateName)
      .maybeSingle();

    if (error) throw error;
    return data;
  },

  // Obtener todas las plantillas de una empresa
  getAllByEmpresa: async (empresa) => {
    const { data, error } = await supabase
      .from('capacitaciones_templates')
      .select('*')
      .eq('empresa', empresa)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  // Crear o actualizar plantilla
  upsert: async (empresa, templateName, templateData) => {
    const { data, error } = await supabase
      .from('capacitaciones_templates')
      .upsert({
        empresa,
        template_name: templateName,
        ...templateData,
        updated_at: new Date().toISOString()
      }, { onConflict: 'empresa,template_name' })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Eliminar plantilla
  delete: async (id) => {
    const { error } = await supabase
      .from('capacitaciones_templates')
      .delete()
      .eq('id', id);

    if (error) throw error;
    return true;
  }
};

module.exports = TemplateModel;
