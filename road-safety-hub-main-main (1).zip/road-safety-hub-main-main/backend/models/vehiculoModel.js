const supabase = require('../config/supabaseClient');

const VehiculoModel = {
  getAll: async () => {
    const { data, error } = await supabase.from('VEHICULO').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },
  getById: async (id) => {
    const { data, error } = await supabase.from('VEHICULO').select('*').eq('id', id).single();
    if (error) throw error;
    return data;
  },
  create: async (dataToInsert) => {
    const { data, error } = await supabase.from('VEHICULO').insert([dataToInsert]).select().single();
    if (error) throw error;
    return data;
  },
  update: async (id, dataToUpdate) => {
    const { data, error } = await supabase.from('VEHICULO').update(dataToUpdate).eq('id', id).select().single();
    if (error) throw error;
    return data;
  },
  delete: async (id) => {
    const { data, error } = await supabase.from('VEHICULO').delete().eq('id', id).select().single();
    if (error) throw error;
    return data;
  }
};

module.exports = VehiculoModel;
