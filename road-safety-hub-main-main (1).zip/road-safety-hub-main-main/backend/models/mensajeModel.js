const supabase = require('../config/supabaseClient');

// Normaliza valores de media_type para cumplir el CHECK constraint de la DB
// La DB acepta: 'texto', 'imagen', 'video', 'audio', 'multimedia'
const normalizeMediaType = (mt) => {
  if (!mt) return null;
  const map = { image: 'imagen', img: 'imagen', foto: 'imagen', audio: 'audio', video: 'video', texto: 'texto', text: 'texto', multimedia: 'multimedia' };
  return map[mt.toLowerCase()] ?? mt;
};

const MensajeModel = {
  getAll: async () => {
    const { data, error } = await supabase
      .from('mensajes')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  getById: async (id) => {
    const { data, error } = await supabase
      .from('mensajes')
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  },

  getByTipo: async (tipo) => {
    const { data, error } = await supabase
      .from('mensajes')
      .select('*')
      .eq('tipo', tipo)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  getByEstado: async (estado) => {
    const { data, error } = await supabase
      .from('mensajes')
      .select('*')
      .eq('estado', estado)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  create: async (dataToInsert) => {
    const { 
      titulo, 
      tipo, 
      contenido, 
      destinatario, 
      asunto, 
      prioridad, 
      emoji, 
      estado,
      media_type,
      media_url,
      media_size,
      file_name,
      fecha_programada,
      hora_programada,
      conductor_id,
    } = dataToInsert;

    const fullData = {
      titulo,
      tipo: tipo || 'preventiva',
      contenido,
      destinatario: destinatario || null,
      asunto: asunto || null,
      prioridad: prioridad || 'normal',
      emoji: emoji || '📬',
      estado: estado || 'draft',
      media_type: normalizeMediaType(media_type),
      media_url: media_url || null,
      media_size: media_size || null,
      file_name: file_name || null,
      fecha_programada: fecha_programada || null,
      hora_programada: hora_programada || null,
      conductor_id: conductor_id || null,
    };

    const { data, error } = await supabase
      .from('mensajes')
      .insert([fullData])
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  update: async (id, dataToUpdate) => {
    const { 
      titulo, 
      tipo, 
      contenido, 
      destinatario, 
      asunto, 
      prioridad, 
      emoji, 
      estado,
      media_type,
      media_url,
      media_size,
      file_name,
      fecha_programada,
      hora_programada,
      conductor_id,
    } = dataToUpdate;

    const fullData = {
      titulo,
      tipo,
      contenido,
      destinatario: destinatario ?? null,
      asunto: asunto ?? null,
      prioridad: prioridad ?? 'normal',
      emoji: emoji ?? '📬',
      estado: estado ?? 'draft',
      media_type: normalizeMediaType(media_type),
      media_url: media_url ?? null,
      media_size: media_size ?? null,
      file_name: file_name ?? null,
      fecha_programada: fecha_programada ?? null,
      hora_programada: hora_programada ?? null,
      conductor_id: conductor_id ?? null,
      updated_at: new Date().toISOString(),
    };

    const { data, error } = await supabase
      .from('mensajes')
      .update(fullData)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  delete: async (id) => {
    const { data, error } = await supabase
      .from('mensajes')
      .delete()
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  // Media upload
  uploadMedia: async (file, tipo) => {
    if (!file) throw new Error('No file provided');
    
    const sanitizedName = file.originalname
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-zA-Z0-9._-]/g, '_');
    const fileName = `${Date.now()}-${sanitizedName}`;
    const filePath = `${tipo}/${fileName}`;

    try {
      const { data, error } = await supabase.storage
        .from('mensaje-media')
        .upload(filePath, file.buffer, {
          contentType: file.mimetype,
          cacheControl: '3600',
          upsert: false,
        });

      if (error) throw error;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('mensaje-media')
        .getPublicUrl(filePath);

      return {
        url: publicUrl,
        path: filePath,
        fileName: file.originalname,
        size: file.size,
        mimetype: file.mimetype,
      };
    } catch (error) {
      console.error('Upload error:', error);
      throw error;
    }
  },

  // Delete media
  deleteMedia: async (filePath) => {
    const { error } = await supabase.storage
      .from('mensaje-media')
      .remove([filePath]);

    if (error) throw error;
    return { success: true };
  },
};

module.exports = MensajeModel;
