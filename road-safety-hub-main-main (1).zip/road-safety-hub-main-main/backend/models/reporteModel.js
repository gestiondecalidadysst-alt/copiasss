const supabase = require('../config/supabaseClient');

const ReporteModel = {
  // Obtener todos los reportes con paginación
  getAll: async (options = {}) => {
    const { 
      page = 1, 
      limit = 100, // Límite por defecto de 100 reportes
      includePagination = true 
    } = options;

    // Si no se requiere paginación, obtener todos (usar con cuidado)
    if (!includePagination) {
      const { data, error } = await supabase
        .from('reportes')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return { data, pagination: null };
    }

    // Calcular offset para paginación
    const offset = (page - 1) * limit;

    // Obtener datos paginados
    const { data, error, count } = await supabase
      .from('reportes')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;

    // Retornar datos con información de paginación
    return {
      data,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: count,
        totalPages: Math.ceil(count / limit),
        hasMore: offset + limit < count
      }
    };
  },
  
  getById: async (id) => {
    const { data, error } = await supabase
      .from('reportes')
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  },
  
  create: async (reporteData) => {
    const { data, error } = await supabase
      .from('reportes')
      .insert([reporteData])
      .select()
      .single();
    if (error) throw error;
    return data;
  },
  
  update: async (id, reporteData) => {
    const { data, error } = await supabase
      .from('reportes')
      .update(reporteData)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },
  
  delete: async (id) => {
    // Primero verificar que existe
    const { data: existing, error: getError } = await supabase
      .from('reportes')
      .select('id')
      .eq('id', id)
      .single();
    
    if (getError || !existing) {
      throw new Error('Reporte no encontrado');
    }

    // Luego eliminar
    const { error: deleteError } = await supabase
      .from('reportes')
      .delete()
      .eq('id', id);
    
    if (deleteError) throw deleteError;
    return { id }; // Retornar el id eliminado
  }
};

module.exports = ReporteModel;
