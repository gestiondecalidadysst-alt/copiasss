const supabase = require('../config/supabaseClient');

const EventoModel = {
  getAll: async () => {
    let allData = [];
    let page = 0;
    const pageSize = 1000; // Máximo permitido por Supabase
    let hasMore = true;

    while (hasMore) {
      const { data, error } = await supabase
        .from('EXCESOS DE VELOCIDAD')
        .select('*')
        .order('created_at', { ascending: false })
        .range(page * pageSize, (page + 1) * pageSize - 1);
      
      if (error) throw error;
      
      if (data && data.length > 0) {
        allData = allData.concat(data);
        page++;
        hasMore = data.length === pageSize;
      } else {
        hasMore = false;
      }
    }
    
    console.log(`✅ EventoModel.getAll(): ${allData.length} eventos cargados`);
    return allData;
  },

  // Retorna eventos cuyo created_at está dentro del rango [fechaInicio, fechaFin] (YYYY-MM-DD)
  getByDateRange: async (fechaInicio, fechaFin) => {
    const desde = `${fechaInicio}T00:00:00.000Z`;
    const hasta = `${fechaFin}T23:59:59.999Z`;

    let allData = [];
    let page = 0;
    const pageSize = 1000;
    let hasMore = true;

    while (hasMore) {
      const { data, error } = await supabase
        .from('EXCESOS DE VELOCIDAD')
        .select('*')
        .gte('created_at', desde)
        .lte('created_at', hasta)
        .order('created_at', { ascending: false })
        .range(page * pageSize, (page + 1) * pageSize - 1);

      if (error) throw error;

      if (data && data.length > 0) {
        allData = allData.concat(data);
        page++;
        hasMore = data.length === pageSize;
      } else {
        hasMore = false;
      }
    }

    console.log(`✅ EventoModel.getByDateRange(${fechaInicio}, ${fechaFin}): ${allData.length} eventos`);
    return allData;
  },
  getById: async (id) => {
    const { data, error } = await supabase.from('EXCESOS DE VELOCIDAD').select('*').eq('id', id).single();
    if (error) throw error;
    return data;
  },
  create: async (dataToInsert) => {
    const { data, error } = await supabase.from('EXCESOS DE VELOCIDAD').insert([dataToInsert]).select().single();
    if (error) throw error;
    return data;
  },
  update: async (id, dataToUpdate) => {
    const { data, error } = await supabase.from('EXCESOS DE VELOCIDAD').update(dataToUpdate).eq('id', id).select().single();
    if (error) throw error;
    return data;
  },
  delete: async (id) => {
    const { data, error } = await supabase.from('EXCESOS DE VELOCIDAD').delete().eq('id', id).select().single();
    if (error) throw error;
    return data;
  }
};

module.exports = EventoModel;
