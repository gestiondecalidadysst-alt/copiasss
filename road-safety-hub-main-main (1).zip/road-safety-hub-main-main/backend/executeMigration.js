/**
 * Script para ejecutar la migración SQL directamente en Supabase
 * Este script lee el archivo SQL y lo ejecuta usando Supabase Admin API
 * Uso: node backend/executeMigration.js
 */

const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Error: Faltan credenciales en .env');
  console.error('   Se necesita: SUPABASE_URL y SUPABASE_SERVICE_ROLE_KEY (o SUPABASE_ANON_KEY)');
  process.exit(1);
}

// Usar service role key para operaciones DDL
const supabase = createClient(supabaseUrl, supabaseServiceKey);

async function executeMigration() {
  try {
    console.log('\n╔════════════════════════════════════════════════╗');
    console.log('║        EJECUTANDO MIGRACIÓN SQL                 ║');
    console.log('╚════════════════════════════════════════════════╝\n');

    // 1. Leer archivo SQL
    const sqlFile = path.join(__dirname, 'migrations', '002_create_mensajes_table.sql');
    
    if (!fs.existsSync(sqlFile)) {
      throw new Error(`Archivo SQL no encontrado: ${sqlFile}`);
    }

    const sqlContent = fs.readFileSync(sqlFile, 'utf-8');
    console.log(`📁 Archivo: migrations/002_create_mensajes_table.sql`);
    console.log(`📝 Tamaño: ${sqlContent.length} caracteres\n`);

    // 2. Separar comandos SQL
    const statements = sqlContent
      .split(';')
      .map(stmt => {
        // Eliminar comentarios y espacios innecesarios
        return stmt
          .split('\n')
          .filter(line => !line.trim().startsWith('--'))
          .join('\n')
          .trim();
      })
      .filter(stmt => stmt.length > 0);

    console.log(`📋 Se encontraron ${statements.length} comandos\n`);

    // 3. Ejecutar cada comando
    let executed = 0;
    let skipped = 0;

    for (let i = 0; i < statements.length; i++) {
      const stmt = statements[i];
      const shortStmt = stmt.substring(0, 60).replace(/\s+/g, ' ');
      
      console.log(`[${i + 1}/${statements.length}] ${shortStmt}...`);

      try {
        // Intentar ejecutar usando RPC function 'execute_sql' si existe
        const { data, error } = await supabase.rpc('execute_sql', {
          sql: stmt
        });

        if (error) {
          // Si la función RPC no existe, mostrar instrucciones
          if (error.message.includes('does not exist') || error.code === 'PGRST104') {
            console.log('   ⚠️  RPC no disponible - requiere ejecución manual\n');
            skipped++;
            continue;
          }
          throw error;
        }

        console.log('   ✅ OK\n');
        executed++;
      } catch (error) {
        console.log(`   ⚠️  ${error.message}\n`);
        skipped++;
      }
    }

    console.log('\n╔════════════════════════════════════════════════╗');
    console.log('║           RESULTADO DE LA MIGRACIÓN            ║');
    console.log('╚════════════════════════════════════════════════╝\n');
    console.log(`✅ Ejecutados: ${executed}`);
    console.log(`⚠️  Omitidos: ${skipped}\n`);

    // 4. Verificar tabla
    console.log('🧪 Verificando tabla mensajes...');
    const { data: tableData, error: tableError } = await supabase
      .from('mensajes')
      .select('*')
      .limit(1);

    if (tableError && tableError.code !== 'PGRST116') {
      throw tableError;
    }

    console.log('✅ Tabla mensajes está disponible\n');

    console.log('╔════════════════════════════════════════════════╗');
    console.log('║   ✨ ¡MIGRACIÓN COMPLETADA EXITOSAMENTE! ✨   ║');
    console.log('╚════════════════════════════════════════════════╝\n');

    showTableInfo();

  } catch (error) {
    console.error('\n❌ ERROR:', error.message);
    console.log('\n🔧 SOLUCIÓN MANUAL:\n');
    console.log('Si no se pudo ejecutar automáticamente, copia y ejecuta esto');
    console.log('en el SQL Editor de tu proyecto Supabase (https://supabase.com):\n');
    
    try {
      const sqlFile = path.join(__dirname, 'migrations', '002_create_mensajes_table.sql');
      const sql = fs.readFileSync(sqlFile, 'utf-8');
      console.log('═'.repeat(60));
      console.log(sql);
      console.log('═'.repeat(60));
    } catch (e) {
      console.error('No se pudo leer el archivo SQL');
    }
    
    process.exit(1);
  }
}

function showTableInfo() {
  console.log('📊 TABLA "mensajes" - ESTRUCTURA:\n');
  
  const fields = [
    { name: 'id', type: 'UUID', desc: 'ID único' },
    { name: 'titulo', type: 'VARCHAR', desc: 'Requerido' },
    { name: 'tipo', type: 'VARCHAR', desc: 'preventiva|segunda|tercera|informativa|broadcast' },
    { name: 'contenido', type: 'TEXT', desc: 'Cuerpo del mensaje' },
    { name: 'asunto', type: 'VARCHAR', desc: 'Opcional' },
    { name: 'prioridad', type: 'VARCHAR', desc: 'alta|normal|baja' },
    { name: 'estado', type: 'VARCHAR', desc: 'draft|enviado|programado' },
    { name: 'emoji', type: 'VARCHAR', desc: 'Emoji personalizado' },
    { name: 'destinatario', type: 'VARCHAR', desc: 'A quién enviar' },
    { name: 'media_type', type: 'VARCHAR', desc: '🎬 NEW: texto|imagen|video|audio|multimedia' },
    { name: 'media_url', type: 'TEXT', desc: '🎬 NEW: URL pública del archivo' },
    { name: 'media_size', type: 'INT', desc: '🎬 NEW: Tamaño en bytes' },
    { name: 'file_name', type: 'VARCHAR', desc: '🎬 NEW: Nombre original' },
    { name: 'fecha_programada', type: 'TIMESTAMP', desc: 'Para mensajes programados' },
    { name: 'conductor_id', type: 'UUID FK', desc: 'Referencia a conductor' },
    { name: 'enviados', type: 'INT', desc: 'Contador de envíos' },
    { name: 'visualizados', type: 'INT', desc: 'Contador de visualizaciones' },
    { name: 'created_at', type: 'TIMESTAMP', desc: 'Fecha creación' },
    { name: 'updated_at', type: 'TIMESTAMP', desc: 'Última actualización' },
    { name: 'created_by', type: 'UUID', desc: 'Usuario que creó' },
  ];

  fields.forEach(field => {
    console.log(`  • ${field.name.padEnd(18)} (${field.type.padEnd(12)}) ${field.desc}`);
  });

  console.log('\n🔐 Seguridad: RLS habilitado (lecturas públicas, escritura autenticada)');
  console.log('📈 Índices: tipo, estado, created_at, conductor_id');
  console.log('\n📦 Próximos pasos:');
  console.log('  1. Crear bucket "mensaje-media" en Storage (Supabase UI)');
  console.log('  2. Iniciar el servidor: npm start');
  console.log('  3. Probar en el frontend: http://localhost:5173/mensajes\n');
}

// Ejecutar migración
executeMigration()
  .then(() => process.exit(0))
  .catch(err => {
    console.error('Fatal error:', err);
    process.exit(1);
  });
