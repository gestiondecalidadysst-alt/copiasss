const express = require('express');
const router = express.Router();
const reportesController = require('../controllers/reportesController');
const { authMiddleware } = require('../middlewares/authMiddleware');

// Todas las rutas requieren autenticación
router.use(authMiddleware);

router.get('/', reportesController.getReportes);
router.get('/:id', reportesController.getReporte);
router.post('/', reportesController.createReporte);
router.put('/:id', reportesController.updateReporte);
router.delete('/:id', reportesController.deleteReporte);

module.exports = router;
