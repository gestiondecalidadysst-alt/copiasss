const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../middlewares/authMiddleware');
const ConfiguracionController = require('../controllers/configuracionController');

router.get('/certificado',  authMiddleware, ConfiguracionController.getCertificadoConfig);
router.put('/certificado',  authMiddleware, ConfiguracionController.upsertCertificadoConfig);

// Branding es consumido por el frontend y puede ser público para mostrar la marca.
router.get('/branding', ConfiguracionController.getBranding);
router.put('/branding',  authMiddleware, ConfiguracionController.upsertBranding);

module.exports = router;
