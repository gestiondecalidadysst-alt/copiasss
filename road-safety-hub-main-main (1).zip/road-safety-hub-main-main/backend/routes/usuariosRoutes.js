const express = require('express');
const UsuariosController = require('../controllers/usuariosController.js');
const { authMiddleware, adminMiddleware } = require('../middlewares/authMiddleware.js');

const router = express.Router();

// Aplicar middleware de autenticación a todas las rutas
router.use(authMiddleware);

/**
 * @route   GET /api/usuarios
 * @desc    Obtener todos los usuarios
 * @access  Private/Admin
 */
router.get('/', adminMiddleware, UsuariosController.getAll);

/**
 * @route   GET /api/usuarios/:id
 * @desc    Obtener usuario por ID
 * @access  Private/Admin
 */
router.get('/:id', adminMiddleware, UsuariosController.getById);

/**
 * @route   POST /api/usuarios
 * @desc    Crear nuevo usuario
 * @access  Private/Admin
 */
router.post('/', adminMiddleware, UsuariosController.crear);

/**
 * @route   PUT /api/usuarios/:id
 * @desc    Actualizar usuario
 * @access  Private/Admin
 */
router.put('/:id', adminMiddleware, UsuariosController.actualizar);

/**
 * @route   DELETE /api/usuarios/:id
 * @desc    Eliminar usuario
 * @access  Private/Admin
 */
router.delete('/:id', adminMiddleware, UsuariosController.eliminar);

/**
 * @route   POST /api/usuarios/:id/roles
 * @desc    Asignar rol a usuario
 * @access  Private/Admin
 */
router.post('/:id/roles', adminMiddleware, UsuariosController.asignarRol);

/**
 * @route   DELETE /api/usuarios/:id/roles
 * @desc    Remover rol de usuario
 * @access  Private/Admin
 */
router.delete('/:id/roles', adminMiddleware, UsuariosController.removerRol);

/**
 * @route   PATCH /api/usuarios/:id/toggle-activo
 * @desc    Activar/Desactivar usuario
 * @access  Private/Admin
 */
router.patch('/:id/toggle-activo', adminMiddleware, UsuariosController.toggleActivo);

module.exports = router;
