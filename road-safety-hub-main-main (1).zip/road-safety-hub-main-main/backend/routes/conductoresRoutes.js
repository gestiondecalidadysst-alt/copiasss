const express = require('express');
const router = express.Router();
const conductoresController = require('../controllers/conductoresController');
const { authMiddleware } = require('../middlewares/authMiddleware');

// Todas las rutas requieren autenticación
router.use(authMiddleware);

router.get('/', conductoresController.getConductores);
router.get('/:id', conductoresController.getConductor);
router.post('/', conductoresController.createConductor);
router.put('/:id', conductoresController.updateConductor);
router.delete('/:id', conductoresController.deleteConductor);

module.exports = router;
