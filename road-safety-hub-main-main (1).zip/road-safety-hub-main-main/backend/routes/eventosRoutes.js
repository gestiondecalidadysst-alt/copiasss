const express = require('express');
const router = express.Router();
const eventosController = require('../controllers/eventosController');
const { authMiddleware } = require('../middlewares/authMiddleware');

// Todas las rutas requieren autenticación
router.use(authMiddleware);

router.get('/', eventosController.getEventos);
router.get('/:id', eventosController.getEvento);
router.post('/', eventosController.createEvento);
router.put('/:id', eventosController.updateEvento);
router.delete('/:id', eventosController.deleteEvento);

module.exports = router;
