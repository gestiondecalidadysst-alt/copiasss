const express = require('express');
const rateLimit = require('express-rate-limit');
const AuthController = require('../controllers/authController.js');
const { authMiddleware } = require('../middlewares/authMiddleware.js');

const router = express.Router();

// Protección contra fuerza bruta: máx 10 intentos cada 15 minutos
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Demasiados intentos de inicio de sesión. Intenta de nuevo en 15 minutos.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// Protección en registro: máx 5 registros cada hora
const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  message: { error: 'Demasiadas solicitudes de registro. Intenta de nuevo más tarde.' },
  standardHeaders: true,
  legacyHeaders: false,
});

/**
 * @route   POST /api/auth/login
 * @desc    Login del usuario
 * @access  Public
 */
router.post('/login', loginLimiter, AuthController.login);

/**
 * @route   POST /api/auth/logout
 * @desc    Logout del usuario
 * @access  Private
 */
router.post('/logout', authMiddleware, AuthController.logout);

/**
 * @route   GET /api/auth/me
 * @desc    Obtener perfil del usuario autenticado
 * @access  Private
 */
router.get('/me', authMiddleware, AuthController.me);

/**
 * @route   POST /api/auth/registrar
 * @desc    Registro de nuevo usuario (auto-registro)
 * @access  Public
 */
router.post('/registrar', registerLimiter, AuthController.registrar);

/**
 * @route   POST /api/auth/cambiar-password
 * @desc    Cambiar contraseña del usuario autenticado
 * @access  Private
 */
router.post('/cambiar-password', authMiddleware, AuthController.cambiarPassword);

/**
 * @route   PUT /api/auth/perfil
 * @desc    Actualizar perfil del usuario autenticado
 * @access  Private
 */
router.put('/perfil', authMiddleware, AuthController.actualizarPerfil);

/**
 * @route   GET /api/auth/verificar-token
 * @desc    Verificar si el token es válido
 * @access  Private
 */
router.get('/verificar-token', authMiddleware, AuthController.verificarToken);

module.exports = router;
