const express = require('express');
const router = express.Router();
const CapacitacionesController = require('../controllers/capacitacionesController');
const { authMiddleware, roleMiddleware } = require('../middlewares/authMiddleware');

router.use(authMiddleware);

// Asignaciones (antes de /:id para evitar conflictos de ruta)
router.get('/asignaciones', CapacitacionesController.getAsignaciones);
router.post('/asignaciones', roleMiddleware(['admin', 'usuario']), CapacitacionesController.asignarConductores);
router.delete('/asignaciones/:id', roleMiddleware(['admin', 'usuario']), CapacitacionesController.desasignarConductor);
router.put('/asignaciones/:id/estado', CapacitacionesController.updateEstadoAsignacion);

// Exportación de resultados (descargas individuales y masivas)
router.get('/:capId/asignaciones/:asignacionId/resultado', CapacitacionesController.downloadResultadoIndividual);
router.get('/:capId/resultados', CapacitacionesController.downloadResultadosMasivo);

// Capacitaciones CRUD
router.get('/', CapacitacionesController.getCapacitaciones);
router.get('/:id', CapacitacionesController.getCapacitacion);
router.post('/', roleMiddleware(['admin', 'usuario']), CapacitacionesController.createCapacitacion);
router.put('/:id', roleMiddleware(['admin', 'usuario']), CapacitacionesController.updateCapacitacion);
router.delete('/:id', roleMiddleware(['admin', 'usuario']), CapacitacionesController.deleteCapacitacion);

// Quiz por capacitación (SIN MÓDULOS)
router.get('/:id/quiz', CapacitacionesController.getQuiz);
router.post('/:id/quiz', roleMiddleware(['admin', 'usuario']), CapacitacionesController.saveQuiz);

// Módulos por capacitación (NUEVA ARQUITECTURA)
router.get('/:id/modulos', roleMiddleware(['admin', 'usuario']), CapacitacionesController.getModulos);
router.post('/:id/modulos', roleMiddleware(['admin', 'usuario']), CapacitacionesController.saveModulos);

// Progreso de conductores en una capacitación (admin)
router.get('/:id/progreso', roleMiddleware(['admin', 'usuario']), CapacitacionesController.getProgreso);

module.exports = router;
