const express = require('express');
const router = express.Router();
const vehiculosController = require('../controllers/vehiculosController');
const { authMiddleware } = require('../middlewares/authMiddleware');

// Todas las rutas requieren autenticación
router.use(authMiddleware);

router.get('/', vehiculosController.getVehiculos);
router.get('/:id', vehiculosController.getVehiculo);
router.post('/', vehiculosController.createVehiculo);
router.put('/:id', vehiculosController.updateVehiculo);
router.delete('/:id', vehiculosController.deleteVehiculo);

module.exports = router;
