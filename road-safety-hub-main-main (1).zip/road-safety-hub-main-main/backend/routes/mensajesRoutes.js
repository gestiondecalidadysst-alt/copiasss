const express = require('express');
const router = express.Router();
const mensajesController = require('../controllers/mensajesController');
const mensajesEnvioController = require('../controllers/mensajesEnvioController');
const mensajesProgramadoController = require('../controllers/mensajesProgramadoController');
const { authMiddleware } = require('../middlewares/authMiddleware');
const multer = require('multer');

// Todas las rutas requieren autenticación
router.use(authMiddleware);

// Configure multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB max
  fileFilter: (req, file, cb) => {
    // Accept image, video, and audio files
    const allowedMimes = [
      'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp',
      'video/mp4', 'video/mpeg', 'video/quicktime', 'video/webm',
      'audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/webm',
      'audio/mp4', 'audio/aac', 'audio/x-m4a', 'audio/flac',
      'audio/x-wav', 'audio/mp3',
      'application/pdf'
    ];
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Tipo de archivo no permitido: ${file.mimetype}`));
    }
  }
});

// Media endpoints — definidos ANTES de rutas con parámetros para evitar conflictos
router.post('/media/upload', (req, res, next) => {
  upload.single('file')(req, res, (err) => {
    if (err) {
      return res.status(400).json({ message: err.message || 'Error al procesar el archivo' });
    }
    next();
  });
}, mensajesController.uploadMedia);
router.post('/media/delete', mensajesController.deleteMedia);

router.get('/', mensajesController.getMensajes);
router.get('/tipo/:tipo', mensajesController.getMensajesByTipo);
router.get('/estado/:estado', mensajesController.getMensajesByEstado);
router.get('/:id', mensajesController.getMensaje);
router.post('/', mensajesController.createMensaje);
router.put('/:id', mensajesController.updateMensaje);
router.delete('/:id', mensajesController.deleteMensaje);

// Registro de envíos por día (tabla mensajes_envios)
router.get('/:id/envios', mensajesEnvioController.getEnviosByMensaje);
router.post('/:id/envios', mensajesEnvioController.registrarEnvio);
router.delete('/:id/envios', mensajesEnvioController.eliminarEnvio);

// Programados por día con estado (tabla mensajes_programados)
router.get('/:id/programados', mensajesProgramadoController.getProgramados);
router.patch('/:id/programados', mensajesProgramadoController.updateEstado);

module.exports = router;
