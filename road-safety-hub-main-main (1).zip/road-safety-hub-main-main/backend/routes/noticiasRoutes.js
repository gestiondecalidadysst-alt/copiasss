const express = require('express');
const router = express.Router();
const NoticiasController = require('../controllers/noticiasController');
const { authMiddleware } = require('../middlewares/authMiddleware');
const multer = require('multer');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) cb(null, true);
    else cb(new Error('Solo se permiten imágenes'));
  },
});

// Todas las rutas requieren autenticación
router.use(authMiddleware);

// Rutas estáticas (ANTES de /:id para evitar conflictos)
router.get('/mis-interacciones', NoticiasController.getMisInteracciones);
router.post('/upload-imagen', upload.single('imagen'), NoticiasController.uploadImagen);
router.get('/descargar/todas-estadisticas', NoticiasController.descargarTodasEstadisticas);

// CRUD noticias
router.get('/', NoticiasController.getNoticias);
router.post('/', NoticiasController.createNoticia);
router.put('/:id', NoticiasController.updateNoticia);
router.delete('/:id', NoticiasController.deleteNoticia);

// Interacciones por noticia
router.post('/:id/reaccionar', NoticiasController.reaccionar);
router.get('/:id/comentarios', NoticiasController.getComentarios);
router.post('/:id/comentarios', NoticiasController.comentar);
router.delete('/:id/comentarios/:cid', NoticiasController.eliminarComentario);
router.post('/:id/visto', NoticiasController.marcarComoVisto);
router.get('/:id/estadisticas', NoticiasController.getEstadisticas);
router.get('/:id/descargar-estadisticas', NoticiasController.descargarEstadisticasNoticia);
router.post('/:id/certificar', NoticiasController.certificar);

module.exports = router;
