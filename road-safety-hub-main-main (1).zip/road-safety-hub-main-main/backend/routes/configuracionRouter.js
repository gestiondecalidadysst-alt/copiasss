const express = require('express');
const multer = require('multer');
const router = express.Router();
const authMiddleware = require('../middlewares/authMiddleware');
const ConfiguracionController = require('../controllers/configuracionController');

// Middleware para subidas de archivos
const upload = multer({ storage: multer.memoryStorage() });

// Todos los endpoints requieren autenticación
router.use(authMiddleware);

// Configuración de certificado
router.get('/certificado', ConfiguracionController.getCertificadoConfig);
router.put('/certificado', ConfiguracionController.upsertCertificadoConfig);

// Branding
router.get('/branding', ConfiguracionController.getBranding);
router.put('/branding', ConfiguracionController.upsertBranding);

// Plantillas de capacitación
router.get('/plantillas', ConfiguracionController.getPlantillas);
router.post('/plantillas/importar', upload.single('file'), ConfiguracionController.importPlantilla);
router.put('/plantillas/:templateName', ConfiguracionController.updatePlantilla);
router.delete('/plantillas/:id', ConfiguracionController.deletePlantilla);

module.exports = router;
