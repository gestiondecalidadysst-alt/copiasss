const express = require('express');
const router = express.Router();
const PortalConductorController = require('../controllers/portalConductorController');
const { authMiddleware, roleMiddleware } = require('../middlewares/authMiddleware');

// Solo conductores pueden acceder al portal
router.use(authMiddleware);
router.use(roleMiddleware('conductor'));

router.get('/resumen', PortalConductorController.getResumen);
router.get('/perfil', PortalConductorController.getPerfil);
router.get('/eventos', PortalConductorController.getEventos);
router.get('/mensajes', PortalConductorController.getMensajes);
router.get('/capacitaciones', PortalConductorController.getCapacitaciones);
router.put('/capacitaciones/:id/estado', PortalConductorController.actualizarEstadoCapacitacion);

// Flujo de capacitación: video, quiz, completado (SIN MÓDULOS)
router.put('/capacitaciones/:id/progreso-video', PortalConductorController.actualizarProgresoVideo);
router.get('/capacitaciones/:id/quiz', PortalConductorController.getQuizConductor);
router.post('/capacitaciones/:id/quiz/responder', PortalConductorController.responderQuiz);

// Flujo de capacitación CON MÓDULOS (NUEVA ARQUITECTURA)
router.get('/capacitaciones/:id/modulos', PortalConductorController.getModulosCapacitacion);
router.put('/capacitaciones/:id/modulos/video-progreso', PortalConductorController.actualizarProgresoVideoModulo);
router.post('/capacitaciones/:id/modulos/quiz/responder', PortalConductorController.responderQuizModulo);
router.post('/capacitaciones/:id/modulos/completar', PortalConductorController.completarCapacitacionModulos);

module.exports = router;
