#!/usr/bin/env node
/**
 * Script de inicio del servidor con garbage collection habilitado
 * Ejecutar: node --expose-gc start.js
 */

require('./server');
