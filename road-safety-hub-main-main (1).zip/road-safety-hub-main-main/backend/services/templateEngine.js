const ExcelJS = require('exceljs');
const XLSX = require('xlsx');

/**
 * Motor de plantillas que parsea archivos XLSX/CSV y extrae estructura
 */
class TemplateEngine {
  /**
   * Parsea un archivo XLSX y extrae la configuración de plantilla
   * @param {Buffer} fileBuffer - Contenido del archivo cargado
   * @returns {Object} Configuración extraída de la plantilla
   */
  static async parseXLSXTemplate(fileBuffer) {
    try {
      const workbook = new ExcelJS.Workbook();
      await workbook.xlsx.load(fileBuffer);
      
      const worksheet = workbook.getWorksheet(1);
      if (!worksheet) throw new Error('No se encontró hoja en el archivo');

      const config = {
        columns_config: [],
        header_text: '',
        footer_text: '',
        title_color: '#1A1A2E',
        header_bg_color: '#0D6EFD',
        border_color: '#DEE2E6',
        font_family: 'helvetica'
      };

      // Extraer encabezados (primera fila con datos)
      const firstRow = worksheet.getRow(1);
      if (firstRow) {
        const columns = [];
        let colIndex = 1;

        firstRow.eachCell((cell, cellNumber) => {
          const cellValue = cell.value?.toString().trim();
          if (cellValue) {
            columns.push({
              columnIndex: cellNumber,
              header: cellValue,
              fieldName: this._normalizeFieldName(cellValue),
              width: cell.width || 20
            });
          }
          colIndex++;
        });

        config.columns_config = columns;
      }

      // Buscar texto de encabezado/pie en celdas de meta
      // Generalmente primeras 3 filas antes de encabezados
      for (let i = 1; i <= Math.min(5, worksheet.actualRowCount); i++) {
        const row = worksheet.getRow(i);
        if (row) {
          row.eachCell((cell, colIndex) => {
            const value = cell.value?.toString().trim();
            if (value && value.length > 20) {
              if (i === 1 && colIndex === 1) config.header_text = value;
              if (i === 2 && colIndex === 1) config.footer_text = value;
            }
          });
        }
      }

      // Extraer logo si existe (imagen incrustada)
      const drawingImages = worksheet.getDrawings();
      if (drawingImages && drawingImages.length > 0) {
        const firstImage = drawingImages[0];
        if (firstImage) {
          const imageBuffer = await this._extractImageBuffer(workbook, firstImage);
          if (imageBuffer) {
            config.header_logo = imageBuffer;
            config.header_logo_height = 60;
          }
        }
      }

      // Extraer colores si existen en primera fila
      const headerRow = worksheet.getRow(1);
      if (headerRow) {
        const firstCell = headerRow.getCell(1);
        if (firstCell && firstCell.fill && firstCell.fill.fgColor) {
          config.header_bg_color = '#' + (firstCell.fill.fgColor.argb || 'FF0D6EFD').substring(2);
        }
      }

      return config;
    } catch (error) {
      throw new Error(`Error parseando archivo XLSX: ${error.message}`);
    }
  }

  /**
   * Normaliza nombres de campos para mapear a datos del sistema
   */
  static _normalizeFieldName(header) {
    const mapping = {
      'nombre': 'conductor.nombre',
      'name': 'conductor.nombre',
      'cédula': 'conductor.cedula',
      'cedula': 'conductor.cedula',
      'documento': 'conductor.cedula',
      'doc': 'conductor.cedula',
      'estado': 'asignacion.estado',
      'status': 'asignacion.estado',
      'fecha': 'asignacion.fecha_completado',
      'date': 'asignacion.fecha_completado',
      'resultado': 'asignacion.quiz_puntaje',
      'result': 'asignacion.quiz_puntaje',
      'calificación': 'asignacion.quiz_puntaje',
      'calificacion': 'asignacion.quiz_puntaje',
      'score': 'asignacion.quiz_puntaje',
      'firma': 'firma',
      'signature': 'firma',
      'empresa': 'empresa',
      'company': 'empresa'
    };

    const normalized = header.toLowerCase().trim();
    return mapping[normalized] || normalized;
  }

  /**
   * Extrae buffer de imagen del workbook
   */
  static async _extractImageBuffer(workbook, drawing) {
    try {
      if (drawing.image && drawing.image.buffer) {
        return drawing.image.buffer;
      }
      return null;
    } catch (error) {
      console.error('Error extrayendo imagen:', error);
      return null;
    }
  }

  /**
   * Renderiza datos usando una plantilla
   * @param {Array} rowsData - Datos a renderizar
   * @param {Object} template - Configuración de plantilla
   * @returns {Array} Filas formateadas según plantilla
   */
  static renderData(rowsData, template) {
    if (!template || !template.columns_config) {
      return rowsData;
    }

    const columnsConfig = template.columns_config;

    return rowsData.map(row => {
      const formattedRow = {};
      columnsConfig.forEach(col => {
        const fieldName = col.fieldName;
        const value = this._getNestedValue(row, fieldName);
        formattedRow[col.header] = this._formatValue(value, fieldName);
      });
      return formattedRow;
    });
  }

  /**
   * Obtiene valor anidado de objeto
   */
  static _getNestedValue(obj, path) {
    return path.split('.').reduce((current, prop) => current?.[prop], obj);
  }

  /**
   * Formatea valor según tipo de campo
   */
  static _formatValue(value, fieldName) {
    if (value === null || value === undefined) return '';

    // Fechas
    if (fieldName.includes('fecha') || fieldName.includes('date')) {
      if (value instanceof Date) {
        return value.toLocaleDateString('es-ES');
      }
      return new Date(value).toLocaleDateString('es-ES');
    }

    // Porcentajes
    if (fieldName.includes('puntaje') || fieldName.includes('score')) {
      return `${value}%`;
    }

    // Estados (capitalize)
    if (fieldName.includes('estado') || fieldName.includes('status')) {
      return value.charAt(0).toUpperCase() + value.slice(1);
    }

    return String(value);
  }
}

module.exports = TemplateEngine;
