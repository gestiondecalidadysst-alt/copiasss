const TemplateModel = require('../models/templateModel');
const TemplateEngine = require('./templateEngine');

const templatesService = {
  /**
   * Obtener plantilla activa de la empresa
   */
  getTemplate: async (empresa, templateName = 'default') => {
    return await TemplateModel.getByEmpresa(empresa, templateName);
  },

  /**
   * Obtener todas las plantillas de la empresa
   */
  getAll: async (empresa) => {
    return await TemplateModel.getAllByEmpresa(empresa);
  },

  /**
   * Importar y procesar archivo de plantilla
   */
  importTemplate: async (empresa, fileBuffer, templateName = 'default') => {
    try {
      // Parsear el archivo XLSX
      const templateConfig = await TemplateEngine.parseXLSXTemplate(fileBuffer);

      // Guardar en BD
      const saved = await TemplateModel.upsert(
        empresa,
        templateName,
        templateConfig
      );

      return {
        success: true,
        message: 'Plantilla importada correctamente',
        template: saved
      };
    } catch (error) {
      throw new Error(`Error importando plantilla: ${error.message}`);
    }
  },

  /**
   * Actualizar metadatos de plantilla
   */
  updateTemplate: async (empresa, templateName, updates) => {
    return await TemplateModel.upsert(empresa, templateName, updates);
  },

  /**
   * Eliminar plantilla
   */
  deleteTemplate: async (id) => {
    return await TemplateModel.delete(id);
  },

  /**
   * Renderizar datos con plantilla
   */
  renderWithTemplate: async (empresa, rowsData, templateName = 'default') => {
    const template = await this.getTemplate(empresa, templateName);
    if (!template) {
      return rowsData; // Sin plantilla, devolver datos sin procesar
    }
    return TemplateEngine.renderData(rowsData, template);
  }
};

module.exports = templatesService;
