const EventoModel = require('../models/eventoModel');

const getAllEventos = async () => {
  return await EventoModel.getAll();
};

const getEventosByDateRange = async (fechaInicio, fechaFin) => {
  return await EventoModel.getByDateRange(fechaInicio, fechaFin);
};

const getEventoById = async (id) => {
  return await EventoModel.getById(id);
};

const createEvento = async (data) => {
  return await EventoModel.create(data);
};

const updateEvento = async (id, data) => {
  return await EventoModel.update(id, data);
};

const deleteEvento = async (id) => {
  return await EventoModel.delete(id);
};

module.exports = {
  getAllEventos,
  getEventosByDateRange,
  getEventoById,
  createEvento,
  updateEvento,
  deleteEvento
};
