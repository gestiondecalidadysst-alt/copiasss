const ConductorModel = require('../models/conductorModel');

const conductoresService = {
  getAll: async () => await ConductorModel.getAll(),
  getById: async (id) => await ConductorModel.getById(id),
  create: async (data) => await ConductorModel.create(data),
  update: async (id, data) => await ConductorModel.update(id, data),
  delete: async (id) => await ConductorModel.delete(id)
};

module.exports = conductoresService;
