const ReporteModel = require('../models/reporteModel');
const EventoModel = require('../models/eventoModel');

const getAllReportes = async (options = {}) => {
  return await ReporteModel.getAll(options);
};

const getReporteById = async (id) => {
  return await ReporteModel.getById(id);
};

const createReporte = async (data) => {
  // Crear el reporte
  const reporte = await ReporteModel.create(data);
  
  // Crear un evento correspondiente para que aparezca la notificación instantáneamente
  try {
    const eventoData = {
      placa: data.placa !== 'todas' ? data.placa : `REPORTE-${reporte.id}`,
      velocidad: data.velocidad_promedio || 0,
      ruta: data.nombre || 'Reporte generado',
      fecha: new Date().toISOString(),
      latitud: 4.6597,
      longitud: -74.0833
    };
    
    await EventoModel.create(eventoData);
    console.log('✅ Evento creado para reporte:', reporte.id);
  } catch (eventoError) {
    console.warn('⚠️ Error creando evento para reporte (no crítico):', eventoError.message);
    // No lanzar error aquí, el reporte ya fue creado
  }
  
  return reporte;
};

const updateReporte = async (id, data) => {
  return await ReporteModel.update(id, data);
};

const deleteReporte = async (id) => {
  return await ReporteModel.delete(id);
};

module.exports = {
  getAllReportes,
  getReporteById,
  createReporte,
  updateReporte,
  deleteReporte
};
