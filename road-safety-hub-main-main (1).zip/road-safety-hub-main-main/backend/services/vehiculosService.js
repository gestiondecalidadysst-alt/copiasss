const VehiculoModel = require('../models/vehiculoModel');

const vehiculosService = {
  getAll: async () => await VehiculoModel.getAll(),
  getById: async (id) => await VehiculoModel.getById(id),
  create: async (data) => await VehiculoModel.create(data),
  update: async (id, data) => await VehiculoModel.update(id, data),
  delete: async (id) => await VehiculoModel.delete(id)
};

module.exports = vehiculosService;
