const MensajeModel = require('../models/mensajeModel');

const getAllMensajes = async () => {
  return await MensajeModel.getAll();
};

const getMensajeById = async (id) => {
  return await MensajeModel.getById(id);
};

const getMensajesByTipo = async (tipo) => {
  return await MensajeModel.getByTipo(tipo);
};

const getMensajesByEstado = async (estado) => {
  return await MensajeModel.getByEstado(estado);
};

const createMensaje = async (data) => {
  return await MensajeModel.create(data);
};

const updateMensaje = async (id, data) => {
  return await MensajeModel.update(id, data);
};

const deleteMensaje = async (id) => {
  return await MensajeModel.delete(id);
};

const uploadMedia = async (file, tipo) => {
  return await MensajeModel.uploadMedia(file, tipo);
};

const deleteMedia = async (filePath) => {
  return await MensajeModel.deleteMedia(filePath);
};

module.exports = {
  getAllMensajes,
  getMensajeById,
  getMensajesByTipo,
  getMensajesByEstado,
  createMensaje,
  updateMensaje,
  deleteMensaje,
  uploadMedia,
  deleteMedia,
};
