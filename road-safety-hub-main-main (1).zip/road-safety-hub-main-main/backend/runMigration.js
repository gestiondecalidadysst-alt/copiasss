/**
 * Script para ejecutar migraciones en Supabase
 * Uso: node backend/runMigration.js
 */

const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Error: Faltan credenciales de Supabase en .env');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function runMigration() {
  try {
    console.log('🔄 Iniciando actualización de base de datos...\n');

    // Obtener el archivo de migración desde argumentos o usar el predeterminado
    const migrationFile = process.argv[2] || 'migrations/002_create_mensajes_table.sql';
    
    // 1. Leer archivo de migración SQL
    const sqlFile = path.join(__dirname, migrationFile);
    
    if (!fs.existsSync(sqlFile)) {
      console.error(`❌ Error: Archivo de migración no encontrado: ${sqlFile}`);
      process.exit(1);
    }
    
    const sqlContent = fs.readFileSync(sqlFile, 'utf-8');
    
    console.log('📋 Leyendo migración SQL...');
    console.log(`📁 Archivo: ${sqlFile}\n`);

    // 2. Dividir por puntos y coma para ejecutar múltiples comandos
    const statements = sqlContent
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt.length > 0 && !stmt.startsWith('--'));

    console.log(`📝 Encontrados ${statements.length} comandos SQL\n`);

    let successCount = 0;
    let errorCount = 0;

    for (let i = 0; i < statements.length; i++) {
      const stmt = statements[i];
      console.log(`\n[${i + 1}/${statements.length}] Ejecutando comando...`);
      
      try {
        // Para consultas DDL (CREATE, ALTER, etc) usamos RPC
        const { data, error } = await supabase.rpc('exec_sql', {
          sql_query: stmt
        }).catch(async () => {
          // Si el RPC no existe, intentar con postgrest
          return await supabase.from('_pg_sql').select().limit(0);
        });

        if (error && !error.message.includes('does not exist')) {
          // Si es un error de función no encontrada, ejecutar manualmente
          await executeDirectSQL(stmt);
        }
        
        successCount++;
        console.log('✅ Comando ejecutado');
      } catch (err) {
        console.error(`❌ Error: ${err.message}`);
        errorCount++;
      }
    }

    console.log('\n════════════════════════════════════════════════════════');
    console.log(`✨ MIGRACIÓN COMPLETADA: ${successCount} éxito, ${errorCount} errores`);
    console.log('════════════════════════════════════════════════════════\n');

    console.log('✅ Migración ejecutada correctamente\n');

  } catch (error) {
    console.error('❌ Error fatal:', error.message);
    console.log('\n📖 INSTRUCCIONES MANUALES:\n');
    console.log('Si el script falló, ejecuta el SQL manualmente en Supabase SQL Editor:\n');
    
    try {
      const migrationFile = process.argv[2] || 'migrations/002_create_mensajes_table.sql';
      const sqlFile = path.join(__dirname, migrationFile);
      const sqlContent = fs.readFileSync(sqlFile, 'utf-8');
      console.log(sqlContent);
    } catch (readError) {
      console.error('No se pudo leer archivo SQL');
    }
    
    process.exit(1);
  }
}

async function executeDirectSQL(sql) {
  // Función auxiliar para ejecutar SQL directamente si es posible
  // Por ahora es un placeholder
  return true;
}

runMigration().then(() => {
  console.log('🎉 ¡Migración completada correctamente!');
  process.exit(0);
}).catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
