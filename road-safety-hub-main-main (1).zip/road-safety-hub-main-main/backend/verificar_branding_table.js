#!/usr/bin/env node

const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  'https://tcmoypkoyozgxhsioqwz.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRjbW95cGtveW96Z3hoc2lvcXd6Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3NTg4NzU4OCwiZXhwIjoyMDkxNDYzNTg4fQ.slzc-XFrgSYK6y0E-tagMfEviVBN675Mhu7WH5VvDZY'
);

(async () => {
  console.log('\n🔍 Verificando tabla branding_config...\n');
  
  try {
    const { data, error } = await supabase.from('branding_config').select('*').limit(1);
    
    if (error) {
      console.log('❌ Tabla branding_config NO EXISTE');
      console.log('Error:', error.message);
      console.log('\n⚠️ Necesitas crear la tabla. Ejecuta este SQL en Supabase:\n');
      console.log(`
CREATE TABLE branding_config (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa VARCHAR(255) NOT NULL UNIQUE,
  company_name VARCHAR(255),
  company_logo LONGTEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
      `);
    } else {
      console.log('✅ Tabla branding_config EXISTE');
      console.log('📊 Registros encontrados:', data.length);
      if (data.length > 0) {
        console.log('\n📋 Configuraciones guardadas:');
        data.forEach((item, i) => {
          console.log(`\n  ${i + 1}. Empresa: ${item.empresa}`);
          console.log(`     - Nombre: ${item.company_name || 'Sin configurar'}`);
          console.log(`     - Logo: ${item.company_logo ? 'Sí' : 'No'}`);
        });
      }
    }
  } catch (err) {
    console.error('❌ Error de conexión:', err.message);
  }
  
  console.log('\n');
})();
