const supabase = require('./config/supabaseClient');

async function checkSupabaseDirect() {
  try {
    console.log('Conectando directamente a Supabase...\n');
    
    // Obtener directamente de Supabase
    const { data, error } = await supabase
      .from('EXCESOS DE VELOCIDAD')
      .select('id, created_at, velocidad, placa, fecha')
      .order('created_at', { ascending: false })
      .limit(20);
    
    if (error) {
      console.error('Error en Supabase:', error);
      return;
    }
    
    console.log(`Total registros (últimos 20):`);
    data.forEach((row, idx) => {
      const dateStr = new Date(row.created_at).toLocaleDateString('en-CA');
      console.log(`[${idx}] ${dateStr} | created_at: ${row.created_at} | velocidad: ${row.velocidad} | placa: ${row.placa}`);
    });
    
    // Contar por fechas
    const dateMap = {};
    data.forEach(row => {
      const d = new Date(row.created_at).toLocaleDateString('en-CA');
      dateMap[d] = (dateMap[d] || 0) + 1;
    });
    
    console.log(`\n=== Conteo por fecha (últimos 20) ===`);
    Object.entries(dateMap)
      .sort((a, b) => b[0].localeCompare(a[0]))
      .forEach(([date, count]) => {
        console.log(`${date}: ${count}`);
      });
    
    // Buscar específicamente datos de hoy
    const today = new Date().toLocaleDateString('en-CA');
    console.log(`\nBuscando específicamente para hoy: ${today}`);
    
    const { data: todayData, error: todayError } = await supabase
      .from('EXCESOS DE VELOCIDAD')
      .select('*')
      .gte('created_at', `${today}T00:00:00`)
      .lte('created_at', `${today}T23:59:59`);
    
    if (todayError) {
      console.error('Error buscando datos de hoy:', todayError);
    } else {
      console.log(`Eventos encontrados para hoy: ${todayData.length}`);
      if (todayData.length > 0) {
        console.log('Primero:', JSON.stringify(todayData[0], null, 2));
      }
    }
    
  } catch (err) {
    console.error('Error:', err);
  }
}

checkSupabaseDirect();
