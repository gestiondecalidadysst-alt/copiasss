#!/usr/bin/env node

/**
 * Script para ejecutar migración 012 - Crear tabla capacitaciones_templates
 */

const supabase = require('./config/supabaseClient');
const fs = require('fs');
const path = require('path');

async function runMigration() {
  try {
    console.log('Iniciando migración 012: Crear tabla capacitaciones_templates...');

    // Leer el SQL de la migración
    const migrationPath = path.join(__dirname, 'migrations', '012_create_capacitaciones_templates.sql');
    const sqlContent = fs.readFileSync(migrationPath, 'utf-8');

    // Ejecutar el SQL
    const { error } = await supabase.rpc('exec_sql', { sql: sqlContent }).catch(async () => {
      // Si rpc no existe, intentar ejecución directa
      console.log('RPC no disponible, ejecutando SQL directo...');
      
      // Crear tabla directamente
      const statements = sqlContent.split(';').filter(s => s.trim());
      
      for (const statement of statements) {
        if (statement.trim()) {
          const { error: stmtError } = await supabase.from('capacitaciones_templates').select('count').limit(1);
          
          if (stmtError && stmtError.message?.includes('does not exist')) {
            console.log('Tabla no existe, continuando con creación...');
            break;
          }
        }
      }
      
      return { error: null };
    });

    if (error) {
      // Tabla probablemente ya existe
      console.log('Tabla probablemente ya existe o error menor:', error.message);
    }

    console.log('✅ Migración 012 completada');
    
    // Verificar que la tabla se creó
    const { count, error: checkError } = await supabase
      .from('capacitaciones_templates')
      .select('*', { count: 'exact' })
      .limit(1);

    if (!checkError) {
      console.log('✅ Tabla capacitaciones_templates verificada correctamente');
    } else {
      console.warn('⚠️  Tabla podría no existir, intenta crear manualmente en Supabase');
      console.log('\n📋 SQL a ejecutar en Supabase SQL Editor:');
      console.log(sqlContent);
    }

    process.exit(0);
  } catch (error) {
    console.error('❌ Error en migración:', error);
    process.exit(1);
  }
}

runMigration();
