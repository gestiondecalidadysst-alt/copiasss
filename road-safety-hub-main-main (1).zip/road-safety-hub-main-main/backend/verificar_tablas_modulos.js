#!/usr/bin/env node

/**
 * Script para verificar qué tablas existen en Supabase
 * Compara con las tablas necesarias para módulos
 */

const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://tcmoypkoyozgxhsioqwz.supabase.co';
const supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRjbW95cGtveW96Z3hoc2lvcXd6Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3NTg4NzU4OCwiZXhwIjoyMDkxNDYzNTg4fQ.slzc-XFrgSYK6y0E-tagMfEviVBN675Mhu7WH5VvDZY';

const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Tablas necesarias para módulos
const TABLAS_NECESARIAS = [
  'modulos',
  'videos_modulo',
  'quizzes_modulo',
  'preguntas_modulo',
  'opciones_modulo',
  'progreso_modulos',
  'progreso_videos',
  'respuestas_modulo',
  'intentos_quiz_modulo'
];

// Tablas existentes del sistema
const TABLAS_EXISTENTES = [
  'capacitaciones',
  'asignaciones_capacitacion',
  'preguntas_capacitacion',
  'opciones_pregunta',
  'respuestas_conductor',
  'conductores',
  'usuarios',
  'vehiculos',
  'eventos',
  'mensajes',
  'noticias',
  'reportes'
];

async function verificarTablas() {
  console.log('\n🔍 Verificando tablas en Supabase...\n');

  try {
    // Intentar obtener tablas usando RPC o consulta directa
    let tablasExistentes = [];

    // Primero, intentamos obtener las tablas directamente
    try {
      // Obtener una tabla conocida para verificar conexión
      const { data: testData, error: testError } = await supabase
        .from('capacitaciones')
        .select('*')
        .limit(1);

      if (testError && testError.code !== 'PGRST116') { // PGRST116 es "not found"
        throw testError;
      }

      console.log('✅ Conexión a Supabase establecida\n');

      // Intentar consultar cada tabla
      for (const tabla of [...TABLAS_NECESARIAS, ...TABLAS_EXISTENTES]) {
        try {
          const { error } = await supabase
            .from(tabla)
            .select('*')
            .limit(1);

          // Si no hay error, la tabla existe
          if (!error || error.code === 'PGRST116') {
            tablasExistentes.push(tabla);
          }
        } catch (e) {
          // La tabla no existe
        }
      }
    } catch (err) {
      console.error('❌ Error de conexión:', err.message);
      return;
    }

    console.log('═'.repeat(60));
    console.log('TABLAS EXISTENTES EN SUPABASE');
    console.log('═'.repeat(60));
    console.log('\n📊 Total de tablas:', tablasExistentes.length, '\n');

    // Verificar tablas de módulos
    console.log('🎓 TABLAS DE MÓDULOS (REQUERIDAS):');
    console.log('─'.repeat(60));
    let modulosOK = 0;
    TABLAS_NECESARIAS.forEach(tabla => {
      if (tablasExistentes.includes(tabla)) {
        console.log(`  ✅ ${tabla}`);
        modulosOK++;
      } else {
        console.log(`  ❌ ${tabla} - FALTA`);
      }
    });
    console.log(`\nResumen: ${modulosOK}/${TABLAS_NECESARIAS.length} presentes\n`);

    // Verificar tablas existentes del sistema
    console.log('📁 TABLAS DEL SISTEMA (VERIFICACIÓN):');
    console.log('─'.repeat(60));
    let sistemasOK = 0;
    TABLAS_EXISTENTES.forEach(tabla => {
      if (tablasExistentes.includes(tabla)) {
        console.log(`  ✅ ${tabla}`);
        sistemasOK++;
      } else {
        console.log(`  ⚠️  ${tabla} - FALTA`);
      }
    });
    console.log(`\nResumen: ${sistemasOK}/${TABLAS_EXISTENTES.length} presentes\n`);

    // Mostrar todas las tablas
    console.log('📋 TODAS LAS TABLAS:');
    console.log('─'.repeat(60));
    tablasExistentes.sort().forEach(tabla => {
      console.log(`  • ${tabla}`);
    });

    // Resumen final
    console.log('\n' + '═'.repeat(60));
    console.log('📊 RESUMEN FINAL');
    console.log('═'.repeat(60));

    const faltanModulos = TABLAS_NECESARIAS.filter(t => !tablasExistentes.includes(t));

    if (faltanModulos.length === 0) {
      console.log('✅ ¡Todas las tablas de módulos están presentes!\n');
    } else {
      console.log(`❌ Faltan ${faltanModulos.length} tablas:\n`);
      faltanModulos.forEach(tabla => {
        console.log(`   • ${tabla}`);
      });
      console.log('\n⚠️  Necesitas ejecutar la migración SQL en Supabase');
      console.log('📄 Archivo: backend/migrations/MODULOS_SCHEMA.sql\n');
    }

    console.log('═'.repeat(60) + '\n');

  } catch (err) {
    console.error('❌ Error:', err.message);
  }
}

verificarTablas();
