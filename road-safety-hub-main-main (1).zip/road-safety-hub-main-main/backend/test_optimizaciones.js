const axios = require('axios');

/**
 * Script de prueba para validar optimizaciones de rendimiento
 */

const BASE_URL = 'http://localhost:5000';

async function testOptimizaciones() {
  console.log('🧪 Probando Optimizaciones de Rendimiento\n');
  console.log('═══════════════════════════════════════════════════════════\n');

  try {
    // 1. Test de Health Endpoint
    console.log('1️⃣ Test: Health Check');
    const healthResponse = await axios.get(`${BASE_URL}/api/health`);
    console.log('✅ Status:', healthResponse.data.status);
    console.log('📊 Memoria:', healthResponse.data.memory);
    console.log('⏱️  Uptime:', `${Math.floor(healthResponse.data.uptime)}s`);
    console.log('');

    // 2. Test de Paginación
    console.log('2️⃣ Test: Paginación de Reportes');
    const page1Response = await axios.get(`${BASE_URL}/api/reportes?page=1&limit=10`);
    console.log('✅ Página 1 obtenida');
    
    if (page1Response.data.pagination) {
      console.log('📄 Paginación:', {
        total: page1Response.data.pagination.total,
        página: page1Response.data.pagination.page,
        límite: page1Response.data.pagination.limit,
        totalPáginas: page1Response.data.pagination.totalPages
      });
    }
    
    // Headers de paginación
    console.log('📋 Headers recibidos:');
    console.log('   X-Total-Count:', page1Response.headers['x-total-count']);
    console.log('   X-Page:', page1Response.headers['x-page']);
    console.log('   X-Cache:', page1Response.headers['x-cache'] || 'N/A');
    console.log('');

    // 3. Test de Compresión
    console.log('3️⃣ Test: Compresión Gzip');
    const uncompressed = await axios.get(`${BASE_URL}/api/eventos`, {
      headers: { 'x-no-compression': '1' }
    });
    const compressed = await axios.get(`${BASE_URL}/api/eventos`);
    
    const uncompressedSize = JSON.stringify(uncompressed.data).length;
    const compressedSize = JSON.stringify(compressed.data).length;
    const savings = ((1 - compressedSize / uncompressedSize) * 100).toFixed(2);
    
    console.log(`📦 Tamaño sin comprimir: ${(uncompressedSize / 1024).toFixed(2)} KB`);
    console.log(`🗜️  Tamaño comprimido: ${(compressedSize / 1024).toFixed(2)} KB`);
    console.log(`💾 Ahorro: ${savings}%`);
    console.log('');

    // 4. Test de Caché
    console.log('4️⃣ Test: Sistema de Caché');
    
    const firstRequest = await axios.get(`${BASE_URL}/api/reportes?page=1&limit=5`);
    const cacheStatus1 = firstRequest.headers['x-cache'];
    console.log(`1ra Request - X-Cache: ${cacheStatus1} (esperado: MISS)`);
    
    // Segunda request debe venir del caché
    const secondRequest = await axios.get(`${BASE_URL}/api/reportes?page=1&limit=5`);
    const cacheStatus2 = secondRequest.headers['x-cache'];
    console.log(`2da Request - X-Cache: ${cacheStatus2} (esperado: HIT)`);
    
    if (cacheStatus2 === 'HIT') {
      console.log('✅ Caché funcionando correctamente');
    } else {
      console.log('⚠️  Caché no detectado (puede ser normal si el caché expiró)');
    }
    console.log('');

    // 5. Test de Estadísticas
    console.log('5️⃣ Test: Endpoint de Estadísticas');
    const statsResponse = await axios.get(`${BASE_URL}/api/export/eventos/stats`);
    console.log('✅ Estadísticas obtenidas');
    console.log('📊 Total eventos:', statsResponse.data.total);
    console.log('🏎️  Velocidad promedio:', statsResponse.data.velocidad_promedio, 'km/h');
    console.log('📈 Distribución:');
    console.log('   Baja (≤80):', statsResponse.data.distribucion_velocidades.baja);
    console.log('   Media (80-100):', statsResponse.data.distribucion_velocidades.media);
    console.log('   Alta (>100):', statsResponse.data.distribucion_velocidades.alta);
    console.log('');

    // 6. Test de Límites
    console.log('6️⃣ Test: Validación de Límites');
    try {
      await axios.get(`${BASE_URL}/api/reportes?page=1&limit=1000`);
      console.log('⚠️  Límite de 500 no aplicado (puede necesitar reinicio)');
    } catch (error) {
      if (error.response && error.response.status === 400) {
        console.log('✅ Límite de 500 registros validado correctamente');
        console.log('📄 Mensaje:', error.response.data.message);
      }
    }
    console.log('');

    // 7. Test de Headers de Rendimiento
    console.log('7️⃣ Test: Headers de Rendimiento');
    const perfResponse = await axios.get(`${BASE_URL}/api/eventos`);
    console.log('📋 Headers de rendimiento:');
    console.log('   X-Response-Time:', perfResponse.headers['x-response-time'] || 'N/A');
    console.log('   X-Memory-Usage:', perfResponse.headers['x-memory-usage'] || 'N/A');
    console.log('   X-Response-Size:', perfResponse.headers['x-response-size'] || 'N/A');
    console.log('');

    // Resumen
    console.log('═══════════════════════════════════════════════════════════');
    console.log('✅ TODAS LAS PRUEBAS COMPLETADAS');
    console.log('═══════════════════════════════════════════════════════════');
    console.log('');
    console.log('🎉 Optimizaciones funcionando correctamente:');
    console.log('   ✓ Health check activo');
    console.log('   ✓ Paginación implementada');
    console.log('   ✓ Compresión funcionando');
    console.log('   ✓ Caché operativo');
    console.log('   ✓ Estadísticas disponibles');
    console.log('   ✓ Límites validados');
    console.log('   ✓ Headers informativos');
    console.log('');

  } catch (error) {
    console.error('');
    console.error('❌ ERROR EN LAS PRUEBAS:');
    console.error('═══════════════════════════════════════════════════════════');
    
    if (error.response) {
      console.error(`Status HTTP: ${error.response.status}`);
      console.error(`Mensaje:`, error.response.data);
    } else if (error.request) {
      console.error('No se pudo conectar al servidor.');
      console.error('');
      console.error('⚠️  IMPORTANTE:');
      console.error('1. Verifica que el backend esté corriendo:');
      console.error('   cd backend');
      console.error('   npm install');
      console.error('   node server.js');
      console.error('');
      console.error('2. Si acabas de hacer cambios, reinicia el servidor');
    } else {
      console.error('Error:', error.message);
    }
    
    console.error('═══════════════════════════════════════════════════════════');
    process.exit(1);
  }
}

testOptimizaciones();
