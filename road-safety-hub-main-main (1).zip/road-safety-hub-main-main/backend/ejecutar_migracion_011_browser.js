/**
 * Script para ejecutar la migración 011 en Supabase
 * Abre el SQL Editor del dashboard con el SQL listo para ejecutar.
 * Uso: node ejecutar_migracion_011_browser.js
 */

const open = require('open');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL || '';
const urlMatch = supabaseUrl.match(/https:\/\/([^.]+)\.supabase\.co/);
const PROJECT_REF = urlMatch ? urlMatch[1] : 'tcmoypkoyozgxhsioqwz';

const SQL = `-- MIGRACIÓN 011: Portal del Conductor y Módulo de Capacitaciones

-- 1. Agregar conductor_id a tabla usuarios
ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS conductor_id UUID REFERENCES conductores(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_usuarios_conductor_id ON usuarios(conductor_id);

-- 2. Insertar rol conductor
INSERT INTO roles (nombre, descripcion)
VALUES ('conductor', 'Conductor con acceso al portal de autogestión')
ON CONFLICT (nombre) DO NOTHING;

-- 3. Tabla de capacitaciones
CREATE TABLE IF NOT EXISTS capacitaciones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  titulo VARCHAR(255) NOT NULL,
  descripcion TEXT,
  contenido_url TEXT,
  tipo VARCHAR(50) DEFAULT 'documento' CHECK (tipo IN ('video', 'documento', 'quiz', 'presencial')),
  duracion_minutos INTEGER DEFAULT 0,
  empresa VARCHAR(255),
  activo BOOLEAN DEFAULT true,
  created_by UUID REFERENCES usuarios(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_capacitaciones_empresa ON capacitaciones(empresa);
CREATE INDEX IF NOT EXISTS idx_capacitaciones_activo ON capacitaciones(activo);

-- 4. Tabla de asignaciones de capacitación a conductores
CREATE TABLE IF NOT EXISTS asignaciones_capacitacion (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  capacitacion_id UUID NOT NULL REFERENCES capacitaciones(id) ON DELETE CASCADE,
  conductor_id UUID NOT NULL REFERENCES conductores(id) ON DELETE CASCADE,
  estado VARCHAR(50) DEFAULT 'pendiente' CHECK (estado IN ('pendiente', 'en_progreso', 'completado')),
  fecha_asignacion TIMESTAMP DEFAULT NOW(),
  fecha_completado TIMESTAMP,
  observaciones TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(capacitacion_id, conductor_id)
);
CREATE INDEX IF NOT EXISTS idx_asignaciones_conductor_id ON asignaciones_capacitacion(conductor_id);
CREATE INDEX IF NOT EXISTS idx_asignaciones_capacitacion_id ON asignaciones_capacitacion(capacitacion_id);
CREATE INDEX IF NOT EXISTS idx_asignaciones_estado ON asignaciones_capacitacion(estado);
`;

const DASHBOARD_URL = `https://supabase.com/dashboard/project/${PROJECT_REF}/sql/new`;

console.log('\n╔════════════════════════════════════════════════════════════╗');
console.log('║  MIGRACIÓN 011 – Portal del Conductor y Capacitaciones     ║');
console.log('╚════════════════════════════════════════════════════════════╝\n');
console.log(`  Proyecto: ${PROJECT_REF}`);
console.log(`  Abriendo SQL Editor en el navegador...\n`);
console.log('─'.repeat(62));
console.log('\n  Copia y pega este SQL en el editor:\n');
console.log(SQL);
console.log('─'.repeat(62));
console.log('\n  ➡️  Haz clic en "Run" para ejecutar.\n');

// Copiar al portapapeles (Windows)
try {
  const { execSync } = require('child_process');
  execSync(`echo ${JSON.stringify(SQL)} | clip`, { shell: 'cmd.exe' });
  console.log('  ✅ SQL copiado al portapapeles automáticamente.\n');
} catch {
  console.log('  ℹ️  Copia el SQL manualmente desde arriba.\n');
}

open(DASHBOARD_URL).catch(() => {
  console.log(`  Abre manualmente: ${DASHBOARD_URL}\n`);
});
