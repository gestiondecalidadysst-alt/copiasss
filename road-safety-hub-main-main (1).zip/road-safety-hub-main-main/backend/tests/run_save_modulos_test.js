const crypto = require('crypto');
const supabase = require('../config/supabaseClient');
const CapacitacionesController = require('../controllers/capacitacionesController');

async function run() {
  try {
    // Obtener una capacitación existente
    const { data: cap, error: capErr } = await supabase
      .from('capacitaciones')
      .select('id, titulo')
      .limit(1)
      .single();
    if (capErr || !cap) {
      console.error('No se encontró una capacitación para pruebas', capErr);
      process.exit(1);
    }

    const capId = cap.id;
    console.log('Usando capacitación:', capId, cap.titulo);

    // Construir payload de modulos de prueba
    const makeId = (prefix) => (crypto.randomUUID ? crypto.randomUUID() : `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`);

    const modulos = [
      {
        id: makeId('mod'),
        titulo: 'Módulo de prueba',
        descripcion: 'Contenido de prueba',
        orden: 1,
        videos: [
          { id: makeId('vid'), titulo: 'Video prueba', url: 'https://example.com/video.mp4', duracion_minutos: 1, orden: 1 }
        ],
        quizzes: [
          {
            id: makeId('quiz'),
            titulo: 'Quiz prueba',
            porcentaje_aprobacion: 70,
            orden: 1,
            preguntas: [
              {
                id: makeId('preg'),
                pregunta: '¿2+2?'
                ,puntos: 1
                ,orden: 1
                ,opciones: [
                  { id: makeId('opc'), texto: '3', es_correcta: false, orden: 1 },
                  { id: makeId('opc'), texto: '4', es_correcta: true, orden: 2 }
                ]
              }
            ]
          }
        ]
      }
    ];

    // Mock req/res
    const req = { params: { id: capId }, body: { modulos }, usuario: { id: 'system', empresa: 'tests' } };

    const res = {
      status(code) { this._status = code; return this; },
      json(obj) { console.log('RESPONSE status=' + (this._status || 200) + ' ->', JSON.stringify(obj, null, 2)); }
    };

    await CapacitacionesController.saveModulos(req, res);
    console.log('Prueba completada');
    process.exit(0);
  } catch (err) {
    console.error('Error en prueba:', err);
    process.exit(1);
  }
}

run();
