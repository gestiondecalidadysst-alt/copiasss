const supabase = require('../config/supabaseClient');
const PortalConductorController = require('../controllers/portalConductorController');

async function run() {
  try {
    // Seleccionar una capacitación con módulos (JSONB) buscando entre varias filas
    const { data: caps, error: capsErr } = await supabase
      .from('capacitaciones')
      .select('id, modulos')
      .limit(10);
    if (capsErr || !Array.isArray(caps)) {
      console.error('Error obteniendo capacitaciones:', capsErr);
      process.exit(1);
    }

    const cap = caps.find(c => Array.isArray(c.modulos) && c.modulos.length > 0);
    if (!cap) {
      console.error('No se encontró capacitación con módulos estructurados en las primeras 10 filas');
      process.exit(1);
    }

    const capId = cap.id;
    const mod = cap.modulos[0];
    if (!mod) {
      console.error('Capacitación sin módulos estructurados');
      process.exit(1);
    }

    const video = Array.isArray(mod.videos) && mod.videos.length > 0 ? mod.videos[0] : null;
    const quiz = Array.isArray(mod.quizzes) && mod.quizzes.length > 0 ? mod.quizzes[0] : null;
    const pregunta = quiz && Array.isArray(quiz.preguntas) && quiz.preguntas.length > 0 ? quiz.preguntas[0] : null;
    const opcionCorrecta = pregunta && Array.isArray(pregunta.opciones) ? pregunta.opciones.find(o => o.es_correcta) : null;

    if (!video || !quiz || !pregunta || !opcionCorrecta) {
      console.error('Datos incompletos en módulo (se necesita video + quiz + pregunta + opción correcta)');
      process.exit(1);
    }

    // Obtener o crear un conductor de prueba
    const { data: conductor } = await supabase.from('conductores').select('id').limit(1).single();
    if (!conductor) {
      console.error('No hay conductores en la tabla');
      process.exit(1);
    }

    const conductorId = conductor.id;

    // Obtener o crear una asignación temporal
    let asignacionId = null;
    let createdAssignment = false;
    const { data: existingAsig } = await supabase
      .from('asignaciones_capacitacion')
      .select('id')
      .eq('capacitacion_id', capId)
      .eq('conductor_id', conductorId)
      .limit(1)
      .single();
    if (existingAsig && existingAsig.id) {
      asignacionId = existingAsig.id;
      console.log('Usando asignación existente:', asignacionId);
    } else {
      const { data: asigData, error: asigErr } = await supabase
        .from('asignaciones_capacitacion')
        .insert([{ capacitacion_id: capId, conductor_id: conductorId, estado: 'pendiente', fecha_asignacion: new Date() }])
        .select()
        .single();
      if (asigErr || !asigData) {
        console.error('Error creando asignación:', asigErr);
        process.exit(1);
      }
      asignacionId = asigData.id;
      createdAssignment = true;
      console.log('Asignación creada:', asignacionId);
    }

    // Mock req/res para actualizar progreso de video
    const reqVideo = { params: { id: asignacionId }, body: { modulo_id: mod.id, video_id: video.id, progreso: 50 }, usuario: { conductor_id: conductorId } };
    const resVideo = {
      status(code) { this._status = code; return this; },
      json(obj) { console.log('actualizarProgresoVideoModulo response status=' + (this._status || 200) + ' ->', JSON.stringify(obj)); }
    };

    await PortalConductorController.actualizarProgresoVideoModulo(reqVideo, resVideo);

    // Mock req/res para responder quiz (respuesta correcta)
    const respuestas = [{ pregunta_id: pregunta.id, opcion_id: opcionCorrecta.id }];
    const reqQuiz = { params: { id: asignacionId }, body: { modulo_id: mod.id, quiz_id: quiz.id, respuestas }, usuario: { conductor_id: conductorId } };
    const resQuiz = {
      status(code) { this._status = code; return this; },
      json(obj) { console.log('responderQuizModulo response status=' + (this._status || 200) + ' ->', JSON.stringify(obj)); }
    };

    await PortalConductorController.responderQuizModulo(reqQuiz, resQuiz);

    console.log('Pruebas de conductor completadas');

    // Limpiar: eliminar asignación de prueba si la creamos
    if (createdAssignment) {
      await supabase.from('asignaciones_capacitacion').delete().eq('id', asignacionId);
      console.log('Asignación de prueba eliminada');
    } else {
      console.log('No se eliminó la asignación existente (no fue creada por la prueba)');
    }

    process.exit(0);
  } catch (err) {
    console.error('Error en pruebas conductor:', err);
    process.exit(1);
  }
}

run();
