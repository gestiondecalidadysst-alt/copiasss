const supabase = require('../config/supabaseClient');

async function run() {
  try {
    const id = '93ea439f-4d24-4162-badd-e21ac90e9864';
    const capacitacion_id = '83f43b79-ea6a-418b-bc5e-43d2d4aa75d7';
    const conductor_id = '69a63464-7d68-4dae-b15c-ed8557fc4899';

    const row = {
      id,
      capacitacion_id,
      conductor_id,
      estado: 'pendiente',
      fecha_asignacion: new Date()
    };

    const { data, error } = await supabase.from('asignaciones_capacitacion').upsert([row], { onConflict: 'id' }).select().single();
    if (error) {
      console.error('Error restaurando asignación:', error);
      process.exit(1);
    }
    console.log('Asignación restaurada:', data.id);
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

run();
