require('dotenv').config({ path: __dirname + '/.env' });

const express = require('express');
const cors = require('cors');
const compression = require('compression');
const helmet = require('helmet');

const app = express();
const PORT = process.env.PORT || 5000;

// Configuración de límites para prevenir colapso con datos grandes
const MAX_JSON_SIZE = '10mb'; // Límite reducido a 10 MB (50 MB era excesivo y peligroso)
const MAX_TIMEOUT = 5 * 60 * 1000; // 5 minutos timeout

// ── Seguridad: cabeceras HTTP (CSP, X-Frame-Options, etc.) ─────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameSrc: ["'none'"],
    },
  },
  crossOriginEmbedderPolicy: false, // Evita romper recursos de terceros
  crossOriginResourcePolicy: { policy: 'cross-origin' }, // Permite leer respuestas desde otros dominios
}));

// ── CORS: sólo permitir el origen del frontend ─────────────────────────────
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || 'http://localhost:5173')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);
const ALLOW_ALL_ORIGINS = ALLOWED_ORIGINS.includes('*');

app.use(cors({
  origin: (origin, callback) => {
    // Permitir peticiones sin origin (ej. Postman en desarrollo)
    if (!origin || ALLOW_ALL_ORIGINS || ALLOWED_ORIGINS.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error(`CORS: origen no permitido → ${origin}`));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  maxAge: 86400,
}));

// Compresión gzip para reducir tamaño de respuestas
app.use(compression({
  filter: (req, res) => {
    if (req.headers['x-no-compression']) {
      return false;
    }
    return compression.filter(req, res);
  },
  level: 6 // Nivel de compresión balanceado (0-9)
}));

// Límite de tamaño de payload JSON
app.use(express.json({ limit: MAX_JSON_SIZE }));
app.use(express.urlencoded({ extended: true, limit: MAX_JSON_SIZE }));

// Timeout para todas las requests
app.use((req, res, next) => {
  req.setTimeout(MAX_TIMEOUT);
  res.setTimeout(MAX_TIMEOUT);
  next();
});

// Logging middleware para monitorear requests pesadas
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    if (duration > 1000) { // Log requests que toman más de 1 segundo
      console.log(`⚠️  Request lenta: ${req.method} ${req.path} - ${duration}ms`);
    }
  });
  next();
});

// TODO: Importar e inicializar Supabase después

// Middlewares de rendimiento
const { 
  memoryMonitor, 
  performanceHeaders, 
  responseSizeLimit,
  cacheMiddleware
} = require('./middlewares/performanceMiddleware');

app.use(memoryMonitor);
app.use(performanceHeaders);
app.use(responseSizeLimit(50)); // Límite de 50MB por respuesta

// Rutas
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/usuarios', require('./routes/usuariosRoutes'));
app.use('/api/eventos', require('./routes/eventosRoutes'));
app.use('/api/vehiculos', require('./routes/vehiculosRoutes'));
app.use('/api/conductores', require('./routes/conductoresRoutes'));
app.use('/api/mensajes', require('./routes/mensajesRoutes'));
app.use('/api/capacitaciones', require('./routes/capacitacionesRoutes'));
app.use('/api/portal/conductor', require('./routes/portalConductorRoutes'));
app.use('/api/configuracion', require('./routes/configuracionRoutes'));
app.use('/api/noticias', require('./routes/noticiasRoutes'));

// Rutas de reportes con caché (5 minutos)
app.use('/api/reportes', cacheMiddleware(5 * 60 * 1000), require('./routes/reportesRoutes'));

// Ruta optimizada para exportar datos grandes
const exportController = require('./controllers/exportController');
app.get('/api/export/eventos/stream', exportController.exportEventosStream);
app.get('/api/export/eventos/stats', exportController.getEventosStats);

// Endpoint de salud del servidor
app.get('/api/health', (req, res) => {
  const memUsage = process.memoryUsage();
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    memory: {
      heapUsed: `${(memUsage.heapUsed / 1024 / 1024).toFixed(2)}MB`,
      heapTotal: `${(memUsage.heapTotal / 1024 / 1024).toFixed(2)}MB`,
      rss: `${(memUsage.rss / 1024 / 1024).toFixed(2)}MB`
    },
    timestamp: new Date().toISOString()
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor backend corriendo en http://localhost:${PORT}`);
});
