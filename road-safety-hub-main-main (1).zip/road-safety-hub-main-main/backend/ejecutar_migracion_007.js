/**
 * Script para ejecutar la migración 007: Programación de mensajes
 * Uso: node ejecutar_migracion_007.js
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Error: Faltan credenciales de Supabase en .env');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

// Comandos DDL individuales de la migración 007
const COMANDOS = [
  {
    desc: 'Eliminar columna obsoleta fecha_hora',
    sql: `ALTER TABLE mensajes DROP COLUMN IF EXISTS fecha_hora`,
  },
  {
    desc: 'Agregar columna num_repeticiones',
    sql: `ALTER TABLE mensajes ADD COLUMN IF NOT EXISTS num_repeticiones SMALLINT DEFAULT 1`,
  },
  {
    desc: 'Agregar constraint a num_repeticiones',
    sql: `ALTER TABLE mensajes ADD CONSTRAINT IF NOT EXISTS valid_num_repeticiones CHECK (num_repeticiones BETWEEN 1 AND 2)`,
  },
  {
    desc: 'Agregar columna programaciones (JSONB)',
    sql: `ALTER TABLE mensajes ADD COLUMN IF NOT EXISTS programaciones JSONB DEFAULT '[]'::jsonb`,
  },
  {
    desc: 'Crear índice GIN para programaciones',
    sql: `CREATE INDEX IF NOT EXISTS idx_mensajes_programaciones ON mensajes USING GIN (programaciones)`,
  },
];

async function ejecutarComando(desc, sql) {
  try {
    const response = await fetch(`${supabaseUrl}/rest/v1/rpc/exec`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': supabaseKey,
        'Authorization': `Bearer ${supabaseKey}`,
      },
      body: JSON.stringify({ sql }),
    });

    if (response.ok) {
      console.log(`  ✅ ${desc}`);
      return true;
    }

    // Intentar con rpc 'exec_sql'
    const { error } = await supabase.rpc('exec_sql', { sql_query: sql });
    if (!error) {
      console.log(`  ✅ ${desc}`);
      return true;
    }

    const errText = await response.text().catch(() => error?.message || 'error desconocido');
    console.log(`  ⚠️  ${desc} — ${errText.substring(0, 120)}`);
    return false;
  } catch (err) {
    console.log(`  ⚠️  ${desc} — ${err.message.substring(0, 120)}`);
    return false;
  }
}

async function main() {
  console.log('\n╔════════════════════════════════════════════════════╗');
  console.log('║  MIGRACIÓN 007 – Programación de mensajes          ║');
  console.log('╚════════════════════════════════════════════════════╝\n');

  let ok = 0;
  let warn = 0;

  for (const { desc, sql } of COMANDOS) {
    const success = await ejecutarComando(desc, sql);
    success ? ok++ : warn++;
  }

  console.log('\n────────────────────────────────────────────────────');
  console.log(`  ✅ ${ok} ejecutados correctamente`);
  if (warn > 0) {
    console.log(`  ⚠️  ${warn} con advertencias (puede que los RPC no estén habilitados)`);
    console.log('\n  ➡️  Si hay advertencias, ejecuta manualmente el SQL en:');
    console.log('     Supabase Dashboard → SQL Editor → pega el contenido de:');
    console.log('     backend/migrations/007_add_programacion_mensajes.sql\n');
  } else {
    console.log('\n  🎉 Migración completada sin errores.\n');
  }
}

main();
