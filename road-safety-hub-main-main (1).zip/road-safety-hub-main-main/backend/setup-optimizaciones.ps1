# Script para instalar dependencias y arrancar servidor optimizado
# PowerShell

Write-Host "🚀 Instalando Optimizaciones de Rendimiento" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Cambiar al directorio backend
Set-Location "C:\Users\ces_m\Downloads\road-safety-hub-main\road-safety-hub-main\backend"

Write-Host "📦 Instalando dependencia de compresión..." -ForegroundColor Yellow
npm install compression

Write-Host ""
Write-Host "✅ Dependencias instaladas" -ForegroundColor Green
Write-Host ""

Write-Host "📋 Optimizaciones implementadas:" -ForegroundColor Cyan
Write-Host "   ✓ Paginación automática (máx 500 registros/página)" -ForegroundColor Green
Write-Host "   ✓ Compresión gzip (ahorra 60-90% bandwidth)" -ForegroundColor Green
Write-Host "   ✓ Streaming para datos grandes" -ForegroundColor Green
Write-Host "   ✓ Caché inteligente (5 min TTL)" -ForegroundColor Green
Write-Host "   ✓ Límites de seguridad (50MB max)" -ForegroundColor Green
Write-Host "   ✓ Monitoreo de memoria" -ForegroundColor Green
Write-Host "   ✓ Timeouts configurables (5 min)" -ForegroundColor Green
Write-Host ""

Write-Host "🔍 Nuevos endpoints disponibles:" -ForegroundColor Cyan
Write-Host "   GET  /api/health                     - Estado del servidor" -ForegroundColor White
Write-Host "   GET  /api/reportes?page=1&limit=100 - Reportes paginados" -ForegroundColor White
Write-Host "   GET  /api/export/eventos/stream     - Streaming de eventos" -ForegroundColor White
Write-Host "   GET  /api/export/eventos/stats      - Estadísticas rápidas" -ForegroundColor White
Write-Host ""

Write-Host "💡 Para iniciar el servidor:" -ForegroundColor Yellow
Write-Host "   node server.js" -ForegroundColor White
Write-Host ""

Write-Host "🧪 Para probar las optimizaciones:" -ForegroundColor Yellow
Write-Host "   node test_optimizaciones.js" -ForegroundColor White
Write-Host ""

Write-Host "📚 Ver documentación completa:" -ForegroundColor Yellow
Write-Host "   OPTIMIZACIONES_BACKEND.md" -ForegroundColor White
Write-Host ""

Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "✅ Sistema listo para manejar reportes grandes" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
