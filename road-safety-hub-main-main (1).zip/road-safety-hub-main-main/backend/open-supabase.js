#!/usr/bin/env node

/**
 * Script para abrir Supabase SQL Editor y crear la tabla automáticamente
 */

const open = require('open');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const sqlFile = path.join(__dirname, 'migrations', '002_create_mensajes_table.sql');
const sqlContent = fs.readFileSync(sqlFile, 'utf-8');

// Extraer project ref
const urlMatch = supabaseUrl.match(/https:\/\/([^.]+)\.supabase\.co/);
const projectRef = urlMatch ? urlMatch[1] : 'tu-proyecto';

console.log('\n╔═══════════════════════════════════════════════════════════╗');
console.log('║      CREANDO TABLA mensajes EN SUPABASE                  ║');
console.log('╚═══════════════════════════════════════════════════════════╝\n');

console.log('📖 OPCIÓN MÁS RÁPIDA - SQL Directo:\n');

console.log('El SQL ha sido copiado. Sigue estos pasos:\n');

console.log('1️⃣  Abriendo Supabase SQL Editor...\n');

// Copiar al portapapeles
const os = require('os');
if (process.platform === 'win32') {
  try {
    const proc = require('child_process').spawn('powershell.exe', [
      '-Command',
      `Set-Clipboard -Value @"
${sqlContent}
"@`
    ]);
    console.log('   ✅ SQL copiado al portapapeles\n');
  } catch (e) {
    console.log('   ⚠️  No se pudo copiar\n');
  }
}

const dashboardUrl = `https://supabase.com/dashboard/project/${projectRef}/sql/new`;

console.log('2️⃣  Ve a este enlace (se abrirá automáticamente):\n');
console.log(`   ${dashboardUrl}\n`);

console.log('3️⃣  Pega el SQL (Ctrl+V) y haz clic en "Run"\n');

console.log('═'.repeat(63) + '\n');

console.log('📋 SQL A EJECUTAR:\n');
console.log(sqlContent);
console.log('\n' + '═'.repeat(63) + '\n');

console.log('4️⃣  Después de que se ejecute, vuelve y ejecuta:\n');
console.log('   npm start\n');

// Intentar abrir el navegador
try {
  open(dashboardUrl);
  console.log('✅ Supabase SQL Editor abierto en tu navegador\n');
} catch (error) {
  console.log('ℹ️  Abre manualmente: ' + dashboardUrl + '\n');
}
