/**
 * Script para ejecutar la migración de usuarios y roles en Supabase
 */

const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Error: Faltan credenciales de Supabase en .env');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function ejecutarSQL(sql) {
  try {
    const { data, error } = await supabase.rpc('exec', { sql });
    if (error) throw error;
    return data;
  } catch (error) {
    // Si exec no existe, intentar con otra función
    throw error;
  }
}

async function ejecutarMigracion() {
  console.log('🔄 Ejecutando migración de usuarios y roles...\n');

  try {
    // Leer archivo SQL
    const sqlFile = path.join(__dirname, 'migrations', '004_create_users_and_roles.sql');
    const sqlContent = fs.readFileSync(sqlFile, 'utf-8');

    // Dividir en comandos individuales
    const commands = sqlContent
      .split(';')
      .map(cmd => cmd.trim())
      .filter(cmd => cmd.length > 0 && !cmd.startsWith('--'));

    console.log(`📝 Ejecutando ${commands.length} comandos SQL...\n`);

    let success = 0;
    let failed = 0;

    for (let i = 0; i < commands.length; i++) {
      const cmd = commands[i];
      console.log(`[${i + 1}/${commands.length}] Ejecutando...`);
      
      try {
        // Intentar ejecutar cada comando
        const response = await fetch(`${supabaseUrl}/rest/v1/rpc/exec`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': supabaseKey,
            'Authorization': `Bearer ${supabaseKey}`
          },
          body: JSON.stringify({ sql: cmd })
        });

        if (response.ok) {
          console.log('✅ Comando ejecutado');
          success++;
        } else {
          const error = await response.text();
          console.log(`⚠️  Posible error (puede ser normal): ${error.substring(0, 100)}`);
          failed++;
        }
      } catch (error) {
        console.log(`⚠️  Error: ${error.message.substring(0, 100)}`);
        failed++;
      }
    }

    console.log('\n════════════════════════════════════════════════════════');
    console.log(`✅ Migración completada: ${success} éxitos, ${failed} advertencias`);
    console.log('════════════════════════════════════════════════════════\n');

    // Verificar que las tablas existen
    console.log('🧪 Verificando tablas creadas...\n');

    const tablesToCheck = ['roles', 'usuarios', 'usuario_roles'];
    
    for (const table of tablesToCheck) {
      try {
        const { data, error } = await supabase
          .from(table)
          .select('*')
          .limit(1);

        if (error && error.code !== 'PGRST116') {
          console.log(`❌ Tabla ${table}: ERROR`);
        } else {
          console.log(`✅ Tabla ${table}: OK`);
        }
      } catch (err) {
        console.log(`⚠️  Tabla ${table}: No se pudo verificar`);
      }
    }

    console.log('\n🎉 ¡Migración completada!\n');
    console.log('Siguiente paso:');
    console.log('  node crear_admin_inicial.js\n');

  } catch (error) {
    console.error('❌ Error fatal:', error.message);
    console.log('\n⚠️  Si hay errores, ejecuta el SQL manualmente en Supabase SQL Editor');
    console.log('El archivo SQL está en: backend/migrations/004_create_users_and_roles.sql\n');
    process.exit(1);
  }
}

ejecutarMigracion();
