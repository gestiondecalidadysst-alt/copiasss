const supabase = require('./config/supabaseClient');

async function checkReportes() {
  try {
    const { data, error, count } = await supabase
      .from('reportes')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false });

    if (error) throw error;

    console.log(`\n📊 Total de reportes en la BD: ${count}\n`);
    
    if (data && data.length > 0) {
      console.log('Reportes encontrados:\n');
      data.forEach((r, idx) => {
        console.log(`${idx + 1}. ID: ${r.id}`);
        console.log(`   Nombre: ${r.nombre}`);
        console.log(`   Placa: ${r.placa}`);
        console.log(`   Fecha desde: ${r.fecha_desde}`);
        console.log(`   Fecha hasta: ${r.fecha_hasta}`);
        console.log(`   Total eventos: ${r.total_eventos}`);
        console.log(`   Creado: ${new Date(r.created_at).toLocaleString('es-ES')}`);
        console.log(`   Usuario: ${r.usuario}`);
        console.log(`   Empresa: ${r.empresa}`);
        console.log('---');
      });

      // Agrupar por placa
      console.log('\n📋 Reportes agrupados por placa:\n');
      const porPlaca = {};
      data.forEach(r => {
        if (!porPlaca[r.placa]) {
          porPlaca[r.placa] = [];
        }
        porPlaca[r.placa].push(r.nombre);
      });

      Object.entries(porPlaca).forEach(([placa, reportes]) => {
        console.log(`Placa "${placa}": ${reportes.length} reporte(s)`);
        reportes.forEach(nom => console.log(`  - ${nom}`));
      });
    } else {
      console.log('✅ No hay reportes en la base de datos.');
    }

    process.exit(0);
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
}

checkReportes();
