const axios = require('axios');
require('dotenv').config();

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

// SQL para crear la tabla reportes
const SQL_CREATE_TABLE = `
-- Crear tabla de reportes guardados
CREATE TABLE IF NOT EXISTS reportes (
  id BIGSERIAL PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  nombre VARCHAR(255) NOT NULL,
  placa VARCHAR(50),
  fecha_desde DATE,
  fecha_hasta DATE,
  tipo_evento VARCHAR(50),
  total_eventos INTEGER DEFAULT 0,
  velocidad_promedio DECIMAL(10, 2),
  filtros_aplicados JSONB,
  usuario VARCHAR(255),
  empresa VARCHAR(255)
);

-- Crear índice para búsquedas más rápidas
CREATE INDEX IF NOT EXISTS idx_reportes_created_at ON reportes(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reportes_nombre ON reportes(nombre);

-- Habilitar RLS (Row Level Security)
ALTER TABLE reportes ENABLE ROW LEVEL SECURITY;

-- Política para permitir todas las operaciones
DROP POLICY IF EXISTS "Permitir todas las operaciones en reportes" ON reportes;
CREATE POLICY "Permitir todas las operaciones en reportes" 
  ON reportes 
  FOR ALL 
  USING (true) 
  WITH CHECK (true);
`;

async function crearTablaReportes() {
  console.log('🚀 Creando tabla "reportes" en Supabase...\n');

  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    console.error('❌ Error: Faltan las credenciales de Supabase');
    console.error('Verifica que existan en el archivo .env:');
    console.error('  - SUPABASE_URL');
    console.error('  - SUPABASE_SERVICE_ROLE_KEY');
    process.exit(1);
  }

  try {
    // Usar la API REST de Supabase para ejecutar SQL
    const response = await axios.post(
      `${SUPABASE_URL}/rest/v1/rpc/exec_sql`,
      { query: SQL_CREATE_TABLE },
      {
        headers: {
          'apikey': SUPABASE_SERVICE_ROLE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    console.log('✅ Tabla "reportes" creada exitosamente!');
    console.log('📊 Respuesta:', response.data);
    
  } catch (error) {
    if (error.response) {
      console.error('❌ Error HTTP:', error.response.status);
      console.error('📄 Mensaje:', error.response.data);
      
      if (error.response.status === 404) {
        console.log('\n⚠️  La función exec_sql no está disponible.');
        console.log('\n📋 SOLUCIÓN: Ejecuta este SQL manualmente en Supabase:');
        console.log('═══════════════════════════════════════════════════════════');
        console.log(SQL_CREATE_TABLE);
        console.log('═══════════════════════════════════════════════════════════\n');
        console.log('📍 Pasos:');
        console.log('1. Ve a: https://supabase.com/dashboard/project/_/sql/new');
        console.log('2. Copia y pega el SQL de arriba');
        console.log('3. Haz clic en "Run" o "Ejecutar"\n');
      }
    } else {
      console.error('❌ Error:', error.message);
      console.log('\n📋 Por favor, ejecuta este SQL manualmente en Supabase:');
      console.log('═══════════════════════════════════════════════════════════');
      console.log(SQL_CREATE_TABLE);
      console.log('═══════════════════════════════════════════════════════════\n');
    }
    process.exit(1);
  }
}

crearTablaReportes();
