#!/usr/bin/env node

/**
 * Verificar si la tabla mensajes existe en Supabase
 * Si no existe, mostrar instrucciones para crearla
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Error: Faltan credenciales en .env');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function verificarTabla() {
  console.log('\n╔════════════════════════════════════════════════╗');
  console.log('║   VERIFICANDO TABLA "mensajes" EN SUPABASE     ║');
  console.log('╚════════════════════════════════════════════════╝\n');

  try {
    console.log('🔍 Verificando tabla...');
    
    // Intentar leer la tabla
    const { data, error } = await supabase
      .from('mensajes')
      .select('*')
      .limit(1);

    if (error) {
      if (error.code === 'PGRST116') {
        console.log('❌ Tabla NO encontrada\n');
        mostrarInstruccionesPastaManualmente();
      } else {
        console.error('❌ Error:', error.message);
      }
      return;
    }

    console.log('✅ Tabla ENCONTRADA!\n');
    console.log('✨ La tabla "mensajes" está lista para usar\n');
    
    // Mostrar estructura
    console.log('📋 Campos disponibles:');
    if (data.length > 0) {
      const obj = data[0];
      Object.keys(obj).forEach(key => {
        console.log(`   • ${key}`);
      });
    } else {
      console.log('   (tabla vacía, pero creada correctamente)');
    }

    console.log('\n✅ Próximos pasos:');
    console.log('   1. Crea bucket "mensaje-media" en Storage (Supabase UI)');
    console.log('   2. npm start');
    console.log('   3. Abre http://localhost:5173/mensajes\n');

  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

function mostrarInstruccionesPastaManualmente() {
  const fs = require('fs');
  const path = require('path');
  
  const sqlFile = path.join(__dirname, 'migrations', '002_create_mensajes_table.sql');
  const sql = fs.readFileSync(sqlFile, 'utf-8');

  console.log('📖 INSTRUCCIONES PARA CREAR LA TABLA MANUALMENTE:\n');
  console.log('1️⃣  Abre tu proyecto Supabase:');
  console.log('   👉 https://supabase.com/dashboard\n');

  console.log('2️⃣  Ve a "SQL Editor" (panel izquierdo)\n');

  console.log('3️⃣  Haz clic en "+ New Query"\n');

  console.log('4️⃣  Copia y pega TODO esto en el editor:\n');
  console.log('═'.repeat(70));
  console.log(sql);
  console.log('═'.repeat(70) + '\n');

  console.log('5️⃣  Haz clic en "RUN" (botón verde) o presiona Ctrl+Enter\n');

  console.log('6️⃣  Espera a ver "Query successful!"\n');

  console.log('7️⃣  Después, vuelve aquí y ejecuta:\n');
  console.log('   node verify-tabla.js\n');

  console.log('   O directamente:\n');
  console.log('   npm start\n');
}

verificarTabla();
