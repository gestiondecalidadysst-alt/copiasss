/**
 * Script para ejecutar la migración de usuarios y roles
 * Ejecuta el SQL directamente en Supabase
 */

const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Error: Faltan credenciales de Supabase en .env');
  console.log('Se requiere:');
  console.log('  - SUPABASE_URL');
  console.log('  - SUPABASE_SERVICE_ROLE_KEY (o SUPABASE_ANON_KEY)');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

async function ejecutarMigracionUsuarios() {
  try {
    console.log('🔄 Iniciando migración de usuarios y roles...\n');

    // Leer archivo SQL
    const sqlFile = path.join(__dirname, 'migrations', '004_create_users_and_roles.sql');
    
    if (!fs.existsSync(sqlFile)) {
      console.error(`❌ Error: Archivo no encontrado: ${sqlFile}`);
      process.exit(1);
    }

    const sqlContent = fs.readFileSync(sqlFile, 'utf-8');
    
    console.log('📋 Archivo SQL cargado');
    console.log('📁 Ruta:', sqlFile);
    console.log('\n⚠️  NOTA: Este script requiere ejecutar el SQL manualmente en Supabase\n');
    console.log('════════════════════════════════════════════════════════════════\n');
    
    console.log('Por favor, sigue estos pasos:\n');
    console.log('1. Ve a tu proyecto en Supabase (https://app.supabase.com)');
    console.log('2. Abre el "SQL Editor" en el menú lateral');
    console.log('3. Crea una nueva query');
    console.log('4. Copia y pega el siguiente SQL:\n');
    console.log('════════════════════════════════════════════════════════════════\n');
    console.log(sqlContent);
    console.log('\n════════════════════════════════════════════════════════════════\n');
    console.log('5. Haz clic en "Run" para ejecutar la migración');
    console.log('6. Verifica que las tablas se crearon correctamente\n');
    
    console.log('✅ SQL copiado al portapapeles (si es posible)\n');
    console.log('Después de ejecutar el SQL en Supabase, ejecuta:');
    console.log('  node crear_admin_inicial.js\n');
    
    // Guardar en archivo temporal
    const tempFile = path.join(__dirname, 'temp_migration_004.sql');
    fs.writeFileSync(tempFile, sqlContent);
    console.log(`💾 SQL guardado en: ${tempFile}`);
    console.log('   Puedes abrir este archivo y copiarlo desde ahí\n');

  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

ejecutarMigracionUsuarios();
