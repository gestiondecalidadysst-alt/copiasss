async function checkTodayData() {
  try {
    const res = await fetch('http://localhost:5000/api/eventos');
    const data = await res.json();
    
    const today = new Date().toLocaleDateString('en-CA');
    console.log(`\n=== Verificando datos de hoy: ${today} ===\n`);
    
    // Buscar eventos de hoy usando diferentes campos
    const byCreatedAt = data.filter(e => {
      if (!e.created_at) return false;
      const d = new Date(e.created_at).toLocaleDateString('en-CA');
      return d === today;
    });
    
    const byFecha = data.filter(e => {
      if (!e.fecha) return false;
      // e.fecha tiene formato "HH:MM:SS", verificar en el campo original
      return false; // fecha es solo hora
    });
    
    console.log(`Eventos con created_at === hoy: ${byCreatedAt.length}`);
    
    if (byCreatedAt.length > 0) {
      console.log(`\nPrimer evento de hoy:`);
      console.log(JSON.stringify(byCreatedAt[0], null, 2));
    }
    
    // Ver todas las fechas únicas
    const uniqueDates = new Set();
    data.forEach(e => {
      if (e.created_at) {
        const d = new Date(e.created_at).toLocaleDateString('en-CA');
        uniqueDates.add(d);
      }
    });
    
    const allDates = Array.from(uniqueDates).sort().reverse();
    console.log(`\n=== TODAS las fechas en la BD ===`);
    allDates.forEach(d => {
      const count = data.filter(e => e.created_at && new Date(e.created_at).toLocaleDateString('en-CA') === d).length;
      console.log(`${d}: ${count} eventos`);
    });
    
  } catch (err) {
    console.error('Error:', err);
  }
}

checkTodayData();
