const supabase = require('./config/supabaseClient');
const fs = require('fs');
const path = require('path');

async function verificarYCrearTablaReportes() {
  console.log('🔍 Verificando si existe la tabla "reportes" en Supabase...\n');

  try {
    // Intentar hacer una consulta simple a la tabla
    const { data, error } = await supabase
      .from('reportes')
      .select('id')
      .limit(1);

    if (error) {
      if (error.message.includes('relation') && error.message.includes('does not exist')) {
        console.log('❌ La tabla "reportes" NO existe.');
        console.log('📝 Procediendo a crear la tabla...\n');
        
        // Leer el archivo de migración
        const migrationPath = path.join(__dirname, 'migrations', '003_create_reportes_table.sql');
        const migrationSQL = fs.readFileSync(migrationPath, 'utf8');
        
        console.log('📄 Contenido del script SQL:');
        console.log('═══════════════════════════════════════════════════════');
        console.log(migrationSQL);
        console.log('═══════════════════════════════════════════════════════\n');

        // Intentar ejecutar la migración usando el cliente de Supabase
        console.log('🚀 Ejecutando migración...');
        
        // Nota: Supabase JS no soporta directamente la ejecución de SQL DDL
        // Hay que usar la API REST de Supabase o el dashboard
        console.log('\n⚠️  IMPORTANTE:');
        console.log('El cliente JavaScript de Supabase no puede ejecutar SQL DDL directamente.');
        console.log('Por favor, ejecuta el script SQL manualmente de una de estas formas:\n');
        console.log('OPCIÓN 1 - Dashboard de Supabase (Recomendado):');
        console.log('1. Ve a: https://supabase.com/dashboard/project/_/sql/new');
        console.log('2. Copia y pega el contenido del archivo:');
        console.log(`   ${migrationPath}`);
        console.log('3. Haz clic en "Run"\n');
        
        console.log('OPCIÓN 2 - psql (si tienes acceso):');
        console.log('1. Conéctate a tu base de datos con psql');
        console.log(`2. Ejecuta: \\i ${migrationPath}\n`);
        
        console.log('📋 SCRIPT SQL A COPIAR:');
        console.log('═══════════════════════════════════════════════════════');
        console.log(migrationSQL);
        console.log('═══════════════════════════════════════════════════════\n');
        
        return false;
      } else {
        console.error('❌ Error al verificar la tabla:', error.message);
        return false;
      }
    }

    console.log('✅ La tabla "reportes" existe correctamente en Supabase!');
    console.log(`📊 Verificación exitosa. Datos encontrados: ${data ? data.length : 0} registros\n`);
    
    // Mostrar estructura de la tabla
    console.log('📋 Verificando estructura de la tabla...');
    const { data: reportes, error: queryError } = await supabase
      .from('reportes')
      .select('*')
      .limit(1);
    
    if (!queryError && reportes) {
      console.log('✅ La tabla tiene las siguientes columnas:');
      if (reportes.length > 0) {
        Object.keys(reportes[0]).forEach(col => {
          console.log(`   - ${col}`);
        });
      } else {
        console.log('   (Tabla vacía, columnas esperadas: id, created_at, nombre, placa, fecha_desde, fecha_hasta, tipo_evento, total_eventos, velocidad_promedio, filtros_aplicados, usuario, empresa)');
      }
    }
    
    return true;
  } catch (err) {
    console.error('❌ Error inesperado:', err.message);
    return false;
  }
}

// Ejecutar verificación
verificarYCrearTablaReportes()
  .then(success => {
    if (success) {
      console.log('\n✅ Sistema de reportes listo para usar!');
      process.exit(0);
    } else {
      console.log('\n⚠️  Se requiere acción manual para crear la tabla.');
      process.exit(1);
    }
  })
  .catch(err => {
    console.error('\n❌ Error fatal:', err);
    process.exit(1);
  });
