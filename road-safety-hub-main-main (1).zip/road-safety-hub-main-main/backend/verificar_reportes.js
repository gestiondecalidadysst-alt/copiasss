const supabase = require('./config/supabaseClient');

async function verificarReportes() {
  console.log('🔍 Verificando reportes en la base de datos...\n');

  try {
    const { data, error } = await supabase
      .from('reportes')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('❌ Error:', error.message);
      return;
    }

    if (!data || data.length === 0) {
      console.log('📋 No hay reportes en la base de datos');
      console.log('✅ La tabla está vacía - esto es correcto si acabas de crearla\n');
      return;
    }

    console.log(`📊 Total de reportes en la base de datos: ${data.length}\n`);
    
    data.forEach((reporte, index) => {
      console.log(`Reporte ${index + 1}:`);
      console.log(`  ID: ${reporte.id}`);
      console.log(`  Nombre: ${reporte.nombre}`);
      console.log(`  Placa: ${reporte.placa}`);
      console.log(`  Eventos: ${reporte.total_eventos}`);
      console.log(`  Creado: ${new Date(reporte.created_at).toLocaleString('es-ES')}`);
      console.log('');
    });

  } catch (err) {
    console.error('❌ Error inesperado:', err.message);
  }
}

verificarReportes();
