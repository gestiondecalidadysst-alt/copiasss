#!/usr/bin/env node

/**
 * Script para copiar SQL de migración y mostrar instrucciones
 * Este script lee el archivo SQL y lo prepara para ejecución manual en Supabase
 */

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const sqlFile = path.join(__dirname, 'migrations', '002_create_mensajes_table.sql');

if (!fs.existsSync(sqlFile)) {
  console.error('❌ Archivo SQL no encontrado:', sqlFile);
  process.exit(1);
}

const sqlContent = fs.readFileSync(sqlFile, 'utf-8');

console.log('\n╔══════════════════════════════════════════════════════════╗');
console.log('║     SETUP MANUAL DE LA TABLA MENSAJES EN SUPABASE       ║');
console.log('╚══════════════════════════════════════════════════════════╝\n');

console.log('📋 Se encontró el archivo SQL. Sigue estos pasos:\n');

console.log('1️⃣  Abre tu proyecto en Supabase:');
console.log('   👉 https://supabase.com/dashboard\n');

console.log('2️⃣  Ve a "SQL Editor" en el panel izquierdo\n');

console.log('3️⃣  Haz clic en "New Query" o "+" para crear una nueva consulta\n');

console.log('4️⃣  Copia TODO el siguiente código SQL:\n');
console.log('═'.repeat(60));
console.log(sqlContent);
console.log('═'.repeat(60) + '\n');

console.log('5️⃣  Pega el código en el editor SQL de Supabase\n');

console.log('6️⃣  Haz clic en "Run" (o presiona Ctrl+Enter)\n');

console.log('7️⃣  Espera a que termine la ejecución ✅\n');

console.log('8️⃣  Cuando veas "Query successful!" vuelve aquí y ejecuta:\n');
console.log('   npm start\n');

console.log('═'.repeat(60));
console.log('💡 ALTERNATIVA RÁPIDA (Si usas Supabase CLI):\n');
console.log('   supabase db push\n');
console.log('═'.repeat(60));

// Intentar copiar al portapapeles si es posible
if (process.platform === 'win32') {
  // Windows
  try {
    require('child_process').spawn('clip').stdin.write(sqlContent);
    console.log('\n✅ SQL copiado al portapapeles! (Windows)\n');
  } catch (e) {
    console.log('\n⚠️  No se pudo copiar al portapapeles\n');
  }
} else if (process.platform === 'darwin') {
  // macOS
  try {
    require('child_process').spawn('pbcopy').stdin.write(sqlContent);
    console.log('\n✅ SQL copiado al portapapeles! (macOS)\n');
  } catch (e) {
    console.log('\n⚠️  No se pudo copiar al portapapeles\n');
  }
} else {
  // Linux
  try {
    require('child_process').spawn('xclip', ['-selection', 'clipboard']).stdin.write(sqlContent);
    console.log('\n✅ SQL copiado al portapapeles! (Linux)\n');
  } catch (e) {
    console.log('\n⚠️  No se pudo copiar al portapapeles\n');
  }
}

console.log('📝 Campos que se crearán:\n');
console.log('  Contenido:');
console.log('    • titulo, tipo, contenido, asunto');
console.log('');
console.log('  Prioridad y Estado:');
console.log('    • prioridad, estado, emoji');
console.log('');
console.log('  Media (NUEVO):');
console.log('    • media_type, media_url, media_size, file_name');
console.log('');
console.log('  Scheduling y Tracking:');
console.log('    • fecha_programada, enviados, visualizados');
console.log('');
console.log('  Metadata:');
console.log('    • created_at, updated_at, created_by, conductor_id');
console.log('\n✅ ¡Listo! Procede con los pasos de arriba.\n');
