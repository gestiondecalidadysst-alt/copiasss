#!/usr/bin/env node
/**
 * Comprueba la existencia de datos en Supabase para el módulo de capacitaciones.
 * Uso:
 *   SUPABASE_URL=<url> SUPABASE_KEY=<anon_or_service_key> [CONDUCTOR_ID=<id>] node backend/tools/check_supabase_capacitaciones.js
 */
const { createClient } = require('@supabase/supabase-js');

async function main() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_KEY;
  const conductorId = process.env.CONDUCTOR_ID;

  if (!url || !key) {
    console.error('ERROR: define SUPABASE_URL y SUPABASE_KEY en las variables de entorno');
    process.exit(2);
  }

  const supabase = createClient(url, key, { auth: { persistSession: false } });

  try {
    console.log('Consultando tabla `capacitaciones`...');
    const { data: caps, error: capErr } = await supabase
      .from('capacitaciones')
      .select('id, titulo, modulos, created_at')
      .order('created_at', { ascending: false })
      .limit(50);
    if (capErr) throw capErr;

    console.log(`Encontradas ${Array.isArray(caps) ? caps.length : 0} capacitacione(s) (muestra hasta 50)`);
    if (Array.isArray(caps) && caps.length > 0) {
      for (const c of caps) {
        const modCount = Array.isArray(c.modulos) ? c.modulos.length : 0;
        console.log(`- ${c.id} | ${c.titulo || '<sin titulo>'} | modulos: ${modCount} | created_at: ${c.created_at}`);
      }
    }

    console.log('\nConsultando tabla `asignaciones_capacitacion`...');
    let q = supabase.from('asignaciones_capacitacion').select('id, conductor_id, capacitacion_id, estado, etapa, fecha_asignacion, fecha_completado').order('fecha_asignacion', { ascending: false }).limit(200);
    if (conductorId) q = q.eq('conductor_id', conductorId);
    const { data: asigs, error: asErr } = await q;
    if (asErr) throw asErr;

    console.log(`Encontradas ${Array.isArray(asigs) ? asigs.length : 0} asignacione(s) (muestra hasta 200)`);
    if (Array.isArray(asigs) && asigs.length > 0) {
      for (const a of asigs.slice(0, 50)) {
        console.log(`- ${a.id} | conductor: ${a.conductor_id} | capacitacion: ${a.capacitacion_id} | estado: ${a.estado} | etapa: ${a.etapa} | asignada: ${a.fecha_asignacion} | completada: ${a.fecha_completado || '-'} `);
      }
    }

    console.log('\nComprobación completada. Si hay datos en las tablas pero el portal no los muestra, verifica:');
    console.log('- Que el usuario conductor tenga `conductor_id` válido en el token');
    console.log('- Que el token usado por el frontend sea del conductor o que el middleware `roleMiddleware` permita el acceso');
    console.log('- Que la columna `modulos` en `capacitaciones` contenga el JSON esperado');

    process.exit(0);
  } catch (err) {
    console.error('Error al consultar Supabase:', err.message || err);
    process.exit(1);
  }
}

main();
