#!/usr/bin/env node
/**
 * Script de verificación: consulta /api/portal/conductor/capacitaciones
 * Uso:
 *   BASE_URL=http://localhost:3000 TOKEN=<jwt> node backend/tools/verify_portal_capacitaciones.js
 * Parámetros por env:
 *   BASE_URL - URL base del backend (por defecto http://localhost:3000)
 *   TOKEN    - Bearer token JWT del conductor
 */
const axios = require('axios');

async function main() {
  const baseUrl = process.env.BASE_URL || 'http://localhost:3000';
  const token = process.env.TOKEN;

  if (!token) {
    console.error('ERROR: debes definir la variable de entorno TOKEN con el JWT del conductor');
    process.exit(2);
  }

  try {
    const res = await axios.get(`${baseUrl.replace(/\/+$/,'')}/api/portal/conductor/capacitaciones`, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json'
      },
      timeout: 15000
    });

    console.log('Respuesta recibida:');
    console.log(JSON.stringify(res.data, null, 2));
    process.exit(0);
  } catch (err) {
    if (err.response) {
      console.error('Error en la petición:', err.response.status, err.response.data || err.response.statusText);
    } else {
      console.error('Error:', err.message);
    }
    process.exit(1);
  }
}

main();
