/**
 * Script para ejecutar la migración 011: Portal del Conductor y Capacitaciones
 * Uso: node ejecutar_migracion_011.js
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Error: Faltan credenciales de Supabase en .env');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

const COMANDOS = [
  {
    desc: 'Agregar columna conductor_id a usuarios',
    sql: `ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS conductor_id UUID REFERENCES conductores(id) ON DELETE SET NULL`,
  },
  {
    desc: 'Crear índice idx_usuarios_conductor_id',
    sql: `CREATE INDEX IF NOT EXISTS idx_usuarios_conductor_id ON usuarios(conductor_id)`,
  },
  {
    desc: 'Insertar rol conductor',
    sql: `INSERT INTO roles (nombre, descripcion) VALUES ('conductor', 'Conductor con acceso al portal de autogestión') ON CONFLICT (nombre) DO NOTHING`,
  },
  {
    desc: 'Crear tabla capacitaciones',
    sql: `CREATE TABLE IF NOT EXISTS capacitaciones (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      titulo VARCHAR(255) NOT NULL,
      descripcion TEXT,
      contenido_url TEXT,
      tipo VARCHAR(50) DEFAULT 'documento' CHECK (tipo IN ('video', 'documento', 'quiz', 'presencial')),
      duracion_minutos INTEGER DEFAULT 0,
      empresa VARCHAR(255),
      activo BOOLEAN DEFAULT true,
      created_by UUID REFERENCES usuarios(id) ON DELETE SET NULL,
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW()
    )`,
  },
  {
    desc: 'Crear índice idx_capacitaciones_empresa',
    sql: `CREATE INDEX IF NOT EXISTS idx_capacitaciones_empresa ON capacitaciones(empresa)`,
  },
  {
    desc: 'Crear índice idx_capacitaciones_activo',
    sql: `CREATE INDEX IF NOT EXISTS idx_capacitaciones_activo ON capacitaciones(activo)`,
  },
  {
    desc: 'Crear tabla asignaciones_capacitacion',
    sql: `CREATE TABLE IF NOT EXISTS asignaciones_capacitacion (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      capacitacion_id UUID NOT NULL REFERENCES capacitaciones(id) ON DELETE CASCADE,
      conductor_id UUID NOT NULL REFERENCES conductores(id) ON DELETE CASCADE,
      estado VARCHAR(50) DEFAULT 'pendiente' CHECK (estado IN ('pendiente', 'en_progreso', 'completado')),
      fecha_asignacion TIMESTAMP DEFAULT NOW(),
      fecha_completado TIMESTAMP,
      observaciones TEXT,
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW(),
      UNIQUE(capacitacion_id, conductor_id)
    )`,
  },
  {
    desc: 'Crear índice idx_asignaciones_conductor_id',
    sql: `CREATE INDEX IF NOT EXISTS idx_asignaciones_conductor_id ON asignaciones_capacitacion(conductor_id)`,
  },
  {
    desc: 'Crear índice idx_asignaciones_capacitacion_id',
    sql: `CREATE INDEX IF NOT EXISTS idx_asignaciones_capacitacion_id ON asignaciones_capacitacion(capacitacion_id)`,
  },
  {
    desc: 'Crear índice idx_asignaciones_estado',
    sql: `CREATE INDEX IF NOT EXISTS idx_asignaciones_estado ON asignaciones_capacitacion(estado)`,
  },
];

async function ejecutarComando(desc, sql) {
  try {
    const { error } = await supabase.rpc('exec_sql', { sql_query: sql });
    if (!error) {
      console.log(`  ✅ ${desc}`);
      return true;
    }

    // Fallback: intentar via REST
    const response = await fetch(`${supabaseUrl}/rest/v1/rpc/exec`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        apikey: supabaseKey,
        Authorization: `Bearer ${supabaseKey}`,
      },
      body: JSON.stringify({ sql }),
    });

    if (response.ok) {
      console.log(`  ✅ ${desc}`);
      return true;
    }

    const errText = error?.message || (await response.text().catch(() => 'error desconocido'));
    console.log(`  ⚠️  ${desc} — ${String(errText).substring(0, 120)}`);
    return false;
  } catch (err) {
    console.log(`  ⚠️  ${desc} — ${err.message.substring(0, 120)}`);
    return false;
  }
}

async function main() {
  console.log('\n╔════════════════════════════════════════════════════════════╗');
  console.log('║  MIGRACIÓN 011 – Portal del Conductor y Capacitaciones     ║');
  console.log('╚════════════════════════════════════════════════════════════╝\n');

  let ok = 0;
  let warn = 0;

  for (const { desc, sql } of COMANDOS) {
    const success = await ejecutarComando(desc, sql);
    success ? ok++ : warn++;
  }

  console.log('\n────────────────────────────────────────────────────────────');
  console.log(`  ✅ ${ok} ejecutados correctamente`);

  if (warn > 0) {
    console.log(`  ⚠️  ${warn} con advertencias`);
    console.log('\n  ➡️  Si hay advertencias, ejecuta manualmente el SQL en:');
    console.log('     Supabase Dashboard → SQL Editor → pega el contenido de:');
    console.log('     backend/migrations/011_portal_conductor_capacitaciones.sql\n');
  } else {
    console.log('\n  🎉 Migración completada sin errores.\n');
  }
}

main();
