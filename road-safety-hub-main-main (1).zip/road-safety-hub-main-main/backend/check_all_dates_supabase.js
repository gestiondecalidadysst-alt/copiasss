const supabase = require('./config/supabaseClient');

async function checkAllDates() {
  try {
    console.log('Consultando todas las fechas en Supabase...\n');
    
    // Obtener todos los registros pero solo ciertos campos
    const { data, error, count } = await supabase
      .from('EXCESOS DE VELOCIDAD')
      .select('id, created_at', { count: 'exact' });
    
    if (error) {
      console.error('Error en Supabase:', error);
      return;
    }
    
    console.log(`Total de registros en Supabase: ${count}`);
    
    // Agrupar por fecha
    const dateMap = {};
    data.forEach(row => {
      if (row.created_at) {
        const d = new Date(row.created_at).toLocaleDateString('en-CA');
        dateMap[d] = (dateMap[d] || 0) + 1;
      }
    });
    
    const sortedDates = Object.entries(dateMap)
      .sort((a, b) => b[0].localeCompare(a[0]))
      .slice(0, 15);
    
    console.log(`\n=== Últimas 15 fechas con eventos ===`);
    sortedDates.forEach(([date, count]) => {
      console.log(`${date}: ${count} eventos`);
    });
    
    const today = new Date().toLocaleDateString('en-CA');
    console.log(`\nFecha de hoy: ${today}`);
    console.log(`Eventos de hoy: ${dateMap[today] || 0}`);
    
  } catch (err) {
    console.error('Error:', err.message);
  }
}

checkAllDates();
