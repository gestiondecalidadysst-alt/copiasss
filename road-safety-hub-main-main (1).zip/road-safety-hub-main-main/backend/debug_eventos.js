async function check() {
  try {
    const res = await fetch('http://localhost:5000/api/eventos');
    const data = await res.json();
    
    console.log(`Total eventos: ${data.length}`);
    
    if (data.length > 0) {
      console.log(`\nPrimer evento completo:`);
      console.log(JSON.stringify(data[0], null, 2));
      
      // Mostrar created_at de varios eventos
      console.log(`\nMuestra de created_at en 5 eventos:`);
      for (let i = 0; i < Math.min(5, data.length); i++) {
        console.log(`  [${i}] created_at: ${data[i].created_at}`);
      }
      
      // Ver qué fechas unique tenemos
      const uniqueDates = new Set();
      data.forEach(e => {
        if (e.created_at) {
          const dateStr = new Date(e.created_at).toLocaleDateString('en-CA');
          uniqueDates.add(dateStr);
        }
      });
      
      const dates = Array.from(uniqueDates).sort().reverse().slice(0, 5);
      console.log(`\nÚltimas 5 fechas únicas:`);
      dates.forEach(d => {
        const count = data.filter(e => e.created_at && new Date(e.created_at).toLocaleDateString('en-CA') === d).length;
        console.log(`  ${d}: ${count} eventos`);
      });
    }
  } catch (err) {
    console.error('Error:', err);
  }
}

check();
