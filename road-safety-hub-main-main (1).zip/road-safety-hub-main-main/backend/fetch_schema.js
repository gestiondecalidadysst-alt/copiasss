const supabaseUrl = 'https://tcmoypkoyozgxhsioqwz.supabase.co';
const supabaseKey = 'sb_publishable_c5xZmPQ8iIJ7snTm2AtlPw_RyeXebT_';

async function fetchSchema() {
  try {
    const res = await fetch(`${supabaseUrl}/rest/v1/?apikey=${supabaseKey}`);
    const data = await res.json();
    console.log("Tablas encontradas:", Object.keys(data.definitions || {}));
    if (data.definitions) {
      for (const [tableName, definition] of Object.entries(data.definitions)) {
        console.log(`\nTabla: ${tableName}`);
        console.log(`Columnas: ${Object.keys(definition.properties).join(', ')}`);
      }
    }
  } catch (err) {
    console.error("Error fetching schema:", err);
  }
}
fetchSchema();
