const { createClient } = require('@supabase/supabase-js');
const supabaseUrl = 'https://tcmoypkoyozgxhsioqwz.supabase.co';
const supabaseKey = 'sb_publishable_c5xZmPQ8iIJ7snTm2AtlPw_RyeXebT_';
const supabase = createClient(supabaseUrl, supabaseKey);

async function test() {
  const tableNames = ['excesos de velocidad', 'excesos_de_velocidad', 'excesos-de-velocidad', 'ExcesosDeVelocidad'];
  for (let name of tableNames) {
    console.log(`Trying table: "${name}"...`);
    const { data, error } = await supabase.from(name).select('*').limit(1);
    if (!error) {
      console.log(`SUCCESS! Found table "${name}"`);
      console.log(`Columns: ${data && data.length > 0 ? Object.keys(data[0]).join(', ') : 'No rows found to infer columns'}`);
      console.log(data);
      return;
    } else {
      console.log(`Failed for "${name}":`, error.message);
    }
  }
}
test();
