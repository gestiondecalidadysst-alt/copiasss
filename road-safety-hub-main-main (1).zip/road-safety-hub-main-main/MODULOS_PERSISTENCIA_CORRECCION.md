# Verificación y Corrección: Persistencia de Módulos en Capacitaciones

## 📋 Problema Identificado

Cuando se creaban capacitaciones con módulos desde la UI, el backend intentaba guardarlos en **tablas separadas que no existían**:
- `modulos` tabla
- `videos_modulo` tabla  
- `quizzes_modulo` tabla
- `preguntas_modulo` tabla
- `opciones_modulo` tabla

Esto causaba que:
1. Fallara la inserción de módulos
2. Se revirtiera la creación completa de la capacitación
3. Los módulos nunca se guardaran en la BD

## ✅ Solución Implementada

Se modificaron dos funciones en [backend/controllers/capacitacionesController.js](backend/controllers/capacitacionesController.js):

### 1. `createCapacitacion()` - Crear capacitación con módulos
**Cambio:** Guardar módulos como **JSONB** en la columna `modulos` de la tabla `capacitaciones`

**Antes:**
```javascript
// Intentaba insertar en tablas separadas (inexistentes)
for (const mod of modulos) {
  const { data: modData } = await supabase
    .from('modulos')  // ❌ Esta tabla no existe
    .insert({ capacitacion_id: capId, ... })
    // Más inserciones en videos_modulo, quizzes_modulo, etc.
}
```

**Después:**
```javascript
// Guarda como JSONB en la capacitación
const modulosConId = modulos.map(mod => ({
  ...mod,
  id: mod.id || crypto.randomUUID?.(),
  videos: [...], // con IDs únicos
  quizzes: [...]  // con IDs únicos
}));

const { data } = await supabase
  .from('capacitaciones')
  .insert([{
    titulo,
    // ... otros campos
    modulos: modulosConId  // ✅ Guarda como JSONB
  }]);
```

### 2. `saveModulos()` - Actualizar módulos de capacitación existente
**Cambio:** Usar `update()` en lugar de intentar inserciones en tablas separadas

**Antes:**
```javascript
// Deletea de tabla inexistente y reintenta inserciones
await supabase.from('modulos').delete().eq('capacitacion_id', capId);
for (const mod of modulos) {
  // Más intentos de inserciones en tablas inexistentes
}
```

**Después:**
```javascript
// Actualiza directamente la columna JSONB
const { data } = await supabase
  .from('capacitaciones')
  .update({ modulos: modulosConId })
  .eq('id', capId);
```

## 📊 Verificación de Persistencia

Se creó el script [backend/verify_modulos_persistence.js](backend/verify_modulos_persistence.js) que verifica:

```bash
node backend/verify_modulos_persistence.js
```

**Resultados actuales:**
✅ 2 capacitaciones con módulos guardados:
- "control" → 2 módulos con videos y quizzes
- "MENEJO DE EXTINTORES" → 1 módulo con video y quiz

## 🔄 Flujo de Datos Correcto

### Crear capacitación con módulos:
```
Frontend (Capacitaciones.tsx)
  ↓
const payload = { ...form, modulos: newModulos }
  ↓
POST /api/capacitaciones
  ↓
Backend (createCapacitacion)
  ↓
INSERT INTO capacitaciones (titulo, ..., modulos: JSONB)
  ↓
✅ Módulos guardados en BD como JSONB
```

### Actualizar módulos después:
```
Frontend (ModulosEditor.tsx)
  ↓
POST /api/capacitaciones/:id/modulos
  ↓
Backend (saveModulos)
  ↓
UPDATE capacitaciones SET modulos = JSONB WHERE id = :id
  ↓
✅ Módulos actualizados en BD
```

## 🎯 Próximos Pasos (Opcional)

Si en el futuro necesitas acceder a módulos desde el frontend:

### Opción 1: Recuperar módulos con la capacitación
```javascript
// Supabase select ya incluye modulos como JSONB
const { data } = await supabase
  .from('capacitaciones')
  .select('*, modulos')
  .eq('id', capId);
// data.modulos contendrá el array de módulos completo
```

### Opción 2: Endpoint separado para módulos
```javascript
GET /api/capacitaciones/:id/modulos
→ Retorna: { modulos: [...], progreso_modulos: {...} }
```

## 📝 Cambios en Git

```
Commit: 5265f46
Message: Fix modulos persistence: save as JSONB in capacitaciones.modulos column instead of separate tables
Files: backend/controllers/capacitacionesController.js

Commit: d813331
Message: Add verification script for modules persistence
Files: backend/verify_modulos_persistence.js
```

## ✨ Conclusión

✅ **Los módulos ahora se guardan correctamente en la BD**
- Como estructura JSONB en la columna `modulos` de `capacitaciones`
- Con IDs únicos generados automáticamente
- Con datos completos (videos, quizzes, preguntas, opciones)
- Sin dependencias de tablas que no existen
