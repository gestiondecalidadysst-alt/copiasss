# Sistema de Notificaciones de Velocidad

## 📋 Descripción General

Se ha implementado un sistema completo de notificaciones de velocidad que se muestra en la **esquina inferior derecha** de la pantalla. Las notificaciones varían en estilo y contenido según el nivel de velocidad detectado.

## 🚀 Características

✅ **Notificaciones en esquina inferior derecha**
- Posicionadas fijas en `bottom-4 right-4`
- Máximo 3 notificaciones visibles simultáneamente
- Auto-eliminación después de 5-8 segundos

✅ **4 Niveles de Velocidad con estilos únicos:**
- 🟢 **BAJA** (0-80 km/h): Verde - "Velocidad normal"
- 🟡 **MEDIA** (81-100 km/h): Amarillo - "⚠️ Velocidad media"
- 🟠 **ALTA** (101-150 km/h): Naranja - "🚨 Exceso de velocidad"
- 🔴 **CRÍTICA** (>150 km/h): Rojo - "🚨🚨 ¡ALERTA CRÍTICA!"

✅ **Información en cada notificación:**
- Icono visual del nivel
- Velocidad detectada
- Placa del vehículo (formato monoespaciado)
- Ruta (opcional)
- Barra de progreso animada

✅ **Interactividad:**
- Botón para cerrar manualmente
- Animación de entrada suave
- Barra de progreso que indica tiempo restante

## 📁 Archivos Creados

```
src/
├── types/
│   └── notifications.ts              # Tipos y configuración de velocidades
├── hooks/
│   └── useSpeedNotification.ts        # Hook para manejar notificaciones
├── context/
│   └── SpeedNotificationContext.tsx   # Contexto global de notificaciones
├── components/
│   └── SpeedNotificationCenter.tsx    # Componente de visualización

Modificados:
├── App.tsx                           # Integración del Provider
└── pages/Eventos.tsx                 # Ejemplos de uso
```

## 🔧 Uso

### 1. En cualquier componente dentro de la aplicación:

```typescript
import { useSpeedNotificationContext } from '@/context/SpeedNotificationContext';

export const MiComponente = () => {
  const { addNotification } = useSpeedNotificationContext();

  const handleNuevoEvento = (placa: string, velocidad: number, ruta?: string) => {
    // Mostrar notificación
    addNotification(placa, velocidad, ruta);
  };

  return (
    <button onClick={() => handleNuevoEvento('ABC-123', 105, 'Vía Principal')}>
      Mostrar Notificación
    </button>
  );
};
```

### 2. Capturar eventos automáticamente:

```typescript
useEffect(() => {
  const fetchEventos = async () => {
    const response = await fetch('http://localhost:5000/api/eventos');
    const data = await response.json();
    
    // Mostrar notificaciones para eventos recientes
    data.slice(-3).forEach((evento) => {
      addNotification(evento.placa, evento.velocidad, evento.ruta);
    });
  };
  
  fetchEventos();
}, []);
```

## ⚙️ Configuración Personalizable

### Modificar umbrales de velocidad

En `src/types/notifications.ts`, editar `SPEED_THRESHOLDS`:

```typescript
export const SPEED_THRESHOLDS = {
  baja: { min: 0, max: 80, label: 'Baja', color: 'green', icon: '🟢' },
  media: { min: 81, max: 100, label: 'Media', color: 'yellow', icon: '🟡' },
  alta: { min: 101, max: 150, label: 'Alta', color: 'orange', icon: '🟠' },
  crítica: { min: 151, max: Infinity, label: 'Crítica', color: 'red', icon: '🔴' },
};
```

### Modificar duración de notificaciones

En `src/hooks/useSpeedNotification.ts`, cambiar `NOTIFICATION_DURATION`:

```typescript
const NOTIFICATION_DURATION = 5000; // 5 segundos (cambiar este valor)
const duration = level === 'crítica' ? 8000 : NOTIFICATION_DURATION; // Críticas duran 8s
```

### Limitar número de notificaciones visibles

En `src/components/SpeedNotificationCenter.tsx`:

```typescript
<SpeedNotificationCenter
  notifications={notifications}
  onClose={removeNotification}
  maxVisible={3}  // Cambiar este número
/>
```

## 📊 Estructura de Datos

### Interfaz SpeedNotification

```typescript
interface SpeedNotification {
  id: string;              // ID único
  placa: string;           // Placa del vehículo
  velocidad: number;       // Velocidad en km/h
  ruta?: string;           // Ruta opcional
  level: SpeedLevel;       // 'baja' | 'media' | 'alta' | 'crítica'
  timestamp: Date;         // Momento de la notificación
  message: string;         // Mensaje generado
}
```

## 🎨 Personalizar Estilos

### Cambiar colores

En `src/components/SpeedNotificationCenter.tsx`, modificar `colorClasses`:

```typescript
const colorClasses = {
  green: 'bg-green-100 border-green-300 text-green-900',   // Cambiar clases Tailwind
  yellow: 'bg-yellow-100 border-yellow-300 text-yellow-900',
  orange: 'bg-orange-100 border-orange-300 text-orange-900',
  red: 'bg-red-100 border-red-300 text-red-900',
};
```

### Cambiar posición

En `src/components/SpeedNotificationCenter.tsx`, modificar la posición del contenedor:

```typescript
return (
  <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm">
    {/* Cambiar 'bottom-4 right-4' a cualquier posición:
        - top-4 left-4     (esquina superior izquierda)
        - top-4 right-4    (esquina superior derecha)
        - bottom-4 left-4  (esquina inferior izquierda)
    */}
  </div>
);
```

## 🔌 Integración con WebSockets (Futuro)

Para notificaciones en tiempo real, el hook `useSpeedEventListener` está preparado:

```typescript
const { addNotification } = useSpeedNotificationContext();

useEffect(() => {
  // Conectar a WebSocket del servidor
  const ws = new WebSocket('ws://localhost:5000/eventos');
  
  ws.onmessage = (event) => {
    const evento = JSON.parse(event.data);
    addNotification(evento.placa, evento.velocidad, evento.ruta);
  };
  
  return () => ws.close();
}, []);
```

## 🧪 Pruebas

### Probar en la página de Eventos

1. Ir a `/eventos`
2. Crear un nuevo evento con velocidad variable
3. Ver cómo se genera la notificación automáticamente
4. Observe los diferentes estilos según la velocidad

### Código de prueba en consola

```javascript
// En cualquier página, abrir DevTools y ejecutar:
// (Requiere que el componente tenga acceso al contexto)
const notification = document.querySelector('[role="alert"]');
console.log('Notificación visible:', !!notification);
```

## 🐛 Solución de Problemas

### Notificaciones no aparecen
- Verificar que `SpeedNotificationProvider` esté en `App.tsx`
- Verificar que el componente está dentro de `<BrowserRouter>`
- Verificar la consola por errores

### Notificaciones desaparecen muy rápido
- Aumentar `NOTIFICATION_DURATION` en `useSpeedNotification.ts`
- Aumentar duración específica para nivel crítico

### Notificaciones se superponen
- Reducir `MAX_NOTIFICATIONS`
- Aumentar `gap-2` en el contenedor a `gap-3` o `gap-4`

## 📈 Estadísticas

El sistema mantiene:
- ID único para cada notificación
- Timestamp de creación
- Nivel de severidad calculado automáticamente
- Auto-cleanup después de expiración

## 🔐 Seguridad

- Sin exposición de datos sensibles
- IDs generados aleatoriamente
- Limitación de notificaciones simultáneas
- Validación de entrada (velocidad, placa)

## 📝 Notas

- Las notificaciones NO se guardan en BD (solo en memoria)
- Cada recarga de página limpia todas las notificaciones
- Se pueden agregar tantas como se desee (se mostrarán máx 3 simultáneamente)
- Compatible con todos los navegadores modernos

---

**Última actualización:** 21 de abril de 2026
