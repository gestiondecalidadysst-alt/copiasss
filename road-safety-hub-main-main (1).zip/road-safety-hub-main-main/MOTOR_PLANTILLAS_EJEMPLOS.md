# Ejemplos de Uso del Motor de Plantillas

## Ejemplo 1: En Certificados de Capacitación

```javascript
// certificadosController.js

const templatesService = require('../services/templatesService');

static async generateCertificatePDF(req, res) {
  try {
    const { asignacionId } = req.params;
    const empresa = req.usuario?.empresa || req.usuario?.email;
    
    // Obtener datos
    const { data: asignacion } = await supabase
      .from('asignaciones_capacitacion')
      .select('*, conductor(*)')
      .eq('id', asignacionId)
      .single();

    // Obtener plantilla de empresa
    const template = await templatesService.getTemplate(empresa, 'default');
    
    // Si hay plantilla, renderizar con ella
    let renderedData = asignacion;
    if (template) {
      const [rendered] = await templatesService.renderWithTemplate(
        empresa,
        [asignacion],
        'default'
      );
      renderedData = rendered;
    }

    // Generar PDF (similar a capacitaciones)
    const doc = new PDFDocument();
    
    // Usar logo de plantilla si existe
    if (template?.header_logo) {
      const logoBuffer = Buffer.isBuffer(template.header_logo)
        ? template.header_logo
        : Buffer.from(template.header_logo, 'base64');
      doc.image(logoBuffer, 40, 40, { height: 60 });
    }
    
    // Aplicar estilos de plantilla
    const titleColor = template?.title_color || '#000000';
    doc.fontSize(24).fillColor(titleColor).text('CERTIFICADO DE APTITUD');
    
    // ... resto de generación
    
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
```

## Ejemplo 2: En Reportes de Eventos de Seguridad

```javascript
// eventosReportController.js

const templatesService = require('../services/templatesService');

static async generateEventosReport(req, res) {
  try {
    const empresa = req.usuario?.empresa;
    const { desde, hasta } = req.query;
    
    // Obtener eventos
    const { data: eventos } = await supabase
      .from('eventos')
      .select('*')
      .eq('empresa', empresa)
      .gte('fecha', desde)
      .lte('fecha', hasta);

    // Renderizar con plantilla de eventos (si existe)
    const renderedEventos = await templatesService.renderWithTemplate(
      empresa,
      eventos,
      'default' // O 'eventos' si tienes plantillas específicas
    );

    // Generar Excel con estructura de plantilla
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Eventos');
    
    // Usar nombres de columnas de plantilla
    const template = await templatesService.getTemplate(empresa, 'default');
    const columnas = template?.columns_config || [
      { header: 'Fecha', fieldName: 'fecha' },
      { header: 'Tipo', fieldName: 'tipo' },
      { header: 'Severidad', fieldName: 'severidad' },
      // ...
    ];
    
    // Agregar headers
    worksheet.columns = columnas.map(c => ({ header: c.header, key: c.fieldName, width: 20 }));
    
    // Agregar datos renderizados
    renderedEventos.forEach(evento => {
      worksheet.addRow(evento);
    });
    
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="eventos.xlsx"');
    
    await workbook.xlsx.write(res);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
```

## Ejemplo 3: Crear Plantillas Específicas por Tipo

```javascript
// templatesService.js - Extensión

const getTemplateForType = async (empresa, reportType) => {
  // reportType: 'capacitacion', 'eventos', 'conduccion', 'certificado'
  const templateName = `${reportType}_default`;
  
  return await TemplateModel.getByEmpresa(empresa, templateName);
};

const importTemplateForType = async (empresa, fileBuffer, reportType) => {
  const templateName = `${reportType}_default`;
  
  const templateConfig = await TemplateEngine.parseXLSXTemplate(fileBuffer);
  
  // Validar que tiene columnas esperadas
  const requiredColumns = getRequiredColumns(reportType);
  const importedColumns = templateConfig.columns_config.map(c => c.fieldName);
  
  const hasRequiredColumns = requiredColumns.every(rc => 
    importedColumns.some(ic => ic.includes(rc))
  );
  
  if (!hasRequiredColumns) {
    throw new Error(`Plantilla debe incluir columnas: ${requiredColumns.join(', ')}`);
  }
  
  return await TemplateModel.upsert(empresa, templateName, templateConfig);
};

const getRequiredColumns = (reportType) => {
  const columnsByType = {
    'capacitacion': ['nombre', 'cedula', 'estado', 'puntaje'],
    'eventos': ['fecha', 'tipo', 'severidad'],
    'conduccion': ['conductor', 'fecha', 'tipo', 'resultado'],
    'certificado': ['nombre', 'curso', 'fecha_completado']
  };
  
  return columnsByType[reportType] || [];
};
```

## Ejemplo 4: UI para Importar por Tipo

```typescript
// ConfiguracionAvanzada.tsx

import { useState } from 'react';

const reportTypes = [
  { value: 'capacitacion', label: 'Capacitación' },
  { value: 'eventos', label: 'Eventos' },
  { value: 'conduccion', label: 'Conducción' },
  { value: 'certificado', label: 'Certificado' }
];

export function PlantillasAvanzadas() {
  const [selectedType, setSelectedType] = useState('capacitacion');
  
  return (
    <div className="space-y-4">
      <Select value={selectedType} onValueChange={setSelectedType}>
        {reportTypes.map(type => (
          <option key={type.value} value={type.value}>{type.label}</option>
        ))}
      </Select>
      
      <button onClick={() => handleUploadForType(selectedType)}>
        Importar plantilla para {reportTypes.find(t => t.value === selectedType)?.label}
      </button>
    </div>
  );
}

async function handleUploadForType(reportType: string) {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('templateName', `${reportType}_default`);
  
  const response = await fetch('/api/configuracion/plantillas/importar', {
    method: 'POST',
    body: formData,
    headers: { 'Authorization': `Bearer ${token}` }
  });
}
```

## Ejemplo 5: Validación Avanzada

```javascript
// templateEngine.js - Extensión

static validateTemplate(template, requiredFields = []) {
  // Validar campos requeridos
  if (requiredFields.length > 0) {
    const templateFields = template.columns_config.map(c => c.fieldName);
    
    const missing = requiredFields.filter(
      rf => !templateFields.some(tf => tf.includes(rf))
    );
    
    if (missing.length > 0) {
      throw new Error(`Faltan columnas requeridas: ${missing.join(', ')}`);
    }
  }
  
  // Validar estructura
  if (!template.columns_config || template.columns_config.length === 0) {
    throw new Error('Plantilla debe tener al menos una columna');
  }
  
  // Validar logo (si existe)
  if (template.header_logo && template.header_logo.length > 2 * 1024 * 1024) {
    throw new Error('Logo no debe pesar más de 2MB');
  }
  
  return true;
}

static async parseAndValidate(fileBuffer, requiredFields) {
  const template = await this.parseXLSXTemplate(fileBuffer);
  this.validateTemplate(template, requiredFields);
  return template;
}
```

## Ejemplo 6: Caché en Sesión

```javascript
// templatesService.js - Con caché

const templateCache = new Map();

const getTemplate = async (empresa, templateName = 'default') => {
  const cacheKey = `${empresa}:${templateName}`;
  
  // Buscar en caché
  if (templateCache.has(cacheKey)) {
    const cached = templateCache.get(cacheKey);
    if (Date.now() - cached.timestamp < 5 * 60 * 1000) { // 5 minutos
      return cached.data;
    }
  }
  
  // Cargar de BD
  const template = await TemplateModel.getByEmpresa(empresa, templateName);
  
  // Guardar en caché
  if (template) {
    templateCache.set(cacheKey, {
      data: template,
      timestamp: Date.now()
    });
  }
  
  return template;
};

const invalidateCache = (empresa, templateName) => {
  const cacheKey = `${empresa}:${templateName}`;
  templateCache.delete(cacheKey);
};
```

## Ejemplo 7: Historial de Cambios

```javascript
// Agregar a capacitaciones_templates table

ALTER TABLE capacitaciones_templates ADD COLUMN IF NOT EXISTS
  version INT DEFAULT 1;

ALTER TABLE capacitaciones_templates ADD COLUMN IF NOT EXISTS
  updated_by VARCHAR(255);

-- Tabla de historial
CREATE TABLE IF NOT EXISTS capacitaciones_templates_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id UUID NOT NULL REFERENCES capacitaciones_templates(id),
  version INT NOT NULL,
  changes JSONB,
  changed_at TIMESTAMP DEFAULT NOW(),
  changed_by VARCHAR(255)
);

-- Trigger para registrar cambios
CREATE OR REPLACE FUNCTION log_template_changes()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO capacitaciones_templates_history (template_id, version, changes, changed_by)
  VALUES (NEW.id, NEW.version, 
    jsonb_build_object(
      'header_text', NEW.header_text,
      'columns_config', NEW.columns_config,
      'title_color', NEW.title_color
    ),
    NEW.updated_by
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER template_changes_trigger
  AFTER UPDATE ON capacitaciones_templates
  FOR EACH ROW
  WHEN (OLD.updated_at IS DISTINCT FROM NEW.updated_at)
  EXECUTE FUNCTION log_template_changes();
```

## Resumen

El motor de plantillas es **extensible** y puede adaptarse para:
- ✅ Múltiples tipos de reporte
- ✅ Validaciones específicas
- ✅ Caché de rendimiento
- ✅ Historial de versiones
- ✅ Plantillas por rol/departamento
- ✅ Importación desde múltiples formatos

---

¿Necesitas implementar alguno de estos ejemplos?
