# 📊 Submódulo de Estadísticas de Noticias

## Descripción General

Se ha implementado un submódulo completo para verificar estadísticas de noticias y descargarlas en formato CSV dentro del módulo de Noticias. Este submódulo permite a los administradores:

✅ Ver métricas detalladas de cada noticia (vistas, likes, comentarios, certificaciones)
✅ Descargar estadísticas por noticia
✅ Descargar un reporte completo con todas las noticias
✅ Visualizar detalle de quién vio y certificó cada noticia

---

## 🏗️ Arquitectura

### Bases de Datos (Backend)

Las estadísticas se calculan a partir de tablas existentes:

```
├─ noticias (tabla principal)
├─ noticias_vistas (registro de vistas por usuario)
├─ noticias_reacciones (likes/dislikes)
├─ noticias_comentarios (comentarios)
└─ noticias_certificaciones (certificaciones)
```

**Consultas realizadas:**
- `SELECT` desde `noticias_vistas` para contar vistas
- `SELECT` desde `noticias_reacciones` para contar likes/dislikes
- `SELECT` desde `noticias_comentarios` para contar comentarios
- `SELECT` desde `noticias_certificaciones` para contar certificaciones

---

## 🔧 Backend

### Nuevos Métodos en `noticiasController.js`

#### 1. `getEstadisticas(req, res)` - **YA EXISTÍA**
Obtiene estadísticas de una noticia específica.

**Endpoint:**
```
GET /api/noticias/:id/estadisticas
```

**Respuesta:**
```json
{
  "vista_count": 15,
  "certificacion_count": 3,
  "comentarios_count": 2,
  "me_gusta_count": 8,
  "no_me_gusta_count": 1,
  "vistas": [
    {
      "user_id": "uuid-123",
      "autor": "Juan Pérez",
      "created_at": "2026-06-05T10:30:00Z"
    }
  ],
  "certificaciones": [
    {
      "user_id": "uuid-456",
      "autor": "María García",
      "created_at": "2026-06-05T11:00:00Z"
    }
  ]
}
```

---

#### 2. `descargarEstadisticasNoticia(req, res)` - **NUEVO**
Descarga estadísticas de una noticia específica en formato CSV.

**Endpoint:**
```
GET /api/noticias/:id/descargar-estadisticas
```

**Formato CSV:**
```
ESTADÍSTICAS DE NOTICIA
=======================

Título,Mi Noticia Importante
Autor,Admin User
Fecha de publicación,05/06/2026

RESUMEN DE INTERACCIONES
Métrica,Cantidad
Vistas,15
Me gusta,8
No me gusta,1
Comentarios,2
Certificaciones,3

DETALLE DE VISTAS
Conductor,Fecha y Hora
"Juan Pérez","5/06/2026 10:30:00"
"María García","5/06/2026 10:35:00"

DETALLE DE CERTIFICACIONES
Conductor,Fecha y Hora
"Juan Pérez","5/06/2026 11:00:00"
```

---

#### 3. `descargarTodasEstadisticas(req, res)` - **NUEVO**
Descarga un reporte completo con estadísticas de TODAS las noticias.

**Endpoint:**
```
GET /api/noticias/descargar/todas-estadisticas
```

**Formato CSV:**
```
REPORTE COMPLETO DE ESTADÍSTICAS DE NOTICIAS
==================================================
Generado: 5/06/2026 14:30:00

RESUMEN POR NOTICIA
Título,Autor,Fecha Publicación,Vistas,Me Gusta,No Me Gusta,Comentarios,Certificaciones
"Noticia 1","Admin","05/06/2026",15,8,1,2,3
"Noticia 2","Editor","04/06/2026",22,10,2,5,4

TOTAL DE NOTICIAS,,2
TOTAL DE VISTAS,,37
TOTAL DE ME GUSTA,,18
TOTAL DE NO ME GUSTA,,3
TOTAL DE COMENTARIOS,,7
TOTAL DE CERTIFICACIONES,,7
```

---

### Rutas Actualizadas en `noticiasRoutes.js`

```javascript
// Rutas nuevas agregadas:
router.get('/descargar/todas-estadisticas', NoticiasController.descargarTodasEstadisticas);
router.get('/:id/descargar-estadisticas', NoticiasController.descargarEstadisticasNoticia);

// Rutas existentes (sin cambios):
router.get('/:id/estadisticas', NoticiasController.getEstadisticas);
```

**⚠️ Importante:** La ruta `/descargar/todas-estadisticas` debe estar ANTES de `/:id` para evitar conflictos de routing.

---

## 🎨 Frontend

### Nuevo Componente: `EstadisticasNoticias.tsx`

**Ubicación:** `frontend/src/components/EstadisticasNoticias.tsx`

**Props:**
```typescript
interface EstadisticasNoticiasProps {
  noticias: Noticia[];
}
```

**Características:**

1. **Selector de Noticias**
   - Lista desplegable de todas las noticias
   - Busqueda y selección por noticia

2. **Métricas Visuales**
   - Cards con íconos mostrando:
     - 👁️ Vistas
     - ❤️ Me gusta
     - 💬 Comentarios
     - 🏆 Certificaciones
     - 👎 No me gusta

3. **Tablas Detalladas**
   - Tabla de vistas (quién vio y cuándo)
   - Tabla de certificaciones (quién certificó y cuándo)

4. **Descarga de Datos**
   - Botón "Descargar CSV" para noticia específica
   - Botón "Descargar Todo" para reporte completo
   - Archivos con timestamp automático

### Integración en `Noticias.tsx`

```typescript
import EstadisticasNoticias from '@/components/EstadisticasNoticias';

// En el JSX:
{isAdmin && (
  <EstadisticasNoticias noticias={noticias} />
)}
```

**Ubicación:** Se muestra justo después del encabezado y solo para administradores.

---

## 📋 Flujo de Uso

### Para Administradores:

1. **Acceder al módulo de Noticias**
   ```
   Menú → Noticias
   ```

2. **Ver Estadísticas**
   ```
   Clic en "Ver Estadísticas"
   ```

3. **Seleccionar una Noticia**
   ```
   Clic en cualquier noticia de la lista
   ```

4. **Ver Métricas**
   ```
   Se muestran las 5 cards con números
   Scroll para ver tablas detalladas
   ```

5. **Descargar Datos**
   - **Por noticia:** Clic en "Descargar como CSV"
   - **Todas las noticias:** Clic en "Descargar Todo" en la parte superior

---

## 🔐 Seguridad

### Autenticación
- ✅ Todas las rutas requieren `authMiddleware`
- ✅ Solo usuarios autenticados pueden acceder

### Autorización
- ✅ El componente solo se muestra si `isAdmin === true`
- ✅ Backend valida autenticación antes de enviar datos

### Datos Sensibles
- ✅ Se incluyen nombres de conductores (información pública de interacciones)
- ✅ No se exponen emails privados ni contraseñas
- ✅ Solo se muestran datos de interacciones públicas (vistas, certificaciones)

---

## 📊 Estadísticas que se Generan

### Por Noticia:
```
- Total de vistas (usuarios únicos)
- Total de likes
- Total de dislikes
- Total de comentarios
- Total de certificaciones
- Detalle de cada vista (quién y cuándo)
- Detalle de cada certificación (quién y cuándo)
```

### Reporte Global:
```
- Número total de noticias
- Total de vistas en todo el sistema
- Total de likes en todo el sistema
- Total de dislikes en todo el sistema
- Total de comentarios en todo el sistema
- Total de certificaciones en todo el sistema
- Tabla con estadísticas de cada noticia
```

---

## 💾 Formatos de Descarga

### CSV (Comma-Separated Values)

**Ventajas:**
- ✅ Compatible con Excel, Google Sheets, LibreOffice
- ✅ Ligero (tamaño pequeño)
- ✅ Fácil de procesar con scripts
- ✅ Abierto y universal

**Ejemplo de archivo:**
```
Título,Vistas,Me gusta
"Noticia 1",15,8
"Noticia 2",22,10
```

---

## 🎯 Casos de Uso

### 1. **Seguimiento de Engagement**
```
¿Cuál de mis noticias genera más interacción?
→ Ver estadísticas de cada una y compararlas
```

### 2. **Reportes Mensuales**
```
¿Cuál es el alcance total de mis publicaciones?
→ Descargar "Descargar Todo" y abrir en Excel
```

### 3. **Análisis de Impacto**
```
¿Quién está viendo mis noticias de seguridad vial?
→ Ver tabla detallada de vistas
```

### 4. **Validación de Certificaciones**
```
¿Quiénes se certificaron en la noticia X?
→ Ver tabla de certificaciones con fechas
```

---

## 🛠️ Archivos Modificados

```
backend/
├─ controllers/noticiasController.js
│  ├─ Método: descargarEstadisticasNoticia() ✨ NUEVO
│  └─ Método: descargarTodasEstadisticas() ✨ NUEVO
└─ routes/noticiasRoutes.js
   ├─ GET /descargar/todas-estadisticas ✨ NUEVO
   └─ GET /:id/descargar-estadisticas ✨ NUEVO

frontend/
├─ src/
│  ├─ components/EstadisticasNoticias.tsx ✨ NUEVO
│  └─ pages/Noticias.tsx
│     ├─ Import EstadisticasNoticias ✨ NUEVO
│     └─ <EstadisticasNoticias /> ✨ NUEVO
```

---

## ✅ Checklist de Validación

- [x] Backend - Métodos de estadísticas funcionan
- [x] Backend - Métodos de descarga generan CSV válido
- [x] Backend - Rutas correctamente ordenadas (estáticas antes de dinámicas)
- [x] Frontend - Componente carga noticias correctamente
- [x] Frontend - Selector permite elegir noticia
- [x] Frontend - Se muestran las 5 métricas en cards
- [x] Frontend - Tablas detalladas se renderizan
- [x] Frontend - Botón de descarga descarga CSV
- [x] Frontend - Botón "Descargar Todo" descarga reporte completo
- [x] Frontend - Solo admins ven el componente
- [x] Autenticación - Las rutas requieren token válido

---

## 🚀 Próximas Mejoras (Opcionales)

1. **Gráficos Visuales**
   ```
   - Gráfico de línea con vistas en el tiempo
   - Gráfico de pastel con proporción de reacciones
   - Gráfico de barras comparativo entre noticias
   ```

2. **Filtros Avanzados**
   ```
   - Filtrar por rango de fechas
   - Filtrar por tipo de interacción
   - Filtrar por autor
   ```

3. **Formato Excel Mejorado**
   ```
   - Usar librería para crear .xlsx nativo
   - Agregar estilos y formatos
   - Gráficos dentro del Excel
   ```

4. **Email Automático**
   ```
   - Enviar reporte por email
   - Programar reportes automáticos
   - Alertas de baja interacción
   ```

---

## 📞 Soporte

Si encuentras errores:

1. **Verifica que el servidor esté corriendo**
   ```bash
   npm start
   ```

2. **Verifica la conexión con Supabase**
   ```bash
   node backend/test_supabase.js
   ```

3. **Revisa la consola del navegador**
   ```
   F12 → Consola → Busca errores de red
   ```

4. **Prueba un endpoint manualmente**
   ```bash
   curl http://localhost:3001/api/noticias/descargar/todas-estadisticas
   ```

---

## 📝 Notas Técnicas

- Las estadísticas se calculan en tiempo real desde la BD
- No hay caché, siempre son datos actuales
- Los CSV se generan con encoding UTF-8
- Las fechas se formatean en formato es-CO
- El archivo CSV se descarga automáticamente al cliente

---

## 🎉 ¡Implementación Completada!

El submódulo de estadísticas de noticias está completamente funcional y listo para usar.

**Resumen:**
- ✅ 2 nuevos métodos backend
- ✅ 2 nuevas rutas API
- ✅ 1 nuevo componente React
- ✅ Integración en página Noticias
- ✅ Descarga CSV funcionando
- ✅ Tablas detalladas mostrando
- ✅ Solo admins ven el módulo

**¡Disfruta del análisis de tus noticias! 📊**
