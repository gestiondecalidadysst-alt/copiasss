# Sistema de Mensajes - 5 Tipos con Soporte de Medios

## 📋 Descripción

Sistema completo para crear, enviar y gestionar 5 tipos de mensajes:
1. **Preventiva** - Alerta preventiva de exceso de velocidad
2. **Segunda** - Segunda advertencia
3. **Tercera** - Tercer llamado/reporte formal
4. **Informativa** - Mensajes informativos
5. **Broadcast** - Mensajes para difusión masiva

Cada mensaje soporta múltiples tipos de contenido:
- **Texto**: Contenido textual con variables dinámicas
- **Imagen**: JPG, PNG, GIF, WebP (max 50MB)
- **Video**: MP4, MPEG, MOV (max 50MB)
- **Audio**: MP3, WAV, OGG (max 50MB)
- **Multimedia**: Combinación de formatos

## 🗄️ Setup de Base de Datos

### Opción 1: Ejecutar migración (Recomendado)

En la carpeta `backend`, ejecuta:

```bash
npm run migrate
```

Esto creará automáticamente la tabla `mensajes` con todos los campos necesarios.

### Opción 2: SQL Manual

Si necesitas crear la tabla manualmente, ejecuta en tu instancia de Supabase:

```sql
-- Ver archivo: backend/migrations/002_create_mensajes_table.sql
```

### Opción 3: Crear Storage Bucket

En Supabase Dashboard:
1. Ve a **Storage** → **Buckets**
2. Crea un bucket llamado `mensaje-media`
3. Habilita acceso público (Public)

## 🔧 Instalación de Dependencias

```bash
cd backend
npm install multer
```

## 📁 Estructura de Archivos

```
backend/
├── migrations/
│   └── 002_create_mensajes_table.sql    (Nueva tabla)
├── models/
│   └── mensajeModel.js                   (Actualizado con media)
├── controllers/
│   └── mensajesController.js             (Actualizado)
├── services/
│   └── mensajesService.js                (Actualizado)
├── routes/
│   └── mensajesRoutes.js                 (Actualizado con upload)
└── server.js
```

## 📡 API Endpoints

### Mensajes (CRUD)

- `GET /api/mensajes` - Obtener todos
- `GET /api/mensajes/:id` - Obtener por ID
- `GET /api/mensajes/tipo/:tipo` - Filtrar por tipo
- `GET /api/mensajes/estado/:estado` - Filtrar por estado
- `POST /api/mensajes` - Crear nuevo
- `PUT /api/mensajes/:id` - Actualizar
- `DELETE /api/mensajes/:id` - Eliminar

### Media Upload

- `POST /api/mensajes/media/upload` - Subir archivo
  - Form-data:
    - `file`: archivo (imagen/video/audio)
    - `tipo`: tipo de mensaje (preventiva/segunda/tercera/informativa/broadcast)

- `POST /api/mensajes/media/delete` - Eliminar archivo
  - JSON body: `{ "filePath": "path/to/file" }`

## 💻 Ejemplo de Uso - Frontend

### 1. Subir Media

```javascript
const uploadMedia = async (file, messageType) => {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('tipo', messageType);

  const res = await fetch('http://localhost:5000/api/mensajes/media/upload', {
    method: 'POST',
    body: formData,
  });
  
  const mediaData = await res.json();
  return mediaData; // { url, path, fileName, size, mimetype }
};
```

### 2. Crear Mensaje con Media

```javascript
const createMessageWithMedia = async (messageData, mediaData) => {
  const payload = {
    titulo: messageData.titulo,
    tipo: messageData.tipo,
    contenido: messageData.contenido,
    prioridad: messageData.prioridad,
    estado: messageData.estado || 'draft',
    emoji: messageData.emoji,
    destinatario: messageData.destinatario,
    
    // Media fields
    media_type: mediaData.mimetype.split('/')[0], // 'image', 'video', 'audio'
    media_url: mediaData.url,
    media_size: mediaData.size,
    file_name: mediaData.fileName,
  };

  const res = await fetch('http://localhost:5000/api/mensajes', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  return await res.json();
};
```

### 3. Enviar Mensaje

```javascript
const sendMessage = async (messageId) => {
  const res = await fetch(`http://localhost:5000/api/mensajes/${messageId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      estado: 'enviado',
      enviados: 1,
    }),
  });

  return await res.json();
};
```

## 📊 Estructura de Tabla

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | UUID | ID único |
| `titulo` | VARCHAR | Título del mensaje |
| `tipo` | VARCHAR | preventiva/segunda/tercera/informativa/broadcast |
| `contenido` | TEXT | Cuerpo del mensaje |
| `prioridad` | VARCHAR | alta/normal/baja |
| `estado` | VARCHAR | draft/enviado/programado |
| `emoji` | VARCHAR | Emoji del mensaje |
| `media_type` | VARCHAR | texto/imagen/video/audio/multimedia |
| `media_url` | TEXT | URL pública del archivo |
| `media_size` | INT | Tamaño en bytes |
| `file_name` | VARCHAR | Nombre original del archivo |
| `fecha_programada` | TIMESTAMP | Para mensajes programados |
| `conductor_id` | UUID | FK a conductores |
| `created_at` | TIMESTAMP | Fecha creación |
| `updated_at` | TIMESTAMP | Última actualización |

## 🎯 Tipos de Mensajes

### 1. Preventiva (🚨)
- Primer llamado de atención
- Alerta preventiva
- Tono cordial pero firme

### 2. Segunda (⚠️)
- Segundo llamado de atención
- Reincidencia detectada
- Tono más formal

### 3. Tercera (🔴)
- Tercer llamado
- Genera reporte formal
- Tono oficial

### 4. Informativa (📋)
- Actualizaciones
- Cambios de ruta
- Información operativa

### 5. Broadcast (📢)
- Mensajes masivos
- Múltiples destinatarios
- Comunicados generales

## ⚙️ Variables Dinámicas

Los mensajes pueden incluir variables que se reemplazan dinámicamente:

```
{{ $json.placa }}
{{ $json.velocidad_ultimo_reporte }}
{{ $json.ruta_ultimo_reporte }}
{{ $json.conductor }}
{{ $json.fecha }}
```

## 🔐 Seguridad

- RLS habilitado en tabla
- Validación de tipos MIME
- Limite de tamaño de archivo (50MB)
- Rutas protegidas por autenticación

## 📝 Notas

- La tabla se crea con IFs NOT EXISTS
- Compatible con tabla existente de mensajes
- Migration script detecta errores de columnas faltantes
- Storage bucket debe crearse manualmente en Supabase UI

## 🚀 Próximos Pasos

1. ✅ Ejecutar migración: `npm run migrate`
2. ✅ Crear bucket: `mensaje-media`
3. ✅ Instalar dependencias: `npm install multer`
4. ✅ Actualizar frontend (Mensajes.tsx)
5. ✅ Probar endpoints con Postman/Insomnia
