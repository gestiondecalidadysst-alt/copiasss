# Motor de Plantillas - Documentación Completa

## Resumen

El **Motor de Plantillas** es un sistema reusable que permite a las empresas importar plantillas XLSX personalizadas para generar reportes, certificados y otros documentos de capacitación con su branding y estructura específica.

## Arquitectura

### Componentes Principales

1. **Base de Datos** (`capacitaciones_templates`)
   - Almacena plantillas por empresa
   - Campos: encabezado, pie, logo, configuración de columnas, estilos

2. **Modelo** (`templateModel.js`)
   - Abstracción de datos
   - Métodos CRUD

3. **Motor** (`templateEngine.js`)
   - Parsea archivos XLSX
   - Extrae estructura y estilos
   - Renderiza datos con formato de plantilla

4. **Servicio** (`templatesService.js`)
   - Orquesta importación y uso
   - Integra modelo + motor

5. **Controlador** (`configuracionController.js`)
   - Expone endpoints HTTP
   - Maneja autenticación

6. **Rutas** (`configuracionRouter.js`)
   - Define endpoints API

7. **UI** (`Configuracion.tsx`)
   - Interfaz para subir plantillas

## Flujo de Importación

```
Usuario sube archivo XLSX
        ↓
Frontend envía a POST /api/configuracion/plantillas/importar
        ↓
TemplateEngine.parseXLSXTemplate() extrae estructura
        ↓
TemplatesService.importTemplate() valida y procesa
        ↓
TemplateModel.upsert() guarda en BD
        ↓
Plantilla disponible para futuros reportes
```

## Uso: Importar Plantilla

### 1. Preparar Archivo XLSX

La plantilla debe tener:
- **Fila 1**: Encabezado con nombres de columnas
  - Ejemplo: `Nombre | Cédula | Cargo | Estado | Calificación | Firma`
- **Fila 2 (opcional)**: Texto de encabezado
- **Fila 3 (opcional)**: Texto de pie de página
- **Imágenes (opcional)**: Logo en celda A1 (se extrae automáticamente)
- **Colores**: Formato automático de celdas del encabezado

### 2. Subir en UI

1. Ir a Configuración → Plantillas de Reportes
2. Hacer click en "Importar plantilla XLSX"
3. Seleccionar archivo
4. Sistema extrae automáticamente:
   - Nombres de columnas
   - Encabezado
   - Logo
   - Estilos (colores)

### 3. Verificar Importación

```bash
# En BD Supabase
SELECT * FROM capacitaciones_templates 
WHERE empresa = 'tu_empresa' 
AND template_name = 'default';
```

## Uso: Generar Reportes con Plantilla

### En Backend

```javascript
// capacitacionesController.js
const templatesService = require('../services/templatesService');

// Generar PDF con plantilla
await CapacitacionesController._generatePDFWithTemplate(
  res,
  capacitacion,
  asignaciones,
  'todos',
  empresa,
  certificadoConfig,
  brandingConfig,
  reportHeader,
  reportFooter
);
```

### Flujo Automático

Cuando se descarga un reporte:
1. Sistema busca plantilla de la empresa
2. Si existe → Aplica estructura de plantilla
3. Si no existe → Usa diseño por defecto

## API Endpoints

### GET /api/configuracion/plantillas
Obtener todas las plantillas de la empresa

**Response:**
```json
[
  {
    "id": "uuid",
    "template_name": "default",
    "header_text": "...",
    "columns_config": [...],
    "title_color": "#1A1A2E"
  }
]
```

### POST /api/configuracion/plantillas/importar
Importar plantilla desde archivo XLSX

**Form Data:**
- `file`: archivo .xlsx
- `templateName`: nombre de plantilla (default: "default")

**Response:**
```json
{
  "success": true,
  "message": "Plantilla importada correctamente",
  "template": { ... }
}
```

### PUT /api/configuracion/plantillas/:templateName
Actualizar metadatos de plantilla

**Body:**
```json
{
  "header_text": "Nuevo encabezado",
  "footer_text": "Nuevo pie",
  "title_color": "#FF0000"
}
```

### DELETE /api/configuracion/plantillas/:id
Eliminar plantilla

**Response:**
```json
{
  "message": "Plantilla eliminada"
}
```

## Mapeo Automático de Campos

El motor normaliza nombres de columnas:

| Nombre en XLSX | Mapea a | Formato |
|---|---|---|
| Nombre / Name | conductor.nombre | String |
| Cédula / Cedula / Doc | conductor.cedula | String |
| Cargo | conductor.cargo | String |
| Estado / Status | asignacion.estado | Capitalizado |
| Fecha / Date | asignacion.fecha_completado | dd/mm/yyyy |
| Resultado / Score | asignacion.quiz_puntaje | "X%" |
| Firma | firma | String |

## Ejemplo: Crear Plantilla Personalizada

### 1. Crear Excel con esta estructura:

```
[Logo en A1:B3]  | Empresa XYZ - Reporte de Capacitación
|
Nombre | Cédula | Cargo | Estado | Calificación | Firma
John Doe | 12345 | Manager | Completado | 95% | _____
Jane Smith | 54321 | Analyst | Pendiente | -- | _____

Pie de página: "Confidencial - contacto@empresa.com"
```

### 2. Guardar como .xlsx

### 3. Ir a Configuración → Importar

### 4. Sistema automáticamente:
- Extrae logo
- Detecta columnas
- Guarda estructura
- Aplica a futuros reportes

## Extensión: Usar en Otros Módulos

Para usar en certificados, reportes de eventos, etc.:

```javascript
// En cualquier controlador
const templatesService = require('../services/templatesService');

// Obtener plantilla
const template = await templatesService.getTemplate(empresa, 'default');

// Renderizar datos
const rendered = await templatesService.renderWithTemplate(
  empresa,
  datosArray,
  'default'
);

// Usar en generador (PDF, Excel, etc.)
// template.header_logo → Buffer para dibujar
// template.header_text → Encabezado
// rendered → Datos formateados con estilos
```

## Validación de Plantillas

### Requerimientos:
- ✅ Archivo .xlsx o .xls
- ✅ Primera fila con nombres de columna
- ❌ Tabla sin estructura completa → Error claro

### Errores Comunes:

| Error | Causa | Solución |
|---|---|---|
| "No se encontró hoja" | Archivo Excel vacío | Agregar datos a hoja 1 |
| "No se proporcionó archivo" | Upload fallido | Reintenta o verifica conexión |
| "Error parseando XLSX" | Formato inválido | Guardar como .xlsx moderno |

## Performance

- **Parsing XLSX**: < 500ms para plantillas < 5MB
- **Rendering**: < 100ms por 1000 filas
- **Cache BD**: Plantillas en sesión tras primer uso

## Seguridad

✅ **Validaciones:**
- Solo empresa propietaria puede acceder
- Autenticación requerida
- Validación de tipo MIME
- Límite de tamaño de archivo

✅ **RLS Policy:**
```sql
POLICY "Permitir acceso a templates propias"
  ON capacitaciones_templates
  USING (empresa = current_setting('request.headers')::json->>'X-Company')
```

## Próximas Mejoras

- [ ] Múltiples plantillas por empresa
- [ ] Plantillas para diferentes tipos de reporte
- [ ] Editor visual de plantillas
- [ ] Importar desde Google Sheets
- [ ] Exportar plantilla como template (para clientes)
