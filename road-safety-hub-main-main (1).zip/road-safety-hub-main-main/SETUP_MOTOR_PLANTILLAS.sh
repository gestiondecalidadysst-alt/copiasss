#!/bin/bash

# Script de setup del Motor de Plantillas
# Este script configura la base de datos y verifica que todo esté listo

echo "🚀 Configurando Motor de Plantillas..."
echo ""

# 1. Crear tabla en Supabase
echo "📋 Paso 1: Crear tabla en Supabase"
echo "================================"
echo ""
echo "Debes ejecutar este SQL en el Supabase SQL Editor:"
echo "https://app.supabase.com/project/[YOUR_PROJECT_ID]/sql"
echo ""
echo "---"

cat << 'EOF'
-- Crear tabla para plantillas de capacitaciones por empresa
CREATE TABLE IF NOT EXISTS capacitaciones_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  empresa VARCHAR(255) NOT NULL,
  template_name VARCHAR(255) NOT NULL DEFAULT 'default',
  
  -- Encabezado
  header_text VARCHAR(500),
  header_logo BYTEA,
  header_logo_height SMALLINT DEFAULT 60,
  
  -- Pie de página
  footer_text VARCHAR(500),
  footer_logo BYTEA,
  footer_logo_height SMALLINT DEFAULT 40,
  
  -- Estructura de columnas
  columns_config JSONB DEFAULT '{}'::jsonb,
  
  -- Estilos
  title_color VARCHAR(10),
  header_bg_color VARCHAR(10),
  border_color VARCHAR(10),
  font_family VARCHAR(50),
  
  -- Metadata
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(empresa, template_name)
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_templates_empresa ON capacitaciones_templates(empresa);
CREATE INDEX IF NOT EXISTS idx_templates_created_at ON capacitaciones_templates(created_at DESC);

-- RLS Policy
ALTER TABLE capacitaciones_templates ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Permitir acceso a templates propias" ON capacitaciones_templates;
CREATE POLICY "Permitir acceso a templates propias"
  ON capacitaciones_templates
  FOR ALL
  USING (
    empresa = current_setting('request.headers')::json->>'X-Company' 
    OR empresa = (SELECT email FROM auth.users WHERE id = auth.uid())
  );
EOF

echo "---"
echo ""
echo "Copia el SQL anterior y pégalo en Supabase."
echo ""

# 2. Verificar dependencias
echo "📦 Paso 2: Verificar dependencias de Node"
echo "========================================"

# Verificar que exeljs está instalado
if grep -q "exceljs" backend/package.json 2>/dev/null; then
  echo "✅ exceljs: instalado"
else
  echo "⚠️  exceljs: NO INSTALADO"
  echo "   Ejecuta: npm install exceljs --save"
fi

# Verificar multer
if grep -q "multer" backend/package.json 2>/dev/null; then
  echo "✅ multer: instalado"
else
  echo "⚠️  multer: NO INSTALADO"
  echo "   Ejecuta: npm install multer --save"
fi

echo ""

# 3. Listar archivos creados
echo "📁 Paso 3: Archivos creados"
echo "=========================="

files=(
  "backend/migrations/012_create_capacitaciones_templates.sql"
  "backend/models/templateModel.js"
  "backend/services/templateEngine.js"
  "backend/services/templatesService.js"
  "backend/routes/configuracionRouter.js"
  "frontend/src/pages/Configuracion.tsx"
  "MOTOR_PLANTILLAS_DOCUMENTACION.md"
)

for file in "${files[@]}"; do
  if [ -f "$file" ]; then
    echo "✅ $file"
  else
    echo "❌ $file - NO ENCONTRADO"
  fi
done

echo ""

# 4. Instrucciones de prueba
echo "🧪 Paso 4: Pruebas"
echo "================"
echo ""
echo "1. Inicia el backend: npm start"
echo "2. Inicia el frontend: npm run dev"
echo "3. Ve a Configuración → Plantillas de Reportes"
echo "4. Sube un archivo Excel de ejemplo"
echo "5. Descarga un reporte de capacitación para ver la plantilla aplicada"
echo ""

echo "✅ Setup completado!"
echo ""
echo "📖 Documentación: MOTOR_PLANTILLAS_DOCUMENTACION.md"
