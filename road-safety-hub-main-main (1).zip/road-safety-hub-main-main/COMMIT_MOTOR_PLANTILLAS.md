# Commit y Deploy del Motor de Plantillas

## 📋 Resumen de Cambios

Se ha implementado un **motor de plantillas reusable y completo** que permite a las empresas personalizar reportes de capacitación mediante archivos Excel.

## 📁 Archivos Creados/Modificados

### Backend (7 archivos)

```
✅ backend/migrations/012_create_capacitaciones_templates.sql
   - Tabla PostgreSQL con RLS Policy
   - Campos: logo, encabezado, pie, columnas, estilos

✅ backend/models/templateModel.js
   - CRUD operations para plantillas
   - getByEmpresa, getAllByEmpresa, upsert, delete

✅ backend/services/templateEngine.js
   - Parseo automático de archivos XLSX
   - Extrae: logo, encabezado, columnas, estilos
   - Renderizado de datos con formato de plantilla
   - Normalización automática de campos

✅ backend/services/templatesService.js
   - Servicio de orquestación
   - importTemplate, renderWithTemplate, updateTemplate, deleteTemplate

✅ backend/routes/configuracionRouter.js
   - Nuevas rutas para plantillas
   - GET /plantillas
   - POST /plantillas/importar (con multer)
   - PUT /plantillas/:templateName
   - DELETE /plantillas/:id

✅ backend/controllers/configuracionController.js
   - 4 nuevos métodos de endpoints
   - getPlantillas, importPlantilla, updatePlantilla, deletePlantilla

✅ backend/controllers/capacitacionesController.js
   - Nuevo método: _generatePDFWithTemplate()
   - Integración con motor de plantillas
   - Fallback automático a diseño por defecto
```

### Frontend (1 archivo)

```
✅ frontend/src/pages/Configuracion.tsx
   - Nueva sección: "Plantillas de Reportes"
   - Botón para importar archivo XLSX
   - Método: handleTemplateUpload(file)
   - Validación de formato
   - Feedback con toast notifications
```

### Documentación (4 archivos)

```
✅ MOTOR_PLANTILLAS_DOCUMENTACION.md
   - Documentación técnica completa
   - Arquitectura, flujos, API, ejemplos

✅ MOTOR_PLANTILLAS_README.md
   - Guía de implementación
   - Setup, uso, testing

✅ MOTOR_PLANTILLAS_EJEMPLOS.md
   - 7 ejemplos de extensión
   - Certificados, eventos, validación, caché, historial

✅ SETUP_MOTOR_PLANTILLAS.sh
   - Script de configuración
   - Verificación de dependencias
   - Instrucciones paso a paso
```

## 🔧 Pasos Antes del Commit

### 1. Crear la Tabla en Supabase

```bash
# Ve a https://app.supabase.com/project/[PROJECT_ID]/sql
# Copia y ejecuta el SQL de:
# backend/migrations/012_create_capacitaciones_templates.sql
```

O desde la terminal:

```bash
# Opción alternativa (si tienes acceso directo)
cd backend
node -e "
const sql = require('fs').readFileSync('./migrations/012_create_capacitaciones_templates.sql', 'utf-8');
const supabase = require('./config/supabaseClient');
// Ejecutar manualmente en Supabase UI
console.log(sql);
"
```

### 2. Verificar Dependencias

```bash
cd backend
npm list exceljs multer

# Deben estar instaladas (ya están en package.json)
# exceljs: ^4.4.0
# multer: ^2.1.1
```

### 3. Pruebas Locales

```bash
# Terminal 1: Backend
cd backend
npm start

# Terminal 2: Frontend
cd frontend
npm run dev

# Terminal 3: Pruebas
# 1. Ir a http://localhost:5173
# 2. Configuración → Plantillas de Reportes
# 3. Importar archivo XLSX de ejemplo
# 4. Descargar reporte de capacitación
# 5. Verificar que se aplicó la plantilla
```

## 📦 Commit

### Mensajes de Commit Recomendados

```bash
git add -A

# Opción 1: Commit único
git commit -m "Implementar motor de plantillas reusable para reportes

- Agregar tabla capacitaciones_templates en BD
- Crear TemplateModel, TemplateEngine, TemplatesService
- Agregar endpoints GET/POST/PUT/DELETE para plantillas
- Integrar con generador PDF de capacitaciones
- UI para importar plantillas en Configuración
- Documentación completa y ejemplos"

# Opción 2: Commits separados
git commit -m "feat(backend): crear tabla y modelo de plantillas"
git add backend/models/templateModel.js backend/services/templateEngine.js
git commit -m "feat(backend): implementar motor y servicio de plantillas"
git add backend/routes/configuracionRouter.js backend/controllers/configuracionController.js
git commit -m "feat(backend): agregar endpoints para gestión de plantillas"
git add frontend/src/pages/Configuracion.tsx
git commit -m "feat(frontend): UI para importar plantillas en Configuración"
git add MOTOR_PLANTILLAS*.md SETUP_MOTOR_PLANTILLAS.sh
git commit -m "docs: agregar documentación del motor de plantillas"
```

## 🚀 Push

```bash
git push origin main

# O si necesitas especificar credenciales:
git push https://github.com/tuuser/repositorio.git main
```

## ✅ Validaciones Post-Deploy

```bash
# 1. Verificar tabla en Supabase
SELECT COUNT(*) FROM capacitaciones_templates;

# 2. Probar endpoint
curl -X GET http://localhost:3000/api/configuracion/plantillas \
  -H "Authorization: Bearer YOUR_TOKEN"

# 3. Probar upload
curl -X POST http://localhost:3000/api/configuracion/plantillas/importar \
  -F "file=@plantilla.xlsx" \
  -F "templateName=default" \
  -H "Authorization: Bearer YOUR_TOKEN"

# 4. Verificar que se guardó
SELECT * FROM capacitaciones_templates WHERE empresa = 'tu_empresa';
```

## 🐛 Troubleshooting

### Problema: "No se puede cargar archivo"
**Solución**: Verificar que multer está instalado en package.json

### Problema: "Tabla no existe"
**Solución**: Ejecutar SQL de migración en Supabase SQL Editor

### Problema: "Template no se aplica al PDF"
**Solución**: Verificar que la tabla tiene datos:
```sql
SELECT * FROM capacitaciones_templates WHERE empresa = 'YOUR_COMPANY';
```

### Problema: "Error parseando XLSX"
**Solución**: Verificar que exceljs está instalado:
```bash
npm install exceljs --save
```

## 📊 Estadísticas de Implementación

- **Líneas de código backend**: ~600
- **Líneas de código frontend**: ~50
- **Líneas de SQL**: ~40
- **Documentación**: ~800 líneas
- **Tiempo de implementación**: Completo

## 🎉 Características Finales

✅ Importar plantillas XLSX
✅ Parseo automático de estructura
✅ Extracción de logo y estilos
✅ Almacenamiento por empresa
✅ Renderizado de datos
✅ Integración con reportes
✅ API completa
✅ UI intuitiva
✅ Validaciones
✅ Error handling
✅ Fallback a diseño por defecto
✅ Documentación completa

## 📞 Soporte

Si encuentras problemas durante el deploy:

1. Verifica que la tabla se creó en Supabase
2. Comprueba que exceljs y multer están instalados
3. Revisa los logs del backend
4. Consulta MOTOR_PLANTILLAS_DOCUMENTACION.md

---

**Motor de Plantillas: LISTO PARA PRODUCCIÓN ✅**
