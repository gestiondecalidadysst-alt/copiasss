# Sistema de Roles y Gestión de Usuarios

## 📋 Descripción

Se ha implementado un sistema completo de roles y autenticación para la aplicación Road Safety Hub con los siguientes componentes:

- **2 Roles**: Administrador y Usuario/Cliente
- **Autenticación JWT**: Con tokens seguros
- **Gestión de Usuarios**: Módulo completo para administradores
- **Protección de Rutas**: Por rol y autenticación
- **Backend API REST**: Con validaciones y seguridad

---

## 🚀 Instalación

### 1. Instalar Dependencias del Backend

```bash
cd backend
npm install
```

Esto instalará las nuevas dependencias:
- `bcryptjs`: Para hash de contraseñas
- `jsonwebtoken`: Para autenticación JWT

### 2. Ejecutar Migraciones en Supabase

Ejecuta la migración para crear las tablas de usuarios y roles:

```bash
node runMigration.js 004_create_users_and_roles.sql
```

Esto creará:
- Tabla `usuarios`: Almacena los usuarios del sistema
- Tabla `roles`: Define los roles (admin, usuario)
- Tabla `usuario_roles`: Relación usuario-rol
- Tabla `usuario_auditoria`: Registro de acciones (opcional)
- Políticas RLS: Seguridad a nivel de fila

### 3. Crear Usuario Administrador Inicial

```bash
node crear_admin_inicial.js
```

Esto creará el primer usuario administrador con:
- **Email**: admin@translogistica.com
- **Contraseña**: admin123
- **Rol**: admin

⚠️ **IMPORTANTE**: Cambia esta contraseña después del primer login.

### 4. Configurar Variables de Entorno

Agrega a tu archivo `.env` del backend:

```env
JWT_SECRET=tu_secreto_super_seguro_cambiar_en_produccion
PORT=3001
```

### 5. Iniciar el Backend

```bash
cd backend
npm start
```

El servidor estará corriendo en `http://localhost:3001`

### 6. Iniciar el Frontend

```bash
cd road-safety-hub-main
npm run dev
```

La aplicación estará en `http://localhost:5173`

---

## 🔐 Funcionalidades Implementadas

### Backend

#### Modelos
- `usuarioModel.js`: CRUD completo de usuarios
  - Crear, leer, actualizar, eliminar usuarios
  - Asignar/remover roles
  - Cambiar contraseñas con validación
  - Activar/desactivar usuarios

#### Controladores
- `authController.js`: Autenticación
  - Login con JWT
  - Obtener perfil del usuario
  - Cambiar contraseña
  - Verificar token

- `usuariosController.js`: Gestión de usuarios (solo admin)
  - CRUD de usuarios
  - Asignar roles
  - Activar/desactivar usuarios

#### Middlewares
- `authMiddleware.js`: Middleware de autenticación JWT
- `roleMiddleware()`: Middleware de verificación de roles
- `adminMiddleware`: Solo permite acceso a administradores

#### Rutas

**Autenticación** (`/api/auth`)
- `POST /api/auth/login` - Login
- `POST /api/auth/logout` - Logout
- `GET /api/auth/me` - Obtener perfil
- `POST /api/auth/cambiar-password` - Cambiar contraseña
- `GET /api/auth/verificar-token` - Verificar token

**Usuarios** (`/api/usuarios`) - Solo Admin
- `GET /api/usuarios` - Listar todos
- `GET /api/usuarios/:id` - Obtener por ID
- `POST /api/usuarios` - Crear usuario
- `PUT /api/usuarios/:id` - Actualizar usuario
- `DELETE /api/usuarios/:id` - Eliminar usuario
- `POST /api/usuarios/:id/roles` - Asignar rol
- `DELETE /api/usuarios/:id/roles` - Remover rol
- `PATCH /api/usuarios/:id/toggle-activo` - Activar/Desactivar

### Frontend

#### Stores
- `authStore.ts`: Estado de autenticación
  - Login/Logout
  - Manejo de usuario y token
  - Carga de usuario desde token

#### Servicios
- `authService.ts`: Llamadas API de autenticación
- `usuariosService.ts`: Llamadas API de gestión de usuarios

#### Componentes
- `RoleProtectedRoute.tsx`: Protección de rutas por rol
- `AppSidebar.tsx`: Menú lateral con opciones según rol
- `AppHeader.tsx`: Cabecera con información del usuario y rol

#### Páginas
- `Usuarios.tsx`: Módulo completo de gestión de usuarios
  - Listar usuarios
  - Crear usuario (email, nombre, empresa, password, rol)
  - Editar usuario
  - Eliminar usuario
  - Activar/Desactivar usuario
  - Interfaz moderna y responsiva

#### Hooks Personalizados
- `useCanAccess(role)`: Verificar si el usuario tiene acceso
- `useIsAdmin()`: Verificar si el usuario es admin
- `ConditionalRender`: Renderizar solo si tiene el rol requerido

---

## 👤 Uso del Sistema

### Login

1. Abre la aplicación en el navegador
2. Ingresa las credenciales:
   - Email: admin@translogistica.com
   - Contraseña: admin123
3. Presiona "Iniciar sesión"

### Crear Usuarios (Solo Admin)

1. Inicia sesión como administrador
2. Ve a la opción "Usuarios" en el menú lateral
3. Presiona "Crear Usuario"
4. Completa el formulario:
   - Email
   - Nombre
   - Empresa (opcional)
   - Contraseña
   - Rol (Usuario/Cliente o Administrador)
5. Presiona "Guardar"

### Gestionar Usuarios

Como administrador puedes:
- **Editar**: Actualizar nombre y empresa
- **Eliminar**: Borrar usuario (no se puede eliminar el único admin)
- **Activar/Desactivar**: Cambiar estado del usuario
- **Ver detalles**: Email, nombre, empresa, rol, estado

### Diferencias entre Roles

**Administrador**:
- Acceso completo a todas las funcionalidades
- Puede ver y gestionar usuarios
- Opción "Usuarios" visible en el menú

**Usuario/Cliente**:
- Acceso a todas las funcionalidades excepto gestión de usuarios
- No puede crear, editar o eliminar usuarios
- Opción "Usuarios" NO visible en el menú

---

## 🔒 Seguridad

### Backend
- Contraseñas hasheadas con bcrypt (10 rounds)
- Autenticación con JWT (expira en 24h)
- Middleware de autenticación en todas las rutas protegidas
- Middleware de autorización por rol
- Row Level Security (RLS) en Supabase
- Validaciones de entrada en controladores

### Frontend
- Token almacenado en localStorage
- Interceptor de axios para agregar token automáticamente
- Redirección automática a login si el token es inválido (401)
- Protección de rutas con `ProtectedRoute`
- Protección adicional por rol en componentes

### Base de Datos
- Políticas RLS configuradas
- Solo admin puede ver/crear/editar usuarios
- Usuarios solo pueden ver su propio perfil
- Índices para mejor rendimiento

---

## 🧪 Pruebas

### Probar Autenticación

```bash
# Login
curl -X POST http://localhost:3001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@translogistica.com", "password": "admin123"}'

# Obtener perfil (reemplaza TOKEN con el token recibido)
curl http://localhost:3001/api/auth/me \
  -H "Authorization: Bearer TOKEN"
```

### Probar Gestión de Usuarios

```bash
# Crear usuario (requiere token de admin)
curl -X POST http://localhost:3001/api/usuarios \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer TOKEN" \
  -d '{
    "email": "usuario@example.com",
    "nombre": "Juan Pérez",
    "empresa": "Mi Empresa",
    "password": "password123",
    "rol": "usuario"
  }'

# Listar usuarios
curl http://localhost:3001/api/usuarios \
  -H "Authorization: Bearer TOKEN"
```

---

## 📝 Notas Importantes

1. **Primer Login**: Usa admin@translogistica.com / admin123
2. **Cambiar Contraseña**: Hazlo desde "Configuración" después del primer login
3. **JWT Secret**: Cambia `JWT_SECRET` en producción
4. **RLS**: Las políticas de Supabase funcionan en conjunto con los middlewares
5. **Permisos**: Solo admin puede acceder a `/api/usuarios`
6. **Token**: Válido por 24 horas, después se requiere nuevo login

---

## 🐛 Solución de Problemas

### Error: "Token no proporcionado"
- Verifica que el token esté en localStorage
- Asegúrate de que el header `Authorization` tenga el formato: `Bearer TOKEN`

### Error: "No tienes permiso"
- El usuario no tiene el rol requerido
- Verifica que el usuario tenga rol "admin" para acceder a usuarios

### Error al crear usuario: "Email ya registrado"
- El email ya existe en la base de datos
- Usa un email diferente

### No aparece opción "Usuarios" en el menú
- El usuario no es administrador
- Verifica que el rol sea "admin" en la base de datos

---

## 🔄 Próximas Mejoras (Opcional)

- Recuperación de contraseña por email
- Autenticación de dos factores (2FA)
- Permisos granulares adicionales
- Auditoría completa de acciones
- Sesiones concurrentes
- Expiración configurable de tokens
- Refresh tokens

---

## 📚 Estructura de Archivos

```
backend/
├── migrations/
│   └── 004_create_users_and_roles.sql
├── models/
│   └── usuarioModel.js
├── controllers/
│   ├── authController.js
│   └── usuariosController.js
├── middlewares/
│   └── authMiddleware.js
├── routes/
│   ├── authRoutes.js
│   └── usuariosRoutes.js
├── crear_admin_inicial.js
└── server.js

frontend/src/
├── stores/
│   └── authStore.ts
├── services/
│   ├── authService.ts
│   └── usuariosService.ts
├── components/
│   ├── RoleProtectedRoute.tsx
│   ├── AppSidebar.tsx
│   └── AppHeader.tsx
├── pages/
│   ├── Usuarios.tsx
│   └── Login.tsx
└── App.tsx
```

---

¡Sistema de roles implementado correctamente! 🎉
