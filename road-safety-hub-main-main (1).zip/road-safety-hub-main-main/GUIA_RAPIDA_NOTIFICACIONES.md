# 🚨 Guía Rápida: Sistema de Notificaciones de Velocidad

## ✅ ¿Qué se implementó?

Un **sistema completo de notificaciones** que muestra alertas en la **esquina inferior derecha** de la aplicación, variando en estilo y contenido según el nivel de velocidad detectado.

### 🎯 Características Principales

| Nivel | Velocidad | Estilo | Duración |
|-------|-----------|--------|----------|
| 🟢 Baja | 0-80 km/h | Verde | 5s |
| 🟡 Media | 81-100 km/h | Amarillo | 5s |
| 🟠 Alta | 101-150 km/h | Naranja | 5s |
| 🔴 Crítica | >150 km/h | Rojo | 8s |

---

## 📁 Archivos Nuevos Creados

```
✨ NUEVOS ARCHIVOS:
├── src/types/notifications.ts                    (Tipos y configuración)
├── src/hooks/useSpeedNotification.ts            (Hook de lógica)
├── src/context/SpeedNotificationContext.tsx     (Contexto global)
├── src/components/SpeedNotificationCenter.tsx   (Componente UI)
├── NOTIFICACIONES_VELOCIDAD.md                  (Documentación completa)
├── EJEMPLOS_NOTIFICACIONES.tsx                  (10 ejemplos de uso)

✏️ MODIFICADOS:
├── src/App.tsx                                   (Integración del Provider)
├── src/pages/Eventos.tsx                        (Ejemplos de uso)
```

---

## 🚀 Cómo Usar

### 1. **En la página de Eventos** (Ya integrado ✅)

```tsx
// Ya funciona automáticamente:
// - Al cargar eventos: muestra notificaciones de los últimos 3
// - Al crear evento: muestra notificación automáticamente
// - Al actualizar evento: muestra notificación actualizada
```

**Pruebalo:**
1. Ve a la página `/eventos`
2. Crea un nuevo evento con velocidad > 80 km/h
3. ¡Verás la notificación en la esquina inferior derecha!

---

### 2. **En cualquier otro componente**

```typescript
import { useSpeedNotificationContext } from '@/context/SpeedNotificationContext';

export const MiComponente = () => {
  const { addNotification } = useSpeedNotificationContext();

  return (
    <button onClick={() => addNotification('ABC-123', 105, 'Vía Principal')}>
      Mostrar Notificación
    </button>
  );
};
```

---

## 🎨 Ejemplo Visual

```
┌─────────────────────────────────────────────────────────┐
│                    Tu Aplicación                         │
│                                                           │
│                                                           │
│                                                           │
│                                                           │
│                                      ┌──────────────────┐│
│                                      │🔴 CRÍTICA - 160  ││
│                                      │ABC-1234          ││
│                                      │Vía Principal     ││
│                                      │[X]               ││
│                                      │████░░░░░░░░░░░  ││
│                                      └──────────────────┘│
│                                      ┌──────────────────┐│
│                                      │🟠 ALTA - 105    ││
│                                      │XYZ-5678          ││
│                                      │Calle 50          ││
│                                      │[X]               ││
│                                      │██████░░░░░░░░░░ ││
│                                      └──────────────────┘│
└─────────────────────────────────────────────────────────┘
```

---

## ⚙️ Configuración Rápida

### Cambiar umbrales de velocidad

Editar `src/types/notifications.ts`:

```typescript
export const SPEED_THRESHOLDS = {
  baja: { min: 0, max: 80, label: 'Baja', color: 'green', icon: '🟢' },
  media: { min: 81, max: 100, label: 'Media', color: 'yellow', icon: '🟡' },
  alta: { min: 101, max: 150, label: 'Alta', color: 'orange', icon: '🟠' },
  crítica: { min: 151, max: Infinity, label: 'Crítica', color: 'red', icon: '🔴' },
};
```

### Cambiar duración

Editar `src/hooks/useSpeedNotification.ts`:

```typescript
const NOTIFICATION_DURATION = 5000; // Cambiar a 3000 (3s) o 10000 (10s)
```

### Cambiar posición (esquinas)

En `src/components/SpeedNotificationCenter.tsx`:

```typescript
// Línea: <div className="fixed bottom-4 right-4 z-50...">

// Cambiar a:
// - "top-4 right-4"   = Superior derecha
// - "top-4 left-4"    = Superior izquierda
// - "bottom-4 left-4" = Inferior izquierda
```

---

## 🔌 Integración Avanzada

### Cargar notificaciones automáticamente desde API

```typescript
import { useEffect } from 'react';
import { useSpeedNotificationContext } from '@/context/SpeedNotificationContext';

export const Dashboard = () => {
  const { addNotification } = useSpeedNotificationContext();

  useEffect(() => {
    const loadEventos = async () => {
      const res = await fetch('http://localhost:5000/api/eventos');
      const eventos = await res.json();
      
      // Mostrar últimos 5 eventos
      eventos.slice(-5).forEach(e => {
        addNotification(e.placa, e.velocidad, e.ruta);
      });
    };
    
    loadEventos();
  }, [addNotification]);

  return <div>Dashboard con notificaciones</div>;
};
```

### Polling de eventos (cada 10 segundos)

```typescript
useEffect(() => {
  const interval = setInterval(async () => {
    const res = await fetch('http://localhost:5000/api/eventos');
    const eventos = await res.json();
    
    // Mostrar solo nuevos
    eventos.forEach(e => {
      if (e.velocidad > 80) {
        addNotification(e.placa, e.velocidad, e.ruta);
      }
    });
  }, 10000);
  
  return () => clearInterval(interval);
}, [addNotification]);
```

---

## 📊 API del Sistema

### Funciones disponibles

```typescript
const { 
  notifications,        // Array de notificaciones activas
  addNotification,      // (placa, velocidad, ruta?) => string (id)
  removeNotification,   // (id) => void
  clearAll              // () => void
} = useSpeedNotificationContext();
```

### Estructura de Notificación

```typescript
interface SpeedNotification {
  id: string;              // ID único
  placa: string;           // Placa del vehículo
  velocidad: number;       // Velocidad en km/h
  ruta?: string;           // Ruta opcional
  level: SpeedLevel;       // 'baja' | 'media' | 'alta' | 'crítica'
  timestamp: Date;         // Cuándo se creó
  message: string;         // Mensaje generado
}
```

---

## 🧪 Probar la Funcionalidad

### Opción 1: Desde la UI (Recomendado)

1. Abre la aplicación
2. Ve a `/eventos`
3. Crea eventos con diferentes velocidades:
   - 75 km/h → Notificación verde ✅
   - 95 km/h → Notificación amarilla ⚠️
   - 120 km/h → Notificación naranja 🚨
   - 160 km/h → Notificación roja 🚨🚨

### Opción 2: Desde la Consola del Navegador

```javascript
// Abre DevTools (F12) y pega esto en la consola:
// (Funciona si estás en una página con el contexto)

// Simular evento
const placa = 'TEST-001';
const velocidad = 125;
const ruta = 'Calle Test';

// Buscar la función (requiere que esté expuesta)
console.log('✅ Sistema de notificaciones activo');
```

---

## 🐛 Solución de Problemas

### ❌ Notificaciones no aparecen

**Causa:** El Provider no está envolviendo la aplicación

**Solución:** Verificar que `App.tsx` tenga:
```typescript
<SpeedNotificationProvider>
  <AppContent />
</SpeedNotificationProvider>
```

### ❌ Error: "useSpeedNotificationContext debe ser usado dentro de SpeedNotificationProvider"

**Causa:** Usando el hook en un componente que no está dentro del Provider

**Solución:** Verificar que el componente está dentro del árbol de componentes

### ❌ Las notificaciones desaparecen muy rápido

**Solución:** Cambiar `NOTIFICATION_DURATION` en `useSpeedNotification.ts` a un valor mayor (ej: 8000)

### ❌ Se superponen demasiadas notificaciones

**Solución:** Reducir `MAX_NOTIFICATIONS` en `useSpeedNotification.ts` o aumentar gap en CSS

---

## 📖 Documentación Completa

Para más detalles, consulta:
- `NOTIFICACIONES_VELOCIDAD.md` - Documentación técnica completa
- `EJEMPLOS_NOTIFICACIONES.tsx` - 10 ejemplos prácticos

---

## 🎯 Próximas Mejoras Sugeridas

- [ ] WebSocket para notificaciones en tiempo real
- [ ] Sonidos de alerta según nivel
- [ ] Historial persistente de notificaciones
- [ ] Notificaciones por pushes
- [ ] Integración con Smart Watch
- [ ] Reportes de notificaciones
- [ ] Umbrales personalizables por usuario

---

## ✨ Resumen

✅ **Instalado y funcionando:**
- Sistema de notificaciones en esquina inferior derecha
- 4 niveles de severidad con estilos únicos
- Auto-eliminación de notificaciones
- Integración en página de Eventos
- Fácil de usar en cualquier componente

🚀 **Listo para usar en producción**

---

**Última actualización:** 21 de abril de 2026
