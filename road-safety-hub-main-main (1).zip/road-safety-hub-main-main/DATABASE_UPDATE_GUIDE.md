# 📋 Instrucciones para Actualizar la Base de Datos Supabase

## Opción 1: Actualización Manual (Recomendado)

### Paso 1: Acceder a Supabase
1. Ve a https://supabase.com
2. Inicia sesión con tu cuenta
3. Selecciona tu proyecto: **road-safety-hub**

### Paso 2: Abrir el Editor SQL
1. En el panel izquierdo, ve a **SQL Editor**
2. Haz clic en **+ New Query**

### Paso 3: Ejecutar el SQL

Copia y pega el siguiente comando en el editor SQL:

```sql
-- Agregar nuevos campos a la tabla mensajes
ALTER TABLE mensajes
ADD COLUMN IF NOT EXISTS destinatario VARCHAR(255),
ADD COLUMN IF NOT EXISTS asunto VARCHAR(255),
ADD COLUMN IF NOT EXISTS prioridad VARCHAR(50) DEFAULT 'normal',
ADD COLUMN IF NOT EXISTS emoji VARCHAR(50) DEFAULT '📬',
ADD COLUMN IF NOT EXISTS estado VARCHAR(50) DEFAULT 'draft';
```

### Paso 4: Ejecutar
1. Presiona **Ctrl + Enter** o el botón ▶️ **Run**
2. Deberías ver: `✓ Success. No rows returned`

---

## ✅ Columnas Agregadas

| Campo | Tipo | Descripción | Por defecto |
|-------|------|-------------|------------|
| **destinatario** | VARCHAR(255) | A quién va dirigido el mensaje | NULL |
| **asunto** | VARCHAR(255) | Asunto del mensaje | NULL |
| **prioridad** | VARCHAR(50) | alta/normal/baja | 'normal' |
| **emoji** | VARCHAR(50) | Emoji personalizado | '📬' |
| **estado** | VARCHAR(50) | draft/enviado/programado | 'draft' |

---

## 🔍 Verificar que todo funciona

Ejecuta esta query para ver la estructura actualizada:

```sql
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns
WHERE table_name = 'mensajes'
ORDER BY ordinal_position;
```

Deberías ver 10 columnas en total:
- id
- created_at
- titulo
- tipo
- contenido
- destinatario ✨ (NUEVO)
- asunto ✨ (NUEVO)
- prioridad ✨ (NUEVO)
- emoji ✨ (NUEVO)
- estado ✨ (NUEVO)

---

## ✨ ¡Listo!

Una vez ejecutado, la aplicación estará lista para usar:
- ✅ Crear mensajes con destinatario
- ✅ Asignar asuntos
- ✅ Configurar prioridad
- ✅ Seleccionar emojis
- ✅ Establecer estados

---

## 📝 Si tienes problemas:

1. **Error: "column ... already exists"**
   - Los campos ya existen ✅ (puedes ignorar este error)

2. **La tabla "mensajes" no existe**
   - Primero crea la tabla con:
   ```sql
   CREATE TABLE mensajes (
     id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
     titulo VARCHAR(255) NOT NULL,
     tipo VARCHAR(50),
     contenido TEXT,
     destinatario VARCHAR(255),
     asunto VARCHAR(255),
     prioridad VARCHAR(50) DEFAULT 'normal',
     emoji VARCHAR(50) DEFAULT '📬',
     estado VARCHAR(50) DEFAULT 'draft'
   );
   ```

3. **No puedo ver los cambios en la aplicación**
   - Recarga la página del navegador (Ctrl + F5)
   - Reinicia el servidor backend

---

**Fecha de actualización**: 18 de abril de 2026
**Versión**: 1.0
