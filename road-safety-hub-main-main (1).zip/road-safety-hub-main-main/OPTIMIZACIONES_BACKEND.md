# 🚀 OPTIMIZACIONES DE RENDIMIENTO BACKEND

## Implementadas para prevenir colapso con datos grandes

### 📋 Tabla de Contenido
1. [Paginación Automática](#paginación)
2. [Compresión Gzip](#compresión)
3. [Streaming de Datos](#streaming)
4. [Caché Inteligente](#caché)
5. [Límites de Seguridad](#límites)
6. [Monitoreo de Memoria](#monitoreo)

---

## 📄 Paginación

### API de Reportes con Paginación

**Endpoint:** `GET /api/reportes`

**Parámetros de Query:**
- `page` (número, default: 1) - Número de página
- `limit` (número, default: 100, max: 500) - Registros por página
- `all` (boolean) - Si es 'true', obtiene todos los registros (usar con precaución)

**Ejemplos:**
```bash
# Obtener primera página (100 registros)
GET /api/reportes

# Obtener página 2 con 50 registros
GET /api/reportes?page=2&limit=50

# Obtener todos los registros (sin paginación)
GET /api/reportes?all=true
```

**Respuesta con Paginación:**
```json
{
  "data": [...],
  "pagination": {
    "page": 1,
    "limit": 100,
    "total": 2500,
    "totalPages": 25,
    "hasMore": true
  }
}
```

**Headers de Respuesta:**
- `X-Total-Count`: Total de registros
- `X-Page`: Página actual
- `X-Per-Page`: Registros por página
- `X-Total-Pages`: Total de páginas

---

## 🗜️ Compresión

### Compresión Gzip Automática

Todas las respuestas son comprimidas automáticamente con gzip, reduciendo el tamaño en un 60-90%.

**Configuración:**
- Nivel de compresión: 6 (balance entre velocidad y tamaño)
- Automático para respuestas > 1KB

**Desactivar compresión:**
```javascript
// Agregar header en la request
headers: {
  'x-no-compression': '1'
}
```

---

## 📤 Streaming de Datos

### Exportar Eventos Grandes

Para datasets masivos que no caben en memoria, usa el endpoint de streaming:

**Endpoint:** `GET /api/export/eventos/stream`

**Parámetros:**
- `placa` - Filtrar por placa
- `fecha_desde` - Fecha inicio (YYYY-MM-DD)
- `fecha_hasta` - Fecha fin (YYYY-MM-DD)
- `tipo_evento` - Tipo: 'alta', 'media', 'baja', 'todos'

**Ejemplo:**
```javascript
// En el frontend
const response = await fetch(
  'http://localhost:5000/api/export/eventos/stream?placa=ABC123&fecha_desde=2026-01-01'
);
const data = await response.json();
```

**Características:**
- ✅ Procesa datos en batches de 500 registros
- ✅ No carga todo en memoria
- ✅ Perfecto para exportar 10,000+ eventos
- ✅ Incluye metadata con estadísticas

---

## 💾 Caché

### Sistema de Caché Inteligente

**Automático en:**
- `GET /api/reportes` - 5 minutos de caché
- Todas las consultas GET con mismo query

**Headers de Caché:**
- `X-Cache: HIT` - Respuesta desde caché
- `X-Cache: MISS` - Consulta nueva a base de datos

**Beneficios:**
- Reduce carga en base de datos
- Respuestas instantáneas para queries repetidas
- Limpieza automática cada 10 minutos

---

## 🛡️ Límites de Seguridad

### Protecciones Implementadas

1. **Límite de Payload JSON**
   - Máximo: 50MB por request/response
   - Previene desbordamiento de memoria

2. **Límite de Paginación**
   - Máximo: 500 registros por página
   - Error 400 si se excede

3. **Timeout de Requests**
   - Máximo: 5 minutos por request
   - Previene requests colgadas

4. **Validación de Respuesta**
   - Si respuesta > 50MB, retorna error 413
   - Sugerencia de usar paginación

**Error de Payload Grande:**
```json
{
  "error": "Payload demasiado grande",
  "message": "La respuesta (75.5MB) excede el límite de 50MB",
  "suggestion": "Usa paginación o filtros para reducir el tamaño de los datos",
  "params": {
    "page": "?page=1&limit=100",
    "filters": "Aplica filtros específicos"
  }
}
```

---

## 📊 Monitoreo de Memoria

### Estadísticas en Tiempo Real

**Endpoint:** `GET /api/health`

**Respuesta:**
```json
{
  "status": "ok",
  "uptime": 3600,
  "memory": {
    "heapUsed": "125.45MB",
    "heapTotal": "180.00MB",
    "rss": "220.30MB"
  },
  "timestamp": "2026-04-21T10:30:00.000Z"
}
```

**Headers en Respuestas:**
- `X-Memory-Usage` - Memoria usada actual
- `X-Response-Time` - Tiempo de respuesta en ms
- `X-Response-Size` - Tamaño de la respuesta

**Advertencias Automáticas:**
- ⚠️ Si memoria > 90% del heap
- ⚠️ Si request toma > 1 segundo
- ⚠️ Si respuesta > límite configurado

---

## 🎯 Estadísticas de Eventos

### Obtener Stats sin Cargar Datos

Para dashboards y resúmenes sin consumir memoria:

**Endpoint:** `GET /api/export/eventos/stats`

**Respuesta:**
```json
{
  "total": 12500,
  "por_placa": {
    "ABC123": 450,
    "DEF456": 380,
    ...
  },
  "velocidad_promedio": "95.34",
  "velocidad_maxima": 145,
  "fecha_primer_evento": "2026-01-01T...",
  "fecha_ultimo_evento": "2026-04-21T...",
  "distribucion_velocidades": {
    "baja": 3200,
    "media": 5800,
    "alta": 3500
  }
}
```

**Uso:**
- ✅ Ideal para KPIs del dashboard
- ✅ No carga datos completos
- ✅ Respuesta rápida y ligera

---

## 🔧 Utilidades de Rendimiento

### Funciones Disponibles

En `backend/utils/streamHelpers.js`:

```javascript
const { 
  arrayToStream,      // Convierte array a stream
  processBatches,     // Procesa en batches
  streamJsonResponse, // Stream de JSON
  withMemoryLimit,    // Ejecuta con límite de memoria
  SimpleCache         // Sistema de caché
} = require('./utils/streamHelpers');
```

### Ejemplo de Uso:

```javascript
// Procesar 50,000 eventos en batches
const result = await processBatches(
  eventos,
  async (batch) => {
    // Procesar cada batch de 1000
    return batch.map(transformEvento);
  },
  1000 // Tamaño del batch
);
```

---

## 📈 Recomendaciones

### Para Mejor Rendimiento:

1. **Usa Paginación**
   - Siempre especifica `limit` razonable
   - Evita `?all=true` a menos que sea necesario

2. **Aplica Filtros**
   - Filtra por placa, fechas específicas
   - Reduce el dataset antes de consultar

3. **Usa Streaming**
   - Para exportar > 5,000 eventos
   - Para generar reportes grandes

4. **Monitorea**
   - Revisa `/api/health` regularmente
   - Observa headers de rendimiento

5. **Caché**
   - Aprovecha el caché automático
   - Consultas repetidas son instantáneas

---

## 🚨 Troubleshooting

### "Error 413: Payload Too Large"
**Solución:** Usa paginación o filtros más específicos

### "Request timeout"
**Solución:** Reduce el tamaño del dataset o usa streaming

### "Memoria alta (90%+)"
**Solución:** Reinicia el servidor o reduce requests simultáneas

### "Cache no funciona"
**Solución:** Verifica que sea GET request con mismos parámetros

---

## 📝 Notas Técnicas

- **Compresión:** Ahorra 60-90% de bandwidth
- **Caché:** TTL de 5 minutos por defecto
- **Batches:** Tamaño óptimo es 500-1000 registros
- **Memoria:** Límite recomendado 100MB por operación
- **Timeout:** 5 minutos máximo por request

---

## ✅ Checklist de Optimización

- [x] Paginación implementada
- [x] Compresión gzip activa
- [x] Streaming para datos grandes
- [x] Caché en queries frecuentes
- [x] Límites de seguridad
- [x] Monitoreo de memoria
- [x] Headers informativos
- [x] Logging de operaciones lentas
- [x] Validación de payload
- [x] Endpoint de salud

---

**Última actualización:** 21 de Abril, 2026
**Versión:** 1.0.0
