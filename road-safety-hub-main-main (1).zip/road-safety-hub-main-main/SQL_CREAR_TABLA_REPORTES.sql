-- ===================================================================
-- SCRIPT PARA CREAR LA TABLA DE REPORTES EN SUPABASE
-- ===================================================================
-- Este script crea la tabla 'reportes' para guardar los informes
-- generados en la aplicación Road Safety Hub
-- ===================================================================

-- 1. Crear tabla de reportes guardados
CREATE TABLE IF NOT EXISTS reportes (
  id BIGSERIAL PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  nombre VARCHAR(255) NOT NULL,
  placa VARCHAR(50),
  fecha_desde DATE,
  fecha_hasta DATE,
  tipo_evento VARCHAR(50),
  total_eventos INTEGER DEFAULT 0,
  velocidad_promedio DECIMAL(10, 2),
  filtros_aplicados JSONB,
  usuario VARCHAR(255),
  empresa VARCHAR(255)
);

-- 2. Crear índices para búsquedas más rápidas
CREATE INDEX IF NOT EXISTS idx_reportes_created_at ON reportes(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reportes_nombre ON reportes(nombre);

-- 3. Habilitar RLS (Row Level Security)
ALTER TABLE reportes ENABLE ROW LEVEL SECURITY;

-- 4. Eliminar política anterior si existe
DROP POLICY IF EXISTS "Permitir todas las operaciones en reportes" ON reportes;

-- 5. Crear política para permitir todas las operaciones
CREATE POLICY "Permitir todas las operaciones en reportes" 
  ON reportes 
  FOR ALL 
  USING (true) 
  WITH CHECK (true);

-- ===================================================================
-- SCRIPT COMPLETADO
-- ===================================================================
-- La tabla 'reportes' está lista para ser usada
-- Columnas creadas:
--   - id: Identificador único
--   - created_at: Fecha de creación del reporte
--   - nombre: Nombre del reporte
--   - placa: Placa filtrada
--   - fecha_desde: Fecha inicial del filtro
--   - fecha_hasta: Fecha final del filtro
--   - tipo_evento: Tipo de evento filtrado
--   - total_eventos: Número total de eventos
--   - velocidad_promedio: Velocidad promedio de los eventos
--   - filtros_aplicados: JSON con todos los filtros
--   - usuario: Usuario que creó el reporte
--   - empresa: Empresa del usuario
-- ===================================================================
